-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 23 jan 2026 om 11:21
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodbank`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `data_breaches`
--

CREATE TABLE `data_breaches` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `breach_date` date NOT NULL,
  `discovery_date` date NOT NULL,
  `breach_type` enum('confidentiality','integrity','availability','mixed') NOT NULL,
  `personal_data_affected` text NOT NULL,
  `affected_data_subjects` int(11) DEFAULT NULL,
  `causes` text NOT NULL,
  `measures_taken` text NOT NULL,
  `notified_authority` enum('yes','no','in_progress') DEFAULT 'no',
  `notification_date` date DEFAULT NULL,
  `notified_affected_persons` enum('yes','no','in_progress') DEFAULT 'no',
  `risk_level` enum('low','medium','high') NOT NULL,
  `status` enum('open','investigating','contained','resolved','closed') DEFAULT 'open',
  `reported_by` int(11) NOT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `data_breaches`
--

INSERT INTO `data_breaches` (`id`, `title`, `description`, `breach_date`, `discovery_date`, `breach_type`, `personal_data_affected`, `affected_data_subjects`, `causes`, `measures_taken`, `notified_authority`, `notification_date`, `notified_affected_persons`, `risk_level`, `status`, `reported_by`, `assigned_to`, `created_at`, `updated_at`) VALUES
(1, 'test', 'test', '2026-01-23', '2026-01-21', 'confidentiality', 'test', 1000, 'test', 'test', 'in_progress', '2026-01-22', 'no', 'low', 'open', 1, NULL, '2026-01-23 09:17:17', '2026-01-23 09:17:17');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `dpia_registrations`
--

CREATE TABLE `dpia_registrations` (
  `id` int(11) NOT NULL,
  `record_id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `necessity_proportionality` text DEFAULT NULL,
  `mitigation_measures` text DEFAULT NULL,
  `residual_risk` text DEFAULT NULL,
  `overall_risk_level` enum('low','medium','high') DEFAULT 'medium',
  `status` enum('open','closed','pending') DEFAULT 'pending',
  `registered_by` int(11) NOT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `gdpr_register`
--

CREATE TABLE `gdpr_register` (
  `id` int(11) NOT NULL,
  `has_processing_agreement_with_third_party` enum('Yes','No') DEFAULT 'No',
  `we_are_processor` enum('Yes','No') DEFAULT 'No',
  `processing_activity` varchar(500) NOT NULL,
  `name_data_controller` varchar(255) DEFAULT NULL,
  `contact_data_controller` varchar(255) DEFAULT NULL,
  `name_joint_data_controller` varchar(255) DEFAULT NULL,
  `contact_joint_data_controller` varchar(255) DEFAULT NULL,
  `name_representative` varchar(255) DEFAULT NULL,
  `contact_representative` varchar(255) DEFAULT NULL,
  `name_dpo` varchar(255) DEFAULT NULL,
  `contact_dpo` varchar(255) DEFAULT NULL,
  `purpose_of_processing` text NOT NULL,
  `legal_basis` varchar(300) NOT NULL,
  `categories_personal_data` text NOT NULL,
  `categories_data_subjects` varchar(300) NOT NULL,
  `categories_recipients` varchar(300) NOT NULL,
  `retention_periods` varchar(200) NOT NULL,
  `risk_level` enum('low','medium','high') NOT NULL,
  `technical_measures` text NOT NULL,
  `organizational_measures` text NOT NULL,
  `dpia_required` enum('yes','no') NOT NULL,
  `is_international_data_transfers` enum('yes','no','unknown') DEFAULT 'unknown',
  `to_country` enum('none','EU_EEA_Switzerland','UK','Argentina','Canada','Israel','Japan','New_Zealand','Republic_of_Korea','Uruguay','USA','Australia','Brazil','India','Mexico','Singapore','South_Africa','Other_third_country','Multiple_countries') DEFAULT 'none',
  `safeguards` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `review_due_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `department` enum('administration','distribution','volunteers','donations','marketing','other') DEFAULT 'other',
  `status` enum('active','inactive','archived','review_needed') DEFAULT 'active',
  `legitimate_interest_description` text DEFAULT NULL,
  `dpia_status` enum('open','in_progress','completed','not_required') DEFAULT 'not_required'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `gdpr_register`
--

INSERT INTO `gdpr_register` (`id`, `has_processing_agreement_with_third_party`, `we_are_processor`, `processing_activity`, `name_data_controller`, `contact_data_controller`, `name_joint_data_controller`, `contact_joint_data_controller`, `name_representative`, `contact_representative`, `name_dpo`, `contact_dpo`, `purpose_of_processing`, `legal_basis`, `categories_personal_data`, `categories_data_subjects`, `categories_recipients`, `retention_periods`, `risk_level`, `technical_measures`, `organizational_measures`, `dpia_required`, `is_international_data_transfers`, `to_country`, `safeguards`, `created_at`, `updated_at`, `review_due_date`, `created_by`, `updated_by`, `department`, `status`, `legitimate_interest_description`, `dpia_status`) VALUES
(1, 'Yes', 'No', 'Activiteit 2', 'OXdrTjJmTjA5UXdUQTZBRlc1WVNXZz09Ojpb9YyoXl9doL4UrrLoD2Qn', 'b2I3L25MbHZJL0RlR3p4Nk1TcytxQT09OjrcjfjJ7Y1Rn8GLktu95T2r', 'Z2ZXMkhPa3VzK0tveUk5R29BNTlOdz09OjqXecz8IgZQclR5ScCVFXdU', 'RzluZy90V2ZXOUtMeURYd0VhS3pLZz09Ojo62I27/x1mt84kxI+JCYK2', 'TkUwL0djeDRmNGhWMkN1ZGlYdnJYUT09OjpS70fXqJs/MPz5DuXasLIj', 'aXZ5YWgwREw3czEyLzloczl4WGNXQT09Ojrum9HbH91WkYmq5vZz48d6', 'Vi8rU2JmdUc1NEtqdkxWOGhYbjZTQT09Ojr+Stpl8NIUq/PE6N4VIbeb', 'SU5aKzhUMHNpanR6SnBWS0xoUlpYZz09OjpM/4y0/2MyCmi+4HvgHLtY', '1', 'consent', '1', '1', '1', '1', 'low', '1', '1', 'yes', 'no', 'Other_third_country', '1', '2026-01-23 10:08:21', '2026-01-23 10:20:00', '2027-01-23', 1, 1, 'distribution', 'active', '', 'in_progress');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `implementation_notes`
--

CREATE TABLE `implementation_notes` (
  `id` int(11) NOT NULL,
  `measure_id` int(11) NOT NULL,
  `note_text` text NOT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `security_measures`
--

CREATE TABLE `security_measures` (
  `id` int(11) NOT NULL,
  `gdpr_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `system_changes`
--

CREATE TABLE `system_changes` (
  `id` int(11) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `record_id` int(11) NOT NULL,
  `action` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `old_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_data`)),
  `new_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_data`)),
  `changed_fields` text DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `changed_by` int(11) NOT NULL,
  `user_ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `system_changes`
--

INSERT INTO `system_changes` (`id`, `table_name`, `record_id`, `action`, `old_data`, `new_data`, `changed_fields`, `changed_at`, `changed_by`, `user_ip`, `user_agent`) VALUES
(1, 'data_breaches', 1, 'INSERT', NULL, '{\"title\":\"test\",\"description\":\"test\",\"breach_date\":\"2026-01-23\",\"discovery_date\":\"2026-01-21\",\"breach_type\":\"confidentiality\",\"personal_data_affected\":\"test\",\"affected_data_subjects\":1000,\"causes\":\"test\",\"measures_taken\":\"test\",\"notified_authority\":\"in_progress\",\"notification_date\":\"2026-01-22\",\"notified_affected_persons\":\"no\",\"risk_level\":\"low\",\"status\":\"open\",\"assigned_to\":null,\"reported_by\":\"1\"}', 'all_fields', '2026-01-23 09:17:17', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'),
(2, 'third_parties', 1, 'INSERT', NULL, '{\"company_name\":\"iRestore\",\"contact_person\":\"M\",\"email\":\"matijn@gmail.com\",\"phone\":\"06\",\"address\":\"test\",\"service_provided\":\"test\",\"processing_agreement_signed\":\"in_progress\",\"agreement_date\":\"2026-01-22\",\"agreement_expiry_date\":\"2026-01-22\",\"compliance_status\":\"review_needed\",\"created_by\":\"1\"}', 'all_fields', '2026-01-23 09:17:43', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'),
(3, 'system_users', 2, 'INSERT', NULL, '{\"username\":\"test2\",\"full_name\":\"test2\",\"email\":\"test2@test.nl\",\"role\":\"viewer\",\"is_active\":1,\"password\":\"$2y$10$b57Jg02cAvUd1J5cjeLH4OJviNWabYEgAL5BaqdgS\\/as501MPKLEe\"}', 'all_fields', '2026-01-23 09:43:04', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'),
(4, 'gdpr_register', 1, 'INSERT', NULL, '{\"processing_activity\":\"test\",\"department\":\"distribution\",\"status\":\"active\",\"has_processing_agreement_with_third_party\":\"yes\",\"we_are_processor\":\"no\",\"name_data_controller\":\"Matijn\",\"contact_data_controller\":\"van der Schans\",\"purpose_of_processing\":\"1\",\"legal_basis\":\"consent\",\"legitimate_interest_description\":\"\",\"categories_personal_data\":\"1\",\"categories_data_subjects\":\"1\",\"categories_recipients\":\"1\",\"retention_periods\":\"1\",\"risk_level\":\"low\",\"technical_measures\":\"1\",\"organizational_measures\":\"1\",\"dpia_required\":\"yes\",\"dpia_status\":\"in_progress\",\"is_international_data_transfers\":\"no\",\"to_country\":\"Other_third_country\",\"safeguards\":\"1\",\"review_due_date\":\"2027-01-23\",\"created_by\":\"1\",\"updated_by\":\"1\"}', 'processing_activity, department, status, has_processing_agreement_with_third_party, we_are_processor, name_data_controller, contact_data_controller, purpose_of_processing, legal_basis, legitimate_interest_description, categories_personal_data, categories_data_subjects, categories_recipients, retention_periods, risk_level, technical_measures, organizational_measures, dpia_required, dpia_status, is_international_data_transfers, to_country, safeguards, review_due_date, created_by, updated_by', '2026-01-23 10:08:21', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'),
(5, 'gdpr_register', 1, 'UPDATE', '{\"id\":1,\"has_processing_agreement_with_third_party\":\"Yes\",\"we_are_processor\":\"No\",\"processing_activity\":\"test\",\"name_data_controller\":\"Matijn\",\"contact_data_controller\":\"van der Schans\",\"name_joint_data_controller\":null,\"contact_joint_data_controller\":null,\"name_representative\":null,\"contact_representative\":null,\"name_dpo\":null,\"contact_dpo\":null,\"purpose_of_processing\":\"1\",\"legal_basis\":\"consent\",\"categories_personal_data\":\"1\",\"categories_data_subjects\":\"1\",\"categories_recipients\":\"1\",\"retention_periods\":\"1\",\"risk_level\":\"low\",\"technical_measures\":\"1\",\"organizational_measures\":\"1\",\"dpia_required\":\"yes\",\"is_international_data_transfers\":\"no\",\"to_country\":\"Other_third_country\",\"safeguards\":\"1\",\"created_at\":\"2026-01-23 11:08:21\",\"updated_at\":\"2026-01-23 11:08:21\",\"review_due_date\":\"2027-01-23\",\"created_by\":1,\"updated_by\":1,\"department\":\"distribution\",\"status\":\"active\",\"legitimate_interest_description\":\"\",\"dpia_status\":\"in_progress\"}', '{\"processing_activity\":\"Activiteit 2\",\"department\":\"distribution\",\"status\":\"active\",\"has_processing_agreement_with_third_party\":\"yes\",\"we_are_processor\":\"no\",\"name_data_controller\":\"Matijn\",\"contact_data_controller\":\"van der Schans\",\"name_joint_data_controller\":\"Evelien\",\"contact_joint_data_controller\":\"van der Schans\",\"name_representative\":\"Lance\",\"contact_representative\":\"van der Schans\",\"name_dpo\":\"Alec\",\"contact_dpo\":\"van der Schans\",\"purpose_of_processing\":\"1\",\"legal_basis\":\"consent\",\"legitimate_interest_description\":\"\",\"categories_personal_data\":\"1\",\"categories_data_subjects\":\"1\",\"categories_recipients\":\"1\",\"retention_periods\":\"1\",\"risk_level\":\"low\",\"technical_measures\":\"1\",\"organizational_measures\":\"1\",\"dpia_required\":\"yes\",\"dpia_status\":\"in_progress\",\"is_international_data_transfers\":\"no\",\"to_country\":\"Other_third_country\",\"safeguards\":\"1\",\"review_due_date\":\"2027-01-23\"}', 'id, has_processing_agreement_with_third_party, we_are_processor, processing_activity, name_joint_data_controller, contact_joint_data_controller, name_representative, contact_representative, name_dpo, contact_dpo, created_at, updated_at, created_by, updated_by', '2026-01-23 10:20:00', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `system_users`
--

CREATE TABLE `system_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('admin','editor','viewer') DEFAULT 'viewer',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `system_users`
--

INSERT INTO `system_users` (`id`, `username`, `password`, `email`, `full_name`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$L4V/HpfagZBAOmM4pLW0MusSocoFfULLYVvNr/eYFVsmU82GqUqNG', 'admin@foodbank-almere.nl', 'System Administrator', 'admin', 1, NULL, '2026-01-23 08:42:06', '2026-01-23 08:42:06'),
(2, 'test2', '$2y$10$b57Jg02cAvUd1J5cjeLH4OJviNWabYEgAL5BaqdgS/as501MPKLEe', 'test2@test.nl', 'test2', 'viewer', 1, NULL, '2026-01-23 09:43:04', '2026-01-23 09:43:04');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `third_parties`
--

CREATE TABLE `third_parties` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `service_provided` text NOT NULL,
  `processing_agreement_signed` enum('yes','no','in_progress') DEFAULT 'no',
  `agreement_date` date DEFAULT NULL,
  `agreement_expiry_date` date DEFAULT NULL,
  `compliance_status` enum('compliant','non_compliant','review_needed') DEFAULT 'review_needed',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `third_parties`
--

INSERT INTO `third_parties` (`id`, `company_name`, `contact_person`, `email`, `phone`, `address`, `service_provided`, `processing_agreement_signed`, `agreement_date`, `agreement_expiry_date`, `compliance_status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'iRestore', 'M', 'matijn@gmail.com', '06', 'test', 'test', 'in_progress', '2026-01-22', '2026-01-22', 'review_needed', 1, '2026-01-23 09:17:43', '2026-01-23 09:17:43');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `data_breaches`
--
ALTER TABLE `data_breaches`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `dpia_registrations`
--
ALTER TABLE `dpia_registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_record_dpia` (`record_id`),
  ADD KEY `registered_by` (`registered_by`);

--
-- Indexen voor tabel `gdpr_register`
--
ALTER TABLE `gdpr_register`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_risk_level` (`risk_level`),
  ADD KEY `idx_dpia_required` (`dpia_required`),
  ADD KEY `idx_international_transfers` (`is_international_data_transfers`);

--
-- Indexen voor tabel `implementation_notes`
--
ALTER TABLE `implementation_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `measure_id` (`measure_id`);

--
-- Indexen voor tabel `security_measures`
--
ALTER TABLE `security_measures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gdpr_id` (`gdpr_id`);

--
-- Indexen voor tabel `system_changes`
--
ALTER TABLE `system_changes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `changed_by` (`changed_by`);

--
-- Indexen voor tabel `system_users`
--
ALTER TABLE `system_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexen voor tabel `third_parties`
--
ALTER TABLE `third_parties`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `data_breaches`
--
ALTER TABLE `data_breaches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `dpia_registrations`
--
ALTER TABLE `dpia_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `gdpr_register`
--
ALTER TABLE `gdpr_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `implementation_notes`
--
ALTER TABLE `implementation_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `security_measures`
--
ALTER TABLE `security_measures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `system_changes`
--
ALTER TABLE `system_changes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `system_users`
--
ALTER TABLE `system_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `third_parties`
--
ALTER TABLE `third_parties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `dpia_registrations`
--
ALTER TABLE `dpia_registrations`
  ADD CONSTRAINT `dpia_registrations_ibfk_1` FOREIGN KEY (`record_id`) REFERENCES `gdpr_register` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `dpia_registrations_ibfk_2` FOREIGN KEY (`registered_by`) REFERENCES `system_users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `implementation_notes`
--
ALTER TABLE `implementation_notes`
  ADD CONSTRAINT `implementation_notes_ibfk_1` FOREIGN KEY (`measure_id`) REFERENCES `security_measures` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `security_measures`
--
ALTER TABLE `security_measures`
  ADD CONSTRAINT `security_measures_ibfk_1` FOREIGN KEY (`gdpr_id`) REFERENCES `gdpr_register` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `system_changes`
--
ALTER TABLE `system_changes`
  ADD CONSTRAINT `system_changes_ibfk_1` FOREIGN KEY (`changed_by`) REFERENCES `system_users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
