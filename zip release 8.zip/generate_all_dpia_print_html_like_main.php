<?php
// standalone_dpia_report.php
// This file can run independently without the main system

// ============================================
// CONFIGURATION
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Database Configuration - UPDATE THESE FOR YOUR ENVIRONMENT
$db_config = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'foodbank',
    'charset' => 'utf8mb4'
];

// GDPR Options
$gdpr_options = [
    'departments' => [
        'administration' => 'Administration',
        'distribution' => 'Food Distribution',
        'volunteers' => 'Volunteer Management',
        'donations' => 'Donations & Funding',
        'marketing' => 'Marketing & Communication',
        'other' => 'Other'
    ],
    'dpia_statuses' => [
        'draft' => 'Draft',
        'in_progress' => 'In Progress',
        'under_review' => 'Under Review',
        'approved' => 'Approved',
        'rejected' => 'Rejected',
        'implemented' => 'Implemented',
        'not_required' => 'Not Required'
    ]
];

// DPIA Options
$dpia_options = [
    'risk_origins' => [
        'new_technology' => 'New technology/system deployment',
        'large_scale' => 'Large-scale processing',
        'sensitive_data' => 'Processing sensitive data',
        'systematic_monitoring' => 'Systematic monitoring of publicly accessible areas',
        'combination_datasets' => 'Combination of datasets from different sources',
        'vulnerable_groups' => 'Processing data of vulnerable groups',
        'other' => 'Other high-risk processing'
    ],
    'compliance_checklist' => [
        'privacy_by_design' => 'Privacy by design and default implemented',
        'data_minimization' => 'Data minimization principles applied',
        'purpose_limitation' => 'Purpose limitation respected',
        'storage_limitation' => 'Storage limitation implemented',
        'security_measures' => 'Appropriate security measures in place',
        'data_subject_rights' => 'Data subject rights procedures established',
        'dpo_consultation' => 'DPO consulted during design phase',
        'risk_assessment' => 'Risk assessment completed',
        'transparency' => 'Transparency requirements met',
        'consent_management' => 'Consent management system implemented'
    ],
    'risk_assessment_matrix' => [
        'likelihood' => [
            'rare' => 'Rare (once in several years)',
            'unlikely' => 'Unlikely (once per year)',
            'possible' => 'Possible (several times per year)',
            'likely' => 'Likely (monthly)',
            'certain' => 'Certain (weekly or more)'
        ],
        'impact' => [
            'insignificant' => 'Insignificant',
            'minor' => 'Minor',
            'moderate' => 'Moderate',
            'major' => 'Major',
            'catastrophic' => 'Catastrophic'
        ]
    ],
    'management_approval' => [
        'pending' => 'Pending Approval',
        'approved' => 'Approved',
        'rejected' => 'Rejected',
        'revised' => 'Needs Revision'
    ]
];

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Create database connection
 */
function create_db_connection($db_config) {
    try {
        $connection = new mysqli(
            $db_config['host'],
            $db_config['username'],
            $db_config['password'],
            $db_config['database']
        );
        
        if ($connection->connect_error) {
            throw new Exception("Database connection failed: " . $connection->connect_error);
        }
        
        $connection->set_charset($db_config['charset']);
        return $connection;
        
    } catch (Exception $e) {
        throw new Exception("Database connection error: " . $e->getMessage());
    }
}

/**
 * Format date for display
 */
function format_date($date, $format = 'd-m-Y H:i') {
    if (empty($date) || $date == '0000-00-00 00:00:00' || $date == '0000-00-00') {
        return '-';
    }
    return date($format, strtotime($date));
}

/**
 * Get risk level badge HTML
 */
function get_risk_badge($risk_level) {
    $colors = [
        'low' => 'success',
        'medium' => 'warning',
        'high' => 'danger'
    ];
    
    $color = $colors[$risk_level] ?? 'secondary';
    $text = ucfirst($risk_level);
    
    $color_map = [
        'success' => ['bg' => '#d4edda', 'text' => '#155724'],
        'warning' => ['bg' => '#fff3cd', 'text' => '#856404'],
        'danger' => ['bg' => '#f8d7da', 'text' => '#721c24'],
        'secondary' => ['bg' => '#e2e3e5', 'text' => '#383d41']
    ];
    
    $colors = $color_map[$color] ?? $color_map['secondary'];
    
    return "<span style='display:inline-block;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:bold;background-color:{$colors['bg']};color:{$colors['text']};'>{$text}</span>";
}

/**
 * Get status badge HTML
 */
function get_status_badge($status) {
    if (empty($status)) return '';
    
    $colors = [
        'draft' => 'secondary',
        'in_progress' => 'primary',
        'under_review' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'implemented' => 'info'
    ];
    
    $color = $colors[$status] ?? 'secondary';
    $display_status = str_replace('_', ' ', $status);
    
    $color_map = [
        'success' => ['bg' => '#d4edda', 'text' => '#155724'],
        'warning' => ['bg' => '#fff3cd', 'text' => '#856404'],
        'danger' => ['bg' => '#f8d7da', 'text' => '#721c24'],
        'info' => ['bg' => '#d1ecf1', 'text' => '#0c5460'],
        'primary' => ['bg' => '#cce5ff', 'text' => '#004085'],
        'secondary' => ['bg' => '#e2e3e5', 'text' => '#383d41']
    ];
    
    $colors = $color_map[$color] ?? $color_map['secondary'];
    
    return "<span style='display:inline-block;padding:2px 8px;border-radius:3px;background-color:{$colors['bg']};color:{$colors['text']};font-size:11px;'>" . ucfirst($display_status) . "</span>";
}

/**
 * Get approval badge HTML
 */
function get_approval_badge($approval_status) {
    if (empty($approval_status)) return '';
    
    $colors = [
        'pending' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'revised' => 'info'
    ];
    
    $color = $colors[$approval_status] ?? 'secondary';
    $text = str_replace('_', ' ', $approval_status);
    
    $color_map = [
        'success' => ['bg' => '#d4edda', 'text' => '#155724'],
        'warning' => ['bg' => '#fff3cd', 'text' => '#856404'],
        'danger' => ['bg' => '#f8d7da', 'text' => '#721c24'],
        'info' => ['bg' => '#d1ecf1', 'text' => '#0c5460']
    ];
    
    $colors = $color_map[$color] ?? $color_map['secondary'];
    
    return "<span style='display:inline-block;padding:2px 8px;border-radius:3px;background-color:{$colors['bg']};color:{$colors['text']};font-size:11px;font-weight:bold;'>" . ucfirst($text) . "</span>";
}

/**
 * Get DPIA statistics
 */
function get_dpia_statistics($conn) {
    $stats = [
        'total' => 0,
        'by_status' => [],
        'by_approval' => [],
        'by_risk' => []
    ];
    
    // Total DPIAs
    $result = $conn->query("SELECT COUNT(*) as total FROM dpia_registrations");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['total'] = $row['total'];
    }
    
    // By status
    $result = $conn->query("
        SELECT status, COUNT(*) as count 
        FROM dpia_registrations 
        GROUP BY status
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_status'][$row['status']] = $row['count'];
        }
    }
    
    // By approval status
    $result = $conn->query("
        SELECT management_approval, COUNT(*) as count 
        FROM dpia_registrations 
        GROUP BY management_approval
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_approval'][$row['management_approval']] = $row['count'];
        }
    }
    
    // By risk level
    $result = $conn->query("
        SELECT overall_risk_level, COUNT(*) as count 
        FROM dpia_registrations 
        GROUP BY overall_risk_level
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_risk'][$row['overall_risk_level']] = $row['count'];
        }
    }
    
    return $stats;
}

/**
 * Generate risk matrix HTML for report
 */
function generate_risk_matrix_html($risk_matrix, $dpia_options) {
    if (empty($risk_matrix) || !is_array($risk_matrix)) {
        return '<p>No risk assessment matrix data available.</p>';
    }
    
    $html = '<div style="margin: 15px 0; overflow-x: auto;">';
    $html .= '<table style="border-collapse: collapse; width: 100%; font-size: 10px;">';
    $html .= '<thead style="background-color: #f8f9fa;">';
    $html .= '<tr><th style="border: 1px solid #dee2e6; padding: 6px;">Impact/Likelihood</th>';
    
    // Header row (likelihood)
    foreach ($dpia_options['risk_assessment_matrix']['likelihood'] as $likelihood_label) {
        $html .= '<th style="border: 1px solid #dee2e6; padding: 6px; text-align: center;">' . $likelihood_label . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    
    // Body rows (impact)
    foreach ($dpia_options['risk_assessment_matrix']['impact'] as $impact_key => $impact_label) {
        $html .= '<tr>';
        $html .= '<th style="border: 1px solid #dee2e6; padding: 6px; background-color: #f8f9fa;">' . $impact_label . '</th>';
        
        foreach ($dpia_options['risk_assessment_matrix']['likelihood'] as $likelihood_key => $likelihood_label) {
            $is_selected = isset($risk_matrix[$impact_key][$likelihood_key]) && $risk_matrix[$impact_key][$likelihood_key];
            $impact_index = array_search($impact_key, array_keys($dpia_options['risk_assessment_matrix']['impact']));
            $likelihood_index = array_search($likelihood_key, array_keys($dpia_options['risk_assessment_matrix']['likelihood']));
            $total_index = $impact_index + $likelihood_index;
            
            // Determine risk level color
            if ($total_index >= 6) {
                $bg_color = '#f8d7da'; // High risk
            } elseif ($total_index >= 3) {
                $bg_color = '#fff3cd'; // Medium risk
            } else {
                $bg_color = '#d4edda'; // Low risk
            }
            
            $border_style = $is_selected ? '2px solid #000' : '1px solid #dee2e6';
            
            $html .= '<td style="border: ' . $border_style . '; padding: 8px; text-align: center; background-color: ' . $bg_color . ';">';
            if ($is_selected) {
                $html .= '<strong style="color: #000;">✓</strong>';
            }
            $html .= '</td>';
        }
        
        $html .= '</tr>';
    }
    
    $html .= '</tbody></table>';
    
    // Legend
    $html .= '<div style="margin-top: 10px; font-size: 9px;">';
    $html .= '<span style="display: inline-block; margin-right: 10px;">';
    $html .= '<span style="display: inline-block; width: 12px; height: 12px; background-color: #d4edda; margin-right: 4px;"></span> Low Risk';
    $html .= '</span>';
    $html .= '<span style="display: inline-block; margin-right: 10px;">';
    $html .= '<span style="display: inline-block; width: 12px; height: 12px; background-color: #fff3cd; margin-right: 4px;"></span> Medium Risk';
    $html .= '</span>';
    $html .= '<span style="display: inline-block;">';
    $html .= '<span style="display: inline-block; width: 12px; height: 12px; background-color: #f8d7da; margin-right: 4px;"></span> High Risk';
    $html .= '</span>';
    $html .= '</div>';
    
    $html .= '</div>';
    
    return $html;
}

/**
 * Calculate risk statistics from matrix
 */
function calculate_risk_statistics($risk_matrix, $dpia_options) {
    if (empty($risk_matrix) || !is_array($risk_matrix)) {
        return ['high' => 0, 'medium' => 0, 'low' => 0, 'total' => 0];
    }
    
    $high_risk_count = 0;
    $medium_risk_count = 0;
    $low_risk_count = 0;
    $total_count = 0;
    
    foreach ($risk_matrix as $impact_key => $likelihood_data) {
        if (!is_array($likelihood_data)) continue;
        
        foreach ($likelihood_data as $likelihood_key => $selected) {
            if ($selected) {
                $impact_index = array_search($impact_key, array_keys($dpia_options['risk_assessment_matrix']['impact']));
                $likelihood_index = array_search($likelihood_key, array_keys($dpia_options['risk_assessment_matrix']['likelihood']));
                
                if ($impact_index !== false && $likelihood_index !== false) {
                    $total_index = $impact_index + $likelihood_index;
                    
                    if ($total_index >= 6) {
                        $high_risk_count++;
                    } elseif ($total_index >= 3) {
                        $medium_risk_count++;
                    } else {
                        $low_risk_count++;
                    }
                    $total_count++;
                }
            }
        }
    }
    
    return [
        'high' => $high_risk_count,
        'medium' => $medium_risk_count,
        'low' => $low_risk_count,
        'total' => $total_count
    ];
}

/**
 * Count risk cells in JSON string (MariaDB compatible)
 */
function count_risk_cells_in_json($json_string) {
    if (empty($json_string) || $json_string === 'null') {
        return 0;
    }
    
    try {
        $data = json_decode($json_string, true);
        if (!is_array($data)) {
            return 0;
        }
        
        $count = 0;
        foreach ($data as $impact_level) {
            if (is_array($impact_level)) {
                foreach ($impact_level as $selected) {
                    if ($selected) {
                        $count++;
                    }
                }
            }
        }
        
        return $count;
    } catch (Exception $e) {
        return 0;
    }
}

// ============================================
// MAIN REPORT FUNCTION
// ============================================

/**
 * Generate printable summary of all DPIAs
 */
function generate_all_dpia_print_html($db_config, $gdpr_options, $dpia_options) {
    try {
        // Create database connection
        $conn = create_db_connection($db_config);
        
        // Get all DPIAs with related activity info
        $result = $conn->query("
            SELECT d.*, 
                   g.processing_activity, g.department, g.risk_level as activity_risk_level,
                   u.full_name as registered_by_name, 
                   a.full_name as approved_by_name,
                   COUNT(*) OVER() as total_count
            FROM dpia_registrations d
            LEFT JOIN gdpr_register g ON d.record_id = g.id
            LEFT JOIN system_users u ON d.registered_by = u.id
            LEFT JOIN system_users a ON d.approved_by = a.id
            ORDER BY d.registered_at DESC
        ");
        
        if (!$result) {
            throw new Exception("Failed to fetch DPIAs from database: " . $conn->error);
        }
        
        $html = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Data Protection Impact Assessments (DPIAs) Summary - Food Bank Almere</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; font-size: 12px; }
                .header { text-align: center; margin-bottom: 30px; }
                .header h1 { color: #2c3e50; margin-bottom: 5px; }
                .header .subtitle { color: #666; margin-bottom: 20px; }
                .header .print-date { color: #999; font-size: 11px; }
                .dpia { margin-bottom: 25px; border: 1px solid #ddd; padding: 15px; page-break-inside: avoid; }
                .dpia-header { background-color: #f8f9fa; padding: 10px; margin: -15px -15px 15px -15px; border-bottom: 1px solid #ddd; }
                .dpia-id { font-weight: bold; color: #2c3e50; }
                .section { margin-bottom: 15px; }
                .section-title { font-weight: bold; color: #2c3e50; border-bottom: 1px solid #eee; padding-bottom: 5px; margin-bottom: 8px; }
                .field { margin-bottom: 5px; }
                .field-label { font-weight: bold; display: inline-block; width: 200px; }
                .field-value { display: inline-block; }
                .page-break { page-break-before: always; }
                .footer { margin-top: 30px; text-align: center; color: #999; font-size: 10px; border-top: 1px solid #eee; padding-top: 10px; }
                @media print {
                    .page-break { page-break-before: always; }
                    .no-print { display: none; }
                }
                .summary-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                .summary-table th { background-color: #f8f9fa; text-align: left; padding: 8px; border: 1px solid #ddd; }
                .summary-table td { padding: 8px; border: 1px solid #ddd; }
                .status-header { background-color: #2c3e50; color: white; padding: 10px; margin: 20px 0 10px 0; border-radius: 3px; }
                .compliance-checklist { margin: 10px 0; padding-left: 20px; }
                .compliance-item { margin-bottom: 3px; position: relative; }
                .compliance-item:before { content: "✓"; position: absolute; left: -15px; color: #28a745; }
                .statistics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
                .stat-card { background-color: #f8f9fa; padding: 15px; border-radius: 5px; border-left: 4px solid #007bff; }
                .stat-value { font-size: 24px; font-weight: bold; color: #2c3e50; }
                .stat-label { font-size: 11px; color: #6c757d; }
                .department-badge { display: inline-block; padding: 2px 6px; border-radius: 3px; font-size: 10px; background-color: #e9ecef; color: #495057; margin-left: 5px; }
                .risk-matrix-container { margin: 10px 0; }
                .risk-cell-stat { display: inline-block; padding: 5px 10px; margin: 2px; border-radius: 3px; font-size: 10px; }
                .risk-stat-high { background-color: #f8d7da; color: #721c24; }
                .risk-stat-medium { background-color: #fff3cd; color: #856404; }
                .risk-stat-low { background-color: #d4edda; color: #155724; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Food Bank Almere</h1>
                <div class="subtitle">Data Protection Impact Assessments (DPIAs) - Complete Summary</div>
                <div class="print-date">Printed: ' . date('d-m-Y H:i') . '</div>
            </div>';
        
        // Get statistics
        $dpia_stats = get_dpia_statistics($conn);
        $total_dpias = $dpia_stats['total'];
        
        $html .= '
            <div class="statistics-grid">
                <div class="stat-card">
                    <div class="stat-value">' . $total_dpias . '</div>
                    <div class="stat-label">Total DPIAs</div>
                </div>
                <div class="stat-card" style="border-left-color: #28a745;">
                    <div class="stat-value">' . ($dpia_stats['by_status']['approved'] ?? 0) . '</div>
                    <div class="stat-label">Approved DPIAs</div>
                </div>
                <div class="stat-card" style="border-left-color: #ffc107;">
                    <div class="stat-value">' . ($dpia_stats['by_approval']['pending'] ?? 0) . '</div>
                    <div class="stat-label">Pending Approval</div>
                </div>
                <div class="stat-card" style="border-left-color: #dc3545;">
                    <div class="stat-value">' . ($dpia_stats['by_risk']['high'] ?? 0) . '</div>
                    <div class="stat-label">High Risk DPIAs</div>
                </div>
            </div>';
        
        $dpia_count = 0;
        $current_status = '';
        
        while ($row = $result->fetch_assoc()) {
            // Decode JSON fields with null checks
            $compliance_checklist = !empty($row['compliance_checklist']) ? json_decode($row['compliance_checklist'], true) : [];
            $risk_assessment_matrix = !empty($row['risk_assessment_matrix']) ? json_decode($row['risk_assessment_matrix'], true) : [];
            
            // Check if status changed
            if ($row['status'] != $current_status) {
                if ($current_status != '') {
                    $html .= '</div>';
                }
                $current_status = $row['status'];
                $status_name = isset($gdpr_options['dpia_statuses'][$current_status]) ? 
                    $gdpr_options['dpia_statuses'][$current_status] : 
                    ucfirst(str_replace('_', ' ', $current_status));
                $html .= '<div class="status-header">' . htmlspecialchars($status_name) . ' DPIAs</div>';
            }
            
            $dpia_count++;
            
            $html .= '
            <div class="dpia">
                <div class="dpia-header">
                    <span class="dpia-id">DPIA #' . $row['id'] . '</span> - 
                    <strong>' . htmlspecialchars($row['title']) . '</strong>
                    ' . get_risk_badge($row['overall_risk_level']) . '
                </div>
                
                <div class="section">
                    <div class="section-title">Basic Information</div>
                    <div class="field">
                        <span class="field-label">Related Activity:</span>
                        <span class="field-value">' . 
                            (isset($row['processing_activity']) ? htmlspecialchars($row['processing_activity']) : 'N/A') . ' 
                        <span class="department-badge">' . 
                            (isset($row['department']) && isset($gdpr_options['departments'][$row['department']]) ? 
                             htmlspecialchars($gdpr_options['departments'][$row['department']]) : 
                             (isset($row['department']) ? htmlspecialchars($row['department']) : 'Unknown')) . 
                        '</span></span>
                    </div>
                    <div class="field">
                        <span class="field-label">DPIA Status:</span>
                        <span class="field-value">' . get_status_badge($row['status'] ?? '') . '</span>
                    </div>
                    <div class="field">
                        <span class="field-label">Management Approval:</span>
                        <span class="field-value">' . get_approval_badge($row['management_approval'] ?? '') . '</span>
                    </div>
                    <div class="field">
                        <span class="field-label">Registered By:</span>
                        <span class="field-value">' . 
                            (isset($row['registered_by_name']) ? htmlspecialchars($row['registered_by_name']) : 'Unknown') . 
                            ' on ' . format_date($row['registered_at'] ?? '', 'd-m-Y') . 
                        '</span>
                    </div>';
            
            if (!empty($row['approved_by']) && !empty($row['approval_date'])) {
                $html .= '
                    <div class="field">
                        <span class="field-label">Approved By:</span>
                        <span class="field-value">' . 
                            (isset($row['approved_by_name']) ? htmlspecialchars($row['approved_by_name']) : 'Unknown') . 
                            ' on ' . format_date($row['approval_date'], 'd-m-Y') . 
                        '</span>
                    </div>';
            }
            
            $html .= '
                    <div class="field">
                        <span class="field-label">Review Date:</span>
                        <span class="field-value">' . 
                            (!empty($row['review_date']) && $row['review_date'] != '0000-00-00' ? 
                             format_date($row['review_date'], 'd-m-Y') : 'Not set') . 
                        '</span>
                    </div>
                </div>
                
                <div class="section">
                    <div class="section-title">DPIA Details</div>
                    <div class="field">
                        <span class="field-label">Risk Origin:</span>
                        <span class="field-value">' . 
                            (isset($row['risk_origin']) && isset($dpia_options['risk_origins'][$row['risk_origin']]) ? 
                             htmlspecialchars($dpia_options['risk_origins'][$row['risk_origin']]) : 
                             (isset($row['risk_origin']) ? htmlspecialchars($row['risk_origin']) : 'Not specified')) . 
                        '</span>
                    </div>
                    <div class="field">
                        <span class="field-label">Data Subjects Affected:</span>
                        <span class="field-value">' . 
                            (isset($row['data_subjects_affected']) ? number_format($row['data_subjects_affected'], 0, ',', '.') : '0') . 
                        '</span>
                    </div>
                    <div class="field">
                        <span class="field-label">Description:</span>
                        <span class="field-value">' . 
                            (isset($row['description']) ? nl2br(htmlspecialchars($row['description'])) : 'No description provided') . 
                        '</span>
                    </div>';
            
            if (!empty($row['processing_activity_description'])) {
                $html .= '
                    <div class="field">
                        <span class="field-label">Processing Activity Description:</span>
                        <span class="field-value">' . nl2br(htmlspecialchars($row['processing_activity_description'])) . '</span>
                    </div>';
            }
            
            $html .= '
                </div>
                
                <div class="section">
                    <div class="section-title">Necessity & Proportionality</div>
                    <div class="field">
                        <span class="field-label">Necessity Test:</span>
                        <span class="field-value">' . 
                            (isset($row['necessity_test']) ? nl2br(htmlspecialchars($row['necessity_test'])) : 'Not specified') . 
                        '</span>
                    </div>
                    <div class="field">
                        <span class="field-label">Proportionality Test:</span>
                        <span class="field-value">' . 
                            (isset($row['proportionality_test']) ? nl2br(htmlspecialchars($row['proportionality_test'])) : 'Not specified') . 
                        '</span>
                    </div>
                </div>';
            
            // RISK ASSESSMENT SECTION - ADDED
            if (!empty($risk_assessment_matrix) && is_array($risk_assessment_matrix)) {
                $risk_stats = calculate_risk_statistics($risk_assessment_matrix, $dpia_options);
                
                $html .= '
                <div class="section">
                    <div class="section-title">Risk Assessment</div>
                    <div class="field">
                        <span class="field-label">Overall Risk Level:</span>
                        <span class="field-value">' . get_risk_badge($row['overall_risk_level'] ?? 'medium') . '</span>
                    </div>';
                
                if ($risk_stats['total'] > 0) {
                    $html .= '
                    <div class="field">
                        <span class="field-label">Risk Cells Identified:</span>
                        <span class="field-value">
                            <span class="risk-cell-stat risk-stat-high">' . $risk_stats['high'] . ' High</span>
                            <span class="risk-cell-stat risk-stat-medium">' . $risk_stats['medium'] . ' Medium</span>
                            <span class="risk-cell-stat risk-stat-low">' . $risk_stats['low'] . ' Low</span>
                            <span style="font-size: 10px; color: #6c757d; margin-left: 10px;">(Total: ' . $risk_stats['total'] . ' cells)</span>
                        </span>
                    </div>';
                }
                
                $html .= '
                    <div class="field">
                        <span class="field-label">Risk Matrix:</span>
                        <div class="risk-matrix-container">
                            ' . generate_risk_matrix_html($risk_assessment_matrix, $dpia_options) . '
                        </div>
                    </div>
                </div>';
            }
            
            if (!empty($compliance_checklist) && is_array($compliance_checklist)) {
                $html .= '
                <div class="section">
                    <div class="section-title">Compliance Checklist</div>
                    <div class="compliance-checklist">';
                
                $checked_count = 0;
                foreach ($dpia_options['compliance_checklist'] as $key => $item) {
                    if (in_array($key, $compliance_checklist)) {
                        $html .= '<div class="compliance-item">' . htmlspecialchars($item) . '</div>';
                        $checked_count++;
                    }
                }
                
                $html .= '
                    </div>
                    <div class="field">
                        <span class="field-label">Compliance Score:</span>
                        <span class="field-value">' . $checked_count . ' / ' . count($dpia_options['compliance_checklist']) . ' (' . round(($checked_count / count($dpia_options['compliance_checklist'])) * 100) . '%)</span>
                    </div>
                </div>';
            }
            
            $html .= '
                <div class="section">
                    <div class="section-title">Mitigation & Residual Risk</div>
                    <div class="field">
                        <span class="field-label">Mitigation Measures:</span>
                        <span class="field-value">' . 
                            (isset($row['mitigation_measures']) ? nl2br(htmlspecialchars($row['mitigation_measures'])) : 'No mitigation measures specified') . 
                        '</span>
                    </div>
                    <div class="field">
                        <span class="field-label">Residual Risk:</span>
                        <span class="field-value">' . 
                            (isset($row['residual_risk']) ? nl2br(htmlspecialchars($row['residual_risk'])) : 'No residual risk assessment') . 
                        '</span>
                    </div>
                </div>';
            
            if (!empty($row['consultation_details']) || (!empty($row['consultation_conducted']) && $row['consultation_conducted'] != 'no')) {
                $html .= '
                <div class="section">
                    <div class="section-title">Consultation</div>
                    <div class="field">
                        <span class="field-label">Consultation Conducted:</span>
                        <span class="field-value">' . 
                            (!empty($row['consultation_conducted']) ? ucfirst($row['consultation_conducted']) : 'Not specified') . 
                        '</span>
                    </div>';
                
                if (!empty($row['consultation_details'])) {
                    $html .= '
                    <div class="field">
                        <span class="field-label">Consultation Details:</span>
                        <span class="field-value">' . nl2br(htmlspecialchars($row['consultation_details'])) . '</span>
                    </div>';
                }
                
                $html .= '</div>';
            }
            
            if (!empty($row['recommendations'])) {
                $html .= '
                <div class="section">
                    <div class="section-title">Recommendations</div>
                    <div class="field">
                        <span class="field-label">Recommendations:</span>
                        <span class="field-value">' . nl2br(htmlspecialchars($row['recommendations'])) . '</span>
                    </div>
                </div>';
            }
            
            $html .= '
            </div>';
            
            // Add page break every 2 DPIAs
            if ($dpia_count % 2 == 0) {
                $html .= '<div class="page-break"></div>';
            }
        }
        
        if ($current_status != '') {
            $html .= '</div>';
        }
        
        // First, get all DPIAs to calculate risk cell statistics in PHP
        $all_dpias_result = $conn->query("
            SELECT d.id, d.status, d.overall_risk_level, d.risk_assessment_matrix,
                   g.department
            FROM dpia_registrations d
            LEFT JOIN gdpr_register g ON d.record_id = g.id
        ");
        
        $stats_by_status = [];
        $stats_by_dept = [];
        $total_risk_cells = 0;
        $dpia_with_matrix = 0;
        
        if ($all_dpias_result) {
            while ($dpia = $all_dpias_result->fetch_assoc()) {
                $status = $dpia['status'];
                $department = $dpia['department'] ?? 'unknown';
                $risk_cells = count_risk_cells_in_json($dpia['risk_assessment_matrix'] ?? '');
                
                // Initialize status stats
                if (!isset($stats_by_status[$status])) {
                    $stats_by_status[$status] = [
                        'count' => 0,
                        'high_risk' => 0,
                        'medium_risk' => 0,
                        'low_risk' => 0,
                        'total_risk_cells' => 0,
                        'dpia_with_matrix' => 0
                    ];
                }
                
                // Initialize department stats
                if (!isset($stats_by_dept[$department])) {
                    $stats_by_dept[$department] = [
                        'count' => 0,
                        'high_risk' => 0,
                        'medium_risk' => 0,
                        'low_risk' => 0,
                        'total_risk_cells' => 0,
                        'dpia_with_matrix' => 0
                    ];
                }
                
                // Update status stats
                $stats_by_status[$status]['count']++;
                if ($dpia['overall_risk_level'] == 'high') $stats_by_status[$status]['high_risk']++;
                if ($dpia['overall_risk_level'] == 'medium') $stats_by_status[$status]['medium_risk']++;
                if ($dpia['overall_risk_level'] == 'low') $stats_by_status[$status]['low_risk']++;
                if ($risk_cells > 0) {
                    $stats_by_status[$status]['total_risk_cells'] += $risk_cells;
                    $stats_by_status[$status]['dpia_with_matrix']++;
                }
                
                // Update department stats
                $stats_by_dept[$department]['count']++;
                if ($dpia['overall_risk_level'] == 'high') $stats_by_dept[$department]['high_risk']++;
                if ($dpia['overall_risk_level'] == 'medium') $stats_by_dept[$department]['medium_risk']++;
                if ($dpia['overall_risk_level'] == 'low') $stats_by_dept[$department]['low_risk']++;
                if ($risk_cells > 0) {
                    $stats_by_dept[$department]['total_risk_cells'] += $risk_cells;
                    $stats_by_dept[$department]['dpia_with_matrix']++;
                }
                
                // Update global stats
                if ($risk_cells > 0) {
                    $total_risk_cells += $risk_cells;
                    $dpia_with_matrix++;
                }
            }
        }
        
        // Calculate averages
        $avg_risk_cells_per_dpia = $dpia_with_matrix > 0 ? round($total_risk_cells / $dpia_with_matrix, 1) : 0;
        
        // Add summary statistics
        $html .= '
            <div class="page-break"></div>
            <div class="header">
                <h2>DPIA Statistics Report</h2>
                <div class="print-date">Generated: ' . date('d-m-Y H:i') . '</div>
            </div>
            
            <table class="summary-table">
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Count</th>
                        <th>Percentage</th>
                        <th>Risk Distribution</th>
                        <th>Avg. Risk Cells</th>
                    </tr>
                </thead>
                <tbody>';
        
        $grand_total = 0;
        $grand_high = 0;
        $grand_medium = 0;
        $grand_low = 0;
        
        // Define status order
        $status_order = ['draft', 'in_progress', 'under_review', 'approved', 'rejected', 'implemented'];
        
        foreach ($status_order as $status) {
            if (isset($stats_by_status[$status])) {
                $stats = $stats_by_status[$status];
                $percentage = $total_dpias > 0 ? round(($stats['count'] / $total_dpias) * 100, 1) : 0;
                $status_name = isset($gdpr_options['dpia_statuses'][$status]) ? 
                    $gdpr_options['dpia_statuses'][$status] : 
                    ucfirst(str_replace('_', ' ', $status));
                
                $avg_cells = $stats['dpia_with_matrix'] > 0 ? round($stats['total_risk_cells'] / $stats['dpia_with_matrix'], 1) : '0';
                
                $html .= '
                    <tr>
                        <td>' . htmlspecialchars($status_name) . '</td>
                        <td>' . $stats['count'] . '</td>
                        <td>' . $percentage . '%</td>
                        <td>
                            High: ' . $stats['high_risk'] . '<br>
                            Medium: ' . $stats['medium_risk'] . '<br>
                            Low: ' . $stats['low_risk'] . '
                        </td>
                        <td>' . $avg_cells . '</td>
                    </tr>';
                
                $grand_total += $stats['count'];
                $grand_high += $stats['high_risk'];
                $grand_medium += $stats['medium_risk'];
                $grand_low += $stats['low_risk'];
            }
        }
        
        $html .= '
                    <tr style="font-weight: bold; background-color: #f8f9fa;">
                        <td>TOTAL</td>
                        <td>' . $grand_total . '</td>
                        <td>100%</td>
                        <td>
                            High: ' . $grand_high . '<br>
                            Medium: ' . $grand_medium . '<br>
                            Low: ' . $grand_low . '
                        </td>
                        <td>' . $avg_risk_cells_per_dpia . '</td>
                    </tr>
                </tbody>
            </table>
            
            <!-- Department Distribution -->
            <h3 style="margin-top: 30px;">DPIA Distribution by Department</h3>
            <table class="summary-table">
                <thead>
                    <tr>
                        <th>Department</th>
                        <th>Total DPIAs</th>
                        <th>High Risk</th>
                        <th>Medium Risk</th>
                        <th>Low Risk</th>
                        <th>Avg. Risk Cells</th>
                    </tr>
                </thead>
                <tbody>';
        
        $dept_total = 0;
        $dept_high = 0;
        $dept_medium = 0;
        $dept_low = 0;
        
        // Sort departments by count
        uasort($stats_by_dept, function($a, $b) {
            return $b['count'] - $a['count'];
        });
        
        foreach ($stats_by_dept as $dept_key => $dept_stats) {
            $dept_name = isset($gdpr_options['departments'][$dept_key]) ? 
                $gdpr_options['departments'][$dept_key] : 
                ucfirst($dept_key);
            
            $avg_cells = $dept_stats['dpia_with_matrix'] > 0 ? round($dept_stats['total_risk_cells'] / $dept_stats['dpia_with_matrix'], 1) : '0';
            
            $html .= '
                <tr>
                    <td>' . htmlspecialchars($dept_name) . '</td>
                    <td>' . $dept_stats['count'] . '</td>
                    <td>' . $dept_stats['high_risk'] . '</td>
                    <td>' . $dept_stats['medium_risk'] . '</td>
                    <td>' . $dept_stats['low_risk'] . '</td>
                    <td>' . $avg_cells . '</td>
                </tr>';
            
            $dept_total += $dept_stats['count'];
            $dept_high += $dept_stats['high_risk'];
            $dept_medium += $dept_stats['medium_risk'];
            $dept_low += $dept_stats['low_risk'];
        }
        
        $html .= '
                <tr style="font-weight: bold; background-color: #f8f9fa;">
                    <td>TOTAL</td>
                    <td>' . $dept_total . '</td>
                    <td>' . $dept_high . '</td>
                    <td>' . $dept_medium . '</td>
                    <td>' . $dept_low . '</td>
                    <td>' . $avg_risk_cells_per_dpia . '</td>
                </tr>
            </tbody>
        </table>
        
        <!-- Risk Assessment Summary -->
        <h3 style="margin-top: 30px;">Overall Risk Assessment Summary</h3>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0;">
            <div style="background-color: #f8d7da; padding: 15px; border-radius: 5px; text-align: center;">
                <div style="font-size: 24px; font-weight: bold; color: #721c24;">' . $grand_high . '</div>
                <div style="font-size: 12px; color: #721c24;">High Risk DPIAs</div>
            </div>
            <div style="background-color: #fff3cd; padding: 15px; border-radius: 5px; text-align: center;">
                <div style="font-size: 24px; font-weight: bold; color: #856404;">' . $grand_medium . '</div>
                <div style="font-size: 12px; color: #856404;">Medium Risk DPIAs</div>
            </div>
            <div style="background-color: #d4edda; padding: 15px; border-radius: 5px; text-align: center;">
                <div style="font-size: 24px; font-weight: bold; color: #155724;">' . $grand_low . '</div>
                <div style="font-size: 12px; color: #155724;">Low Risk DPIAs</div>
            </div>
            <div style="background-color: #cce5ff; padding: 15px; border-radius: 5px; text-align: center;">
                <div style="font-size: 24px; font-weight: bold; color: #004085;">' . $avg_risk_cells_per_dpia . '</div>
                <div style="font-size: 12px; color: #004085;">Avg. Risk Cells per DPIA</div>
            </div>
        </div>
        
        <!-- Risk Matrix Legend -->
        <h3 style="margin-top: 30px;">Risk Matrix Color Legend</h3>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin: 15px 0;">
            <div style="background-color: #d4edda; padding: 10px; border-radius: 5px;">
                <strong>Low Risk (Green)</strong><br>
                <small>Acceptable risk level, minimal impact</small>
            </div>
            <div style="background-color: #fff3cd; padding: 10px; border-radius: 5px;">
                <strong>Medium Risk (Yellow)</strong><br>
                <small>Moderate risk, requires monitoring</small>
            </div>
            <div style="background-color: #f8d7da; padding: 10px; border-radius: 5px;">
                <strong>High Risk (Red)</strong><br>
                <small>Significant risk, requires immediate action</small>
            </div>
        </div>
        
        <div class="footer">
            Food Bank Almere - Data Protection Impact Assessment System<br>
            Generated on ' . date('d-m-Y H:i') . ' | Total DPIAs: ' . $total_dpias . '<br>
            Confidential - For authorized personnel only
        </div>
        
        </body>
        </html>';
        
        $conn->close();
        return $html;
        
    } catch (Exception $e) {
        // Return error page
        return '
        <!DOCTYPE html>
        <html>
        <head><title>Error - DPIA Report</title></head>
        <body style="font-family:Arial;padding:20px;">
            <h1>Error Generating DPIA Report</h1>
            <p><strong>Error:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>
            <p><strong>Time:</strong> ' . date('d-m-Y H:i:s') . '</p>
            <hr>
            <h3>Troubleshooting Steps:</h3>
            <ol>
                <li>Check database configuration in the script</li>
                <li>Verify database credentials</li>
                <li>Ensure tables exist in the database</li>
                <li>Check database connection</li>
            </ol>
        </body>
        </html>';
    }
}

// ============================================
// EXECUTE THE REPORT
// ============================================

// Generate and display the report
$report_html = generate_all_dpia_print_html($db_config, $gdpr_options, $dpia_options);
echo $report_html;
?>