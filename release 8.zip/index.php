<?php
/**
 * Food Bank Almere - GDPR Compliance System
 * Complete One-Page Solution - FULLY UPDATED VERSION
 * PART 1: Configuration, Database, Security, and Helper Functions
 * UPDATED: Fixed DPIA Registration System and Encrypted Fields
 */

// ============================================
// CONFIGURATION SECTION
// ============================================
session_start([
    'cookie_secure' => false, // Set to true in production with HTTPS
    'cookie_httponly' => true,
    'use_strict_mode' => true
]);

// Handle changes AJAX request
if (isset($_GET['action']) && $_GET['action'] == 'get_changes') {
    if (!has_permission('view_audit_log')) {
        die('Access denied');
    }
    
    $log_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    if ($log_id > 0) {
        echo show_changes_details($log_id);
    } else {
        echo '<div class="alert alert-danger">Invalid log ID</div>';
    }
    exit();
}

date_default_timezone_set('Europe/Amsterdam');

// Database Configuration
$db_config = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'foodbank',
    'charset' => 'utf8mb4'
];

// Application Configuration
$app_config = [
    'site_name' => 'Food Bank Almere GDPR System',
    'version' => '3.6.0', // Updated version
    'admin_email' => 'dpo@foodbank-almere.nl',
    'default_records_per_page' => 25,
    'session_timeout' => 3600,
    'password_min_length' => 8,
    'max_login_attempts' => 5,
    'lockout_duration' => 900,
    'encryption_key' => 'foodbank-almere-gdpr-secure-key-2024',
    'recent_update_threshold' => 180,
    'high_risk_review_days' => 90,
    'medium_risk_review_days' => 180,
    'low_risk_review_days' => 365,
    'password_algorithm' => PASSWORD_DEFAULT
];

// User Roles and Permissions
$user_roles = [
    'admin' => [
        'view_dashboard', 'view_activities', 'add_activity', 'edit_activity', 'delete_activity',
        'view_dpias', 'add_dpia', 'edit_dpia', 'delete_dpia', 'view_breaches', 'add_breach',
        'edit_breach', 'view_third_parties', 'add_third_party', 'edit_third_party',
        'view_audit_log', 'manage_users', 'export_data', 'print_reports', 'system_settings',
        'approve_dpia'
    ],
    'dpo' => [
        'view_dashboard', 'view_activities', 'add_activity', 'edit_activity', 'view_dpias',
        'add_dpia', 'edit_dpia', 'view_breaches', 'add_breach', 'edit_breach',
        'view_third_parties', 'add_third_party', 'view_audit_log', 'export_data', 'print_reports',
        'approve_dpia'
    ],
    'editor' => [
        'view_dashboard', 'view_activities', 'add_activity', 'edit_activity', 'view_dpias',
        'add_dpia', 'edit_dpia', 'view_breaches', 'add_breach', 'view_third_parties',
        'export_data', 'print_reports'
    ],
    'viewer' => [
        'view_dashboard', 'view_activities', 'view_dpias', 'view_breaches', 'view_third_parties',
        'print_reports'
    ]
];

// GDPR Categories and Options
$gdpr_options = [
    'departments' => [
        'administration' => 'Administration',
        'distribution' => 'Food Distribution',
        'volunteers' => 'Volunteer Management',
        'donations' => 'Donations & Funding',
        'marketing' => 'Marketing & Communication',
        'other' => 'Other'
    ],
    'risk_levels' => [
        'low' => 'Low Risk',
        'medium' => 'Medium Risk',
        'high' => 'High Risk'
    ],
    'legal_bases' => [
        'consent' => 'Consent',
        'contract' => 'Contract',
        'legal_obligation' => 'Legal Obligation',
        'vital_interests' => 'Vital Interests',
        'public_task' => 'Public Task',
        'legitimate_interests' => 'Legitimate Interests'
    ],
    'status_options' => [
        'active' => 'Active',
        'inactive' => 'Inactive',
        'archived' => 'Archived',
        'review_needed' => 'Review Needed'
    ],
    'dpia_statuses' => [
        'draft' => 'Draft',
        'in_progress' => 'In Progress',
        'under_review' => 'Under Review',
        'approved' => 'Approved',
        'rejected' => 'Rejected',
        'implemented' => 'Implemented',
        'not_required' => 'Not Required'
    ],
    'breach_types' => [
        'confidentiality' => 'Confidentiality Breach',
        'integrity' => 'Integrity Breach',
        'availability' => 'Availability Breach',
        'mixed' => 'Mixed Breach'
    ],
    'countries' => [
        'none' => 'No International Transfer',
        'EU_EEA_Switzerland' => 'EU/EEA/Switzerland',
        'UK' => 'United Kingdom',
        'USA' => 'United States',
        'Canada' => 'Canada',
        'Australia' => 'Australia',
        'Other_third_country' => 'Other Third Country',
        'Multiple_countries' => 'Multiple Countries'
    ]
];

// DPIA-specific options
$dpia_options = [
    'risk_origins' => [
        'new_technology' => 'New technology/system deployment',
        'large_scale' => 'Large-scale processing',
        'sensitive_data' => 'Processing sensitive data',
        'systematic_monitoring' => 'Systematic monitoring of publicly accessible areas',
        'combination_datasets' => 'Combination of datasets from different sources',
        'vulnerable_groups' => 'Processing data of vulnerable groups',
        'other' => 'Other high-risk processing'
    ],
    'compliance_checklist' => [
        'privacy_by_design' => 'Privacy by design and default implemented',
        'data_minimization' => 'Data minimization principles applied',
        'purpose_limitation' => 'Purpose limitation respected',
        'storage_limitation' => 'Storage limitation implemented',
        'security_measures' => 'Appropriate security measures in place',
        'data_subject_rights' => 'Data subject rights procedures established',
        'dpo_consultation' => 'DPO consulted during design phase',
        'risk_assessment' => 'Risk assessment completed',
        'transparency' => 'Transparency requirements met',
        'consent_management' => 'Consent management system implemented'
    ],
    'risk_assessment_matrix' => [
        'likelihood' => [
            'rare' => 'Rare (once in several years)',
            'unlikely' => 'Unlikely (once per year)',
            'possible' => 'Possible (several times per year)',
            'likely' => 'Likely (monthly)',
            'certain' => 'Certain (weekly or more)'
        ],
        'impact' => [
            'insignificant' => 'Insignificant',
            'minor' => 'Minor',
            'moderate' => 'Moderate',
            'major' => 'Major',
            'catastrophic' => 'Catastrophic'
        ]
    ],
    'management_approval' => [
        'pending' => 'Pending Approval',
        'approved' => 'Approved',
        'rejected' => 'Rejected',
        'revised' => 'Needs Revision'
    ]
];

// Safeguards options for auto-population
$safeguards_options = [
    'technical' => [
        'Encryptie van persoonsgegevens',
        'Toegangsbeheer met unieke gebruikersnamen en wachtwoorden',
        'Firewall beveiliging',
        'Applicatie start vanaf network access storage',
        'Logging',
        'Toegangsbeheer op basis van rollen',
        'Tweefactorauthenticatie voor beheerders',
        'Regelmatige back-ups',
        'Encryptie van gevoelige documenten',
        'Gebruik van klantnummers in plaats van namen waar mogelijk',
        'Anonimisering van gegevens voor statistieken',
        'Beveiligde opslag van fysieke formulieren',
        'Gescheiden systemen voor financiële en persoonlijke gegevens',
        'Encryptie van financiële transacties',
        'Beveiligde betaalverwerking',
        'Double opt-in voor nieuwsbrieven',
        'Unsubscribe-functionaliteit in elke mailing',
        'Beveiligde mailingsoftware',
        'Logging van toestemmingen',
        'Versleutelde gegevensuitwisseling',
        'Pseudonimisering waar mogelijk',
        'Audit logging van alle toegang tot BSN-gegevens',
        'Toegangsbeheer op basis van strikte noodzaak',
        'SSL-certificaat',
        'Cookie-toestemmingssysteem',
        'Automatische verwijdering van oude contactformulieren',
        'Beveiligde hosting',
        'DDoS-bescherming',
        'Watermerken op beeldmateriaal',
        'Gescheiden opslag toestemmingsformulieren',
        'Beperkte toegang tot originele bestanden',
        'Beveiligde opslag camerabeelden',
        'Toegangsbeheer tot beelden',
        'Automatische verwijdering na bewaartermijn',
        'Logging van toegang tot beelden',
        'Anonimisering direct na verzameling',
        'Gescheiden opslag geanonimiseerde data',
        'Encryptie van onderzoeksdata',
        'Encryptie bij opslag',
        'Tweefactorauthenticatie voor toegang tot BSN',
        'Automatische herinneringen systeem',
        'Versleutelde opslag wijzigingen',
        'Gebruik klantnummers ipv namen bij pakket',
        'Anonieme labeling',
        'Online afsprakensysteem met beveiligde login',
        'Beveiligde upload VOG',
        'Encryptie CV\'s',
        'Fysiek afgesloten archief',
        'Digitale encryptie',
        'Beveiligde rooster app',
        'Toegangsbeperkingen',
        'Beveiligde opslag evaluaties',
        'Encryptie',
        'Digitale registratie met barcode scanning',
        'Gescheiden financiële administratie',
        'Bankkoppeling',
        'Pseudonimisering bij communicatie',
        'Dubbele opt-in',
        'CRM systeem met toegangsbeperking',
        'Aparte versleutelde database',
        'Strikte toegangscontrole',
        'Barcodesysteem',
        'Automatische alerts',
        'Automatische logging',
        'Digitale handtekening',
        'Digitale kopieën versleuteld',
        'Beperkte toegang',
        'Digitale presentielijsten met encryptie',
        'Elektronisch pasjessysteem',
        'Logging toegang',
        'Double opt-in',
        'Unsubscribe functionaliteit',
        'Toegangsbeperking accounts',
        'Monitoring tools',
        'Media database met encryptie',
        'Watermerken op foto\'s',
        'Toestemmingsdatabase',
        'Gespecialiseerde salarissoftware',
        'Encryptie',
        'Digitale declaratiesysteem',
        'Automatische checks',
        'Documentbeheersysteem met versiebeheer',
        'Wachtwoord policy',
        'Encryptie',
        'Logging',
        'Versleutelde back-ups',
        'Offsite opslag',
        'Incident managementsysteem',
        'Encryptie',
        'Versleutelde e-mail',
        'Beveiligde portals',
        'Versleutelde notulen',
        'Toegangsbeperking',
        'Automatische anonimisering',
        'Aggregatie tools',
        'Anonieme enquêtes mogelijk',
        'Encryptie',
        'Beveiligd klachtensysteem',
        'Logging',
        'Audit trail verzoeken',
        'Beveiligde verzending',
        'Definitieve verwijdering tools',
        'Logging',
        'Beveiligde opslag',
        'Automatische overschrijving',
        'Digitale bezoekersregistratie',
        'Encryptie',
        'Versleutelde EHBO-formulieren',
        'Tijdelijke registratie',
        'Automatische verwijdering',
        'Presentaties zonder persoonsgegevens',
        'Versleutelde notities',
        'Aparte map per deelnemer',
        'Tijdelijke registratie',
        'Snelle verwijdering',
        'Beperkte gegevensverzameling',
        'Encryptie',
        'Gescheiden projectadministratie',
        'Encryptie',
        'Minimale gegevens in bezorg-app',
        'Tijdelijke opslag',
        'Pseudonimisering',
        'Aparte onderzoeksdatabase',
        'Geaggregeerde data alleen',
        'Geen persoonsgegevens',
        'Geolocatie anonimisering',
        'Wijkniveau aggregatie',
        'Koppeling via beveiligde API',
        'Logging',
        'Versleutelde RI&E documenten',
        'Toegangsbeheer',
        'E-mail archivering',
        'Encryptie gevoelige correspondentie'
    ],
    'organizational' => [
        'Verwerkersovereenkomsten met vrijwilligers',
        'Privacyverklaring voor klanten',
        'Functiescheiding',
        'Periodieke trainingen voor medewerkers en vrijwilligers',
        'Meldprocedure datalekken',
        'Data Protection Officer (DPO) aanwezig',
        'Privacyverklaring voor vrijwilligers',
        'Verwerkersovereenkomsten',
        'Screeningsprocedure voor vrijwilligers',
        'Periodieke evaluaties',
        'Duidelijke instructies over omgang met persoonsgegevens',
        'Minimalisatie van persoonsgegevens op distributielocatie',
        'Training vrijwilligers in gegevensbescherming',
        'Duidelijke procedures voor voedseluitgifte',
        'Privacybeleid voor donateurs',
        'Duidelijke communicatie over gebruik gegevens',
        'Anonimiseringsopties voor donateurs',
        'Gescheiden verantwoordelijkheden financiën',
        'Duidelijke toestemmingsprocedure',
        'Periodieke opfrissen toestemmingen',
        'Privacyverklaring in communicatie',
        'Melding wijzigingen in beleid',
        'Formele samenwerkingsovereenkomsten met gemeente',
        'Duidelijke protocollen voor gegevensuitwisseling',
        'DPO-toetsing voor elk gegevensverzoek',
        'Register van gegevensuitwisselingen',
        'Privacyverklaring op website',
        'Cookiebeleid',
        'Duidelijke vermelding van verwerking bij contactformulieren',
        'Procedure voor verzoeken inzage/verwijdering',
        'Toestemmingsformulieren beeldmateriaal',
        'Opt-out mogelijkheid voor vrijwilligers',
        'Procedure voor verwijderingsverzoeken',
        'Duiding cameratoezicht (bordjes)',
        'Procedure voor inzage verzoeken',
        'Beperkte kring van personen met toegang tot beelden',
        'Periodieke evaluatie noodzaak cameratoezicht',
        'Toestemming voor deelname onderzoeken',
        'Duidelijke communicatie over anonimisering',
        'Publicatie alleen geaggregeerde resultaten',
        'Data minimalisatie bij vragenlijsten',
        'Privacyverklaring bij intake',
        'Getrainde intake-medewerkers',
        'Logregistratie toegang',
        'Halfjaarlijkse evaluatie procedure',
        'Update privacyverklaring',
        'Minimalisatie persoonsgegevens op werkvloer',
        'Duidelijke communicatie privacy bij planning',
        'Vernietiging ongewenste documenten',
        'Strikt noodzakelijk delen',
        'DPO-toetsing',
        'Geen privégegevens op openbare roosters',
        'Transparante procedure',
        'Inzage recht',
        'Kwaliteitsprotocol',
        'Terugroep procedure',
        'Scheiding financiën en hulpverlening',
        'Periodieke bevestiging',
        'Sponsorovereenkomsten met privacyclausules',
        'Medische gegevens alleen op need-to-know basis',
        'Crisisprotocol',
        'Snelle communicatie mogelijkheid',
        'Gecertificeerde HACCP procedure',
        'Rijbewijscontroleprocedure',
        'Verzekeringscheck',
        'Jaarlijkse herhaling',
        'Privacy bij oefeningen',
        'Protocol sleuteluitgifte',
        'Periodieke audit',
        'Jaarcheck',
        'Social media beleid',
        'Reactieprotocol',
        'Persprotocol',
        'Toestemming voor interviews',
        'Schriftelijke toestemming vereist',
        'Modelrelease formulier',
        'Beperkte toegang',
        'DPO toezicht',
        'Declaratieprotocol',
        'Maximum bedragen',
        'Subsidieprotocol',
        'Privacy by design bij aanvragen',
        'Acceptable Use Policy',
        'Toegangsmatrix',
        'Incident response plan',
        'Testprocedures',
        'Meldplicht datalekken',
        'Escalatieprocedure',
        'Samenwerkingsovereenkomsten',
        'Toestemmingsformulieren',
        'Agenda vooraf',
        'Notulenprotocol',
        'Data minimalisatie',
        'Statistiekprotocol',
        'Optionele deelname',
        'Duidelijke toelichting',
        'Klachtenreglement',
        'Privacy bij klachten',
        'DPO procedure',
        'Termijnbewaking',
        'Verwijderingsprotocol',
        'Uitzonderingen check',
        'Camera beleid',
        'Duidelijke aanduiding',
        'Bezoekersprotocol',
        'Privacy informatie',
        'Privacy bij medische gegevens',
        'Tijdelijke maatregel',
        'Minimale gegevens',
        'Leeftijdsgerichte voorlichting',
        'Geen kindergegevens',
        'Vertrouwelijkheid bij financiële gegevens',
        'Specifieke evenementen privacy statement',
        'Optionele registratie',
        'Foto beleid',
        'Project-specifieke privacy maatregelen',
        'Strikte selectie bezorgers',
        'Veiligheidsprotocol',
        'Informed consent',
        'Benchmark protocol',
        'Privacy by design',
        'Wijkgerichte privacy aanpak',
        'Lokale samenwerking',
        'Strikte gegevensminimalisatie',
        'Duidelijke grenzen',
        'Medewerker consultatie',
        'Correspondentie protocol',
        'Privacy awareness training'
    ]
];

// Sensitive columns for encryption - UPDATED WITH ALL FIELDS
$encrypted_columns = [
    'name_data_controller',
    'contact_data_controller',
    'name_joint_data_controller',
    'contact_joint_data_controller',
    'name_representative',
    'contact_representative',
    'name_dpo',
    'contact_dpo'
];

// ============================================
// DATABASE FUNCTIONS
// ============================================

/**
 * Create database connection
 */
function create_db_connection() {
    global $db_config;
    static $connection = null;
    
    if ($connection === null) {
        try {
            $connection = new mysqli(
                $db_config['host'],
                $db_config['username'],
                $db_config['password'],
                $db_config['database']
            );
            
            if ($connection->connect_error) {
                die("Database connection failed: " . $connection->connect_error);
            }
            
            $connection->set_charset($db_config['charset']);
        } catch (Exception $e) {
            die("Database connection error: " . $e->getMessage());
        }
    }
    
    return $connection;
}

/**
 * Check if column exists in table
 */
function column_exists($table, $column) {
    $conn = create_db_connection();
    $result = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $result && $result->num_rows > 0;
}

/**
 * Add missing column to table
 */
function add_column_if_not_exists($table, $column, $definition) {
    $conn = create_db_connection();
    
    if (!column_exists($table, $column)) {
        try {
            $conn->query("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
            return true;
        } catch (Exception $e) {
            // Column might already exist or error occurred
            error_log("Failed to add column $column to $table: " . $e->getMessage());
            return false;
        }
    }
    return true;
}

/**
 * Fix missing columns in system_users table
 */
function fix_system_users_table() {
    $conn = create_db_connection();
    
    $missing_columns = [
        'failed_login_attempts' => "INT DEFAULT 0",
        'account_locked_until' => "DATETIME DEFAULT NULL"
    ];
    
    foreach ($missing_columns as $column => $definition) {
        add_column_if_not_exists('system_users', $column, $definition);
    }
    
    return true;
}

/**
 * Fix missing columns in dpia_registrations table - UPDATED
 */
function fix_dpia_table() {
    $conn = create_db_connection();
    
    $missing_columns = [
        'title' => "VARCHAR(255) NOT NULL DEFAULT 'DPIA Assessment'",
        'processing_activity_description' => "TEXT DEFAULT NULL",
        'risk_origin' => "ENUM('new_technology','large_scale','sensitive_data','systematic_monitoring','combination_datasets','vulnerable_groups','other') DEFAULT 'other'",
        'necessity_test' => "TEXT DEFAULT NULL",
        'proportionality_test' => "TEXT DEFAULT NULL",
        'data_subjects_affected' => "INT DEFAULT 0",
        'data_categories' => "TEXT DEFAULT NULL",
        'compliance_checklist' => "JSON DEFAULT NULL",
        'risk_assessment_matrix' => "JSON DEFAULT NULL",
        'consultation_conducted' => "ENUM('yes','no','planned') DEFAULT 'no'",
        'consultation_details' => "TEXT DEFAULT NULL",
        'recommendations' => "TEXT DEFAULT NULL",
        'management_approval' => "ENUM('pending','approved','rejected','revised') DEFAULT 'pending'",
        'approved_by' => "INT DEFAULT NULL",
        'approval_date' => "DATE DEFAULT NULL",
        'review_date' => "DATE DEFAULT NULL"
    ];
    
    foreach ($missing_columns as $column => $definition) {
        add_column_if_not_exists('dpia_registrations', $column, $definition);
    }
    
    return true;
}

/**
 * Fix missing columns in gdpr_register table - UPDATED WITH ALL FIELDS
 */
function fix_gdpr_register_table() {
    $conn = create_db_connection();
    
    $missing_columns = [
        'department' => "ENUM('administration','distribution','volunteers','donations','marketing','other') DEFAULT 'other'",
        'status' => "ENUM('active','inactive','archived','review_needed') DEFAULT 'active'",
        'has_processing_agreement_with_third_party' => "ENUM('yes','no') DEFAULT 'no'",
        'we_are_processor' => "ENUM('yes','no') DEFAULT 'no'",
        'name_data_controller' => "VARCHAR(255) DEFAULT NULL",
        'contact_data_controller' => "VARCHAR(255) DEFAULT NULL",
        'name_joint_data_controller' => "VARCHAR(255) DEFAULT NULL",
        'contact_joint_data_controller' => "VARCHAR(255) DEFAULT NULL",
        'name_representative' => "VARCHAR(255) DEFAULT NULL",
        'contact_representative' => "VARCHAR(255) DEFAULT NULL",
        'name_dpo' => "VARCHAR(255) DEFAULT NULL",
        'contact_dpo' => "VARCHAR(255) DEFAULT NULL",
        'legitimate_interest_description' => "TEXT DEFAULT NULL",
        'dpia_status' => "ENUM('draft','in_progress','under_review','approved','rejected','implemented','not_required') DEFAULT 'not_required'",
        'is_international_data_transfers' => "ENUM('yes','no','unknown') DEFAULT 'unknown'",
        'to_country' => "ENUM('none','EU_EEA_Switzerland','UK','USA','Canada','Australia','Other_third_country','Multiple_countries') DEFAULT 'none'",
        'safeguards' => "TEXT DEFAULT NULL",
        'created_by' => "INT DEFAULT NULL",
        'updated_by' => "INT DEFAULT NULL",
        'review_due_date' => "DATE DEFAULT NULL"
    ];
    
    foreach ($missing_columns as $column => $definition) {
        add_column_if_not_exists('gdpr_register', $column, $definition);
    }
    
    return true;
}

/**
 * Initialize database tables with missing columns check
 */
function initialize_database() {
    $conn = create_db_connection();
    
    // Create system_users table
    $conn->query("
        CREATE TABLE IF NOT EXISTS `system_users` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `username` VARCHAR(50) NOT NULL,
            `password` VARCHAR(255) NOT NULL,
            `email` VARCHAR(100) NOT NULL,
            `full_name` VARCHAR(100) NOT NULL,
            `role` ENUM('admin','dpo','editor','viewer') DEFAULT 'viewer',
            `is_active` TINYINT(1) DEFAULT 1,
            `last_login` DATETIME DEFAULT NULL,
            `failed_login_attempts` INT DEFAULT 0,
            `account_locked_until` DATETIME DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_username` (`username`),
            UNIQUE KEY `uk_email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Create gdpr_register table with basic structure
    $conn->query("
        CREATE TABLE IF NOT EXISTS `gdpr_register` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `processing_activity` VARCHAR(500) NOT NULL,
            `department` ENUM('administration','distribution','volunteers','donations','marketing','other') DEFAULT 'other',
            `status` ENUM('active','inactive','archived','review_needed') DEFAULT 'active',
            `has_processing_agreement_with_third_party` ENUM('yes','no') DEFAULT 'no',
            `we_are_processor` ENUM('yes','no') DEFAULT 'no',
            `name_data_controller` VARCHAR(255) DEFAULT NULL,
            `contact_data_controller` VARCHAR(255) DEFAULT NULL,
            `name_joint_data_controller` VARCHAR(255) DEFAULT NULL,
            `contact_joint_data_controller` VARCHAR(255) DEFAULT NULL,
            `name_representative` VARCHAR(255) DEFAULT NULL,
            `contact_representative` VARCHAR(255) DEFAULT NULL,
            `name_dpo` VARCHAR(255) DEFAULT NULL,
            `contact_dpo` VARCHAR(255) DEFAULT NULL,
            `purpose_of_processing` TEXT NOT NULL,
            `legal_basis` ENUM('consent','contract','legal_obligation','vital_interests','public_task','legitimate_interests') NOT NULL,
            `legitimate_interest_description` TEXT DEFAULT NULL,
            `categories_personal_data` TEXT NOT NULL,
            `categories_data_subjects` VARCHAR(300) NOT NULL,
            `categories_recipients` VARCHAR(300) NOT NULL,
            `retention_periods` VARCHAR(200) NOT NULL,
            `risk_level` ENUM('low','medium','high') NOT NULL,
            `technical_measures` TEXT NOT NULL,
            `organizational_measures` TEXT NOT NULL,
            `dpia_required` ENUM('yes','no') NOT NULL,
            `dpia_status` ENUM('draft','in_progress','under_review','approved','rejected','implemented','not_required') DEFAULT 'not_required',
            `is_international_data_transfers` ENUM('yes','no','unknown') DEFAULT 'unknown',
            `to_country` ENUM('none','EU_EEA_Switzerland','UK','USA','Canada','Australia','Other_third_country','Multiple_countries') DEFAULT 'none',
            `safeguards` TEXT DEFAULT NULL,
            `created_by` INT DEFAULT NULL,
            `updated_by` INT DEFAULT NULL,
            `review_due_date` DATE DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Create dpia_registrations table - UPDATED VERSION with full DPIA structure
    $conn->query("
        CREATE TABLE IF NOT EXISTS `dpia_registrations` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `record_id` INT NOT NULL,
            `title` VARCHAR(255) NOT NULL DEFAULT 'DPIA Assessment',
            `description` TEXT DEFAULT NULL,
            `processing_activity_description` TEXT DEFAULT NULL,
            `risk_origin` ENUM('new_technology','large_scale','sensitive_data','systematic_monitoring','combination_datasets','vulnerable_groups','other') DEFAULT 'other',
            `necessity_test` TEXT DEFAULT NULL,
            `proportionality_test` TEXT DEFAULT NULL,
            `data_subjects_affected` INT DEFAULT 0,
            `data_categories` TEXT DEFAULT NULL,
            `compliance_checklist` JSON DEFAULT NULL,
            `risk_assessment_matrix` JSON DEFAULT NULL,
            `mitigation_measures` TEXT DEFAULT NULL,
            `residual_risk` TEXT DEFAULT NULL,
            `consultation_conducted` ENUM('yes','no','planned') DEFAULT 'no',
            `consultation_details` TEXT DEFAULT NULL,
            `recommendations` TEXT DEFAULT NULL,
            `overall_risk_level` ENUM('low','medium','high') DEFAULT 'medium',
            `status` ENUM('draft','in_progress','under_review','approved','rejected','implemented') DEFAULT 'draft',
            `management_approval` ENUM('pending','approved','rejected','revised') DEFAULT 'pending',
            `approved_by` INT DEFAULT NULL,
            `approval_date` DATE DEFAULT NULL,
            `registered_by` INT NOT NULL,
            `registered_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            `review_date` DATE DEFAULT NULL,
            `notes` TEXT DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `unique_record_dpia` (`record_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Create data_breaches table
    $conn->query("
        CREATE TABLE IF NOT EXISTS `data_breaches` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `title` VARCHAR(255) NOT NULL,
            `description` TEXT NOT NULL,
            `breach_date` DATE NOT NULL,
            `discovery_date` DATE NOT NULL,
            `breach_type` ENUM('confidentiality','integrity','availability','mixed') NOT NULL,
            `personal_data_affected` TEXT NOT NULL,
            `affected_data_subjects` INT DEFAULT NULL,
            `causes` TEXT NOT NULL,
            `measures_taken` TEXT NOT NULL,
            `notified_authority` ENUM('yes','no','in_progress') DEFAULT 'no',
            `notification_date` DATE DEFAULT NULL,
            `notified_affected_persons` ENUM('yes','no','in_progress') DEFAULT 'no',
            `risk_level` ENUM('low','medium','high') NOT NULL,
            `status` ENUM('open','investigating','contained','resolved','closed') DEFAULT 'open',
            `reported_by` INT NOT NULL,
            `assigned_to` INT DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Create system_changes table
    $conn->query("
        CREATE TABLE IF NOT EXISTS `system_changes` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `table_name` VARCHAR(100) NOT NULL,
            `record_id` INT NOT NULL,
            `action` ENUM('INSERT','UPDATE','DELETE','VIEW','EXPORT','LOGIN','LOGOUT','PRINT') NOT NULL,
            `old_data` JSON DEFAULT NULL,
            `new_data` JSON DEFAULT NULL,
            `changed_fields` TEXT DEFAULT NULL,
            `changed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `changed_by` INT NOT NULL,
            `user_ip` VARCHAR(45) DEFAULT NULL,
            `user_agent` VARCHAR(255) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Create third_parties table
    $conn->query("
        CREATE TABLE IF NOT EXISTS `third_parties` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `company_name` VARCHAR(255) NOT NULL,
            `contact_person` VARCHAR(255) DEFAULT NULL,
            `email` VARCHAR(255) DEFAULT NULL,
            `phone` VARCHAR(50) DEFAULT NULL,
            `address` TEXT DEFAULT NULL,
            `service_provided` TEXT NOT NULL,
            `processing_agreement_signed` ENUM('yes','no','in_progress') DEFAULT 'no',
            `agreement_date` DATE DEFAULT NULL,
            `agreement_expiry_date` DATE DEFAULT NULL,
            `compliance_status` ENUM('compliant','non_compliant','review_needed') DEFAULT 'review_needed',
            `created_by` INT NOT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Check if admin user exists, create if not
    $result = $conn->query("SELECT COUNT(*) as count FROM system_users WHERE username = 'admin'");
    if ($result) {
        $row = $result->fetch_assoc();
        if ($row['count'] == 0) {
            $password = password_hash('Admin@12345', PASSWORD_DEFAULT);
            $conn->query("
                INSERT INTO system_users (username, password, email, full_name, role) 
                VALUES ('admin', '$password', 'admin@foodbank-almere.nl', 'System Administrator', 'admin')
            ");
        }
    }
    
    // Fix any missing columns in tables
    fix_system_users_table();
    fix_dpia_table();
    fix_gdpr_register_table();
    
    // Initialize encryption system
    initialize_encryption_system();
    
    return true;
}

// ============================================
// SECURITY FUNCTIONS
// ============================================

/**
 * Check if user has permission
 */
function has_permission($permission) {
    global $user_roles, $current_user;
    
    if (!$current_user || !isset($current_user['role'])) {
        return false;
    }
    
    $role = $current_user['role'];
    return isset($user_roles[$role]) && in_array($permission, $user_roles[$role]);
}

/**
 * Encrypt sensitive data - FIXED VERSION
 */
function encrypt_data($data) {
    global $app_config;
    
    if (empty($data)) {
        return $data;
    }
    
    try {
        $key = $app_config['encryption_key'];
        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
        
        if ($encrypted === false) {
            return $data; // Return original data if encryption failed
        }
        
        // Combine encrypted data and IV
        $combined = $encrypted . '::' . $iv;
        return base64_encode($combined);
    } catch (Exception $e) {
        error_log("Encryption error: " . $e->getMessage());
        return $data;
    }
}

/**
 * Decrypt sensitive data - FIXED VERSION
 */
function decrypt_data($data) {
    global $app_config;
    
    if (empty($data)) {
        return $data;
    }
    
    try {
        // If the data doesn't contain the separator, return as-is
        if (strpos($data, '::') === false) {
            return $data;
        }
        
        $key = $app_config['encryption_key'];
        $decoded = base64_decode($data);
        
        // Split the data into encrypted data and IV
        $parts = explode('::', $decoded);
        
        // Check if we have both parts
        if (count($parts) !== 2) {
            return $data; // Return original data if format is invalid
        }
        
        list($encrypted_data, $iv) = $parts;
        
        // Ensure IV is exactly 16 bytes (truncate or pad if needed)
        $iv = str_pad(substr($iv, 0, 16), 16, "\0");
        
        $decrypted = openssl_decrypt($encrypted_data, 'AES-256-CBC', $key, 0, $iv);
        
        // If decryption fails, return the original data
        if ($decrypted === false) {
            return $data;
        }
        
        return $decrypted;
    } catch (Exception $e) {
        error_log("Decryption error: " . $e->getMessage());
        return $data;
    }
}

/**
 * Check and fix encrypted data format
 */
function fix_encrypted_data($table, $column) {
    $conn = create_db_connection();
    
    $stmt = $conn->prepare("SELECT id, `$column` FROM `$table` WHERE `$column` IS NOT NULL AND `$column` != ''");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $fixed_count = 0;
    
    while ($row = $result->fetch_assoc()) {
        $data = $row[$column];
        
        // Check if data is encrypted (contains :: separator)
        if (strpos($data, '::') !== false) {
            // Try to decrypt and re-encrypt to fix format
            $decrypted = decrypt_data($data);
            if ($decrypted && $decrypted != $data) {
                // Re-encrypt with proper format
                $re_encrypted = encrypt_data($decrypted);
                
                // Update the record
                $update_stmt = $conn->prepare("UPDATE `$table` SET `$column` = ? WHERE id = ?");
                $update_stmt->bind_param("si", $re_encrypted, $row['id']);
                if ($update_stmt->execute()) {
                    $fixed_count++;
                }
            }
        }
    }
    
    return $fixed_count;
}

/**
 * Initialize encryption system - call this during setup
 */
function initialize_encryption_system() {
    global $encrypted_columns;
    
    $total_fixed = 0;
    
    foreach ($encrypted_columns as $column) {
        $fixed = fix_encrypted_data('gdpr_register', $column);
        $total_fixed += $fixed;
        
        if ($fixed > 0) {
            error_log("Fixed $fixed records in column: $column");
        }
    }
    
    return $total_fixed;
}

/**
 * Test encryption/decryption functionality
 */
function test_encryption() {
    $test_data = "Test data for encryption";
    
    echo "Original: " . $test_data . "<br>";
    
    $encrypted = encrypt_data($test_data);
    echo "Encrypted: " . $encrypted . "<br>";
    
    $decrypted = decrypt_data($encrypted);
    echo "Decrypted: " . $decrypted . "<br>";
    
    if ($test_data === $decrypted) {
        echo "<span style='color:green;'>✓ Encryption/Decryption working correctly</span>";
    } else {
        echo "<span style='color:red;'>✗ Encryption/Decryption failed</span>";
    }
}

/**
 * Log system activity
 */
function log_activity($table_name, $record_id, $action, $old_data = null, $new_data = null, $changed_fields = null) {
    global $current_user;
    
    if (!$current_user) return false;
    
    $conn = create_db_connection();
    $user_id = $current_user['id'];
    $user_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    
    $old_data_json = $old_data ? json_encode($old_data, JSON_UNESCAPED_UNICODE) : null;
    $new_data_json = $new_data ? json_encode($new_data, JSON_UNESCAPED_UNICODE) : null;
    
    $stmt = $conn->prepare("
        INSERT INTO system_changes 
        (table_name, record_id, action, old_data, new_data, changed_fields, changed_by, user_ip, user_agent) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    if (!$stmt) {
        return false;
    }
    
    $stmt->bind_param(
        "sissssiss",
        $table_name,
        $record_id,
        $action,
        $old_data_json,
        $new_data_json,
        $changed_fields,
        $user_id,
        $user_ip,
        $user_agent
    );
    
    return $stmt->execute();
}

/**
 * Get changed fields between old and new data
 */
function get_changed_fields($old_data, $new_data) {
    $changed = [];
    $all_keys = array_unique(array_merge(array_keys($old_data), array_keys($new_data)));
    
    foreach ($all_keys as $key) {
        $old_value = $old_data[$key] ?? null;
        $new_value = $new_data[$key] ?? null;
        
        if ($old_value !== $new_value) {
            $changed[] = $key;
        }
    }
    
    return implode(', ', $changed);
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Format date for display
 */
function format_date($date, $format = 'd-m-Y H:i') {
    if (empty($date) || $date == '0000-00-00 00:00:00' || $date == '0000-00-00') {
        return '-';
    }
    return date($format, strtotime($date));
}

/**
 * Get risk level badge
 */
function get_risk_badge($risk_level) {
    $colors = [
        'low' => 'success',
        'medium' => 'warning',
        'high' => 'danger'
    ];
    
    $color = $colors[$risk_level] ?? 'secondary';
    $text = ucfirst($risk_level);
    return "<span class='badge bg-{$color}'>{$text}</span>";
}

/**
 * Get status badge
 */
function get_status_badge($status) {
    $colors = [
        'active' => 'success',
        'inactive' => 'secondary',
        'archived' => 'info',
        'review_needed' => 'warning',
        'draft' => 'secondary',
        'in_progress' => 'primary',
        'under_review' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'implemented' => 'info',
        'not_required' => 'secondary',
        'open' => 'warning',
        'closed' => 'success',
        'pending' => 'info',
        'yes' => 'success',
        'no' => 'secondary',
        'unknown' => 'info',
        'compliant' => 'success',
        'non_compliant' => 'danger',
        'review_needed' => 'warning',
        'investigating' => 'warning',
        'contained' => 'info',
        'resolved' => 'success'
    ];
    
    $color = $colors[$status] ?? 'secondary';
    $display_status = str_replace('_', ' ', $status);
    return "<span class='badge bg-{$color}'>" . ucfirst($display_status) . "</span>";
}

/**
 * Get management approval badge
 */
function get_approval_badge($approval_status) {
    $colors = [
        'pending' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'revised' => 'info'
    ];
    
    $color = $colors[$approval_status] ?? 'secondary';
    $text = str_replace('_', ' ', $approval_status);
    return "<span class='badge bg-{$color}'>" . ucfirst($text) . "</span>";
}

/**
 * Get dashboard statistics
 */
function get_dashboard_stats() {
    $conn = create_db_connection();
    $stats = [];
    
    try {
        // Total activities
        $result = $conn->query("SELECT COUNT(*) as total FROM gdpr_register");
        $stats['total_activities'] = $result ? $result->fetch_assoc()['total'] : 0;
        
        // High risk activities
        $result = $conn->query("SELECT COUNT(*) as total FROM gdpr_register WHERE risk_level = 'high'");
        $stats['high_risk'] = $result ? $result->fetch_assoc()['total'] : 0;
        
        // Activities due for review
        $result = $conn->query("SELECT COUNT(*) as total FROM gdpr_register WHERE (review_due_date <= CURDATE() OR review_due_date IS NULL) AND status = 'active'");
        $stats['due_for_review'] = $result ? $result->fetch_assoc()['total'] : 0;
        
        // Open DPIAs (draft, in_progress, under_review)
        $result = $conn->query("SELECT COUNT(*) as total FROM dpia_registrations WHERE status IN ('draft', 'in_progress', 'under_review')");
        $stats['open_dpias'] = $result ? $result->fetch_assoc()['total'] : 0;
        
        // Pending DPIA approvals
        $result = $conn->query("SELECT COUNT(*) as total FROM dpia_registrations WHERE management_approval = 'pending'");
        $stats['pending_approvals'] = $result ? $result->fetch_assoc()['total'] : 0;
        
        // Open breaches
        $result = $conn->query("SELECT COUNT(*) as total FROM data_breaches WHERE status IN ('open', 'investigating')");
        $stats['open_breaches'] = $result ? $result->fetch_assoc()['total'] : 0;
        
        // Third parties
        $result = $conn->query("SELECT COUNT(*) as total FROM third_parties");
        $stats['third_parties'] = $result ? $result->fetch_assoc()['total'] : 0;
        
    } catch (Exception $e) {
        // If any query fails, set defaults
        $stats['total_activities'] = 0;
        $stats['high_risk'] = 0;
        $stats['due_for_review'] = 0;
        $stats['open_dpias'] = 0;
        $stats['pending_approvals'] = 0;
        $stats['open_breaches'] = 0;
        $stats['third_parties'] = 0;
    }
    
    return $stats;
}

/**
 * Get activities with review status
 */
function get_activities_with_review_status($limit = 10) {
    $conn = create_db_connection();
    $activities = [];
    
    try {
        $stmt = $conn->prepare("
            SELECT id, processing_activity, department, risk_level, status, 
                   updated_at, created_at, review_due_date 
            FROM gdpr_register 
            ORDER BY updated_at DESC 
            LIMIT ?
        ");
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                // Calculate review status
                $row['review_status'] = 'unknown';
                $row['days_until_review'] = null;
                
                if (!empty($row['review_due_date']) && $row['review_due_date'] != '0000-00-00') {
                    $today = new DateTime();
                    $review_date = new DateTime($row['review_due_date']);
                    $interval = $today->diff($review_date);
                    $row['days_until_review'] = $interval->days;
                    
                    if ($review_date < $today) {
                        $row['review_status'] = 'overdue';
                    } elseif ($interval->days <= 30) {
                        $row['review_status'] = 'due_soon';
                    } else {
                        $row['review_status'] = 'ok';
                    }
                }
                
                $activities[] = $row;
            }
        }
    } catch (Exception $e) {
        // Return empty array if query fails
    }
    
    return $activities;
}

// ============================================
// DPIA SPECIFIC FUNCTIONS
// ============================================

/**
 * Get DPIA compliance checklist HTML
 */
function get_dpia_compliance_checklist_html($selected = []) {
    global $dpia_options;
    
    $html = '<div class="compliance-checklist">';
    $html .= '<div class="row">';
    
    $counter = 0;
    foreach ($dpia_options['compliance_checklist'] as $key => $item) {
        $is_checked = in_array($key, $selected);
        $html .= '<div class="col-md-6 mb-2">';
        $html .= '<div class="form-check">';
        $html .= '<input class="form-check-input compliance-checkbox" type="checkbox" 
                        name="compliance_checklist[]" value="' . $key . '" 
                        id="check_' . $key . '" ' . ($is_checked ? 'checked' : '') . '>';
        $html .= '<label class="form-check-label" for="check_' . $key . '">';
        $html .= htmlspecialchars($item);
        $html .= '</label>';
        $html .= '</div>';
        $html .= '</div>';
        
        $counter++;
        if ($counter % 2 == 0) {
            $html .= '</div><div class="row">';
        }
    }
    
    $html .= '</div>';
    $html .= '</div>';
    
    return $html;
}

/**
 * Get DPIA risk assessment matrix HTML
 */
function get_dpia_risk_matrix_html($selected_matrix = null) {
    global $dpia_options;
    
    $html = '<div class="risk-assessment-matrix">';
    $html .= '<table class="table table-bordered table-sm">';
    $html .= '<thead class="table-light">';
    $html .= '<tr><th scope="col">Impact/Likelihood</th>';
    
    // Header row (likelihood)
    foreach ($dpia_options['risk_assessment_matrix']['likelihood'] as $likelihood_key => $likelihood_label) {
        $html .= '<th scope="col">' . $likelihood_label . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    
    // Body rows (impact)
    foreach ($dpia_options['risk_assessment_matrix']['impact'] as $impact_key => $impact_label) {
        $html .= '<tr>';
        $html .= '<th scope="row">' . $impact_label . '</th>';
        
        foreach ($dpia_options['risk_assessment_matrix']['likelihood'] as $likelihood_key => $likelihood_label) {
            $cell_id = 'risk_' . $impact_key . '_' . $likelihood_key;
            $is_selected = false;
            $risk_level = 'medium';
            
            // Determine risk level based on position
            $impact_index = array_search($impact_key, array_keys($dpia_options['risk_assessment_matrix']['impact']));
            $likelihood_index = array_search($likelihood_key, array_keys($dpia_options['risk_assessment_matrix']['likelihood']));
            
            $total_index = $impact_index + $likelihood_index;
            if ($total_index >= 6) {
                $risk_level = 'high';
            } elseif ($total_index >= 3) {
                $risk_level = 'medium';
            } else {
                $risk_level = 'low';
            }
            
            $cell_class = 'risk-cell risk-' . $risk_level;
            
            // Check if this cell was selected
            if ($selected_matrix && isset($selected_matrix[$impact_key][$likelihood_key])) {
                $is_selected = true;
                $cell_class .= ' selected';
            }
            
            $html .= '<td class="' . $cell_class . '" data-impact="' . $impact_key . '" data-likelihood="' . $likelihood_key . '">';
            $html .= '<div class="form-check text-center">';
            $html .= '<input class="form-check-input risk-selector" type="checkbox" 
                            name="risk_assessment[' . $impact_key . '][' . $likelihood_key . ']" 
                            value="1" ' . ($is_selected ? 'checked' : '') . '>';
            $html .= '</div>';
            $html .= '</td>';
        }
        
        $html .= '</tr>';
    }
    
    $html .= '</tbody></table>';
    
    // Legend
    $html .= '<div class="risk-matrix-legend mt-3">';
    $html .= '<small class="text-muted">Legend: </small>';
    $html .= '<span class="badge bg-success me-2">Low Risk</span>';
    $html .= '<span class="badge bg-warning me-2">Medium Risk</span>';
    $html .= '<span class="badge bg-danger">High Risk</span>';
    $html .= '</div>';
    
    $html .= '</div>';
    
    return $html;
}

/**
 * Calculate overall risk level from risk matrix
 */
function calculate_overall_risk_level($risk_matrix) {
    if (empty($risk_matrix)) {
        return 'medium';
    }
    
    $high_risk_count = 0;
    $medium_risk_count = 0;
    $low_risk_count = 0;
    
    global $dpia_options;
    $impact_levels = array_keys($dpia_options['risk_assessment_matrix']['impact']);
    $likelihood_levels = array_keys($dpia_options['risk_assessment_matrix']['likelihood']);
    
    foreach ($risk_matrix as $impact_key => $likelihood_data) {
        foreach ($likelihood_data as $likelihood_key => $selected) {
            if ($selected) {
                $impact_index = array_search($impact_key, $impact_levels);
                $likelihood_index = array_search($likelihood_key, $likelihood_levels);
                $total_index = $impact_index + $likelihood_index;
                
                if ($total_index >= 6) {
                    $high_risk_count++;
                } elseif ($total_index >= 3) {
                    $medium_risk_count++;
                } else {
                    $low_risk_count++;
                }
            }
        }
    }
    
    if ($high_risk_count > 0) {
        return 'high';
    } elseif ($medium_risk_count > 0) {
        return 'medium';
    } else {
        return 'low';
    }
}

/**
 * Generate DPIA print HTML
 */
function generate_dpia_print_html($dpia_id) {
    global $dpia_options, $gdpr_options;
    $conn = create_db_connection();
    
    // Get DPIA with related activity info
    $stmt = $conn->prepare("
        SELECT d.*, g.processing_activity, g.purpose_of_processing, g.legal_basis, 
               g.categories_personal_data, g.categories_data_subjects,
               u.full_name as registered_by_name, a.full_name as approved_by_name
        FROM dpia_registrations d
        LEFT JOIN gdpr_register g ON d.record_id = g.id
        LEFT JOIN system_users u ON d.registered_by = u.id
        LEFT JOIN system_users a ON d.approved_by = a.id
        WHERE d.id = ?
    ");
    $stmt->bind_param("i", $dpia_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $dpia = $result->fetch_assoc();
    
    if (!$dpia) {
        return '<div class="alert alert-danger">DPIA not found</div>';
    }
    
    // Decode JSON fields
    $compliance_checklist = !empty($dpia['compliance_checklist']) ? json_decode($dpia['compliance_checklist'], true) : [];
    $risk_assessment_matrix = !empty($dpia['risk_assessment_matrix']) ? json_decode($dpia['risk_assessment_matrix'], true) : [];
    
    $html = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>DPIA - ' . htmlspecialchars($dpia['title']) . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; font-size: 12px; }
            .header { text-align: center; margin-bottom: 30px; }
            .header h1 { color: #2c3e50; margin-bottom: 5px; font-size: 18px; }
            .header h2 { color: #666; margin-bottom: 10px; font-size: 14px; }
            .header .print-date { color: #999; font-size: 11px; }
            .section { margin-bottom: 20px; border: 1px solid #ddd; padding: 15px; }
            .section-title { font-weight: bold; color: #2c3e50; border-bottom: 1px solid #eee; padding-bottom: 5px; margin-bottom: 10px; font-size: 14px; }
            .info-row { margin-bottom: 5px; }
            .info-label { font-weight: bold; display: inline-block; width: 200px; }
            .info-value { display: inline-block; }
            .risk-badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-weight: bold; margin-left: 10px; }
            .risk-high { background-color: #f8d7da; color: #721c24; }
            .risk-medium { background-color: #fff3cd; color: #856404; }
            .risk-low { background-color: #d4edda; color: #155724; }
            .approval-badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-weight: bold; }
            .approval-pending { background-color: #fff3cd; color: #856404; }
            .approval-approved { background-color: #d4edda; color: #155724; }
            .approval-rejected { background-color: #f8d7da; color: #721c24; }
            .checklist-item { margin-bottom: 3px; padding-left: 15px; position: relative; }
            .checklist-item:before { content: "✓"; position: absolute; left: 0; color: #28a745; }
            .risk-matrix { border-collapse: collapse; width: 100%; margin: 10px 0; }
            .risk-matrix th, .risk-matrix td { border: 1px solid #ddd; padding: 5px; text-align: center; }
            .risk-matrix th { background-color: #f8f9fa; font-weight: bold; }
            .risk-cell-high { background-color: #f8d7da; }
            .risk-cell-medium { background-color: #fff3cd; }
            .risk-cell-low { background-color: #d4edda; }
            .risk-cell-selected { border: 2px solid #000; }
            .footer { margin-top: 30px; text-align: center; color: #999; font-size: 10px; border-top: 1px solid #eee; padding-top: 10px; }
            @media print {
                .no-print { display: none !important; }
                .page-break { page-break-before: always; }
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Food Bank Almere</h1>
            <h2>Data Protection Impact Assessment (DPIA)</h2>
            <div class="print-date">Printed: ' . date('d-m-Y H:i') . '</div>
        </div>
        
        <div class="section">
            <div class="section-title">DPIA Information</div>
            <div class="info-row">
                <span class="info-label">DPIA ID:</span>
                <span class="info-value">#' . $dpia['id'] . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Title:</span>
                <span class="info-value"><strong>' . htmlspecialchars($dpia['title']) . '</strong></span>
            </div>
            <div class="info-row">
                <span class="info-label">Related Activity:</span>
                <span class="info-value">' . htmlspecialchars($dpia['processing_activity']) . ' (ID: #' . $dpia['record_id'] . ')</span>
            </div>
            <div class="info-row">
                <span class="info-label">Status:</span>
                <span class="info-value">' . get_status_badge($dpia['status']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Management Approval:</span>
                <span class="info-value">' . get_approval_badge($dpia['management_approval']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Overall Risk Level:</span>
                <span class="info-value">
                    <span class="risk-badge risk-' . $dpia['overall_risk_level'] . '">
                        ' . strtoupper($dpia['overall_risk_level']) . ' RISK
                    </span>
                </span>
            </div>
            <div class="info-row">
                <span class="info-label">Registered By:</span>
                <span class="info-value">' . htmlspecialchars($dpia['registered_by_name']) . ' on ' . format_date($dpia['registered_at'], 'd-m-Y') . '</span>
            </div>';
    
    if ($dpia['approved_by'] && $dpia['approval_date']) {
        $html .= '
            <div class="info-row">
                <span class="info-label">Approved By:</span>
                <span class="info-value">' . htmlspecialchars($dpia['approved_by_name']) . ' on ' . format_date($dpia['approval_date'], 'd-m-Y') . '</span>
            </div>';
    }
    
    $html .= '
        </div>
        
        <div class="section">
            <div class="section-title">Processing Activity Details</div>
            <div class="info-row">
                <span class="info-label">Purpose of Processing:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['purpose_of_processing'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Legal Basis:</span>
                <span class="info-value">' . ($gdpr_options['legal_bases'][$dpia['legal_basis']] ?? $dpia['legal_basis']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Data Subjects:</span>
                <span class="info-value">' . htmlspecialchars($dpia['categories_data_subjects']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Categories of Personal Data:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['categories_personal_data'])) . '</span>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">DPIA Description</div>
            <div class="info-row">
                <span class="info-label">Description:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['description'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Risk Origin:</span>
                <span class="info-value">' . ($dpia_options['risk_origins'][$dpia['risk_origin']] ?? $dpia['risk_origin']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Estimated Data Subjects Affected:</span>
                <span class="info-value">' . number_format($dpia['data_subjects_affected'], 0, ',', '.') . '</span>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Necessity and Proportionality Tests</div>
            <div class="info-row">
                <span class="info-label">Necessity Test:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['necessity_test'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Proportionality Test:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['proportionality_test'])) . '</span>
            </div>
        </div>';
    
    if (!empty($compliance_checklist)) {
        $html .= '
        <div class="section">
            <div class="section-title">Compliance Checklist</div>';
        
        foreach ($dpia_options['compliance_checklist'] as $key => $item) {
            if (in_array($key, $compliance_checklist)) {
                $html .= '<div class="checklist-item">' . htmlspecialchars($item) . '</div>';
            }
        }
        
        $html .= '</div>';
    }
    
    if (!empty($risk_assessment_matrix)) {
        $html .= '
        <div class="section">
            <div class="section-title">Risk Assessment Matrix</div>
            <table class="risk-matrix">
                <thead>
                    <tr><th>Impact/Likelihood</th>';
        
        foreach ($dpia_options['risk_assessment_matrix']['likelihood'] as $likelihood_label) {
            $html .= '<th>' . $likelihood_label . '</th>';
        }
        
        $html .= '</tr></thead><tbody>';
        
        foreach ($dpia_options['risk_assessment_matrix']['impact'] as $impact_key => $impact_label) {
            $html .= '<tr><th>' . $impact_label . '</th>';
            
            foreach ($dpia_options['risk_assessment_matrix']['likelihood'] as $likelihood_key => $likelihood_label) {
                $is_selected = isset($risk_assessment_matrix[$impact_key][$likelihood_key]) && $risk_assessment_matrix[$impact_key][$likelihood_key];
                $impact_index = array_search($impact_key, array_keys($dpia_options['risk_assessment_matrix']['impact']));
                $likelihood_index = array_search($likelihood_key, array_keys($dpia_options['risk_assessment_matrix']['likelihood']));
                $total_index = $impact_index + $likelihood_index;
                
                $cell_class = 'risk-cell-low';
                if ($total_index >= 6) {
                    $cell_class = 'risk-cell-high';
                } elseif ($total_index >= 3) {
                    $cell_class = 'risk-cell-medium';
                }
                
                if ($is_selected) {
                    $cell_class .= ' risk-cell-selected';
                }
                
                $html .= '<td class="' . $cell_class . '">';
                if ($is_selected) {
                    $html .= '✓';
                }
                $html .= '</td>';
            }
            
            $html .= '</tr>';
        }
        
        $html .= '</tbody></table></div>';
    }
    
    $html .= '
        <div class="section">
            <div class="section-title">Mitigation Measures & Residual Risk</div>
            <div class="info-row">
                <span class="info-label">Mitigation Measures:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['mitigation_measures'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Residual Risk:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['residual_risk'])) . '</span>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Consultation & Recommendations</div>
            <div class="info-row">
                <span class="info-label">Consultation Conducted:</span>
                <span class="info-value">' . ucfirst($dpia['consultation_conducted']) . '</span>
            </div>';
    
    if (!empty($dpia['consultation_details'])) {
        $html .= '
            <div class="info-row">
                <span class="info-label">Consultation Details:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['consultation_details'])) . '</span>
            </div>';
    }
    
    if (!empty($dpia['recommendations'])) {
        $html .= '
            <div class="info-row">
                <span class="info-label">Recommendations:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['recommendations'])) . '</span>
            </div>';
    }
    
    $html .= '
        </div>
        
        <div class="footer">
            Food Bank Almere - Data Protection Impact Assessment<br>
            DPIA ID: #' . $dpia['id'] . ' | Printed on ' . date('d-m-Y H:i') . '<br>
            Confidential - For authorized personnel only
        </div>
    </body>
    </html>';
    
    return $html;
}

// ============================================
// NEW SAFEGUARDS FUNCTIONS
// ============================================

/**
 * Generate HTML for clickable safeguards options
 */
function get_safeguards_options_html($type = 'technical', $selected = []) {
    global $safeguards_options;
    
    if (!isset($safeguards_options[$type])) {
        return '';
    }
    
    $html = '<div class="safeguards-options-container" id="' . $type . '-options">';
    $html .= '<div class="safeguards-search mb-2">';
    $html .= '<input type="text" class="form-control form-control-sm safeguards-search-input" 
                     placeholder="Search ' . ucfirst($type) . ' measures..." 
                     data-type="' . $type . '">';
    $html .= '</div>';
    $html .= '<div class="safeguards-list ' . $type . '-list" style="max-height: 200px; overflow-y: auto;">';
    
    foreach ($safeguards_options[$type] as $index => $measure) {
        $is_selected = in_array($measure, $selected);
        $html .= '<div class="form-check safeguards-item">';
        $html .= '<input class="form-check-input safeguards-checkbox" type="checkbox" 
                        value="' . htmlspecialchars($measure) . '" 
                        id="' . $type . '_' . $index . '"
                        data-type="' . $type . '"
                        ' . ($is_selected ? 'checked' : '') . '>';
        $html .= '<label class="form-check-label" for="' . $type . '_' . $index . '">';
        $html .= htmlspecialchars($measure);
        $html .= '</label>';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    $html .= '<button type="button" class="btn btn-sm btn-primary mt-2 add-selected-safeguards" 
                      data-type="' . $type . '">
                <i class="bi bi-plus-circle"></i> Add Selected to Textarea
              </button>';
    $html .= '</div>';
    
    return $html;
}

/**
 * Parse safeguards text into array
 */
function parse_safeguards_text($text) {
    if (empty($text)) {
        return ['technical' => [], 'organizational' => []];
    }
    
    $technical = [];
    $organizational = [];
    
    // Split by newlines and filter out empty lines
    $lines = array_filter(explode("\n", $text), function($line) {
        return trim($line) !== '';
    });
    
    foreach ($lines as $line) {
        $line = trim($line);
        // Check if this is a technical or organizational measure
        global $safeguards_options;
        
        if (in_array($line, $safeguards_options['technical'])) {
            $technical[] = $line;
        } elseif (in_array($line, $safeguards_options['organizational'])) {
            $organizational[] = $line;
        }
    }
    
    return [
        'technical' => $technical,
        'organizational' => $organizational
    ];
}


function show_changes_details($log_id) {
    global $encrypted_columns;
    $conn = create_db_connection();
    
    // Get the audit log entry
    $stmt = $conn->prepare("
        SELECT s.*, u.full_name as user_name, u.username
        FROM system_changes s
        LEFT JOIN system_users u ON s.changed_by = u.id
        WHERE s.id = ?
    ");
    $stmt->bind_param("i", $log_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $log = $result->fetch_assoc();
    
    if (!$log) {
        return '<div class="alert alert-danger">Log entry not found</div>';
    }
    
    $html = '<div class="changes-container">';
    
    // Basic info
    $html .= '<div class="row mb-4">';
    $html .= '<div class="col-md-4"><strong>User:</strong> ' . htmlspecialchars($log['user_name'] ?? 'Deleted User') . '</div>';
    $html .= '<div class="col-md-4"><strong>Action:</strong> ' . htmlspecialchars($log['action']) . '</div>';
    $html .= '<div class="col-md-4"><strong>Time:</strong> ' . format_date($log['changed_at']) . '</div>';
    $html .= '</div>';
    
    $html .= '<div class="row mb-4">';
    $html .= '<div class="col-md-4"><strong>Table:</strong> ' . htmlspecialchars($log['table_name']) . '</div>';
    $html .= '<div class="col-md-4"><strong>Record ID:</strong> #' . htmlspecialchars($log['record_id']) . '</div>';
    $html .= '<div class="col-md-4"><strong>IP:</strong> ' . htmlspecialchars($log['user_ip']) . '</div>';
    $html .= '</div>';
    
    // Parse old and new data
    $old_data = !empty($log['old_data']) ? json_decode($log['old_data'], true) : [];
    $new_data = !empty($log['new_data']) ? json_decode($log['new_data'], true) : [];
    
    // For encrypted fields, try to decrypt
    if (is_array($old_data)) {
        foreach ($encrypted_columns as $field) {
            if (isset($old_data[$field]) && !empty($old_data[$field])) {
                $old_data[$field] = decrypt_data($old_data[$field]);
            }
        }
    }
    
    if (is_array($new_data)) {
        foreach ($encrypted_columns as $field) {
            if (isset($new_data[$field]) && !empty($new_data[$field])) {
                $new_data[$field] = decrypt_data($new_data[$field]);
            }
        }
    }
    
    if ($log['action'] == 'UPDATE') {
        // Show changes for UPDATE
        $html .= '<h6 class="mt-4 mb-3">Changes Made:</h6>';
        
        if (!empty($log['changed_fields'])) {
            $changed_fields = explode(', ', $log['changed_fields']);
            $html .= '<div class="changes-list">';
            
            foreach ($changed_fields as $field) {
                $field = trim($field);
                $old_value = $old_data[$field] ?? '';
                $new_value = $new_data[$field] ?? '';
                
                $html .= '<div class="change-item mb-3 p-3 border rounded">';
                $html .= '<div class="change-field mb-1">' . htmlspecialchars($field) . '</div>';
                
                if ($old_value != $new_value) {
                    $html .= '<div class="row">';
                    $html .= '<div class="col-md-6">';
                    $html .= '<small class="text-muted">Old Value:</small><br>';
                    $html .= '<div class="change-old p-2">' . nl2br(htmlspecialchars($old_value)) . '</div>';
                    $html .= '</div>';
                    $html .= '<div class="col-md-6">';
                    $html .= '<small class="text-muted">New Value:</small><br>';
                    $html .= '<div class="change-new p-2">' . nl2br(htmlspecialchars($new_value)) . '</div>';
                    $html .= '</div>';
                    $html .= '</div>';
                } else {
                    $html .= '<div class="text-muted">No change in value</div>';
                }
                
                $html .= '</div>';
            }
            $html .= '</div>';
        } else {
            $html .= '<div class="alert alert-info">No specific fields changed</div>';
        }
        
    } elseif ($log['action'] == 'INSERT') {
        // Show all data for INSERT
        $html .= '<h6 class="mt-4 mb-3">New Record Created:</h6>';
        $html .= '<div class="changes-list">';
        
        if (is_array($new_data) && count($new_data) > 0) {
            foreach ($new_data as $field => $value) {
                $html .= '<div class="change-item mb-2 p-2 border rounded">';
                $html .= '<div class="change-field mb-1">' . htmlspecialchars($field) . '</div>';
                $html .= '<div class="change-new p-2">' . nl2br(htmlspecialchars($value)) . '</div>';
                $html .= '</div>';
            }
        } else {
            $html .= '<div class="alert alert-info">No data available</div>';
        }
        $html .= '</div>';
        
    } elseif ($log['action'] == 'DELETE') {
        // Show deleted data
        $html .= '<h6 class="mt-4 mb-3">Record Deleted:</h6>';
        $html .= '<div class="changes-list">';
        
        if (is_array($old_data) && count($old_data) > 0) {
            foreach ($old_data as $field => $value) {
                $html .= '<div class="change-item mb-2 p-2 border rounded">';
                $html .= '<div class="change-field mb-1">' . htmlspecialchars($field) . '</div>';
                $html .= '<div class="change-old p-2">' . nl2br(htmlspecialchars($value)) . '</div>';
                $html .= '</div>';
            }
        } else {
            $html .= '<div class="alert alert-info">No data available</div>';
        }
        $html .= '</div>';
    }
    
    $html .= '</div>'; // Close changes-container
    
    return $html;
}

/**
 * Generate safeguards text from arrays
 */
function generate_safeguards_text($technical_measures, $organizational_measures) {
    $lines = [];
    
    if (!empty($technical_measures)) {
        $lines = array_merge($lines, $technical_measures);
    }
    
    if (!empty($organizational_measures)) {
        $lines = array_merge($lines, $organizational_measures);
    }
    
    return implode("\n", $lines);
}

/**
 * Auto-populate safeguards based on technical and organizational measures
 */
function auto_populate_safeguards($technical_measures_text, $organizational_measures_text) {
    $technical_lines = array_filter(explode("\n", $technical_measures_text), function($line) {
        return trim($line) !== '';
    });
    
    $organizational_lines = array_filter(explode("\n", $organizational_measures_text), function($line) {
        return trim($line) !== '';
    });
    
    $all_measures = array_merge($technical_lines, $organizational_lines);
    
    return implode("\n", $all_measures);
}


// ============================================
// PRINT FUNCTIONS
// ============================================

/**
 * Generate printable summary of all processing activities
 */
function generate_all_activities_print_html() {
    global $gdpr_options, $encrypted_columns;
    $conn = create_db_connection();
    
    // Get all activities with decrypted fields
    $stmt = $conn->prepare("SELECT * FROM gdpr_register ORDER BY department, processing_activity");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $html = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>GDPR Processing Activities Summary - Food Bank Almere</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; font-size: 12px; }
            .header { text-align: center; margin-bottom: 30px; }
            .header h1 { color: #2c3e50; margin-bottom: 5px; }
            .header .subtitle { color: #666; margin-bottom: 20px; }
            .header .print-date { color: #999; font-size: 11px; }
            .activity { margin-bottom: 25px; border: 1px solid #ddd; padding: 15px; page-break-inside: avoid; }
            .activity-header { background-color: #f8f9fa; padding: 10px; margin: -15px -15px 15px -15px; border-bottom: 1px solid #ddd; }
            .activity-id { font-weight: bold; color: #2c3e50; }
            .section { margin-bottom: 15px; }
            .section-title { font-weight: bold; color: #2c3e50; border-bottom: 1px solid #eee; padding-bottom: 5px; margin-bottom: 8px; }
            .field { margin-bottom: 5px; }
            .field-label { font-weight: bold; display: inline-block; width: 200px; }
            .field-value { display: inline-block; }
            .risk-badge { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; }
            .risk-high { background-color: #f8d7da; color: #721c24; }
            .risk-medium { background-color: #fff3cd; color: #856404; }
            .risk-low { background-color: #d4edda; color: #155724; }
            .status-badge { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; }
            .status-active { background-color: #d4edda; color: #155724; }
            .status-inactive { background-color: #e2e3e5; color: #383d41; }
            .status-archived { background-color: #cce5ff; color: #004085; }
            .status-review { background-color: #fff3cd; color: #856404; }
            .page-break { page-break-before: always; }
            .footer { margin-top: 30px; text-align: center; color: #999; font-size: 10px; border-top: 1px solid #eee; padding-top: 10px; }
            @media print {
                .page-break { page-break-before: always; }
                .no-print { display: none; }
            }
            .summary-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            .summary-table th { background-color: #f8f9fa; text-align: left; padding: 8px; border: 1px solid #ddd; }
            .summary-table td { padding: 8px; border: 1px solid #ddd; }
            .department-header { background-color: #2c3e50; color: white; padding: 10px; margin: 20px 0 10px 0; border-radius: 3px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Food Bank Almere</h1>
            <div class="subtitle">GDPR Processing Activities Register - Complete Summary</div>
            <div class="print-date">Printed: ' . date('d-m-Y H:i') . '</div>
        </div>';
    
    $current_dept = '';
    $activity_count = 0;
    
    while ($row = $result->fetch_assoc()) {
        // Decrypt encrypted fields
        foreach ($encrypted_columns as $field) {
            if (!empty($row[$field])) {
                $row[$field] = decrypt_data($row[$field]);
            }
        }
        
        // Check if department changed
        if ($row['department'] != $current_dept) {
            if ($current_dept != '') {
                $html .= '</div>';
            }
            $current_dept = $row['department'];
            $dept_name = $gdpr_options['departments'][$current_dept] ?? ucfirst($current_dept);
            $html .= '<div class="department-header">' . htmlspecialchars($dept_name) . ' Department</div>';
        }
        
        $activity_count++;
        
        $html .= '
        <div class="activity">
            <div class="activity-header">
                <span class="activity-id">Activity #' . $row['id'] . '</span> - 
                <strong>' . htmlspecialchars($row['processing_activity']) . '</strong>
                <span class="risk-badge risk-' . $row['risk_level'] . '" style="float: right;">
                    ' . strtoupper($row['risk_level']) . ' RISK
                </span>
            </div>
            
            <div class="section">
                <div class="section-title">Basic Information</div>
                <div class="field">
                    <span class="field-label">Department:</span>
                    <span class="field-value">' . ($gdpr_options['departments'][$row['department']] ?? $row['department']) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Status:</span>
                    <span class="field-value">' . ($gdpr_options['status_options'][$row['status']] ?? $row['status']) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Created:</span>
                    <span class="field-value">' . format_date($row['created_at'], 'd-m-Y') . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Last Updated:</span>
                    <span class="field-value">' . format_date($row['updated_at'], 'd-m-Y') . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Review Due Date:</span>
                    <span class="field-value">' . (!empty($row['review_due_date']) && $row['review_due_date'] != '0000-00-00' ? format_date($row['review_due_date'], 'd-m-Y') : 'Not set') . '</span>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Processing Details</div>
                <div class="field">
                    <span class="field-label">Purpose:</span>
                    <span class="field-value">' . nl2br(htmlspecialchars($row['purpose_of_processing'])) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Legal Basis:</span>
                    <span class="field-value">' . ($gdpr_options['legal_bases'][$row['legal_basis']] ?? $row['legal_basis']) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Categories of Personal Data:</span>
                    <span class="field-value">' . nl2br(htmlspecialchars($row['categories_personal_data'])) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Data Subjects:</span>
                    <span class="field-value">' . htmlspecialchars($row['categories_data_subjects']) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Recipients:</span>
                    <span class="field-value">' . htmlspecialchars($row['categories_recipients']) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Retention Period:</span>
                    <span class="field-value">' . htmlspecialchars($row['retention_periods']) . '</span>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Security Measures</div>
                <div class="field">
                    <span class="field-label">Technical Measures:</span>
                    <span class="field-value">' . nl2br(htmlspecialchars($row['technical_measures'])) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Organizational Measures:</span>
                    <span class="field-value">' . nl2br(htmlspecialchars($row['organizational_measures'])) . '</span>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">DPIA & International Transfers</div>
                <div class="field">
                    <span class="field-label">DPIA Required:</span>
                    <span class="field-value">' . ($row['dpia_required'] == 'yes' ? 'Yes' : 'No') . '</span>
                </div>
                <div class="field">
                    <span class="field-label">DPIA Status:</span>
                    <span class="field-value">' . ($gdpr_options['dpia_statuses'][$row['dpia_status']] ?? $row['dpia_status']) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">International Data Transfers:</span>
                    <span class="field-value">' . ucfirst($row['is_international_data_transfers']) . '</span>
                </div>';
        
        if ($row['is_international_data_transfers'] == 'yes') {
            $html .= '
                <div class="field">
                    <span class="field-label">To Country:</span>
                    <span class="field-value">' . ($gdpr_options['countries'][$row['to_country']] ?? $row['to_country']) . '</span>
                </div>
                <div class="field">
                    <span class="field-label">Safeguards:</span>
                    <span class="field-value">' . nl2br(htmlspecialchars($row['safeguards'])) . '</span>
                </div>';
        }
        
        $html .= '
            </div>
        </div>';
        
        // Add page break every 3 activities
        if ($activity_count % 3 == 0) {
            $html .= '<div class="page-break"></div>';
        }
    }
    
    if ($current_dept != '') {
        $html .= '</div>';
    }
    
    // Add summary at the end
    $html .= '
        <div class="page-break"></div>
        <div class="header">
            <h2>Summary Report</h2>
            <div class="print-date">Generated: ' . date('d-m-Y H:i') . '</div>
        </div>
        
        <table class="summary-table">
            <thead>
                <tr>
                    <th>Department</th>
                    <th>Total Activities</th>
                    <th>High Risk</th>
                    <th>Medium Risk</th>
                    <th>Low Risk</th>
                    <th>DPIA Required</th>
                </tr>
            </thead>
            <tbody>';
    
    // Get summary by department
    $conn = create_db_connection();
    $summary_result = $conn->query("
        SELECT department,
               COUNT(*) as total,
               SUM(CASE WHEN risk_level = 'high' THEN 1 ELSE 0 END) as high_risk,
               SUM(CASE WHEN risk_level = 'medium' THEN 1 ELSE 0 END) as medium_risk,
               SUM(CASE WHEN risk_level = 'low' THEN 1 ELSE 0 END) as low_risk,
               SUM(CASE WHEN dpia_required = 'yes' THEN 1 ELSE 0 END) as dpia_required
        FROM gdpr_register
        GROUP BY department
        ORDER BY department
    ");
    
    $grand_total = 0;
    $grand_high = 0;
    $grand_medium = 0;
    $grand_low = 0;
    $grand_dpia = 0;
    
    while ($summary = $summary_result->fetch_assoc()) {
        $dept_name = $gdpr_options['departments'][$summary['department']] ?? ucfirst($summary['department']);
        $html .= '
            <tr>
                <td>' . htmlspecialchars($dept_name) . '</td>
                <td>' . $summary['total'] . '</td>
                <td>' . $summary['high_risk'] . '</td>
                <td>' . $summary['medium_risk'] . '</td>
                <td>' . $summary['low_risk'] . '</td>
                <td>' . $summary['dpia_required'] . '</td>
            </tr>';
        
        $grand_total += $summary['total'];
        $grand_high += $summary['high_risk'];
        $grand_medium += $summary['medium_risk'];
        $grand_low += $summary['low_risk'];
        $grand_dpia += $summary['dpia_required'];
    }
    
    $html .= '
            <tr style="font-weight: bold; background-color: #f8f9fa;">
                <td>TOTAL</td>
                <td>' . $grand_total . '</td>
                <td>' . $grand_high . '</td>
                <td>' . $grand_medium . '</td>
                <td>' . $grand_low . '</td>
                <td>' . $grand_dpia . '</td>
            </tr>
        </tbody>
    </table>
    
    <div class="footer">
        Food Bank Almere - GDPR Compliance System<br>
        Generated on ' . date('d-m-Y H:i') . '<br>
        Confidential - For internal use only
    </div>
    
    </body>
    </html>';
    
    return $html;
}

/**
 * Generate printable summary of a single processing activity
 */
function generate_single_activity_print_html($activity_id) {
    global $gdpr_options, $encrypted_columns;
    $conn = create_db_connection();
    
    // Get activity with decrypted fields
    $stmt = $conn->prepare("SELECT * FROM gdpr_register WHERE id = ?");
    $stmt->bind_param("i", $activity_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    if (!$row) {
        return '<div class="alert alert-danger">Activity not found</div>';
    }
    
    // Decrypt encrypted fields
    foreach ($encrypted_columns as $field) {
        if (!empty($row[$field])) {
            $row[$field] = decrypt_data($row[$field]);
        }
    }
    
    // Get DPIA info if exists
    $dpia_stmt = $conn->prepare("SELECT * FROM dpia_registrations WHERE record_id = ?");
    $dpia_stmt->bind_param("i", $activity_id);
    $dpia_stmt->execute();
    $dpia_result = $dpia_stmt->get_result();
    $dpia = $dpia_result->fetch_assoc();
    
    $html = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>GDPR Processing Activity - ' . htmlspecialchars($row['processing_activity']) . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; font-size: 12px; }
            .header { text-align: center; margin-bottom: 30px; }
            .header h1 { color: #2c3e50; margin-bottom: 5px; font-size: 18px; }
            .header h2 { color: #666; margin-bottom: 10px; font-size: 14px; }
            .header .print-date { color: #999; font-size: 11px; }
            .activity-info { margin-bottom: 20px; }
            .info-row { margin-bottom: 5px; }
            .info-label { font-weight: bold; display: inline-block; width: 200px; }
            .info-value { display: inline-block; }
            .section { margin-bottom: 20px; border: 1px solid #ddd; padding: 15px; }
            .section-title { font-weight: bold; color: #2c3e50; border-bottom: 1px solid #eee; padding-bottom: 5px; margin-bottom: 10px; font-size: 14px; }
            .content { line-height: 1.5; }
            .risk-badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-weight: bold; margin-left: 10px; }
            .risk-high { background-color: #f8d7da; color: #721c24; }
            .risk-medium { background-color: #fff3cd; color: #856404; }
            .risk-low { background-color: #d4edda; color: #155724; }
            .safeguards-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 10px; margin-top: 10px; }
            .safeguard-item { background-color: #f8f9fa; padding: 8px; border-left: 3px solid #007bff; font-size: 11px; }
            .footer { margin-top: 30px; text-align: center; color: #999; font-size: 10px; border-top: 1px solid #eee; padding-top: 10px; }
            @media print {
                .no-print { display: none; }
            }
            .qr-code-area { text-align: center; margin: 20px 0; padding: 15px; border: 1px dashed #ddd; }
            .qr-instructions { font-size: 10px; color: #666; margin-top: 10px; }
            .label-container { border: 2px solid #000; padding: 15px; margin: 20px 0; }
            .label-title { font-weight: bold; font-size: 14px; text-align: center; margin-bottom: 10px; }
            .label-content { font-size: 11px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Food Bank Almere</h1>
            <h2>GDPR Processing Activity</h2>
            <div class="print-date">Printed: ' . date('d-m-Y H:i') . '</div>
        </div>
        
        <div class="activity-info">
            <div class="info-row">
                <span class="info-label">Activity ID:</span>
                <span class="info-value">#' . $row['id'] . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Activity Name:</span>
                <span class="info-value"><strong>' . htmlspecialchars($row['processing_activity']) . '</strong>
                <span class="risk-badge risk-' . $row['risk_level'] . '">' . strtoupper($row['risk_level']) . ' RISK</span></span>
            </div>
            <div class="info-row">
                <span class="info-label">Department:</span>
                <span class="info-value">' . ($gdpr_options['departments'][$row['department']] ?? $row['department']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Status:</span>
                <span class="info-value">' . ($gdpr_options['status_options'][$row['status']] ?? $row['status']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Created:</span>
                <span class="info-value">' . format_date($row['created_at'], 'd-m-Y H:i') . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Last Updated:</span>
                <span class="info-value">' . format_date($row['updated_at'], 'd-m-Y H:i') . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Review Due Date:</span>
                <span class="info-value">' . (!empty($row['review_due_date']) && $row['review_due_date'] != '0000-00-00' ? format_date($row['review_due_date'], 'd-m-Y') : 'Not set') . '</span>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Purpose of Processing</div>
            <div class="content">' . nl2br(htmlspecialchars($row['purpose_of_processing'])) . '</div>
        </div>
        
        <div class="section">
            <div class="section-title">Legal Basis & Details</div>
            <div class="info-row">
                <span class="info-label">Legal Basis:</span>
                <span class="info-value">' . ($gdpr_options['legal_bases'][$row['legal_basis']] ?? $row['legal_basis']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Categories of Personal Data:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($row['categories_personal_data'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Data Subjects:</span>
                <span class="info-value">' . htmlspecialchars($row['categories_data_subjects']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Recipients:</span>
                <span class="info-value">' . htmlspecialchars($row['categories_recipients']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Retention Period:</span>
                <span class="info-value">' . htmlspecialchars($row['retention_periods']) . '</span>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Security Measures</div>
            <div class="info-row">
                <span class="info-label">Technical Measures:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($row['technical_measures'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Organizational Measures:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($row['organizational_measures'])) . '</span>
            </div>
        </div>';
    
    if (!empty($row['safeguards'])) {
        $html .= '
        <div class="section">
            <div class="section-title">Safeguards for International Data Transfers</div>
            <div class="safeguards-grid">';
        
        $safeguards = explode("\n", $row['safeguards']);
        foreach ($safeguards as $safeguard) {
            $safeguard = trim($safeguard);
            if (!empty($safeguard)) {
                $html .= '<div class="safeguard-item">' . htmlspecialchars($safeguard) . '</div>';
            }
        }
        
        $html .= '
            </div>
        </div>';
    }
    
    if ($dpia) {
        // Decode JSON fields
        $compliance_checklist = !empty($dpia['compliance_checklist']) ? json_decode($dpia['compliance_checklist'], true) : [];
        $risk_assessment_matrix = !empty($dpia['risk_assessment_matrix']) ? json_decode($dpia['risk_assessment_matrix'], true) : [];
        
        $html .= '
        <div class="section">
            <div class="section-title">Data Protection Impact Assessment (DPIA)</div>
            <div class="info-row">
                <span class="info-label">DPIA Status:</span>
                <span class="info-value">' . ucfirst($dpia['status']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Overall Risk Level:</span>
                <span class="info-value">' . ucfirst($dpia['overall_risk_level']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Management Approval:</span>
                <span class="info-value">' . ucfirst($dpia['management_approval']) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Description:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['description'])) . '</span>
            </div>';
        
        if (!empty($dpia['processing_activity_description'])) {
            $html .= '
            <div class="info-row">
                <span class="info-label">Processing Activity Description:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['processing_activity_description'])) . '</span>
            </div>';
        }
        
        $html .= '
            <div class="info-row">
                <span class="info-label">Necessity Test:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['necessity_test'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Proportionality Test:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['proportionality_test'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Mitigation Measures:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['mitigation_measures'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Residual Risk:</span>
                <span class="info-value">' . nl2br(htmlspecialchars($dpia['residual_risk'])) . '</span>
            </div>
            <div class="info-row">
                <span class="info-label">Review Date:</span>
                <span class="info-value">' . (!empty($dpia['review_date']) ? format_date($dpia['review_date'], 'd-m-Y') : 'Not set') . '</span>
            </div>
        </div>';
    }
    
    // Safeguards label for printing
    if (!empty($row['safeguards'])) {
        $html .= '
        <div class="page-break"></div>
        <div class="label-container">
            <div class="label-title">SAFEGUARDS LABEL - ' . htmlspecialchars($row['processing_activity']) . '</div>
            <div class="label-content">
                <div class="info-row">
                    <span class="info-label">Activity ID:</span>
                    <span class="info-value">#' . $row['id'] . '</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Risk Level:</span>
                    <span class="info-value"><strong>' . strtoupper($row['risk_level']) . '</strong></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Department:</span>
                    <span class="info-value">' . ($gdpr_options['departments'][$row['department']] ?? $row['department']) . '</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Last Review:</span>
                    <span class="info-value">' . format_date($row['updated_at'], 'd-m-Y') . '</span>
                </div>
                <hr>
                <div><strong>IMPLEMENTED SAFEGUARDS:</strong></div>';
        
        $safeguards = explode("\n", $row['safeguards']);
        $counter = 1;
        foreach ($safeguards as $safeguard) {
            $safeguard = trim($safeguard);
            if (!empty($safeguard)) {
                $html .= '<div>' . $counter . '. ' . htmlspecialchars($safeguard) . '</div>';
                $counter++;
            }
        }
        
        $html .= '
                <hr>
                <div class="qr-code-area">
                    <div style="margin: 10px 0; padding: 5px; border: 1px solid #ccc; display: inline-block;">
                        [QR CODE AREA - Scan for details]
                    </div>
                    <div class="qr-instructions">
                        Scan this QR code to view complete activity details in the GDPR system
                    </div>
                </div>
            </div>
        </div>';
    }
    
    $html .= '
        <div class="footer">
            Food Bank Almere - GDPR Compliance System<br>
            Activity ID: #' . $row['id'] . ' | Printed on ' . date('d-m-Y H:i') . '<br>
            Confidential - For authorized personnel only
        </div>
    </body>
    </html>';
    
    return $html;
}

/**
 * Generate printable safeguards label for an activity
 */
function generate_safeguards_label_html($activity_id) {
    global $gdpr_options, $encrypted_columns;
    $conn = create_db_connection();
    
    // Get activity with decrypted fields
    $stmt = $conn->prepare("SELECT * FROM gdpr_register WHERE id = ?");
    $stmt->bind_param("i", $activity_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    if (!$row) {
        return '<div class="alert alert-danger">Activity not found</div>';
    }
    
    // Decrypt encrypted fields
    foreach ($encrypted_columns as $field) {
        if (!empty($row[$field])) {
            $row[$field] = decrypt_data($row[$field]);
        }
    }
    
    $html = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Safeguards Label - ' . htmlspecialchars($row['processing_activity']) . '</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 10mm; font-size: 10pt; }
            @media print {
                body { padding: 5mm; }
            }
            .label { 
                width: 100mm; 
                height: 148mm; 
                border: 2px solid #000;
                padding: 5mm;
                box-sizing: border-box;
                position: relative;
            }
            .label-header { 
                text-align: center; 
                border-bottom: 1px solid #000;
                padding-bottom: 3mm;
                margin-bottom: 3mm;
            }
            .label-title { 
                font-weight: bold; 
                font-size: 12pt;
                margin-bottom: 2mm;
            }
            .label-subtitle {
                font-size: 9pt;
                color: #666;
            }
            .label-section { 
                margin-bottom: 4mm;
                border-bottom: 1px dashed #ccc;
                padding-bottom: 2mm;
            }
            .section-title { 
                font-weight: bold; 
                font-size: 9pt;
                margin-bottom: 1mm;
                background-color: #f0f0f0;
                padding: 1mm 2mm;
            }
            .info-row { 
                margin-bottom: 1mm;
                font-size: 8pt;
            }
            .info-label { 
                font-weight: bold; 
                display: inline-block;
                width: 25mm;
            }
            .info-value { 
                display: inline-block;
            }
            .safeguards-list {
                max-height: 60mm;
                overflow-y: auto;
                font-size: 7pt;
                padding: 2mm;
                background-color: #f9f9f9;
                border: 1px solid #ddd;
            }
            .safeguard-item {
                margin-bottom: 1mm;
                padding-left: 2mm;
                border-left: 2px solid #007bff;
            }
            .qr-area {
                text-align: center;
                margin-top: 3mm;
                padding-top: 3mm;
                border-top: 1px dashed #000;
            }
            .qr-code {
                display: inline-block;
                padding: 2mm;
                border: 1px solid #ccc;
                background-color: white;
            }
            .qr-instruction {
                font-size: 6pt;
                color: #666;
                margin-top: 1mm;
            }
            .footer {
                position: absolute;
                bottom: 3mm;
                left: 5mm;
                right: 5mm;
                font-size: 6pt;
                color: #999;
                text-align: center;
                border-top: 1px solid #eee;
                padding-top: 1mm;
            }
            .risk-indicator {
                display: inline-block;
                padding: 1mm 3mm;
                border-radius: 2mm;
                font-weight: bold;
                font-size: 8pt;
                margin-left: 2mm;
            }
            .risk-high { background-color: #f8d7da; color: #721c24; }
            .risk-medium { background-color: #fff3cd; color: #856404; }
            .risk-low { background-color: #d4edda; color: #155724; }
        </style>
    </head>
    <body>
        <div class="label">
            <div class="label-header">
                <div class="label-title">SAFEGUARDS LABEL</div>
                <div class="label-subtitle">Food Bank Almere - GDPR Compliance</div>
            </div>
            
            <div class="label-section">
                <div class="section-title">ACTIVITY INFORMATION</div>
                <div class="info-row">
                    <span class="info-label">ID:</span>
                    <span class="info-value">#' . $row['id'] . '</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Name:</span>
                    <span class="info-value">' . htmlspecialchars($row['processing_activity']) . '
                    <span class="risk-indicator risk-' . $row['risk_level'] . '">' . strtoupper($row['risk_level']) . '</span></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Department:</span>
                    <span class="info-value">' . ($gdpr_options['departments'][$row['department']] ?? $row['department']) . '</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Status:</span>
                    <span class="info-value">' . ($gdpr_options['status_options'][$row['status']] ?? $row['status']) . '</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Last Updated:</span>
                    <span class="info-value">' . format_date($row['updated_at'], 'd-m-Y') . '</span>
                </div>
            </div>';
    
    if (!empty($row['safeguards'])) {
        $html .= '
            <div class="label-section">
                <div class="section-title">IMPLEMENTED SAFEGUARDS</div>
                <div class="safeguards-list">';
        
        $safeguards = explode("\n", $row['safeguards']);
        $counter = 1;
        foreach ($safeguards as $safeguard) {
            $safeguard = trim($safeguard);
            if (!empty($safeguard)) {
                $html .= '<div class="safeguard-item"><strong>' . $counter . '.</strong> ' . htmlspecialchars($safeguard) . '</div>';
                $counter++;
            }
        }
        
        $html .= '
                </div>
            </div>';
    }
    
    $html .= '
            <div class="qr-area">
                <div class="qr-code">
                    [QR CODE]<br>
                    <span style="font-size: 6pt;">Scan for details</span>
                </div>
                <div class="qr-instruction">
                    Scan QR code to access complete activity information<br>
                    in the GDPR Compliance System
                </div>
            </div>
            
            <div class="footer">
                Food Bank Almere GDPR System<br>
                Label generated: ' . date('d-m-Y H:i') . ' | Activity ID: #' . $row['id'] . '
            </div>
        </div>
    </body>
    </html>';
    
    return $html;
}

/**
 * Print all activities summary
 */
function print_all_activities() {
    if (!has_permission('print_reports')) {
        die('Access denied');
    }
    
    global $current_user;
    $html = generate_all_activities_print_html();
    
    // Log the print action
    log_activity('system', 0, 'PRINT', null, ['type' => 'all_activities_summary'], 'Printed all activities summary');
    
    echo $html;
    exit;
}

/**
 * Print single activity
 */
function print_single_activity($activity_id) {
    if (!has_permission('print_reports')) {
        die('Access denied');
    }
    
    global $current_user;
    $html = generate_single_activity_print_html($activity_id);
    
    // Log the print action
    log_activity('gdpr_register', $activity_id, 'PRINT', null, null, 'Printed activity details');
    
    echo $html;
    exit;
}

/**
 * Print safeguards label
 */
function print_safeguards_label($activity_id) {
    if (!has_permission('print_reports')) {
        die('Access denied');
    }
    
    global $current_user;
    $html = generate_safeguards_label_html($activity_id);
    
    // Log the print action
    log_activity('gdpr_register', $activity_id, 'PRINT', null, null, 'Printed safeguards label');
    
    echo $html;
    exit;
}

/**
 * Print DPIA report
 */
function print_dpia_report($dpia_id) {
    if (!has_permission('print_reports')) {
        die('Access denied');
    }
    
    global $current_user;
    $html = generate_dpia_print_html($dpia_id);
    
    // Log the print action
    log_activity('dpia_registrations', $dpia_id, 'PRINT', null, null, 'Printed DPIA report');
    
    echo $html;
    exit;
}

/**
 * Safe DPIA insert/update function that handles missing columns
 */
function safe_dpia_query($conn, $data, $is_edit = false, $dpia_id = 0) {
    // Define all possible columns
    $all_columns = [
        'record_id', 'title', 'description', 'processing_activity_description', 
        'risk_origin', 'necessity_test', 'proportionality_test', 'data_subjects_affected',
        'data_categories', 'compliance_checklist', 'risk_assessment_matrix',
        'mitigation_measures', 'residual_risk', 'consultation_conducted', 'consultation_details',
        'recommendations', 'overall_risk_level', 'status', 'management_approval',
        'approved_by', 'approval_date', 'registered_by', 'review_date', 'notes'
    ];
    
    // Filter columns that exist in the database
    $existing_columns = [];
    foreach ($all_columns as $column) {
        if (column_exists('dpia_registrations', $column)) {
            $existing_columns[] = $column;
        }
    }
    
    // Ensure required columns exist
    $required_columns = ['record_id', 'title', 'description', 'necessity_test', 
                        'proportionality_test', 'mitigation_measures', 'residual_risk', 
                        'overall_risk_level', 'status', 'registered_by'];
    
    foreach ($required_columns as $col) {
        if (!in_array($col, $existing_columns)) {
            // Try to add missing column
            $column_definitions = [
                'record_id' => "INT NOT NULL",
                'title' => "VARCHAR(255) NOT NULL DEFAULT 'DPIA Assessment'",
                'description' => "TEXT DEFAULT NULL",
                'processing_activity_description' => "TEXT DEFAULT NULL",
                'risk_origin' => "ENUM('new_technology','large_scale','sensitive_data','systematic_monitoring','combination_datasets','vulnerable_groups','other') DEFAULT 'other'",
                'necessity_test' => "TEXT DEFAULT NULL",
                'proportionality_test' => "TEXT DEFAULT NULL",
                'data_subjects_affected' => "INT DEFAULT 0",
                'data_categories' => "TEXT DEFAULT NULL",
                'compliance_checklist' => "JSON DEFAULT NULL",
                'risk_assessment_matrix' => "JSON DEFAULT NULL",
                'mitigation_measures' => "TEXT DEFAULT NULL",
                'residual_risk' => "TEXT DEFAULT NULL",
                'consultation_conducted' => "ENUM('yes','no','planned') DEFAULT 'no'",
                'consultation_details' => "TEXT DEFAULT NULL",
                'recommendations' => "TEXT DEFAULT NULL",
                'overall_risk_level' => "ENUM('low','medium','high') DEFAULT 'medium'",
                'status' => "ENUM('draft','in_progress','under_review','approved','rejected','implemented') DEFAULT 'draft'",
                'management_approval' => "ENUM('pending','approved','rejected','revised') DEFAULT 'pending'",
                'approved_by' => "INT DEFAULT NULL",
                'approval_date' => "DATE DEFAULT NULL",
                'registered_by' => "INT NOT NULL",
                'review_date' => "DATE DEFAULT NULL",
                'notes' => "TEXT DEFAULT NULL"
            ];
            
            if (isset($column_definitions[$col])) {
                add_column_if_not_exists('dpia_registrations', $col, $column_definitions[$col]);
                $existing_columns[] = $col;
            }
        }
    }
    
    if ($is_edit) {
        // Update query
        $set_clauses = [];
        $values = [];
        $types = '';
        
        foreach ($existing_columns as $column) {
            if ($column !== 'id' && $column !== 'record_id' && isset($data[$column])) {
                $set_clauses[] = "`$column` = ?";
                $values[] = $data[$column];
                $types .= 's';
            }
        }
        
        $values[] = $dpia_id;
        $types .= 'i';
        
        $sql = "UPDATE dpia_registrations SET " . implode(', ', $set_clauses) . " WHERE id = ?";
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $stmt->bind_param($types, ...$values);
            return $stmt;
        }
    } else {
        // Insert query
        $columns = array_filter($existing_columns, function($col) use ($data) {
            return $col !== 'id' && isset($data[$col]);
        });
        
        $placeholders = str_repeat('?, ', count($columns) - 1) . '?';
        $sql = "INSERT INTO dpia_registrations (" . implode(', ', $columns) . ") VALUES ($placeholders)";
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $values = [];
            foreach ($columns as $col) {
                $values[] = $data[$col];
            }
            
            $types = str_repeat('s', count($values));
            $stmt->bind_param($types, ...$values);
            return $stmt;
        }
    }
    
    return false;
}

// ============================================
// APPLICATION INITIALIZATION
// ============================================

// Initialize database
initialize_database();

// Check authentication
$is_logged_in = isset($_SESSION['user_id']);
$current_user = $is_logged_in ? $_SESSION['user'] : null;

// Handle print requests
if (isset($_GET['print'])) {
    $print_type = $_GET['print'];
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    switch ($print_type) {
        case 'all_activities':
            print_all_activities();
            break;
        case 'single_activity':
            print_single_activity($id);
            break;
        case 'safeguards_label':
            print_safeguards_label($id);
            break;
        case 'dpia_report':
            print_dpia_report($id);
            break;
    }
}

// Get current action
$action = isset($_GET['action']) ? $_GET['action'] : 'dashboard';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = $app_config['default_records_per_page'];

// Messages array
$messages = [
    'success' => isset($_SESSION['success']) ? $_SESSION['success'] : null,
    'error' => isset($_SESSION['error']) ? $_SESSION['error'] : null,
    'info' => isset($_SESSION['info']) ? $_SESSION['info'] : null
];

// Clear session messages
unset($_SESSION['success'], $_SESSION['error'], $_SESSION['info']);

// Process login
if (isset($_POST['login'])) {
    $conn = create_db_connection();
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT * FROM system_users WHERE username = ? AND is_active = 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            // Successful login
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user'] = $user;
            
            // Update last login
            $update_stmt = $conn->prepare("UPDATE system_users SET last_login = NOW() WHERE id = ?");
            $update_stmt->bind_param("i", $user['id']);
            $update_stmt->execute();
            
            // Log activity
            log_activity('system_users', $user['id'], 'LOGIN', null, null, 'User logged in');
            
            $is_logged_in = true;
            $current_user = $user;
            $_SESSION['success'] = "Login successful! Welcome back, " . htmlspecialchars($user['full_name']);
            
            // Redirect to dashboard
            header("Location: ?action=dashboard");
            exit();
        } else {
            $_SESSION['error'] = "Invalid username or password";
        }
    } else {
        $_SESSION['error'] = "Invalid username or password";
    }
    
    // Reload page to show error
    header("Location: ?");
    exit();
}

// Process logout
if (isset($_GET['logout'])) {
    if ($current_user) {
        log_activity('system_users', $current_user['id'], 'LOGOUT', null, null, 'User logged out');
    }
    session_destroy();
    header("Location: ?");
    exit();
}
?>






<?php
// Continue from Part 1...

// Process form submissions
if ($is_logged_in && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = create_db_connection();
    
    // Add/Edit GDPR Activity - UPDATED WITH ALL ENCRYPTED FIELDS
    if (isset($_POST['save_activity'])) {
        $is_edit = isset($_POST['activity_id']) && $_POST['activity_id'] > 0;
        $activity_id = $is_edit ? intval($_POST['activity_id']) : 0;
        
        // Prepare data - include all fields
        $data = [];
        
        // List all possible fields from the form including encrypted ones
        $possible_fields = [
            'processing_activity', 'department', 'status', 'has_processing_agreement_with_third_party',
            'we_are_processor', 'name_data_controller', 'contact_data_controller',
            'name_joint_data_controller', 'contact_joint_data_controller', 'name_representative',
            'contact_representative', 'name_dpo', 'contact_dpo', 'purpose_of_processing',
            'legal_basis', 'legitimate_interest_description', 'categories_personal_data',
            'categories_data_subjects', 'categories_recipients', 'retention_periods',
            'risk_level', 'technical_measures', 'organizational_measures', 'dpia_required',
            'dpia_status', 'is_international_data_transfers', 'to_country', 'safeguards'
        ];
        
        // Collect all form data
        foreach ($possible_fields as $field) {
            if (isset($_POST[$field])) {
                $value = trim($_POST[$field]);
                if (in_array($field, $encrypted_columns)) {
                    $data[$field] = encrypt_data($value);
                } else {
                    $data[$field] = $value;
                }
            } else {
                // Set default values for optional fields
                if (in_array($field, ['legitimate_interest_description', 'safeguards'])) {
                    $data[$field] = '';
                } elseif (in_array($field, $encrypted_columns)) {
                    $data[$field] = '';
                }
            }
        }
        
        // Calculate review due date based on risk level
        if (isset($data['risk_level'])) {
            $risk_level = $data['risk_level'];
            $review_days = $app_config[$risk_level . '_risk_review_days'];
            $data['review_due_date'] = date('Y-m-d', strtotime("+{$review_days} days"));
        }
        
        if ($is_edit) {
            // Get old data for logging
            $stmt = $conn->prepare("SELECT * FROM gdpr_register WHERE id = ?");
            $stmt->bind_param("i", $activity_id);
            $stmt->execute();
            $old_result = $stmt->get_result();
            $old_data = $old_result->fetch_assoc();
            
            // Build update query dynamically
            $update_fields = [];
            $update_values = [];
            $update_types = '';
            
            // Add regular fields
            foreach ($data as $field => $value) {
                if (in_array($field, $possible_fields) || $field == 'review_due_date') {
                    $update_fields[] = "`$field` = ?";
                    $update_values[] = $value;
                    $update_types .= 's';
                }
            }
            
            // Add updated_by field
            $update_fields[] = "`updated_by` = ?";
            $update_values[] = $current_user['id'];
            $update_types .= 'i';
            
            // Add where clause
            $update_values[] = $activity_id;
            $update_types .= 'i';
            
            $sql = "UPDATE gdpr_register SET " . implode(', ', $update_fields) . " WHERE id = ?";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                $stmt->bind_param($update_types, ...$update_values);
                
                if ($stmt->execute()) {
                    // Decrypt old data for logging
                    foreach ($old_data as $key => $value) {
                        if (in_array($key, $encrypted_columns) && !empty($value)) {
                            $old_data[$key] = decrypt_data($value);
                        }
                    }
                    
                    // Decrypt new data for logging
                    $new_data = $data;
                    foreach ($new_data as $key => $value) {
                        if (in_array($key, $encrypted_columns) && !empty($value)) {
                            $new_data[$key] = decrypt_data($value);
                        }
                    }
                    
                    $changed_fields = get_changed_fields($old_data, $new_data);
                    log_activity('gdpr_register', $activity_id, 'UPDATE', $old_data, $new_data, $changed_fields);
                    
                    $_SESSION['success'] = "Processing activity updated successfully";
                    
                    // If DPIA required changed to yes and no DPIA exists, suggest creating one
                    if ($data['dpia_required'] == 'yes') {
                        $dpia_check = $conn->prepare("SELECT id FROM dpia_registrations WHERE record_id = ?");
                        $dpia_check->bind_param("i", $activity_id);
                        $dpia_check->execute();
                        $dpia_result = $dpia_check->get_result();
                        
                        if ($dpia_result->num_rows == 0) {
                            $_SESSION['info'] = "DPIA is now required for this activity. You can register a DPIA from the DPIAs section.";
                        }
                    }
                    
                    header("Location: ?action=edit_activity&id=" . $activity_id);
                    exit();
                } else {
                    $_SESSION['error'] = "Error updating activity: " . $conn->error;
                }
            } else {
                $_SESSION['error'] = "Error preparing update statement: " . $conn->error;
            }
        } else {
            // Insert new activity
            $data['created_by'] = $current_user['id'];
            $data['updated_by'] = $current_user['id'];
            
            // Build insert query
            $insert_fields = array_keys($data);
            $placeholders = str_repeat('?, ', count($insert_fields) - 1) . '?';
            $insert_values = array_values($data);
            $insert_types = str_repeat('s', count($insert_values));
            
            $sql = "INSERT INTO gdpr_register (" . implode(', ', $insert_fields) . ") VALUES ($placeholders)";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                $stmt->bind_param($insert_types, ...$insert_values);
                
                if ($stmt->execute()) {
                    $activity_id = $conn->insert_id;
                    
                    // Decrypt new data for logging
                    $new_data = $data;
                    foreach ($new_data as $key => $value) {
                        if (in_array($key, $encrypted_columns) && !empty($value)) {
                            $new_data[$key] = decrypt_data($value);
                        }
                    }
                    
                    log_activity('gdpr_register', $activity_id, 'INSERT', null, $new_data, implode(', ', $insert_fields));
                    $_SESSION['success'] = "Processing activity added successfully";
                    
                    // If DPIA required is yes, suggest creating one
                    if ($data['dpia_required'] == 'yes') {
                        $_SESSION['info'] = "DPIA is required for this activity. You can register a DPIA from the DPIAs section.";
                    }
                    
                    header("Location: ?action=edit_activity&id=" . $activity_id);
                    exit();
                } else {
                    $_SESSION['error'] = "Error adding activity: " . $conn->error;
                }
            } else {
                $_SESSION['error'] = "Error preparing insert statement: " . $conn->error;
            }
        }
    }
    
    // Delete GDPR Activity
    if (isset($_POST['delete_activity'])) {
        $activity_id = intval($_POST['activity_id']);
        
        // Get old data
        $stmt = $conn->prepare("SELECT * FROM gdpr_register WHERE id = ?");
        $stmt->bind_param("i", $activity_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $old_data = $result->fetch_assoc();
        
        // Delete activity
        $stmt = $conn->prepare("DELETE FROM gdpr_register WHERE id = ?");
        $stmt->bind_param("i", $activity_id);
        
        if ($stmt->execute()) {
            // Decrypt old data for logging
            foreach ($old_data as $key => $value) {
                if (in_array($key, $encrypted_columns) && !empty($value)) {
                    $old_data[$key] = decrypt_data($value);
                }
            }
            
            log_activity('gdpr_register', $activity_id, 'DELETE', $old_data, null, 'all_fields');
            $_SESSION['success'] = "Processing activity deleted successfully";
            
            // Redirect to view activities
            header("Location: ?action=view_activities");
            exit();
        } else {
            $_SESSION['error'] = "Error deleting activity: " . $conn->error;
        }
    }
    
    // Add/Edit DPIA - COMPREHENSIVE VERSION
    if (isset($_POST['save_dpia'])) {
        $is_edit = isset($_POST['dpia_id']) && $_POST['dpia_id'] > 0;
        $dpia_id = $is_edit ? intval($_POST['dpia_id']) : 0;
        
        // Validate required fields
        if (empty($_POST['record_id']) || empty($_POST['title']) || empty($_POST['description']) || 
            empty($_POST['necessity_test']) || empty($_POST['proportionality_test']) ||
            empty($_POST['mitigation_measures']) || empty($_POST['residual_risk'])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: " . ($is_edit ? "?action=edit_dpia&id=$dpia_id" : "?action=add_dpia"));
            exit();
        }
        
        // Prepare data
        $data = [
            'record_id' => intval($_POST['record_id']),
            'title' => trim($_POST['title']),
            'description' => trim($_POST['description']),
            'processing_activity_description' => trim($_POST['processing_activity_description'] ?? ''),
            'risk_origin' => $_POST['risk_origin'] ?? 'other',
            'necessity_test' => trim($_POST['necessity_test']),
            'proportionality_test' => trim($_POST['proportionality_test']),
            'data_subjects_affected' => intval($_POST['data_subjects_affected'] ?? 0),
            'data_categories' => trim($_POST['data_categories'] ?? ''),
            'mitigation_measures' => trim($_POST['mitigation_measures']),
            'residual_risk' => trim($_POST['residual_risk']),
            'consultation_conducted' => $_POST['consultation_conducted'] ?? 'no',
            'consultation_details' => trim($_POST['consultation_details'] ?? ''),
            'recommendations' => trim($_POST['recommendations'] ?? ''),
            'status' => $_POST['status'] ?? 'draft',
            'management_approval' => $_POST['management_approval'] ?? 'pending',
            'review_date' => !empty($_POST['review_date']) ? $_POST['review_date'] : null,
            'notes' => trim($_POST['notes'] ?? '')
        ];
        
        // Handle compliance checklist (array to JSON)
        $compliance_checklist = isset($_POST['compliance_checklist']) && is_array($_POST['compliance_checklist']) 
            ? $_POST['compliance_checklist'] 
            : [];
        $data['compliance_checklist'] = !empty($compliance_checklist) ? json_encode($compliance_checklist) : null;
        
        // Handle risk assessment matrix (array to JSON)
        $risk_assessment_matrix = isset($_POST['risk_assessment']) && is_array($_POST['risk_assessment'])
            ? $_POST['risk_assessment']
            : [];
        $data['risk_assessment_matrix'] = !empty($risk_assessment_matrix) ? json_encode($risk_assessment_matrix) : null;
        
        // Calculate overall risk level from matrix
        $data['overall_risk_level'] = calculate_overall_risk_level($risk_assessment_matrix);
        
        if ($is_edit) {
            // Get old data
            $stmt = $conn->prepare("SELECT * FROM dpia_registrations WHERE id = ?");
            $stmt->bind_param("i", $dpia_id);
            $stmt->execute();
            $old_result = $stmt->get_result();
            $old_data = $old_result->fetch_assoc();
            
            // Handle approval if changed
            if (isset($_POST['approve_dpia']) && has_permission('approve_dpia')) {
                $data['management_approval'] = 'approved';
                $data['approved_by'] = $current_user['id'];
                $data['approval_date'] = date('Y-m-d');
                $data['status'] = 'approved';
            } elseif (isset($_POST['reject_dpia']) && has_permission('approve_dpia')) {
                $data['management_approval'] = 'rejected';
                $data['status'] = 'rejected';
            }
            
            // Use safe DPIA query function
            $stmt = safe_dpia_query($conn, $data, true, $dpia_id);
            
            if ($stmt && $stmt->execute()) {
                // Update GDPR record DPIA status
                $update_stmt = $conn->prepare("UPDATE gdpr_register SET dpia_status = ? WHERE id = ?");
                $update_stmt->bind_param("si", $data['status'], $data['record_id']);
                $update_stmt->execute();
                
                $changed_fields = get_changed_fields($old_data, $data);
                log_activity('dpia_registrations', $dpia_id, 'UPDATE', $old_data, $data, $changed_fields);
                
                if (isset($_POST['approve_dpia'])) {
                    $_SESSION['success'] = "DPIA approved successfully";
                } elseif (isset($_POST['reject_dpia'])) {
                    $_SESSION['success'] = "DPIA rejected successfully";
                } else {
                    $_SESSION['success'] = "DPIA updated successfully";
                }
                
                header("Location: ?action=view_dpias");
                exit();
            } else {
                $_SESSION['error'] = "Error updating DPIA: " . $conn->error;
            }
        } else {
            // Insert new DPIA
            $data['registered_by'] = $current_user['id'];
            
            // Use safe DPIA query function
            $stmt = safe_dpia_query($conn, $data, false);
            
            if ($stmt && $stmt->execute()) {
                $dpia_id = $conn->insert_id;
                
                // Update GDPR record DPIA status
                $update_stmt = $conn->prepare("UPDATE gdpr_register SET dpia_status = 'in_progress' WHERE id = ?");
                $update_stmt->bind_param("i", $data['record_id']);
                $update_stmt->execute();
                
                log_activity('dpia_registrations', $dpia_id, 'INSERT', null, $data, 'all_fields');
                $_SESSION['success'] = "DPIA registered successfully";
                
                header("Location: ?action=view_dpias");
                exit();
            } else {
                $_SESSION['error'] = "Error registering DPIA: " . $conn->error;
            }
        }
    }
    
    // Add/Edit Data Breach
    if (isset($_POST['save_breach'])) {
        $is_edit = isset($_POST['breach_id']) && $_POST['breach_id'] > 0;
        $breach_id = $is_edit ? intval($_POST['breach_id']) : 0;
        
        $data = [
            'title' => trim($_POST['title']),
            'description' => trim($_POST['description']),
            'breach_date' => $_POST['breach_date'],
            'discovery_date' => $_POST['discovery_date'],
            'breach_type' => $_POST['breach_type'],
            'personal_data_affected' => trim($_POST['personal_data_affected']),
            'affected_data_subjects' => !empty($_POST['affected_data_subjects']) ? intval($_POST['affected_data_subjects']) : null,
            'causes' => trim($_POST['causes']),
            'measures_taken' => trim($_POST['measures_taken']),
            'notified_authority' => $_POST['notified_authority'],
            'notification_date' => !empty($_POST['notification_date']) ? $_POST['notification_date'] : null,
            'notified_affected_persons' => $_POST['notified_affected_persons'],
            'risk_level' => $_POST['risk_level'],
            'status' => $_POST['status'],
            'assigned_to' => !empty($_POST['assigned_to']) ? intval($_POST['assigned_to']) : null
        ];
        
        if ($is_edit) {
            // Get old data
            $stmt = $conn->prepare("SELECT * FROM data_breaches WHERE id = ?");
            $stmt->bind_param("i", $breach_id);
            $stmt->execute();
            $old_result = $stmt->get_result();
            $old_data = $old_result->fetch_assoc();
            
            // Update breach
            $sql = "UPDATE data_breaches SET title = ?, description = ?, breach_date = ?, discovery_date = ?, 
                    breach_type = ?, personal_data_affected = ?, affected_data_subjects = ?, causes = ?, 
                    measures_taken = ?, notified_authority = ?, notification_date = ?, 
                    notified_affected_persons = ?, risk_level = ?, status = ?, assigned_to = ? 
                    WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssisssssssii",
                $data['title'],
                $data['description'],
                $data['breach_date'],
                $data['discovery_date'],
                $data['breach_type'],
                $data['personal_data_affected'],
                $data['affected_data_subjects'],
                $data['causes'],
                $data['measures_taken'],
                $data['notified_authority'],
                $data['notification_date'],
                $data['notified_affected_persons'],
                $data['risk_level'],
                $data['status'],
                $data['assigned_to'],
                $breach_id
            );
            
            if ($stmt->execute()) {
                $changed_fields = get_changed_fields($old_data, $data);
                log_activity('data_breaches', $breach_id, 'UPDATE', $old_data, $data, $changed_fields);
                $_SESSION['success'] = "Data breach updated successfully";
                header("Location: ?action=view_breaches");
                exit();
            } else {
                $_SESSION['error'] = "Error updating breach: " . $conn->error;
            }
        } else {
            // Insert new breach
            $data['reported_by'] = $current_user['id'];
            
            $sql = "INSERT INTO data_breaches 
                    (title, description, breach_date, discovery_date, breach_type, 
                     personal_data_affected, affected_data_subjects, causes, measures_taken, 
                     notified_authority, notification_date, notified_affected_persons, 
                     risk_level, status, reported_by, assigned_to) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssisssssssii",
                $data['title'],
                $data['description'],
                $data['breach_date'],
                $data['discovery_date'],
                $data['breach_type'],
                $data['personal_data_affected'],
                $data['affected_data_subjects'],
                $data['causes'],
                $data['measures_taken'],
                $data['notified_authority'],
                $data['notification_date'],
                $data['notified_affected_persons'],
                $data['risk_level'],
                $data['status'],
                $data['reported_by'],
                $data['assigned_to']
            );
            
            if ($stmt->execute()) {
                $breach_id = $conn->insert_id;
                log_activity('data_breaches', $breach_id, 'INSERT', null, $data, 'all_fields');
                $_SESSION['success'] = "Data breach reported successfully";
                header("Location: ?action=view_breaches");
                exit();
            } else {
                $_SESSION['error'] = "Error reporting breach: " . $conn->error;
            }
        }
    }
    
    // Add/Edit Third Party
    if (isset($_POST['save_third_party'])) {
        $is_edit = isset($_POST['third_party_id']) && $_POST['third_party_id'] > 0;
        $third_party_id = $is_edit ? intval($_POST['third_party_id']) : 0;
        
        $data = [
            'company_name' => trim($_POST['company_name']),
            'contact_person' => trim($_POST['contact_person'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'service_provided' => trim($_POST['service_provided']),
            'processing_agreement_signed' => $_POST['processing_agreement_signed'],
            'agreement_date' => !empty($_POST['agreement_date']) ? $_POST['agreement_date'] : null,
            'agreement_expiry_date' => !empty($_POST['agreement_expiry_date']) ? $_POST['agreement_expiry_date'] : null,
            'compliance_status' => $_POST['compliance_status']
        ];
        
        if ($is_edit) {
            // Get old data
            $stmt = $conn->prepare("SELECT * FROM third_parties WHERE id = ?");
            $stmt->bind_param("i", $third_party_id);
            $stmt->execute();
            $old_result = $stmt->get_result();
            $old_data = $old_result->fetch_assoc();
            
            // Update third party
            $sql = "UPDATE third_parties SET company_name = ?, contact_person = ?, email = ?, 
                    phone = ?, address = ?, service_provided = ?, processing_agreement_signed = ?, 
                    agreement_date = ?, agreement_expiry_date = ?, compliance_status = ? 
                    WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssssssi",
                $data['company_name'],
                $data['contact_person'],
                $data['email'],
                $data['phone'],
                $data['address'],
                $data['service_provided'],
                $data['processing_agreement_signed'],
                $data['agreement_date'],
                $data['agreement_expiry_date'],
                $data['compliance_status'],
                $third_party_id
            );
            
            if ($stmt->execute()) {
                $changed_fields = get_changed_fields($old_data, $data);
                log_activity('third_parties', $third_party_id, 'UPDATE', $old_data, $data, $changed_fields);
                $_SESSION['success'] = "Third party updated successfully";
                header("Location: ?action=view_third_parties");
                exit();
            } else {
                $_SESSION['error'] = "Error updating third party: " . $conn->error;
            }
        } else {
            // Insert new third party
            $data['created_by'] = $current_user['id'];
            
            $sql = "INSERT INTO third_parties 
                    (company_name, contact_person, email, phone, address, service_provided, 
                     processing_agreement_signed, agreement_date, agreement_expiry_date, 
                     compliance_status, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssssssi",
                $data['company_name'],
                $data['contact_person'],
                $data['email'],
                $data['phone'],
                $data['address'],
                $data['service_provided'],
                $data['processing_agreement_signed'],
                $data['agreement_date'],
                $data['agreement_expiry_date'],
                $data['compliance_status'],
                $data['created_by']
            );
            
            if ($stmt->execute()) {
                $third_party_id = $conn->insert_id;
                log_activity('third_parties', $third_party_id, 'INSERT', null, $data, 'all_fields');
                $_SESSION['success'] = "Third party added successfully";
                header("Location: ?action=view_third_parties");
                exit();
            } else {
                $_SESSION['error'] = "Error adding third party: " . $conn->error;
            }
        }
    }
    
    // Add/Edit User - FIXED VERSION
    if (isset($_POST['save_user'])) {
        $is_edit = isset($_POST['user_id']) && $_POST['user_id'] > 0;
        $user_id = $is_edit ? intval($_POST['user_id']) : 0;
        
        // Get form data
        $username = trim($_POST['username'] ?? '');
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $role = $_POST['role'] ?? 'viewer';
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['error'] = "Invalid email address";
            header("Location: ?action=users");
            exit();
        }
        
        // Validate username (alphanumeric and underscores only)
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            $_SESSION['error'] = "Username can only contain letters, numbers and underscores";
            header("Location: ?action=users");
            exit();
        }
        
        if ($is_edit) {
            // UPDATE USER
            $success = false;
            $error_msg = '';
            
            // Check if username already exists (excluding current user)
            $check_stmt = $conn->prepare("SELECT id FROM system_users WHERE username = ? AND id != ?");
            $check_stmt->bind_param("si", $username, $user_id);
            $check_stmt->execute();
            if ($check_stmt->get_result()->num_rows > 0) {
                $_SESSION['error'] = "Username already exists";
                header("Location: ?action=users");
                exit();
            }
            
            // Check if email already exists (excluding current user)
            $check_stmt = $conn->prepare("SELECT id FROM system_users WHERE email = ? AND id != ?");
            $check_stmt->bind_param("si", $email, $user_id);
            $check_stmt->execute();
            if ($check_stmt->get_result()->num_rows > 0) {
                $_SESSION['error'] = "Email already exists";
                header("Location: ?action=users");
                exit();
            }
            
            if (!empty($_POST['new_password'])) {
                // If password is being changed
                if ($_POST['new_password'] !== $_POST['confirm_new_password']) {
                    $_SESSION['error'] = "Passwords do not match";
                    header("Location: ?action=users");
                    exit();
                }
                
                if (strlen($_POST['new_password']) < $app_config['password_min_length']) {
                    $_SESSION['error'] = "Password must be at least " . $app_config['password_min_length'] . " characters long";
                    header("Location: ?action=users");
                    exit();
                }
                
                $hashed_password = password_hash($_POST['new_password'], $app_config['password_algorithm']);
                
                $sql = "UPDATE system_users SET 
                        username = ?, 
                        password = ?, 
                        full_name = ?, 
                        email = ?, 
                        role = ?, 
                        is_active = ? 
                        WHERE id = ?";
                
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("sssssii", 
                        $username,
                        $hashed_password,
                        $full_name,
                        $email,
                        $role,
                        $is_active,
                        $user_id
                    );
                    
                    if ($stmt->execute()) {
                        $success = true;
                    } else {
                        $error_msg = "Error updating user: " . $stmt->error;
                    }
                    $stmt->close();
                } else {
                    $error_msg = "Error preparing statement: " . $conn->error;
                }
            } else {
                // Update without password change
                $sql = "UPDATE system_users SET 
                        username = ?, 
                        full_name = ?, 
                        email = ?, 
                        role = ?, 
                        is_active = ? 
                        WHERE id = ?";
                
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("ssssii", 
                        $username,
                        $full_name,
                        $email,
                        $role,
                        $is_active,
                        $user_id
                    );
                    
                    if ($stmt->execute()) {
                        $success = true;
                    } else {
                        $error_msg = "Error updating user: " . $stmt->error;
                    }
                    $stmt->close();
                } else {
                    $error_msg = "Error preparing statement: " . $conn->error;
                }
            }
            
            if ($success) {
                $_SESSION['success'] = "User updated successfully";
                log_activity('system_users', $user_id, 'UPDATE', null, [
                    'username' => $username,
                    'full_name' => $full_name,
                    'email' => $email,
                    'role' => $role,
                    'is_active' => $is_active
                ], 'user_updated');
                header("Location: ?action=users");
                exit();
            } else {
                $_SESSION['error'] = $error_msg;
                header("Location: ?action=users");
                exit();
            }
            
        } else {
            // INSERT NEW USER
            if (empty($_POST['password'])) {
                $_SESSION['error'] = "Password is required for new users";
                header("Location: ?action=users");
                exit();
            }
            
            if ($_POST['password'] !== $_POST['confirm_password']) {
                $_SESSION['error'] = "Passwords do not match";
                header("Location: ?action=users");
                exit();
            }
            
            if (strlen($_POST['password']) < $app_config['password_min_length']) {
                $_SESSION['error'] = "Password must be at least " . $app_config['password_min_length'] . " characters long";
                header("Location: ?action=users");
                exit();
            }
            
            // Check if username already exists
            $check_stmt = $conn->prepare("SELECT id FROM system_users WHERE username = ?");
            $check_stmt->bind_param("s", $username);
            $check_stmt->execute();
            if ($check_stmt->get_result()->num_rows > 0) {
                $_SESSION['error'] = "Username already exists";
                header("Location: ?action=users");
                exit();
            }
            
            // Check if email already exists
            $check_stmt = $conn->prepare("SELECT id FROM system_users WHERE email = ?");
            $check_stmt->bind_param("s", $email);
            $check_stmt->execute();
            if ($check_stmt->get_result()->num_rows > 0) {
                $_SESSION['error'] = "Email already exists";
                header("Location: ?action=users");
                exit();
            }
            
            $hashed_password = password_hash($_POST['password'], $app_config['password_algorithm']);
            
            $sql = "INSERT INTO system_users (username, password, full_name, email, role, is_active) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sssssi",
                    $username,
                    $hashed_password,
                    $full_name,
                    $email,
                    $role,
                    $is_active
                );
                
                if ($stmt->execute()) {
                    $user_id = $conn->insert_id;
                    log_activity('system_users', $user_id, 'INSERT', null, [
                        'username' => $username,
                        'full_name' => $full_name,
                        'email' => $email,
                        'role' => $role,
                        'is_active' => $is_active
                    ], 'user_created');
                    $_SESSION['success'] = "User added successfully";
                    header("Location: ?action=users");
                    exit();
                } else {
                    $_SESSION['error'] = "Error adding user: " . $stmt->error;
                    header("Location: ?action=users");
                    exit();
                }
                $stmt->close();
            } else {
                $_SESSION['error'] = "Error preparing statement: " . $conn->error;
                header("Location: ?action=users");
                exit();
            }
        }
    }
    
    // Delete User
    if (isset($_POST['delete_user'])) {
        $user_id = intval($_POST['user_id']);
        
        // Cannot delete own account
        if ($user_id == $current_user['id']) {
            $_SESSION['error'] = "You cannot delete your own account";
            header("Location: ?action=users");
            exit();
        }
        
        // Check if user exists
        $check_stmt = $conn->prepare("SELECT username FROM system_users WHERE id = ?");
        $check_stmt->bind_param("i", $user_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        
        if ($result->num_rows == 0) {
            $_SESSION['error'] = "User not found";
            header("Location: ?action=users");
            exit();
        }
        
        $stmt = $conn->prepare("DELETE FROM system_users WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $user_id);
            
            if ($stmt->execute()) {
                log_activity('system_users', $user_id, 'DELETE', null, null, 'user_deleted');
                $_SESSION['success'] = "User deleted successfully";
            } else {
                $_SESSION['error'] = "Error deleting user: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $_SESSION['error'] = "Error preparing statement: " . $conn->error;
        }
        
        header("Location: ?action=users");
        exit();
    }
}

// Function to get all activities for DPIA dropdown
function get_activities_for_dpia($include_all = false) {
    $conn = create_db_connection();
    $activities = [];
    
    if ($include_all) {
        $sql = "SELECT id, processing_activity, dpia_required FROM gdpr_register ORDER BY processing_activity";
    } else {
        $sql = "SELECT id, processing_activity FROM gdpr_register WHERE dpia_required = 'yes' ORDER BY processing_activity";
    }
    
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $activities[] = $row;
        }
    }
    
    return $activities;
}

// Function to check if activity has existing DPIA
function activity_has_dpia($activity_id) {
    $conn = create_db_connection();
    $stmt = $conn->prepare("SELECT id FROM dpia_registrations WHERE record_id = ?");
    $stmt->bind_param("i", $activity_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Function to get DPIA by activity ID
function get_dpia_by_activity($activity_id) {
    $conn = create_db_connection();
    $stmt = $conn->prepare("SELECT * FROM dpia_registrations WHERE record_id = ?");
    $stmt->bind_param("i", $activity_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to get activity details for DPIA form
function get_activity_for_dpia($activity_id) {
    $conn = create_db_connection();
    $stmt = $conn->prepare("SELECT * FROM gdpr_register WHERE id = ?");
    $stmt->bind_param("i", $activity_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to get all users for assignment dropdowns
function get_all_users($active_only = true) {
    $conn = create_db_connection();
    $users = [];
    
    if ($active_only) {
        $sql = "SELECT id, username, full_name, role FROM system_users WHERE is_active = 1 ORDER BY full_name";
    } else {
        $sql = "SELECT id, username, full_name, role FROM system_users ORDER BY full_name";
    }
    
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }
    
    return $users;
}

// Function to get recent audit logs
function get_recent_audit_logs($limit = 50) {
    $conn = create_db_connection();
    $logs = [];
    
    $stmt = $conn->prepare("
        SELECT s.*, u.full_name as user_name, u.username
        FROM system_changes s
        LEFT JOIN system_users u ON s.changed_by = u.id
        ORDER BY s.changed_at DESC
        LIMIT ?
    ");
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $logs[] = $row;
        }
    }
    
    return $logs;
}

// Function to get activity statistics by department
function get_activity_statistics_by_department() {
    $conn = create_db_connection();
    $stats = [];
    
    $sql = "
        SELECT 
            department,
            COUNT(*) as total_activities,
            SUM(CASE WHEN risk_level = 'high' THEN 1 ELSE 0 END) as high_risk,
            SUM(CASE WHEN risk_level = 'medium' THEN 1 ELSE 0 END) as medium_risk,
            SUM(CASE WHEN risk_level = 'low' THEN 1 ELSE 0 END) as low_risk,
            SUM(CASE WHEN dpia_required = 'yes' THEN 1 ELSE 0 END) as dpia_required,
            SUM(CASE WHEN status = 'review_needed' THEN 1 ELSE 0 END) as needs_review
        FROM gdpr_register
        GROUP BY department
        ORDER BY department
    ";
    
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats[] = $row;
        }
    }
    
    return $stats;
}

// Function to get overdue reviews
function get_overdue_reviews() {
    $conn = create_db_connection();
    $overdue = [];
    
    $sql = "
        SELECT id, processing_activity, department, risk_level, review_due_date, 
               DATEDIFF(review_due_date, CURDATE()) as days_overdue
        FROM gdpr_register
        WHERE review_due_date < CURDATE() 
          AND status = 'active'
        ORDER BY review_due_date ASC
    ";
    
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $overdue[] = $row;
        }
    }
    
    return $overdue;
}

// Function to get activities due for review soon (within 30 days)
function get_upcoming_reviews($days = 30) {
    $conn = create_db_connection();
    $upcoming = [];
    
    $sql = "
        SELECT id, processing_activity, department, risk_level, review_due_date,
               DATEDIFF(review_due_date, CURDATE()) as days_until_review
        FROM gdpr_register
        WHERE review_due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
          AND status = 'active'
        ORDER BY review_due_date ASC
    ";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $days);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $upcoming[] = $row;
        }
    }
    
    return $upcoming;
}

// Function to get DPIA statistics
function get_dpia_statistics() {
    $conn = create_db_connection();
    $stats = [
        'total' => 0,
        'by_status' => [],
        'by_approval' => [],
        'by_risk' => []
    ];
    
    // Total DPIAs
    $result = $conn->query("SELECT COUNT(*) as total FROM dpia_registrations");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['total'] = $row['total'];
    }
    
    // By status
    $result = $conn->query("
        SELECT status, COUNT(*) as count 
        FROM dpia_registrations 
        GROUP BY status
        ORDER BY FIELD(status, 'draft', 'in_progress', 'under_review', 'approved', 'rejected', 'implemented')
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_status'][$row['status']] = $row['count'];
        }
    }
    
    // By approval status
    $result = $conn->query("
        SELECT management_approval, COUNT(*) as count 
        FROM dpia_registrations 
        GROUP BY management_approval
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_approval'][$row['management_approval']] = $row['count'];
        }
    }
    
    // By risk level
    $result = $conn->query("
        SELECT overall_risk_level, COUNT(*) as count 
        FROM dpia_registrations 
        GROUP BY overall_risk_level
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_risk'][$row['overall_risk_level']] = $row['count'];
        }
    }
    
    return $stats;
}

// Function to get breach statistics
function get_breach_statistics() {
    $conn = create_db_connection();
    $stats = [
        'total' => 0,
        'by_status' => [],
        'by_type' => [],
        'by_risk' => [],
        'recent_breaches' => []
    ];
    
    // Total breaches
    $result = $conn->query("SELECT COUNT(*) as total FROM data_breaches");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['total'] = $row['total'];
    }
    
    // By status
    $result = $conn->query("
        SELECT status, COUNT(*) as count 
        FROM data_breaches 
        GROUP BY status
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_status'][$row['status']] = $row['count'];
        }
    }
    
    // By type
    $result = $conn->query("
        SELECT breach_type, COUNT(*) as count 
        FROM data_breaches 
        GROUP BY breach_type
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_type'][$row['breach_type']] = $row['count'];
        }
    }
    
    // By risk level
    $result = $conn->query("
        SELECT risk_level, COUNT(*) as count 
        FROM data_breaches 
        GROUP BY risk_level
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_risk'][$row['risk_level']] = $row['count'];
        }
    }
    
    // Recent breaches (last 30 days)
    $result = $conn->query("
        SELECT b.*, u.full_name as reporter_name
        FROM data_breaches b
        LEFT JOIN system_users u ON b.reported_by = u.id
        WHERE b.breach_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        ORDER BY b.breach_date DESC
        LIMIT 10
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['recent_breaches'][] = $row;
        }
    }
    
    return $stats;
}

// Function to get third party statistics
function get_third_party_statistics() {
    $conn = create_db_connection();
    $stats = [
        'total' => 0,
        'by_agreement' => [],
        'by_compliance' => [],
        'expiring_soon' => []
    ];
    
    // Total third parties
    $result = $conn->query("SELECT COUNT(*) as total FROM third_parties");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['total'] = $row['total'];
    }
    
    // By agreement status
    $result = $conn->query("
        SELECT processing_agreement_signed, COUNT(*) as count 
        FROM third_parties 
        GROUP BY processing_agreement_signed
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_agreement'][$row['processing_agreement_signed']] = $row['count'];
        }
    }
    
    // By compliance status
    $result = $conn->query("
        SELECT compliance_status, COUNT(*) as count 
        FROM third_parties 
        GROUP BY compliance_status
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['by_compliance'][$row['compliance_status']] = $row['count'];
        }
    }
    
    // Agreements expiring soon (within 90 days)
    $result = $conn->query("
        SELECT id, company_name, agreement_expiry_date, 
               DATEDIFF(agreement_expiry_date, CURDATE()) as days_until_expiry
        FROM third_parties
        WHERE agreement_expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)
          AND processing_agreement_signed = 'yes'
        ORDER BY agreement_expiry_date ASC
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['expiring_soon'][] = $row;
        }
    }
    
    return $stats;
}

// Function to search activities
function search_activities($search_term, $department = null, $risk_level = null, $status = null, $limit = 50) {
    $conn = create_db_connection();
    $activities = [];
    
    $sql = "SELECT id, processing_activity, department, risk_level, status, 
                   updated_at, created_at, review_due_date 
            FROM gdpr_register 
            WHERE (processing_activity LIKE ? OR purpose_of_processing LIKE ?)";
    
    $params = ["%$search_term%", "%$search_term%"];
    $types = "ss";
    
    if ($department) {
        $sql .= " AND department = ?";
        $params[] = $department;
        $types .= "s";
    }
    
    if ($risk_level) {
        $sql .= " AND risk_level = ?";
        $params[] = $risk_level;
        $types .= "s";
    }
    
    if ($status) {
        $sql .= " AND status = ?";
        $params[] = $status;
        $types .= "s";
    }
    
    $sql .= " ORDER BY updated_at DESC LIMIT ?";
    $params[] = $limit;
    $types .= "i";
    
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $activities[] = $row;
            }
        }
    }
    
    return $activities;
}

// Function to export activities to CSV
function export_activities_to_csv($activities_ids = []) {
    global $gdpr_options, $encrypted_columns;
    $conn = create_db_connection();
    
    $where_clause = "";
    $params = [];
    $types = "";
    
    if (!empty($activities_ids)) {
        $placeholders = str_repeat('?,', count($activities_ids) - 1) . '?';
        $where_clause = " WHERE id IN ($placeholders)";
        $params = $activities_ids;
        $types = str_repeat('i', count($activities_ids));
    }
    
    $sql = "SELECT * FROM gdpr_register $where_clause ORDER BY department, processing_activity";
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Create CSV content
    $csv = "ID,Processing Activity,Department,Status,Risk Level,Legal Basis,DPIA Required,DPIA Status,Created,Last Updated,Review Due Date\n";
    
    while ($row = $result->fetch_assoc()) {
        // Decrypt encrypted fields
        foreach ($encrypted_columns as $field) {
            if (!empty($row[$field])) {
                $row[$field] = decrypt_data($row[$field]);
            }
        }
        
        $csv .= sprintf(
            '"%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s"' . "\n",
            $row['id'],
            str_replace('"', '""', $row['processing_activity']),
            $gdpr_options['departments'][$row['department']] ?? $row['department'],
            $gdpr_options['status_options'][$row['status']] ?? $row['status'],
            $gdpr_options['risk_levels'][$row['risk_level']] ?? $row['risk_level'],
            $gdpr_options['legal_bases'][$row['legal_basis']] ?? $row['legal_basis'],
            $row['dpia_required'],
            $gdpr_options['dpia_statuses'][$row['dpia_status']] ?? $row['dpia_status'],
            format_date($row['created_at'], 'd-m-Y'),
            format_date($row['updated_at'], 'd-m-Y'),
            !empty($row['review_due_date']) && $row['review_due_date'] != '0000-00-00' ? format_date($row['review_due_date'], 'd-m-Y') : ''
        );
    }
    
    return $csv;
}

// Function to export DPIA to CSV
function export_dpias_to_csv($dpia_ids = []) {
    global $gdpr_options, $dpia_options;
    $conn = create_db_connection();
    
    $where_clause = "";
    $params = [];
    $types = "";
    
    if (!empty($dpia_ids)) {
        $placeholders = str_repeat('?,', count($dpia_ids) - 1) . '?';
        $where_clause = " WHERE d.id IN ($placeholders)";
        $params = $dpia_ids;
        $types = str_repeat('i', count($dpia_ids));
    }
    
    $sql = "SELECT d.*, g.processing_activity, u.full_name as registered_by_name
            FROM dpia_registrations d
            LEFT JOIN gdpr_register g ON d.record_id = g.id
            LEFT JOIN system_users u ON d.registered_by = u.id
            $where_clause 
            ORDER BY d.registered_at DESC";
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Create CSV content
    $csv = "DPIA ID,Title,Related Activity,Risk Origin,Overall Risk Level,Status,Management Approval,Registered By,Registered Date,Review Date\n";
    
    while ($row = $result->fetch_assoc()) {
        $csv .= sprintf(
            '"%s","%s","%s","%s","%s","%s","%s","%s","%s","%s"' . "\n",
            $row['id'],
            str_replace('"', '""', $row['title']),
            str_replace('"', '""', $row['processing_activity']),
            $dpia_options['risk_origins'][$row['risk_origin']] ?? $row['risk_origin'],
            $row['overall_risk_level'],
            $gdpr_options['dpia_statuses'][$row['status']] ?? $row['status'],
            $dpia_options['management_approval'][$row['management_approval']] ?? $row['management_approval'],
            str_replace('"', '""', $row['registered_by_name']),
            format_date($row['registered_at'], 'd-m-Y'),
            !empty($row['review_date']) && $row['review_date'] != '0000-00-00' ? format_date($row['review_date'], 'd-m-Y') : ''
        );
    }
    
    return $csv;
}


// Add this function to your helper functions section
function export_audit_log_csv($action_filter = '', $user_filter = '', $date_filter = '') {
    $conn = create_db_connection();
    
    // Build WHERE clause
    $where_clause = "WHERE 1=1";
    $params = [];
    $types = "";
    
    if ($action_filter) {
        $where_clause .= " AND s.action = ?";
        $params[] = $action_filter;
        $types .= "s";
    }
    
    if ($user_filter) {
        $where_clause .= " AND s.changed_by = ?";
        $params[] = $user_filter;
        $types .= "i";
    }
    
    if ($date_filter) {
        $where_clause .= " AND DATE(s.changed_at) = ?";
        $params[] = $date_filter;
        $types .= "s";
    }
    
    $sql = "
        SELECT s.id, s.table_name, s.record_id, s.action, 
               s.changed_at, s.changed_by, s.user_ip, s.changed_fields,
               u.username, u.full_name as user_full_name
        FROM system_changes s
        LEFT JOIN system_users u ON s.changed_by = u.id
        $where_clause
        ORDER BY s.changed_at DESC
    ";
    
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Create CSV
    $csv = "ID,Timestamp,User,Username,Action,Table,Record ID,IP Address,Changed Fields\n";
    
    while ($row = $result->fetch_assoc()) {
        $csv .= sprintf(
            '"%s","%s","%s","%s","%s","%s","%s","%s","%s"' . "\n",
            $row['id'],
            format_date($row['changed_at']),
            str_replace('"', '""', $row['user_full_name'] ?? 'Deleted User'),
            str_replace('"', '""', $row['username'] ?? ''),
            $row['action'],
            $row['table_name'],
            $row['record_id'],
            $row['user_ip'],
            str_replace('"', '""', $row['changed_fields'] ?? '')
        );
    }
    
    return $csv;
}

// Function to check system health
function check_system_health() {
    $health = [
        'database' => true,
        'tables' => [],
        'users' => true,
        'encryption' => true
    ];
    
    $conn = create_db_connection();
    
    // Check database connection
    if ($conn->connect_error) {
        $health['database'] = false;
        return $health;
    }
    
    // Check required tables
    $required_tables = ['system_users', 'gdpr_register', 'dpia_registrations', 'data_breaches', 'third_parties', 'system_changes'];
    
    foreach ($required_tables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        $health['tables'][$table] = $result && $result->num_rows > 0;
    }
    
    // Check if admin user exists
    $result = $conn->query("SELECT COUNT(*) as count FROM system_users WHERE username = 'admin'");
    if ($result) {
        $row = $result->fetch_assoc();
        $health['users'] = $row['count'] > 0;
    }
    
    // Test encryption/decryption
    try {
        $test_data = "test123";
        $encrypted = encrypt_data($test_data);
        $decrypted = decrypt_data($encrypted);
        $health['encryption'] = $decrypted === $test_data;
    } catch (Exception $e) {
        $health['encryption'] = false;
    }
    
    return $health;
}

// Function to get system usage statistics
function get_system_usage_stats() {
    $conn = create_db_connection();
    $stats = [
        'total_activities' => 0,
        'total_dpias' => 0,
        'total_breaches' => 0,
        'total_third_parties' => 0,
        'total_users' => 0,
        'total_audit_logs' => 0,
        'recent_activity' => []
    ];
    
    // Get counts
    $tables = ['gdpr_register', 'dpia_registrations', 'data_breaches', 'third_parties', 'system_users', 'system_changes'];
    
    foreach ($tables as $table) {
        $result = $conn->query("SELECT COUNT(*) as count FROM $table");
        if ($result) {
            $row = $result->fetch_assoc();
            $key = 'total_' . str_replace('_', '', $table);
            $stats[$key] = $row['count'];
        }
    }
    
    // Get recent activity (last 7 days)
    $result = $conn->query("
        SELECT s.*, u.full_name as user_name
        FROM system_changes s
        LEFT JOIN system_users u ON s.changed_by = u.id
        WHERE s.changed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ORDER BY s.changed_at DESC
        LIMIT 20
    ");
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stats['recent_activity'][] = $row;
        }
    }
    
    return $stats;
}

// Function to validate and sanitize input
function sanitize_input($input) {
    if (is_array($input)) {
        foreach ($input as $key => $value) {
            $input[$key] = sanitize_input($value);
        }
        return $input;
    }
    
    // Remove HTML tags and encode special characters
    $input = trim($input);
    $input = strip_tags($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    
    return $input;
}

// Function to validate email
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Function to validate date
function validate_date($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

// Function to generate random password
function generate_random_password($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $password;
}

// Function to send notification email (placeholder - implement with your email system)
function send_notification_email($to, $subject, $message) {
    // This is a placeholder function
    // Implement with your preferred email sending method (PHPMailer, SwiftMailer, etc.)
    
    $headers = "From: noreply@foodbank-almere.nl\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    return mail($to, $subject, $message, $headers);
}

// Function to backup database
function backup_database() {
    global $db_config;
    
    $backup_file = 'backups/backup_' . date('Y-m-d_H-i-s') . '.sql';
    $command = sprintf(
        'mysqldump --host=%s --user=%s --password=%s %s > %s',
        escapeshellarg($db_config['host']),
        escapeshellarg($db_config['username']),
        escapeshellarg($db_config['password']),
        escapeshellarg($db_config['database']),
        escapeshellarg($backup_file)
    );
    
    exec($command, $output, $return_var);
    
    if ($return_var === 0) {
        return $backup_file;
    }
    
    return false;
}

// Function to restore database from backup
function restore_database($backup_file) {
    global $db_config;
    
    if (!file_exists($backup_file)) {
        return false;
    }
    
    $command = sprintf(
        'mysql --host=%s --user=%s --password=%s %s < %s',
        escapeshellarg($db_config['host']),
        escapeshellarg($db_config['username']),
        escapeshellarg($db_config['password']),
        escapeshellarg($db_config['database']),
        escapeshellarg($backup_file)
    );
    
    exec($command, $output, $return_var);
    
    return $return_var === 0;
}
?>

<?php
// Continue from Part 2...
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $app_config['site_name']; ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="bootstrap-icons.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="dataTables.bootstrap5.min.css">
    
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --success-color: #27ae60;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --info-color: #17a2b8;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            background-color: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            padding-top: 20px;
            z-index: 1000;
            overflow-y: auto;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-left: 0;
            }
        }
        
        .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            transition: all 0.3s;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white;
            background-color: rgba(255,255,255,0.1);
            border-left: 3px solid var(--secondary-color);
        }
        
        .stat-card {
            border-radius: 10px;
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(52, 152, 219, 0.1);
        }
        
        .encrypted-field {
            background-color: #fff3cd;
            border-left: 3px solid #ffc107;
        }
        
        .print-only {
            display: none;
        }
        
        @media print {
            .no-print {
                display: none !important;
            }
            .print-only {
                display: block !important;
            }
            body {
                font-size: 12px;
            }
            .table {
                font-size: 11px;
            }
        }
        
        .activity-row {
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .activity-row:hover {
            background-color: #f8f9fa;
        }
        
        .safeguards-options-container {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 15px;
            background-color: #f8f9fa;
        }
        
        .safeguards-list {
            max-height: 200px;
            overflow-y: auto;
            padding: 10px;
            background-color: white;
            border-radius: 3px;
            border: 1px solid #ced4da;
        }
        
        .safeguards-item {
            margin-bottom: 5px;
            padding: 5px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .safeguards-item:hover {
            background-color: #f8f9fa;
        }
        
        .safeguards-search-input {
            margin-bottom: 10px;
        }
        
        .measure-tag {
            display: inline-block;
            background-color: #e9ecef;
            padding: 2px 8px;
            margin: 2px;
            border-radius: 3px;
            font-size: 0.9em;
        }
        
        .auto-populate-btn {
            margin-top: 10px;
        }
        
        .user-actions {
            min-width: 100px;
        }
        
        .print-actions {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        
        .print-actions .btn {
            margin-bottom: 5px;
        }
        
        .dpia-risk-matrix {
            border-collapse: collapse;
            width: 100%;
        }
        
        .dpia-risk-matrix th,
        .dpia-risk-matrix td {
            border: 1px solid #dee2e6;
            padding: 8px;
            text-align: center;
            min-width: 100px;
        }
        
        .dpia-risk-matrix th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .risk-cell {
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .risk-cell:hover {
            opacity: 0.8;
        }
        
        .risk-low {
            background-color: #d4edda !important;
        }
        
        .risk-medium {
            background-color: #fff3cd !important;
        }
        
        .risk-high {
            background-color: #f8d7da !important;
        }
        
        .risk-cell.selected {
            border: 2px solid #000 !important;
        }
        
        .compliance-checklist {
            max-height: 300px;
            overflow-y: auto;
            padding: 15px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            background-color: #f8f9fa;
        }
        
        .dpia-section {
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .dpia-section-title {
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 10px;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .approval-actions {
            background-color: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 5px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .dpia-status-badge {
            font-size: 0.9em;
            padding: 5px 10px;
        }
        
        .data-controller-section {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .section-title {
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 8px;
            margin-bottom: 15px;
            font-weight: bold;
        }
        
        .field-hint {
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 0.25rem;
        }
        
        .required-field::after {
            content: " *";
            color: #dc3545;
        }
    </style>
</head>
<body>
    <?php if (!$is_logged_in): ?>
    <!-- LOGIN PAGE -->
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-lg">
                    <div class="card-body p-5">
                        <div class="text-center mb-4">
                            <h3 class="fw-bold text-primary">Food Bank Almere</h3>
                            <h5 class="text-muted">GDPR Compliance System</h5>
                        </div>
                        
                        <?php if ($messages['error']): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($messages['error']); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" name="username" class="form-control" required autofocus>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            
                            <button type="submit" name="login" class="btn btn-primary w-100 mb-3">Login</button>
                            
                            <div class="text-center">
                                <small class="text-muted">Default admin: admin / Admin@12345</small>
                            </div>
                        </form>
                        
                        <div class="text-center mt-3">
                            <small class="text-muted">GDPR Compliance System v<?php echo $app_config['version']; ?></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php else: ?>
    <!-- MAIN APPLICATION -->
    <!-- Sidebar -->
    <div class="sidebar no-print">
        <div class="text-center mb-4">
            <h4 class="fw-bold">Food Bank Almere</h4>
            <small class="text-muted">GDPR Compliance</small>
        </div>
        
        <div class="px-3 mb-4">
            <div class="d-flex align-items-center">
                <div class="flex-shrink-0">
                    <i class="bi bi-person-circle fs-4"></i>
                </div>
                <div class="flex-grow-1 ms-3">
                    <div class="fw-bold"><?php echo htmlspecialchars($current_user['full_name']); ?></div>
                    <small class="text-muted"><?php echo ucfirst($current_user['role']); ?></small>
                </div>
            </div>
        </div>
        
        <nav class="nav flex-column">
            <a class="nav-link <?php echo $action == 'dashboard' ? 'active' : ''; ?>" href="?action=dashboard">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            
            <a class="nav-link <?php echo in_array($action, ['view_activities', 'add_activity', 'edit_activity']) ? 'active' : ''; ?>" href="?action=view_activities">
                <i class="bi bi-clipboard-data me-2"></i> Processing Activities
            </a>
			
			
			<a class="nav-link <?php echo $action == 'dashboard' ? 'active' : ''; ?>" href="?print=all_activities">
                <i class="bi bi-speedometer2 me-2"></i> Print Processing Activities
            </a>
            
            <a class="nav-link <?php echo in_array($action, ['view_dpias', 'add_dpia', 'edit_dpia']) ? 'active' : ''; ?>" href="?action=view_dpias">
                <i class="bi bi-file-text me-2"></i> DPIAs
            </a>
			
			<a class="nav-link <?php echo $action == 'dashboard' ? 'active' : ''; ?>" href="generate_all_dpia_print_html_like_main.php">
                <i class="bi bi-speedometer2 me-2"></i> Print DPIAs
            </a>
            
            <a class="nav-link <?php echo in_array($action, ['view_breaches', 'add_breach', 'edit_breach']) ? 'active' : ''; ?>" href="?action=view_breaches">
                <i class="bi bi-exclamation-triangle me-2"></i> Data Breaches
            </a>
            
            <a class="nav-link <?php echo in_array($action, ['view_third_parties', 'add_third_party', 'edit_third_party']) ? 'active' : ''; ?>" href="?action=view_third_parties">
                <i class="bi bi-building me-2"></i> Third Parties
            </a>
            
            <?php if (has_permission('view_audit_log')): ?>
            <a class="nav-link <?php echo $action == 'audit_log' ? 'active' : ''; ?>" href="?action=audit_log">
                <i class="bi bi-clock-history me-2"></i> Audit Log
            </a>
            <?php endif; ?>
			
			

            
            <?php if (has_permission('manage_users')): ?>
            <a class="nav-link <?php echo $action == 'users' ? 'active' : ''; ?>" href="?action=users">
                <i class="bi bi-people me-2"></i> User Management
            </a>
            <?php endif; ?>
			
			
			  
			
			

            
            <div class="mt-4">
                <a class="nav-link text-danger" href="?logout">
                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                </a>
            </div>
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 no-print">
            <div>
                <h2 class="fw-bold text-primary">
                    <?php 
                    switch($action) {
                        case 'dashboard': echo 'Dashboard'; break;
                        case 'view_activities': echo 'Processing Activities'; break;
                        case 'add_activity': echo 'Add Processing Activity'; break;
                        case 'edit_activity': echo 'Edit Processing Activity'; break;
                        case 'view_dpias': echo 'Data Protection Impact Assessments'; break;
                        case 'add_dpia': echo 'Register DPIA'; break;
                        case 'edit_dpia': echo 'Edit DPIA'; break;
                        case 'view_breaches': echo 'Data Breaches'; break;
                        case 'add_breach': echo 'Report Data Breach'; break;
                        case 'edit_breach': echo 'Edit Data Breach'; break;
                        case 'view_third_parties': echo 'Third Parties'; break;
                        case 'add_third_party': echo 'Add Third Party'; break;
                        case 'edit_third_party': echo 'Edit Third Party'; break;
                        case 'audit_log': echo 'Audit Log'; break;
                        case 'users': echo 'User Management'; break;
                        default: echo 'Dashboard';
                    }
                    ?>
                </h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="?action=dashboard">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo ucfirst(str_replace('_', ' ', $action)); ?></li>
                    </ol>
                </nav>
            </div>
            
            <div class="d-flex align-items-center">
                <?php if ($action == 'view_activities' && has_permission('add_activity')): ?>
                <a href="?action=add_activity" class="btn btn-primary me-2">
                    <i class="bi bi-plus-circle me-1"></i> Add Activity
                </a>
                <?php endif; ?>
                
                <?php if ($action == 'view_dpias' && has_permission('add_dpia')): ?>
                <a href="?action=add_dpia" class="btn btn-warning me-2">
                    <i class="bi bi-file-text me-1"></i> Register DPIA
                </a>
                <?php endif; ?>
                
                <?php if (has_permission('print_reports')): ?>
                <div class="dropdown me-2">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-printer me-1"></i> Print
                    </button>
                    <ul class="dropdown-menu">
                        <?php if ($action == 'view_activities' || $action == 'edit_activity'): ?>
                        <li><a class="dropdown-item" href="?print=all_activities" target="_blank">
                            <i class="bi bi-clipboard-data me-2"></i> All Activities Summary
                        </a></li>
                        <?php if ($action == 'edit_activity'): ?>
                        <li><a class="dropdown-item" href="?print=single_activity&id=<?php echo $id; ?>" target="_blank">
                            <i class="bi bi-file-text me-2"></i> Current Activity Details
                        </a></li>
                        <li><a class="dropdown-item" href="?print=safeguards_label&id=<?php echo $id; ?>" target="_blank">
                            <i class="bi bi-tag me-2"></i> Safeguards Label
                        </a></li>
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php if ($action == 'edit_dpia'): ?>
                        <li><a class="dropdown-item" href="?print=dpia_report&id=<?php echo $id; ?>" target="_blank">
                            <i class="bi bi-file-earmark-text me-2"></i> DPIA Report
                        </a></li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="javascript:window.print()">
                            <i class="bi bi-printer me-2"></i> Print Current Page
                        </a></li>
                    </ul>
                </div>
                <?php endif; ?>
                
                <div class="dropdown">
                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i> <?php echo htmlspecialchars($current_user['username']); ?>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="?action=dashboard"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="?logout"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Messages -->
        <?php if ($messages['success']): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <i class="bi bi-check-circle me-2"></i> <?php echo htmlspecialchars($messages['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($messages['error']): ?>
        <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
            <i class="bi bi-exclamation-triangle me-2"></i> <?php echo htmlspecialchars($messages['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($messages['info']): ?>
        <div class="alert alert-info alert-dismissible fade show mb-4" role="alert">
            <i class="bi bi-info-circle me-2"></i> <?php echo htmlspecialchars($messages['info']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- Page Content -->
        <div class="content">
            <?php
            // Include the appropriate content based on action
            switch ($action) {
                case 'dashboard':
                    include_dashboard_content();
                    break;
                    
                case 'view_activities':
                    include_view_activities_content($page, $per_page);
                    break;
                    
                case 'add_activity':
                case 'edit_activity':
                    include_activity_form($id);
                    break;
                    
                case 'view_dpias':
                    include_view_dpias_content($page, $per_page);
                    break;
                    
                case 'add_dpia':
                case 'edit_dpia':
                    include_dpia_form($id);
                    break;
                    
                case 'view_breaches':
                    include_view_breaches_content($page, $per_page);
                    break;
                    
                case 'add_breach':
                case 'edit_breach':
                    include_breach_form($id);
                    break;
                    
                case 'view_third_parties':
                    include_view_third_parties_content($page, $per_page);
                    break;
                    
                case 'add_third_party':
                case 'edit_third_party':
                    include_third_party_form($id);
                    break;
                    
                case 'audit_log':
                    include_audit_log_content($page, $per_page);
                    break;
                    
                case 'users':
                    include_users_content($page, $per_page);
                    break;
                    
                default:
                    include_dashboard_content();
            }
            ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- JavaScript Libraries -->
    <script src="bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="jquery.dataTables.min.js"></script>
    <script src="dataTables.bootstrap5.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Initialize DataTables
        $('.datatable').DataTable({
            pageLength: 25,
            responsive: true,
            order: [[0, 'desc']],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            }
        });
        
        // Activity row click
        $('.activity-row').click(function() {
            var id = $(this).data('id');
            window.location.href = '?action=edit_activity&id=' + id;
        });
        
        // Confirm deletions
        $('.confirm-delete').click(function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Toggle password visibility
        $('.toggle-password').click(function() {
            var input = $(this).parent().find('input');
            var icon = $(this).find('i');
            
            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('bi-eye').addClass('bi-eye-slash');
            } else {
                input.attr('type', 'password');
                icon.removeClass('bi-eye-slash').addClass('bi-eye');
            }
        });
        
        // Auto-calculate review date based on risk level
        $('#risk_level').change(function() {
            var riskLevel = $(this).val();
            var days = {
                'low': <?php echo $app_config['low_risk_review_days']; ?>,
                'medium': <?php echo $app_config['medium_risk_review_days']; ?>,
                'high': <?php echo $app_config['high_risk_review_days']; ?>
            };
            
            if (days[riskLevel]) {
                var today = new Date();
                var reviewDate = new Date();
                reviewDate.setDate(today.getDate() + days[riskLevel]);
                
                var formattedDate = reviewDate.toISOString().split('T')[0];
                $('#review_due_date').val(formattedDate);
            }
        });
        
        // Safeguards functionality
        initSafeguardsFunctionality();
        
        // User management form validation
        initUserManagementValidation();
        
        // Print button functionality
        initPrintFunctions();
        
        // DPIA functionality
        initDPIAFunctionality();
        
        // Initialize risk level change for existing forms
        if ($('#risk_level').val()) {
            $('#risk_level').trigger('change');
        }
    });
    
    function initSafeguardsFunctionality() {
        // Search functionality for safeguards
        $('.safeguards-search-input').on('keyup', function() {
            var searchTerm = $(this).val().toLowerCase();
            var type = $(this).data('type');
            var list = $('.' + type + '-list');
            
            list.find('.safeguards-item').each(function() {
                var text = $(this).text().toLowerCase();
                if (text.indexOf(searchTerm) > -1) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
        
        // Add selected safeguards to textarea
        $('.add-selected-safeguards').click(function() {
            var type = $(this).data('type');
            var textarea = $('#safeguards');
            var currentText = textarea.val();
            var selectedItems = [];
            
            $('.' + type + '-list .safeguards-checkbox:checked').each(function() {
                selectedItems.push($(this).val());
            });
            
            if (selectedItems.length > 0) {
                var newText = selectedItems.join('\n');
                if (currentText) {
                    // Check for duplicates
                    var existingLines = currentText.split('\n').filter(line => line.trim() !== '');
                    var allItems = [...existingLines, ...selectedItems];
                    var uniqueItems = [...new Set(allItems)];
                    textarea.val(uniqueItems.join('\n'));
                } else {
                    textarea.val(newText);
                }
                
                // Scroll to safeguards textarea
                $('html, body').animate({
                    scrollTop: textarea.offset().top - 100
                }, 500);
                
                // Show success message
                showToast('Success', selectedItems.length + ' safeguards added to the list.', 'success');
            } else {
                showToast('Info', 'Please select at least one safeguard.', 'info');
            }
        });
        
        // Auto-populate safeguards from technical and organizational measures
        $('#auto_populate_safeguards').click(function() {
            var technical = $('#technical_measures').val();
            var organizational = $('#organizational_measures').val();
            var safeguards = $('#safeguards');
            
            var technicalLines = technical.split('\n').filter(line => line.trim() !== '');
            var organizationalLines = organizational.split('\n').filter(line => line.trim() !== '');
            
            var allMeasures = [...technicalLines, ...organizationalLines];
            var uniqueMeasures = [...new Set(allMeasures)];
            
            safeguards.val(uniqueMeasures.join('\n'));
            
            // Scroll to safeguards textarea
            $('html, body').animate({
                scrollTop: safeguards.offset().top - 100
            }, 500);
            
            showToast('Success', 'Safeguards auto-populated from technical and organizational measures.', 'success');
        });
        
        // Parse existing safeguards and check checkboxes
        parseExistingSafeguards();
    }
    
    function parseExistingSafeguards() {
        var safeguardsText = $('#safeguards').val();
        if (!safeguardsText) return;
        
        var lines = safeguardsText.split('\n').filter(line => line.trim() !== '');
        
        lines.forEach(function(line) {
            line = line.trim();
            // Find and check corresponding checkbox
            $('.safeguards-checkbox').each(function() {
                if ($(this).val() === line) {
                    $(this).prop('checked', true);
                }
            });
        });
    }
    
    function initUserManagementValidation() {
        // Password confirmation for add user form
        $('#addUserModal form').on('submit', function(e) {
            var password = $(this).find('input[name="password"]').val();
            var confirmPassword = $(this).find('input[name="confirm_password"]').val();
            
            if (password !== confirmPassword) {
                showToast('Error', 'Passwords do not match!', 'danger');
                e.preventDefault();
                return false;
            }
            
            if (password.length < <?php echo $app_config['password_min_length']; ?>) {
                showToast('Error', 'Password must be at least <?php echo $app_config['password_min_length']; ?> characters long!', 'danger');
                e.preventDefault();
                return false;
            }
            
            return true;
        });
        
        // Password confirmation for edit user form
        $('#editUserModal form').on('submit', function(e) {
            var newPassword = $(this).find('input[name="new_password"]').val();
            var confirmNewPassword = $(this).find('input[name="confirm_new_password"]').val();
            
            if (newPassword && newPassword !== confirmNewPassword) {
                showToast('Error', 'New passwords do not match!', 'danger');
                e.preventDefault();
                return false;
            }
            
            if (newPassword && newPassword.length < <?php echo $app_config['password_min_length']; ?>) {
                showToast('Error', 'New password must be at least <?php echo $app_config['password_min_length']; ?> characters long!', 'danger');
                e.preventDefault();
                return false;
            }
            
            return true;
        });
    }
    
    function initPrintFunctions() {
        // Print all activities in new window
        $('a[href*="print=all_activities"]').click(function(e) {
            e.preventDefault();
            window.open(this.href, '_blank', 'width=800,height=600');
        });
        
        // Print single activity in new window
        $('a[href*="print=single_activity"]').click(function(e) {
            e.preventDefault();
            window.open(this.href, '_blank', 'width=800,height=600');
        });
        
        // Print safeguards label in new window
        $('a[href*="print=safeguards_label"]').click(function(e) {
            e.preventDefault();
            window.open(this.href, '_blank', 'width=400,height=600');
        });
        
        // Print DPIA report in new window
        $('a[href*="print=dpia_report"]').click(function(e) {
            e.preventDefault();
            window.open(this.href, '_blank', 'width=800,height=600');
        });
    }
    
    function initDPIAFunctionality() {
        // Risk matrix cell selection
        $('.risk-cell').click(function() {
            var checkbox = $(this).find('input[type="checkbox"]');
            checkbox.prop('checked', !checkbox.prop('checked'));
            $(this).toggleClass('selected');
            
            // Update overall risk level
            updateOverallRiskLevel();
        });
        
        // Calculate overall risk level
        function updateOverallRiskLevel() {
            var highRiskCount = 0;
            var mediumRiskCount = 0;
            var lowRiskCount = 0;
            
            $('.risk-cell.selected').each(function() {
                var cell = $(this);
                if (cell.hasClass('risk-high')) {
                    highRiskCount++;
                } else if (cell.hasClass('risk-medium')) {
                    mediumRiskCount++;
                } else if (cell.hasClass('risk-low')) {
                    lowRiskCount++;
                }
            });
            
            var overallRisk = 'medium'; // default
            
            if (highRiskCount > 0) {
                overallRisk = 'high';
            } else if (mediumRiskCount > 0) {
                overallRisk = 'medium';
            } else if (lowRiskCount > 0) {
                overallRisk = 'low';
            }
            
            // Update the overall risk level select
            $('#overall_risk_level').val(overallRisk);
            
            // Update the display
            $('.overall-risk-display').removeClass('risk-low risk-medium risk-high').addClass('risk-' + overallRisk);
        }
        
        // DPIA status change
        $('#dpia_status').change(function() {
            var status = $(this).val();
            
            // Show/hide approval section based on status
            if (status === 'under_review' || status === 'approved' || status === 'rejected') {
                $('.approval-section').show();
            } else {
                $('.approval-section').hide();
            }
            
            // If approved, automatically set management approval
            if (status === 'approved') {
                $('#management_approval').val('approved');
            }
        });
        
        // Initialize
        updateOverallRiskLevel();
        $('#dpia_status').trigger('change');
    }
    
    // Toast notification function
    function showToast(title, message, type = 'info') {
        // Remove existing toasts
        $('.toast-container').remove();
        
        // Create toast container
        var toastContainer = $('<div class="toast-container position-fixed bottom-0 end-0 p-3"></div>');
        
        // Create toast
        var toast = $(`
            <div class="toast align-items-center text-white bg-${type} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        <strong>${title}</strong><br>
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `);
        
        // Append toast to container
        toastContainer.append(toast);
        
        // Append container to body
        $('body').append(toastContainer);
        
        // Initialize and show toast
        var bsToast = new bootstrap.Toast(toast[0]);
        bsToast.show();
        
        // Remove toast after it hides
        toast.on('hidden.bs.toast', function () {
            toastContainer.remove();
        });
    }
    
    // Form validation helper
    function validateForm(formId) {
        var form = document.getElementById(formId);
        if (!form.checkValidity()) {
            form.classList.add('was-validated');
            return false;
        }
        return true;
    }
    
    // Character counter for textareas
    function initCharacterCounters() {
        $('textarea[maxlength]').each(function() {
            var maxLength = $(this).attr('maxlength');
            var currentLength = $(this).val().length;
            var counterId = $(this).attr('id') + '-counter';
            
            // Create counter element
            if (!$('#' + counterId).length) {
                $(this).after('<small id="' + counterId + '" class="form-text text-muted character-counter">' + currentLength + '/' + maxLength + ' characters</small>');
            }
            
            // Update counter on input
            $(this).on('input', function() {
                currentLength = $(this).val().length;
                $('#' + counterId).text(currentLength + '/' + maxLength + ' characters');
                
                if (currentLength > maxLength) {
                    $('#' + counterId).addClass('text-danger');
                } else {
                    $('#' + counterId).removeClass('text-danger');
                }
            });
        });
    }
    
    // Initialize character counters
    initCharacterCounters();
    </script>
</body>
</html>

<?php
// ============================================
// CONTENT INCLUDE FUNCTIONS
// ============================================

function include_dashboard_content() {
    global $current_user, $app_config;
    $stats = get_dashboard_stats();
    $activities = get_activities_with_review_status(10);
    $dpia_stats = get_dpia_statistics();
    $breach_stats = get_breach_statistics();
    $third_party_stats = get_third_party_statistics();
    $overdue_reviews = get_overdue_reviews();
    $upcoming_reviews = get_upcoming_reviews(30);
    ?>
    
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card stat-card border-start border-primary border-4">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col-8">
                            <div class="text-muted fw-semibold">Total Activities</div>
                            <div class="h2 mt-2 fw-bold"><?php echo $stats['total_activities']; ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <i class="bi bi-clipboard-data stat-icon text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stat-card border-start border-danger border-4">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col-8">
                            <div class="text-muted fw-semibold">High Risk</div>
                            <div class="h2 mt-2 fw-bold"><?php echo $stats['high_risk']; ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <i class="bi bi-exclamation-triangle stat-icon text-danger"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stat-card border-start border-warning border-4">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col-8">
                            <div class="text-muted fw-semibold">Due for Review</div>
                            <div class="h2 mt-2 fw-bold"><?php echo $stats['due_for_review']; ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <i class="bi bi-calendar-check stat-icon text-warning"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stat-card border-start border-info border-4">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col-8">
                            <div class="text-muted fw-semibold">Open DPIAs</div>
                            <div class="h2 mt-2 fw-bold"><?php echo $stats['open_dpias']; ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <i class="bi bi-file-text stat-icon text-info"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Recent Activities</h5>
                    <div class="print-actions">
                        <?php if (has_permission('print_reports')): ?>
                        <a href="?print=all_activities" target="_blank" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-printer me-1"></i> Print All
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover datatable">
                            <thead>
                                <tr>
                                    <th>Activity</th>
                                    <th>Department</th>
                                    <th>Risk Level</th>
                                    <th>Status</th>
                                    <th>Last Updated</th>
                                    <th class="no-print">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($activities as $row): ?>
                                <tr>
                                    <td>
                                        <a href="?action=edit_activity&id=<?php echo $row['id']; ?>" class="text-decoration-none">
                                            <?php echo htmlspecialchars($row['processing_activity']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['department']); ?></td>
                                    <td><?php echo get_risk_badge($row['risk_level']); ?></td>
                                    <td><?php echo get_status_badge($row['status']); ?></td>
                                    <td><?php echo format_date($row['updated_at']); ?></td>
                                    <td class="no-print">
                                        <div class="print-actions">
                                            <a href="?action=edit_activity&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="?print=single_activity&id=<?php echo $row['id']; ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="Print Details">
                                                <i class="bi bi-printer"></i>
                                            </a>
                                            <a href="?print=safeguards_label&id=<?php echo $row['id']; ?>" target="_blank" class="btn btn-sm btn-outline-info" title="Print Label">
                                                <i class="bi bi-tag"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <a href="?action=view_activities" class="btn btn-primary btn-sm mt-3">View All Activities</a>
                </div>
            </div>
            
            <!-- Overdue Reviews Section -->
            <?php if (!empty($overdue_reviews)): ?>
            <div class="card mt-4 border-danger">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">
                        <i class="bi bi-exclamation-triangle me-2"></i>Overdue Reviews
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Activity</th>
                                    <th>Department</th>
                                    <th>Risk Level</th>
                                    <th>Review Due Date</th>
                                    <th>Days Overdue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($overdue_reviews as $row): ?>
                                <tr>
                                    <td>
                                        <a href="?action=edit_activity&id=<?php echo $row['id']; ?>" class="text-decoration-none">
                                            <?php echo htmlspecialchars($row['processing_activity']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['department']); ?></td>
                                    <td><?php echo get_risk_badge($row['risk_level']); ?></td>
                                    <td class="text-danger fw-bold"><?php echo format_date($row['review_due_date'], 'd-m-Y'); ?></td>
                                    <td><span class="badge bg-danger"><?php echo abs($row['days_overdue']); ?> days</span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-white border-bottom">
                    <h5 class="card-title mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <?php if (has_permission('add_activity')): ?>
                        <a href="?action=add_activity" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-2"></i> Add Processing Activity
                        </a>
                        <?php endif; ?>
                        
                        <?php if (has_permission('add_dpia')): ?>
                        <a href="?action=add_dpia" class="btn btn-warning">
                            <i class="bi bi-file-text me-2"></i> Register New DPIA
                        </a>
                        <?php endif; ?>
                        
                        <?php if (has_permission('add_breach')): ?>
                        <a href="?action=add_breach" class="btn btn-danger">
                            <i class="bi bi-exclamation-triangle me-2"></i> Report Data Breach
                        </a>
                        <?php endif; ?>
                        
                        <a href="?action=view_activities" class="btn btn-outline-primary">
                            <i class="bi bi-list-ul me-2"></i> View All Activities
                        </a>
                        
                        <?php if (has_permission('print_reports')): ?>
                        <a href="?print=all_activities" target="_blank" class="btn btn-outline-secondary">
                            <i class="bi bi-printer me-2"></i> Print All Activities
                        </a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mt-4">
                        <h6 class="text-muted mb-3">System Information</h6>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="bi bi-clock-history text-primary me-2"></i>
                                <span class="text-muted">Last Login:</span>
                                <strong><?php echo format_date($current_user['last_login'] ?? 'Never'); ?></strong>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-shield-check text-success me-2"></i>
                                <span class="text-muted">Role:</span>
                                <strong><?php echo ucfirst($current_user['role']); ?></strong>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-info-circle text-info me-2"></i>
                                <span class="text-muted">Version:</span>
                                <strong><?php echo $app_config['version']; ?></strong>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Review Status Summary -->
            <div class="card shadow mt-4">
                <div class="card-header bg-white">
                    <h6 class="card-title mb-0">Review Status</h6>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Total Activities:</span>
                        <strong><?php echo $stats['total_activities']; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">High Risk:</span>
                        <strong class="text-danger"><?php echo $stats['high_risk']; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Due for Review:</span>
                        <strong class="text-warning"><?php echo $stats['due_for_review']; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Overdue:</span>
                        <strong class="text-danger"><?php echo count($overdue_reviews); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="text-muted">Upcoming (30 days):</span>
                        <strong class="text-info"><?php echo count($upcoming_reviews); ?></strong>
                    </div>
                </div>
            </div>
            
            <!-- DPIA Statistics -->
            <div class="card shadow mt-4">
                <div class="card-header bg-white">
                    <h6 class="card-title mb-0">DPIA Statistics</h6>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Total DPIAs:</span>
                        <strong><?php echo $dpia_stats['total']; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Pending Approval:</span>
                        <strong class="text-warning"><?php echo $dpia_stats['by_approval']['pending'] ?? 0; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">High Risk DPIAs:</span>
                        <strong class="text-danger"><?php echo $dpia_stats['by_risk']['high'] ?? 0; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="text-muted">Open DPIAs:</span>
                        <strong class="text-warning"><?php echo $stats['open_dpias']; ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}
function include_view_activities_content($page, $per_page) {
    global $gdpr_options;
    $conn = create_db_connection();
    
    // Get all activities (let DataTables handle pagination client-side)
    $result = $conn->query("
        SELECT g.*
        FROM gdpr_register g
        ORDER BY g.updated_at DESC
    ");
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Processing Activities</h5>
            <div class="d-flex">
                <?php if (has_permission('print_reports')): ?>
                <a href="?print=all_activities" target="_blank" class="btn btn-outline-secondary btn-sm me-2">
                    <i class="bi bi-printer me-1"></i> Print All
                </a>
                <?php endif; ?>
                <?php if (has_permission('add_activity')): ?>
                <a href="?action=add_activity" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-circle me-1"></i> Add New
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="activitiesTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Processing Activity</th>
                            <th>Department</th>
                            <th>Risk Level</th>
                            <th>DPIA Status</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td>
                                <a href="?action=edit_activity&id=<?php echo $row['id']; ?>" class="text-decoration-none">
                                    <?php echo htmlspecialchars($row['processing_activity']); ?>
                                </a>
                            </td>
                            <td><?php echo $gdpr_options['departments'][$row['department']] ?? $row['department']; ?></td>
                            <td><?php echo get_risk_badge($row['risk_level']); ?></td>
                            <td><?php echo get_status_badge($row['dpia_status']); ?></td>
                            <td><?php echo get_status_badge($row['status']); ?></td>
                            <td><?php echo format_date($row['created_at'], 'd-m-Y'); ?></td>
                            <td class="no-print">
                                <div class="btn-group btn-group-sm">
                                    <a href="?action=edit_activity&id=<?php echo $row['id']; ?>" class="btn btn-outline-primary" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <?php if (has_permission('print_reports')): ?>
                                    <a href="?print=single_activity&id=<?php echo $row['id']; ?>" target="_blank" class="btn btn-outline-secondary" title="Print">
                                        <i class="bi bi-printer"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if (has_permission('delete_activity')): ?>
                                    <button type="button" class="btn btn-outline-danger confirm-delete" 
                                            data-bs-toggle="modal" data-bs-target="#deleteModal" 
                                            data-id="<?php echo $row['id']; ?>"
                                            data-name="<?php echo htmlspecialchars($row['processing_activity']); ?>"
                                            title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this processing activity?</p>
                    <p id="deleteItemName" class="fw-bold"></p>
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        Warning: This action cannot be undone. Any associated DPIAs will also be deleted.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="activity_id" id="deleteItemId">
                        <button type="submit" name="delete_activity" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    $(document).ready(function() {
        // Initialize DataTables with CLIENT-SIDE pagination only
        $('#activitiesTable').DataTable({
            pageLength: 25,
            responsive: true,
            order: [[0, 'desc']],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            }
        });
        
        // Delete modal handler
        $('#deleteModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var name = button.data('name');
            
            var modal = $(this);
            modal.find('#deleteItemId').val(id);
            modal.find('#deleteItemName').text(name);
        });
    });
    </script>
    <?php
}

function include_activity_form($id = 0) {
    global $gdpr_options, $encrypted_columns, $safeguards_options;
    $conn = create_db_connection();
    
    $is_edit = $id > 0;
    $activity = null;
    
    if ($is_edit) {
        $stmt = $conn->prepare("SELECT * FROM gdpr_register WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $activity = $result->fetch_assoc();
        
        // Decrypt encrypted fields
        if ($activity) {
            foreach ($encrypted_columns as $field) {
                if (!empty($activity[$field])) {
                    $activity[$field] = decrypt_data($activity[$field]);
                }
            }
        }
    }
    
    // Parse existing safeguards
    $existing_safeguards = parse_safeguards_text($activity['safeguards'] ?? '');
    $existing_technical = $existing_safeguards['technical'];
    $existing_organizational = $existing_safeguards['organizational'];
    
    // Check if DPIA exists for this activity
    $has_dpia = false;
    if ($is_edit) {
        $dpia_check = $conn->prepare("SELECT id FROM dpia_registrations WHERE record_id = ?");
        $dpia_check->bind_param("i", $id);
        $dpia_check->execute();
        $has_dpia = $dpia_check->get_result()->num_rows > 0;
    }
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0"><?php echo $is_edit ? 'Edit' : 'Add'; ?> Processing Activity</h5>
            <?php if ($is_edit && has_permission('print_reports')): ?>
            <div class="print-actions">
                <a href="?print=single_activity&id=<?php echo $id; ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-printer me-1"></i> Print Details
                </a>
                <a href="?print=safeguards_label&id=<?php echo $id; ?>" target="_blank" class="btn btn-sm btn-outline-info">
                    <i class="bi bi-tag me-1"></i> Print Label
                </a>
                <?php if ($activity['dpia_required'] == 'yes' && has_permission('add_dpia')): ?>
                    <?php if ($has_dpia): ?>
                    <a href="?action=edit_dpia&id=<?php echo get_dpia_by_activity($id)['id']; ?>" class="btn btn-sm btn-warning">
                        <i class="bi bi-file-text me-1"></i> Edit DPIA
                    </a>
                    <?php else: ?>
                    <a href="?action=add_dpia&record_id=<?php echo $id; ?>" class="btn btn-sm btn-warning">
                        <i class="bi bi-file-text me-1"></i> Register DPIA
                    </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="POST" id="activityForm">
                <?php if ($is_edit): ?>
                <input type="hidden" name="activity_id" value="<?php echo $id; ?>">
                <?php endif; ?>
                
                <!-- Basic Information Section -->
                <div class="data-controller-section">
                    <h5 class="section-title">Basic Information</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label required-field">Processing Activity Name</label>
                                <input type="text" name="processing_activity" class="form-control" required
                                       value="<?php echo htmlspecialchars($activity['processing_activity'] ?? ''); ?>"
                                       placeholder="Enter the name of the processing activity">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Department</label>
                                <select name="department" class="form-select" required>
                                    <option value="">Select Department</option>
                                    <?php foreach ($gdpr_options['departments'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($activity['department'] ?? '') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Status</label>
                                <select name="status" class="form-select" required>
                                    <?php foreach ($gdpr_options['status_options'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($activity['status'] ?? 'active') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Data Controller Information Section -->
                <div class="data-controller-section">
                    <h5 class="section-title">Data Controller Information</h5>
                    <p class="text-muted mb-3">This information is encrypted for security.</p>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group encrypted-field">
                                <label class="form-label">Name of Data Controller</label>
                                <input type="text" name="name_data_controller" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['name_data_controller'] ?? ''); ?>"
                                       placeholder="Enter name of data controller">
                                <small class="field-hint"><i class="bi bi-shield-lock"></i> This field is encrypted</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group encrypted-field">
                                <label class="form-label">Contact Data Controller</label>
                                <input type="text" name="contact_data_controller" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['contact_data_controller'] ?? ''); ?>"
                                       placeholder="Email or phone number">
                                <small class="field-hint"><i class="bi bi-shield-lock"></i> This field is encrypted</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group encrypted-field">
                                <label class="form-label">Name of Joint Data Controller</label>
                                <input type="text" name="name_joint_data_controller" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['name_joint_data_controller'] ?? ''); ?>"
                                       placeholder="If applicable">
                                <small class="field-hint"><i class="bi bi-shield-lock"></i> This field is encrypted</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group encrypted-field">
                                <label class="form-label">Contact Joint Data Controller</label>
                                <input type="text" name="contact_joint_data_controller" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['contact_joint_data_controller'] ?? ''); ?>"
                                       placeholder="Email or phone number">
                                <small class="field-hint"><i class="bi bi-shield-lock"></i> This field is encrypted</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group encrypted-field">
                                <label class="form-label">Name of Representative</label>
                                <input type="text" name="name_representative" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['name_representative'] ?? ''); ?>"
                                       placeholder="If applicable">
                                <small class="field-hint"><i class="bi bi-shield-lock"></i> This field is encrypted</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group encrypted-field">
                                <label class="form-label">Contact Representative</label>
                                <input type="text" name="contact_representative" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['contact_representative'] ?? ''); ?>"
                                       placeholder="Email or phone number">
                                <small class="field-hint"><i class="bi bi-shield-lock"></i> This field is encrypted</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group encrypted-field">
                                <label class="form-label">Name of Data Protection Officer (DPO)</label>
                                <input type="text" name="name_dpo" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['name_dpo'] ?? ''); ?>"
                                       placeholder="If applicable">
                                <small class="field-hint"><i class="bi bi-shield-lock"></i> This field is encrypted</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group encrypted-field">
                                <label class="form-label">Contact DPO</label>
                                <input type="text" name="contact_dpo" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['contact_dpo'] ?? ''); ?>"
                                       placeholder="Email or phone number">
                                <small class="field-hint"><i class="bi bi-shield-lock"></i> This field is encrypted</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Processing Details Section -->
                <div class="data-controller-section">
                    <h5 class="section-title">Processing Details</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Legal Basis</label>
                                <select name="legal_basis" class="form-select" required>
                                    <option value="">Select Legal Basis</option>
                                    <?php foreach ($gdpr_options['legal_bases'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($activity['legal_basis'] ?? '') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Risk Level</label>
                                <select name="risk_level" id="risk_level" class="form-select" required>
                                    <option value="">Select Risk Level</option>
                                    <?php foreach ($gdpr_options['risk_levels'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($activity['risk_level'] ?? '') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Purpose of Processing</label>
                                <textarea name="purpose_of_processing" class="form-control" rows="3" required
                                          placeholder="Describe the purpose of this processing activity"><?php echo htmlspecialchars($activity['purpose_of_processing'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Categories of Personal Data</label>
                                <textarea name="categories_personal_data" class="form-control" rows="3" required
                                          placeholder="List the categories of personal data being processed"><?php echo htmlspecialchars($activity['categories_personal_data'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Categories of Data Subjects</label>
                                <input type="text" name="categories_data_subjects" class="form-control" required
                                       value="<?php echo htmlspecialchars($activity['categories_data_subjects'] ?? ''); ?>"
                                       placeholder="e.g., Employees, Customers, Volunteers">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Categories of Recipients</label>
                                <input type="text" name="categories_recipients" class="form-control" required
                                       value="<?php echo htmlspecialchars($activity['categories_recipients'] ?? ''); ?>"
                                       placeholder="Who receives the data">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Retention Periods</label>
                                <input type="text" name="retention_periods" class="form-control" required
                                       value="<?php echo htmlspecialchars($activity['retention_periods'] ?? ''); ?>"
                                       placeholder="e.g., 7 years, Until deletion request">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Review Due Date</label>
                                <input type="date" name="review_due_date" id="review_due_date" class="form-control"
                                       value="<?php echo htmlspecialchars($activity['review_due_date'] ?? ''); ?>">
                                <small class="field-hint">Auto-calculated based on risk level</small>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">Legitimate Interest Description</label>
                                <textarea name="legitimate_interest_description" class="form-control" rows="2"
                                          placeholder="Required if legal basis is 'Legitimate Interests'"><?php echo htmlspecialchars($activity['legitimate_interest_description'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Third Party Processing Section -->
                <div class="data-controller-section">
                    <h5 class="section-title">Third Party Processing</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Has Processing Agreement with Third Party?</label>
                                <select name="has_processing_agreement_with_third_party" class="form-select">
                                    <option value="no" <?php echo ($activity['has_processing_agreement_with_third_party'] ?? 'no') == 'no' ? 'selected' : ''; ?>>No</option>
                                    <option value="yes" <?php echo ($activity['has_processing_agreement_with_third_party'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">We are Processor?</label>
                                <select name="we_are_processor" class="form-select">
                                    <option value="no" <?php echo ($activity['we_are_processor'] ?? 'no') == 'no' ? 'selected' : ''; ?>>No</option>
                                    <option value="yes" <?php echo ($activity['we_are_processor'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Security Measures Section -->
                <div class="data-controller-section">
                    <h5 class="section-title">Security Measures</h5>
                    
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Technical Measures</label>
                                <textarea name="technical_measures" id="technical_measures" class="form-control" rows="3" required
                                          placeholder="Describe technical security measures"><?php echo htmlspecialchars($activity['technical_measures'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Organizational Measures</label>
                                <textarea name="organizational_measures" id="organizational_measures" class="form-control" rows="3" required
                                          placeholder="Describe organizational security measures"><?php echo htmlspecialchars($activity['organizational_measures'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- DPIA Information Section -->
                <div class="data-controller-section">
                    <h5 class="section-title">DPIA Information</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">DPIA Required?</label>
                                <select name="dpia_required" class="form-select" required>
                                    <option value="no" <?php echo ($activity['dpia_required'] ?? 'no') == 'no' ? 'selected' : ''; ?>>No</option>
                                    <option value="yes" <?php echo ($activity['dpia_required'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">DPIA Status</label>
                                <select name="dpia_status" class="form-select">
                                    <?php foreach ($gdpr_options['dpia_statuses'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($activity['dpia_status'] ?? 'not_required') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <?php if ($has_dpia): ?>
                        <div class="col-12">
                            <div class="alert alert-info">
                                <i class="bi bi-info-circle me-2"></i>
                                This activity has an existing DPIA. 
                                <a href="?action=edit_dpia&id=<?php echo get_dpia_by_activity($id)['id']; ?>" class="alert-link">
                                    View DPIA Details
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- International Data Transfers Section -->
                <div class="data-controller-section">
                    <h5 class="section-title">International Data Transfers</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">International Data Transfers?</label>
                                <select name="is_international_data_transfers" class="form-select">
                                    <option value="unknown" <?php echo ($activity['is_international_data_transfers'] ?? 'unknown') == 'unknown' ? 'selected' : ''; ?>>Unknown</option>
                                    <option value="no" <?php echo ($activity['is_international_data_transfers'] ?? '') == 'no' ? 'selected' : ''; ?>>No</option>
                                    <option value="yes" <?php echo ($activity['is_international_data_transfers'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">To Country</label>
                                <select name="to_country" class="form-select">
                                    <?php foreach ($gdpr_options['countries'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($activity['to_country'] ?? 'none') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Safeguards Section -->
                <div class="data-controller-section">
                    <h5 class="section-title">Safeguards for International Data Transfers</h5>
                    <p class="text-muted mb-3">Select technical and organizational measures from the lists below, then click "Add Selected to Textarea"</p>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Technical Measures Options</label>
                                <?php echo get_safeguards_options_html('technical', $existing_technical); ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Organizational Measures Options</label>
                                <?php echo get_safeguards_options_html('organizational', $existing_organizational); ?>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">Safeguards (Combined Technical & Organizational Measures)</label>
                                <textarea name="safeguards" id="safeguards" class="form-control" rows="5"
                                          placeholder="List all safeguards for international data transfers"><?php echo htmlspecialchars($activity['safeguards'] ?? ''); ?></textarea>
                                <div class="mt-2">
                                    <button type="button" id="auto_populate_safeguards" class="btn btn-sm btn-warning">
                                        <i class="bi bi-arrow-repeat me-1"></i> Auto-populate from Technical & Organizational Measures
                                    </button>
                                    <small class="text-muted ms-2">Combines all technical and organizational measures</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Form Actions -->
                <div class="mt-4 pt-3 border-top">
                    <button type="submit" name="save_activity" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> <?php echo $is_edit ? 'Update' : 'Save'; ?> Activity
                    </button>
                    <a href="?action=view_activities" class="btn btn-secondary">Cancel</a>
                    
                    <?php if ($is_edit): ?>
                    <?php if (has_permission('print_reports')): ?>
                    <a href="?print=single_activity&id=<?php echo $id; ?>" target="_blank" class="btn btn-outline-secondary">
                        <i class="bi bi-printer me-1"></i> Print Details
                    </a>
                    <a href="?print=safeguards_label&id=<?php echo $id; ?>" target="_blank" class="btn btn-outline-info">
                        <i class="bi bi-tag me-1"></i> Print Label
                    </a>
                    <?php endif; ?>
                    
                    <?php if ($activity['dpia_required'] == 'yes' && has_permission('add_dpia')): ?>
                        <?php if ($has_dpia): ?>
                        <a href="?action=edit_dpia&id=<?php echo get_dpia_by_activity($id)['id']; ?>" class="btn btn-warning">
                            <i class="bi bi-file-text me-1"></i> Edit DPIA
                        </a>
                        <?php else: ?>
                        <a href="?action=add_dpia&record_id=<?php echo $id; ?>" class="btn btn-warning">
                            <i class="bi bi-file-text me-1"></i> Register DPIA
                        </a>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if (has_permission('delete_activity')): ?>
                    <button type="button" class="btn btn-outline-danger float-end confirm-delete" 
                            data-bs-toggle="modal" data-bs-target="#deleteModal" 
                            data-id="<?php echo $id; ?>"
                            data-name="<?php echo htmlspecialchars($activity['processing_activity']); ?>">
                        <i class="bi bi-trash me-1"></i> Delete
                    </button>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this processing activity?</p>
                    <p id="deleteItemName" class="fw-bold"></p>
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        Warning: This action cannot be undone. Any associated DPIAs will also be deleted.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="activity_id" id="deleteItemId">
                        <button type="submit" name="delete_activity" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    // Delete modal handler
    $('#deleteModal').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var name = button.data('name');
        
        var modal = $(this);
        modal.find('#deleteItemId').val(id);
        modal.find('#deleteItemName').text(name);
    });
    
    // Form validation
    $('#activityForm').on('submit', function(e) {
        if (!validateForm('activityForm')) {
            e.preventDefault();
            return false;
        }
        return true;
    });
    </script>
    <?php
}


function include_view_dpias_content($page, $per_page) {
    global $dpia_options;
    $conn = create_db_connection();
    
    // Get all DPIAs
    $result = $conn->query("
        SELECT d.*, g.processing_activity, u.full_name as registered_by_name,
               a.full_name as approved_by_name
        FROM dpia_registrations d
        LEFT JOIN gdpr_register g ON d.record_id = g.id
        LEFT JOIN system_users u ON d.registered_by = u.id
        LEFT JOIN system_users a ON d.approved_by = a.id
        ORDER BY d.registered_at DESC
    ");
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Data Protection Impact Assessments</h5>
            <?php if (has_permission('add_dpia')): ?>
            <a href="?action=add_dpia" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Register DPIA
            </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="dpiaTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Related Activity</th>
                            <th>Risk Level</th>
                            <th>Status</th>
                            <th>Approval</th>
                            <th>Registered By</th>
                            <th>Registered Date</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td>
                                <?php if ($row['processing_activity']): ?>
                                <a href="?action=edit_activity&id=<?php echo $row['record_id']; ?>">
                                    <?php echo htmlspecialchars($row['processing_activity']); ?>
                                </a>
                                <?php else: ?>
                                <span class="text-muted">Activity #<?php echo $row['record_id']; ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo get_risk_badge($row['overall_risk_level']); ?></td>
                            <td><?php echo get_status_badge($row['status']); ?></td>
                            <td><?php echo get_approval_badge($row['management_approval']); ?></td>
                            <td><?php echo htmlspecialchars($row['registered_by_name']); ?></td>
                            <td><?php echo format_date($row['registered_at']); ?></td>
                            <td class="no-print">
                                <div class="btn-group btn-group-sm">
                                    <a href="?action=edit_dpia&id=<?php echo $row['id']; ?>" class="btn btn-outline-primary" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <?php if (has_permission('print_reports')): ?>
                                    <a href="?print=dpia_report&id=<?php echo $row['id']; ?>" target="_blank" class="btn btn-outline-secondary" title="Print">
                                        <i class="bi bi-printer"></i>
                                    </a>
                                    <?php endif; ?>
                                    <a href="?action=edit_activity&id=<?php echo $row['record_id']; ?>" class="btn btn-outline-info" title="View Activity">
                                        <i class="bi bi-clipboard-data"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    $(document).ready(function() {
        // Initialize DataTables with CLIENT-SIDE pagination only
        $('#dpiaTable').DataTable({
            pageLength: 25,
            responsive: true,
            order: [[0, 'desc']],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            }
        });
    });
    </script>
    <?php
}




function include_dpia_form($id = 0) {
    global $current_user, $dpia_options, $gdpr_options;
    $conn = create_db_connection();
    
    $is_edit = $id > 0;
    $dpia = null;
    
    if ($is_edit) {
        $stmt = $conn->prepare("SELECT * FROM dpia_registrations WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $dpia = $result->fetch_assoc();
        
        // Decode JSON fields
        $dpia['compliance_checklist'] = !empty($dpia['compliance_checklist']) 
            ? json_decode($dpia['compliance_checklist'], true) 
            : [];
        $dpia['risk_assessment_matrix'] = !empty($dpia['risk_assessment_matrix']) 
            ? json_decode($dpia['risk_assessment_matrix'], true) 
            : [];
    }
    
    // Get activities for dropdown
    $activities = get_activities_for_dpia(true);
    
    // Get activity details if record_id is set
    $activity_details = null;
    if ($is_edit && $dpia['record_id']) {
        $activity_details = get_activity_for_dpia($dpia['record_id']);
    } elseif (isset($_GET['record_id'])) {
        $activity_details = get_activity_for_dpia($_GET['record_id']);
    }
    ?>
    
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="card-title mb-0"><?php echo $is_edit ? 'Edit' : 'Register'; ?> Data Protection Impact Assessment (DPIA)</h5>
        </div>
        <div class="card-body">
            <form method="POST" id="dpiaForm">
                <?php if ($is_edit): ?>
                <input type="hidden" name="dpia_id" value="<?php echo $id; ?>">
                <?php endif; ?>
                
                <!-- DPIA Information Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">DPIA Information</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Related Processing Activity</label>
                                <select name="record_id" id="record_id" class="form-select" required <?php echo $is_edit ? 'disabled' : ''; ?>>
                                    <option value="">Select Activity</option>
                                    <?php foreach ($activities as $activity): ?>
                                    <option value="<?php echo $activity['id']; ?>"
                                        <?php 
                                        if ($is_edit && $dpia['record_id'] == $activity['id']) {
                                            echo 'selected';
                                        } elseif (isset($_GET['record_id']) && $_GET['record_id'] == $activity['id']) {
                                            echo 'selected';
                                        }
                                        ?>
                                        <?php echo ($activity['dpia_required'] ?? 'no') == 'yes' ? '' : 'disabled'; ?>>
                                        <?php echo htmlspecialchars($activity['processing_activity']); ?>
                                        <?php echo ($activity['dpia_required'] ?? 'no') == 'yes' ? '' : ' (DPIA not required)'; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($is_edit): ?>
                                <input type="hidden" name="record_id" value="<?php echo $dpia['record_id']; ?>">
                                <?php endif; ?>
                                <small class="field-hint">Only activities marked as requiring DPIA are available</small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Title</label>
                                <input type="text" name="title" class="form-control" required
                                       value="<?php echo htmlspecialchars($dpia['title'] ?? 'DPIA Assessment'); ?>"
                                       placeholder="Enter DPIA title">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Risk Origin</label>
                                <select name="risk_origin" class="form-select" required>
                                    <option value="">Select Risk Origin</option>
                                    <?php foreach ($dpia_options['risk_origins'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($dpia['risk_origin'] ?? '') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Estimated Data Subjects Affected</label>
                                <input type="number" name="data_subjects_affected" id="data_subjects_affected" class="form-control" required min="0"
                                       value="<?php echo htmlspecialchars($dpia['data_subjects_affected'] ?? '0'); ?>"
                                       placeholder="Enter estimated number">
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">DPIA Description</label>
                                <textarea name="description" class="form-control" rows="3" required
                                          placeholder="Describe the purpose and scope of this DPIA"><?php echo htmlspecialchars($dpia['description'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Processing Activity Description</label>
                                <textarea name="processing_activity_description" class="form-control" rows="3" required
                                          placeholder="Describe the processing activity in detail"><?php 
                                    echo htmlspecialchars($dpia['processing_activity_description'] ?? $activity_details['purpose_of_processing'] ?? ''); 
                                ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Categories of Data Processed</label>
                                <textarea name="data_categories" class="form-control" rows="2" required
                                          placeholder="List categories of personal data being processed"><?php 
                                    echo htmlspecialchars($dpia['data_categories'] ?? $activity_details['categories_personal_data'] ?? ''); 
                                ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Necessity & Proportionality Tests Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Necessity & Proportionality Tests</h5>
                    
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Necessity Test</label>
                                <textarea name="necessity_test" class="form-control" rows="3" required
                                          placeholder="Explain why the processing is necessary for the intended purpose"><?php echo htmlspecialchars($dpia['necessity_test'] ?? ''); ?></textarea>
                                <small class="field-hint">Explain why the processing is necessary for the intended purpose</small>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Proportionality Test</label>
                                <textarea name="proportionality_test" class="form-control" rows="3" required
                                          placeholder="Explain why the processing is proportionate to the intended purpose"><?php echo htmlspecialchars($dpia['proportionality_test'] ?? ''); ?></textarea>
                                <small class="field-hint">Explain why the processing is proportionate to the intended purpose</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Compliance Checklist Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Compliance Checklist</h5>
                    
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Check all compliance requirements that have been met
                    </div>
                    
                    <?php echo get_dpia_compliance_checklist_html($dpia['compliance_checklist'] ?? []); ?>
                </div>
                
                <!-- Risk Assessment Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Risk Assessment</h5>
                    
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Risk Assessment Matrix</label>
                                <?php echo get_dpia_risk_matrix_html($dpia['risk_assessment_matrix'] ?? null); ?>
                                <input type="hidden" name="overall_risk_level" id="overall_risk_level" 
                                       value="<?php echo htmlspecialchars($dpia['overall_risk_level'] ?? 'medium'); ?>">
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">Overall Risk Level</label>
                                <div class="alert alert-<?php 
                                    switch($dpia['overall_risk_level'] ?? 'medium') {
                                        case 'low': echo 'success'; break;
                                        case 'medium': echo 'warning'; break;
                                        case 'high': echo 'danger'; break;
                                        default: echo 'secondary';
                                    }
                                ?>">
                                    <strong>Calculated Risk Level: 
                                        <span class="overall-risk-display risk-<?php echo $dpia['overall_risk_level'] ?? 'medium'; ?>">
                                            <?php echo strtoupper($dpia['overall_risk_level'] ?? 'MEDIUM'); ?>
                                        </span>
                                    </strong>
                                    <br>
                                    <small>Based on selected risk cells in the matrix above</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Mitigation Measures & Residual Risk Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Mitigation Measures & Residual Risk</h5>
                    
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Proposed Mitigation Measures</label>
                                <textarea name="mitigation_measures" class="form-control" rows="3" required
                                          placeholder="Describe measures to mitigate identified risks"><?php echo htmlspecialchars($dpia['mitigation_measures'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Residual Risk After Mitigation</label>
                                <textarea name="residual_risk" class="form-control" rows="3" required
                                          placeholder="Describe remaining risk after implementing mitigation measures"><?php echo htmlspecialchars($dpia['residual_risk'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Consultation & Recommendations Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Consultation & Recommendations</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Consultation Conducted</label>
                                <select name="consultation_conducted" class="form-select">
                                    <option value="no" <?php echo ($dpia['consultation_conducted'] ?? 'no') == 'no' ? 'selected' : ''; ?>>No</option>
                                    <option value="planned" <?php echo ($dpia['consultation_conducted'] ?? '') == 'planned' ? 'selected' : ''; ?>>Planned</option>
                                    <option value="yes" <?php echo ($dpia['consultation_conducted'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">Consultation Details</label>
                                <textarea name="consultation_details" class="form-control" rows="2"
                                          placeholder="Details of consultations conducted"><?php echo htmlspecialchars($dpia['consultation_details'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">Recommendations</label>
                                <textarea name="recommendations" class="form-control" rows="2"
                                          placeholder="Recommendations from the DPIA"><?php echo htmlspecialchars($dpia['recommendations'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- DPIA Status & Review Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">DPIA Status & Review</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">DPIA Status</label>
                                <select name="status" id="dpia_status" class="form-select" required>
                                    <?php foreach ($gdpr_options['dpia_statuses'] as $value => $label): ?>
                                    <?php if ($value != 'not_required'): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($dpia['status'] ?? 'draft') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Review Date</label>
                                <input type="date" name="review_date" class="form-control"
                                       value="<?php echo htmlspecialchars($dpia['review_date'] ?? ''); ?>">
                            </div>
                        </div>
                        
                        <div class="col-12 approval-section" style="<?php echo in_array($dpia['status'] ?? 'draft', ['under_review', 'approved', 'rejected']) ? '' : 'display: none;'; ?>">
                            <div class="form-group">
                                <label class="form-label">Management Approval Status</label>
                                <select name="management_approval" id="management_approval" class="form-select">
                                    <?php foreach ($dpia_options['management_approval'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($dpia['management_approval'] ?? 'pending') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="2"
                                          placeholder="Additional notes or comments"><?php echo htmlspecialchars($dpia['notes'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if ($is_edit && has_permission('approve_dpia') && in_array($dpia['status'], ['under_review', 'draft', 'in_progress'])): ?>
                <!-- Approval Actions -->
                <div class="approval-actions">
                    <h6><i class="bi bi-shield-check me-2"></i>DPIA Approval Actions</h6>
                    <p class="text-muted">As an authorized approver, you can approve or reject this DPIA.</p>
                    
                    <div class="d-flex gap-2">
                        <button type="submit" name="approve_dpia" class="btn btn-success">
                            <i class="bi bi-check-circle me-1"></i> Approve DPIA
                        </button>
                        <button type="submit" name="reject_dpia" class="btn btn-danger">
                            <i class="bi bi-x-circle me-1"></i> Reject DPIA
                        </button>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Form Actions -->
                <div class="mt-4">
                    <button type="submit" name="save_dpia" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> <?php echo $is_edit ? 'Update DPIA' : 'Save DPIA'; ?>
                    </button>
                    <a href="?action=view_dpias" class="btn btn-secondary">Cancel</a>
                    
                    <?php if ($is_edit && has_permission('print_reports')): ?>
                    <a href="?print=dpia_report&id=<?php echo $id; ?>" target="_blank" class="btn btn-outline-secondary">
                        <i class="bi bi-printer me-1"></i> Print DPIA Report
                    </a>
                    <?php endif; ?>
                    
                    <?php if ($is_edit && $dpia['record_id']): ?>
                    <a href="?action=edit_activity&id=<?php echo $dpia['record_id']; ?>" class="btn btn-outline-info">
                        <i class="bi bi-clipboard-data me-1"></i> View Related Activity
                    </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    // Form validation
    $('#dpiaForm').on('submit', function(e) {
        if (!validateForm('dpiaForm')) {
            e.preventDefault();
            return false;
        }
        return true;
    });
    </script>
    <?php
}


?>

<?php
// End of file
?>

<?php


function include_view_breaches_content($page, $per_page) {
    global $gdpr_options;
    $conn = create_db_connection();
    
    // Get all breaches
    $result = $conn->query("
        SELECT b.*, 
               u1.full_name as reporter_name,
               u2.full_name as assigned_to_name
        FROM data_breaches b
        LEFT JOIN system_users u1 ON b.reported_by = u1.id
        LEFT JOIN system_users u2 ON b.assigned_to = u2.id
        ORDER BY b.created_at DESC
    ");
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Data Breaches</h5>
            <?php if (has_permission('add_breach')): ?>
            <a href="?action=add_breach" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Report Breach
            </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="breachesTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Breach Date</th>
                            <th>Type</th>
                            <th>Risk Level</th>
                            <th>Status</th>
                            <th>Reported By</th>
                            <th>Assigned To</th>
                            <th>Created</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo format_date($row['breach_date'], 'd-m-Y'); ?></td>
                            <td><?php echo $gdpr_options['breach_types'][$row['breach_type']] ?? $row['breach_type']; ?></td>
                            <td><?php echo get_risk_badge($row['risk_level']); ?></td>
                            <td><?php echo get_status_badge($row['status']); ?></td>
                            <td><?php echo htmlspecialchars($row['reporter_name']); ?></td>
                            <td>
                                <?php if ($row['assigned_to_name']): ?>
                                <?php echo htmlspecialchars($row['assigned_to_name']); ?>
                                <?php else: ?>
                                <span class="text-muted">Unassigned</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo format_date($row['created_at'], 'd-m-Y'); ?></td>
                            <td class="no-print">
                                <div class="btn-group btn-group-sm">
                                    <a href="?action=edit_breach&id=<?php echo $row['id']; ?>" class="btn btn-outline-primary" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="?action=edit_breach&id=<?php echo $row['id']; ?>&view=true" class="btn btn-outline-info" title="View Details">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    $(document).ready(function() {
        // Initialize DataTables with CLIENT-SIDE pagination only
        $('#breachesTable').DataTable({
            pageLength: 25,
            responsive: true,
            order: [[0, 'desc']],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            }
        });
    });
    </script>
    <?php
}

function include_breach_form($id = 0) {
    global $gdpr_options, $current_user;
    $conn = create_db_connection();
    
    $is_edit = $id > 0;
    $breach = null;
    $view_only = isset($_GET['view']);
    
    if ($is_edit) {
        $stmt = $conn->prepare("
            SELECT b.*, 
                   u1.full_name as reporter_name,
                   u2.full_name as assigned_to_name
            FROM data_breaches b
            LEFT JOIN system_users u1 ON b.reported_by = u1.id
            LEFT JOIN system_users u2 ON b.assigned_to = u2.id
            WHERE b.id = ?
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $breach = $result->fetch_assoc();
    }
    
    // Get users for assignment dropdown
    $users = get_all_users(true);
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">
                <?php if ($view_only): ?>
                View Data Breach
                <?php else: ?>
                <?php echo $is_edit ? 'Edit' : 'Report'; ?> Data Breach
                <?php endif; ?>
            </h5>
            <?php if ($is_edit && !$view_only): ?>
            <div class="print-actions">
                <a href="javascript:window.print()" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-printer me-1"></i> Print
                </a>
            </div>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="POST" id="breachForm" <?php echo $view_only ? 'onsubmit="return false;"' : ''; ?>>
                <?php if ($is_edit): ?>
                <input type="hidden" name="breach_id" value="<?php echo $id; ?>">
                <?php endif; ?>
                
                <!-- Basic Information Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Basic Information</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label class="form-label required-field">Title</label>
                                <input type="text" name="title" class="form-control" required
                                       value="<?php echo htmlspecialchars($breach['title'] ?? ''); ?>"
                                       placeholder="Enter breach title" <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label required-field">Risk Level</label>
                                <select name="risk_level" class="form-select" required <?php echo $view_only ? 'disabled' : ''; ?>>
                                    <option value="">Select Risk Level</option>
                                    <?php foreach ($gdpr_options['risk_levels'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($breach['risk_level'] ?? '') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($view_only): ?>
                                <input type="hidden" name="risk_level" value="<?php echo $breach['risk_level']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Breach Date</label>
                                <input type="date" name="breach_date" class="form-control" required
                                       value="<?php echo htmlspecialchars($breach['breach_date'] ?? date('Y-m-d')); ?>"
                                       <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Discovery Date</label>
                                <input type="date" name="discovery_date" class="form-control" required
                                       value="<?php echo htmlspecialchars($breach['discovery_date'] ?? date('Y-m-d')); ?>"
                                       <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Breach Type</label>
                                <select name="breach_type" class="form-select" required <?php echo $view_only ? 'disabled' : ''; ?>>
                                    <option value="">Select Breach Type</option>
                                    <?php foreach ($gdpr_options['breach_types'] as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($breach['breach_type'] ?? '') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($view_only): ?>
                                <input type="hidden" name="breach_type" value="<?php echo $breach['breach_type']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Affected Data Subjects</label>
                                <input type="number" name="affected_data_subjects" class="form-control" min="0"
                                       value="<?php echo htmlspecialchars($breach['affected_data_subjects'] ?? ''); ?>"
                                       placeholder="Estimated number" <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Breach Description Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Breach Description</h5>
                    
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Description</label>
                                <textarea name="description" class="form-control" rows="3" required
                                          placeholder="Describe the breach in detail" <?php echo $view_only ? 'readonly' : ''; ?>><?php echo htmlspecialchars($breach['description'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Personal Data Affected</label>
                                <textarea name="personal_data_affected" class="form-control" rows="2" required
                                          placeholder="Types of personal data affected" <?php echo $view_only ? 'readonly' : ''; ?>><?php echo htmlspecialchars($breach['personal_data_affected'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Causes</label>
                                <textarea name="causes" class="form-control" rows="2" required
                                          placeholder="What caused the breach?" <?php echo $view_only ? 'readonly' : ''; ?>><?php echo htmlspecialchars($breach['causes'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Response Measures Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Response & Measures</h5>
                    
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Measures Taken</label>
                                <textarea name="measures_taken" class="form-control" rows="3" required
                                          placeholder="What measures have been taken to address the breach?" <?php echo $view_only ? 'readonly' : ''; ?>><?php echo htmlspecialchars($breach['measures_taken'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select" <?php echo $view_only ? 'disabled' : ''; ?>>
                                    <?php 
                                    $status_options = [
                                        'open' => 'Open',
                                        'investigating' => 'Investigating',
                                        'contained' => 'Contained',
                                        'resolved' => 'Resolved',
                                        'closed' => 'Closed'
                                    ];
                                    foreach ($status_options as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"
                                        <?php echo ($breach['status'] ?? 'open') == $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($view_only): ?>
                                <input type="hidden" name="status" value="<?php echo $breach['status']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Assigned To</label>
                                <select name="assigned_to" class="form-select" <?php echo $view_only ? 'disabled' : ''; ?>>
                                    <option value="">Not Assigned</option>
                                    <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['id']; ?>"
                                        <?php echo ($breach['assigned_to'] ?? '') == $user['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($user['full_name'] . ' (' . $user['role'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($view_only): ?>
                                <input type="hidden" name="assigned_to" value="<?php echo $breach['assigned_to']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Notification Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Notification Requirements</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Notified Authority?</label>
                                <select name="notified_authority" class="form-select" <?php echo $view_only ? 'disabled' : ''; ?>>
                                    <option value="no" <?php echo ($breach['notified_authority'] ?? 'no') == 'no' ? 'selected' : ''; ?>>No</option>
                                    <option value="in_progress" <?php echo ($breach['notified_authority'] ?? '') == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                    <option value="yes" <?php echo ($breach['notified_authority'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                                </select>
                                <?php if ($view_only): ?>
                                <input type="hidden" name="notified_authority" value="<?php echo $breach['notified_authority']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Notification Date</label>
                                <input type="date" name="notification_date" class="form-control"
                                       value="<?php echo htmlspecialchars($breach['notification_date'] ?? ''); ?>"
                                       <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Notified Affected Persons?</label>
                                <select name="notified_affected_persons" class="form-select" <?php echo $view_only ? 'disabled' : ''; ?>>
                                    <option value="no" <?php echo ($breach['notified_affected_persons'] ?? 'no') == 'no' ? 'selected' : ''; ?>>No</option>
                                    <option value="in_progress" <?php echo ($breach['notified_affected_persons'] ?? '') == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                    <option value="yes" <?php echo ($breach['notified_affected_persons'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                                </select>
                                <?php if ($view_only): ?>
                                <input type="hidden" name="notified_affected_persons" value="<?php echo $breach['notified_affected_persons']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Form Actions -->
                <div class="mt-4 pt-3 border-top">
                    <?php if (!$view_only): ?>
                    <button type="submit" name="save_breach" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> <?php echo $is_edit ? 'Update' : 'Report'; ?> Breach
                    </button>
                    <?php endif; ?>
                    <a href="?action=view_breaches" class="btn btn-secondary">
                        <?php echo $view_only ? 'Back' : 'Cancel'; ?>
                    </a>
                    
                    <?php if ($is_edit && !$view_only): ?>
                    <a href="?action=edit_breach&id=<?php echo $id; ?>&view=true" class="btn btn-outline-info">
                        <i class="bi bi-eye me-1"></i> View Mode
                    </a>
                    <?php endif; ?>
                    
                    <?php if ($is_edit && $view_only && has_permission('edit_breach')): ?>
                    <a href="?action=edit_breach&id=<?php echo $id; ?>" class="btn btn-outline-primary">
                        <i class="bi bi-pencil me-1"></i> Edit Mode
                    </a>
                    <?php endif; ?>
                    
                    <?php if ($is_edit): ?>
                    <button type="button" class="btn btn-outline-secondary" onclick="window.print()">
                        <i class="bi bi-printer me-1"></i> Print
                    </button>
                    <?php endif; ?>
                </div>
            </form>
            
            <?php if ($is_edit): ?>
            <!-- Breach Details Display -->
            <div class="dpia-section mt-4 print-only">
                <h5 class="dpia-section-title">Breach Report Details</h5>
                
                <div class="row">
                    <div class="col-md-4">
                        <strong>Reported By:</strong><br>
                        <?php echo htmlspecialchars($breach['reporter_name']); ?>
                    </div>
                    <div class="col-md-4">
                        <strong>Reported Date:</strong><br>
                        <?php echo format_date($breach['created_at']); ?>
                    </div>
                    <div class="col-md-4">
                        <strong>Last Updated:</strong><br>
                        <?php echo format_date($breach['updated_at']); ?>
                    </div>
                </div>
                
                <div class="mt-3">
                    <strong>Breach Timeline:</strong>
                    <ul>
                        <li>Breach Date: <?php echo format_date($breach['breach_date'], 'd-m-Y'); ?></li>
                        <li>Discovery Date: <?php echo format_date($breach['discovery_date'], 'd-m-Y'); ?></li>
                        <?php if ($breach['notification_date']): ?>
                        <li>Notification Date: <?php echo format_date($breach['notification_date'], 'd-m-Y'); ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    // Form validation
    $('#breachForm').on('submit', function(e) {
        if (!validateForm('breachForm')) {
            e.preventDefault();
            return false;
        }
        return true;
    });
    </script>
    <?php
}

function include_view_third_parties_content($page, $per_page) {
    $conn = create_db_connection();
    
    // Calculate offset
    $offset = ($page - 1) * $per_page;
    
    // Get total count
    $result = $conn->query("SELECT COUNT(*) as total FROM third_parties");
    $total = $result ? $result->fetch_assoc()['total'] : 0;
    $total_pages = ceil($total / $per_page);
    
    // Get third parties
    $stmt = $conn->prepare("
        SELECT t.*, u.full_name as created_by_name
        FROM third_parties t
        LEFT JOIN system_users u ON t.created_by = u.id
        ORDER BY t.created_at DESC
        LIMIT ?, ?
    ");
    $stmt->bind_param("ii", $offset, $per_page);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Third Parties</h5>
            <?php if (has_permission('add_third_party')): ?>
            <a href="?action=add_third_party" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Add Third Party
            </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Company Name</th>
                            <th>Contact Person</th>
                            <th>Service Provided</th>
                            <th>Agreement Status</th>
                            <th>Compliance Status</th>
                            <th>Expiry Date</th>
                            <th>Created By</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['company_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['contact_person'] ?? 'N/A'); ?></td>
                            <td>
                                <?php 
                                $service = $row['service_provided'];
                                echo strlen($service) > 50 ? substr($service, 0, 50) . '...' : $service;
                                ?>
                            </td>
                            <td><?php echo get_status_badge($row['processing_agreement_signed']); ?></td>
                            <td><?php echo get_status_badge($row['compliance_status']); ?></td>
                            <td>
                                <?php if (!empty($row['agreement_expiry_date']) && $row['agreement_expiry_date'] != '0000-00-00'): ?>
                                    <?php 
                                    $expiry_date = new DateTime($row['agreement_expiry_date']);
                                    $today = new DateTime();
                                    $interval = $today->diff($expiry_date);
                                    $days = $interval->days;
                                    
                                    if ($expiry_date < $today) {
                                        echo '<span class="badge bg-danger">Expired ' . format_date($row['agreement_expiry_date'], 'd-m-Y') . '</span>';
                                    } elseif ($days <= 30) {
                                        echo '<span class="badge bg-warning">Expires in ' . $days . ' days</span>';
                                    } else {
                                        echo format_date($row['agreement_expiry_date'], 'd-m-Y');
                                    }
                                    ?>
                                <?php else: ?>
                                    <span class="text-muted">Not set</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($row['created_by_name']); ?></td>
                            <td class="no-print">
                                <div class="btn-group btn-group-sm">
                                    <a href="?action=edit_third_party&id=<?php echo $row['id']; ?>" class="btn btn-outline-primary" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="?action=edit_third_party&id=<?php echo $row['id']; ?>&view=true" class="btn btn-outline-info" title="View Details">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

function include_third_party_form($id = 0) {
    global $current_user;
    $conn = create_db_connection();
    
    $is_edit = $id > 0;
    $third_party = null;
    $view_only = isset($_GET['view']);
    
    if ($is_edit) {
        $stmt = $conn->prepare("
            SELECT t.*, u.full_name as created_by_name
            FROM third_parties t
            LEFT JOIN system_users u ON t.created_by = u.id
            WHERE t.id = ?
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $third_party = $result->fetch_assoc();
    }
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">
                <?php if ($view_only): ?>
                View Third Party
                <?php else: ?>
                <?php echo $is_edit ? 'Edit' : 'Add'; ?> Third Party
                <?php endif; ?>
            </h5>
            <?php if ($is_edit && !$view_only): ?>
            <div class="print-actions">
                <a href="javascript:window.print()" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-printer me-1"></i> Print
                </a>
            </div>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="POST" id="thirdPartyForm" <?php echo $view_only ? 'onsubmit="return false;"' : ''; ?>>
                <?php if ($is_edit): ?>
                <input type="hidden" name="third_party_id" value="<?php echo $id; ?>">
                <?php endif; ?>
                
                <!-- Company Information Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Company Information</h5>
                    
                    <div class="row g-3">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label class="form-label required-field">Company Name</label>
                                <input type="text" name="company_name" class="form-control" required
                                       value="<?php echo htmlspecialchars($third_party['company_name'] ?? ''); ?>"
                                       placeholder="Enter company name" <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label required-field">Compliance Status</label>
                                <select name="compliance_status" class="form-select" required <?php echo $view_only ? 'disabled' : ''; ?>>
                                    <option value="review_needed" <?php echo ($third_party['compliance_status'] ?? 'review_needed') == 'review_needed' ? 'selected' : ''; ?>>Review Needed</option>
                                    <option value="compliant" <?php echo ($third_party['compliance_status'] ?? '') == 'compliant' ? 'selected' : ''; ?>>Compliant</option>
                                    <option value="non_compliant" <?php echo ($third_party['compliance_status'] ?? '') == 'non_compliant' ? 'selected' : ''; ?>>Non-Compliant</option>
                                </select>
                                <?php if ($view_only): ?>
                                <input type="hidden" name="compliance_status" value="<?php echo $third_party['compliance_status']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Contact Person</label>
                                <input type="text" name="contact_person" class="form-control"
                                       value="<?php echo htmlspecialchars($third_party['contact_person'] ?? ''); ?>"
                                       placeholder="Contact person name" <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control"
                                       value="<?php echo htmlspecialchars($third_party['email'] ?? ''); ?>"
                                       placeholder="contact@company.com" <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Phone</label>
                                <input type="tel" name="phone" class="form-control"
                                       value="<?php echo htmlspecialchars($third_party['phone'] ?? ''); ?>"
                                       placeholder="Phone number" <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">Address</label>
                                <textarea name="address" class="form-control" rows="2"
                                          placeholder="Company address" <?php echo $view_only ? 'readonly' : ''; ?>><?php echo htmlspecialchars($third_party['address'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Service & Agreement Section -->
                <div class="dpia-section">
                    <h5 class="dpia-section-title">Service & Agreement Details</h5>
                    
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label required-field">Service Provided</label>
                                <textarea name="service_provided" class="form-control" rows="3" required
                                          placeholder="Describe the service provided by this third party" <?php echo $view_only ? 'readonly' : ''; ?>><?php echo htmlspecialchars($third_party['service_provided'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label required-field">Processing Agreement Signed?</label>
                                <select name="processing_agreement_signed" class="form-select" required <?php echo $view_only ? 'disabled' : ''; ?>>
                                    <option value="no" <?php echo ($third_party['processing_agreement_signed'] ?? 'no') == 'no' ? 'selected' : ''; ?>>No</option>
                                    <option value="in_progress" <?php echo ($third_party['processing_agreement_signed'] ?? '') == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                    <option value="yes" <?php echo ($third_party['processing_agreement_signed'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                                </select>
                                <?php if ($view_only): ?>
                                <input type="hidden" name="processing_agreement_signed" value="<?php echo $third_party['processing_agreement_signed']; ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Agreement Date</label>
                                <input type="date" name="agreement_date" class="form-control"
                                       value="<?php echo htmlspecialchars($third_party['agreement_date'] ?? ''); ?>"
                                       <?php echo $view_only ? 'readonly' : ''; ?>>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Agreement Expiry Date</label>
                                <input type="date" name="agreement_expiry_date" class="form-control"
                                       value="<?php echo htmlspecialchars($third_party['agreement_expiry_date'] ?? ''); ?>"
                                       <?php echo $view_only ? 'readonly' : ''; ?>>
                                <small class="field-hint">Set reminder for renewal</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Form Actions -->
                <div class="mt-4 pt-3 border-top">
                    <?php if (!$view_only): ?>
                    <button type="submit" name="save_third_party" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> <?php echo $is_edit ? 'Update' : 'Save'; ?> Third Party
                    </button>
                    <?php endif; ?>
                    <a href="?action=view_third_parties" class="btn btn-secondary">
                        <?php echo $view_only ? 'Back' : 'Cancel'; ?>
                    </a>
                    
                    <?php if ($is_edit && !$view_only): ?>
                    <a href="?action=edit_third_party&id=<?php echo $id; ?>&view=true" class="btn btn-outline-info">
                        <i class="bi bi-eye me-1"></i> View Mode
                    </a>
                    <?php endif; ?>
                    
                    <?php if ($is_edit && $view_only && has_permission('edit_third_party')): ?>
                    <a href="?action=edit_third_party&id=<?php echo $id; ?>" class="btn btn-outline-primary">
                        <i class="bi bi-pencil me-1"></i> Edit Mode
                    </a>
                    <?php endif; ?>
                    
                    <?php if ($is_edit): ?>
                    <button type="button" class="btn btn-outline-secondary" onclick="window.print()">
                        <i class="bi bi-printer me-1"></i> Print
                    </button>
                    <?php endif; ?>
                </div>
            </form>
            
            <?php if ($is_edit): ?>
            <!-- Third Party Details Display -->
            <div class="dpia-section mt-4 print-only">
                <h5 class="dpia-section-title">Third Party Details</h5>
                
                <div class="row">
                    <div class="col-md-4">
                        <strong>Created By:</strong><br>
                        <?php echo htmlspecialchars($third_party['created_by_name']); ?>
                    </div>
                    <div class="col-md-4">
                        <strong>Created Date:</strong><br>
                        <?php echo format_date($third_party['created_at']); ?>
                    </div>
                    <div class="col-md-4">
                        <strong>Last Updated:</strong><br>
                        <?php echo format_date($third_party['updated_at']); ?>
                    </div>
                </div>
                
                <?php if (!empty($third_party['agreement_expiry_date']) && $third_party['agreement_expiry_date'] != '0000-00-00'): ?>
                <div class="mt-3">
                    <strong>Agreement Status:</strong>
                    <?php 
                    $expiry_date = new DateTime($third_party['agreement_expiry_date']);
                    $today = new DateTime();
                    $interval = $today->diff($expiry_date);
                    $days = $interval->days;
                    
                    if ($expiry_date < $today) {
                        echo '<span class="badge bg-danger">Agreement expired ' . $days . ' days ago</span>';
                    } elseif ($days <= 30) {
                        echo '<span class="badge bg-warning">Agreement expires in ' . $days . ' days</span>';
                    } else {
                        echo '<span class="badge bg-success">Agreement valid (expires in ' . $days . ' days)</span>';
                    }
                    ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    // Form validation
    $('#thirdPartyForm').on('submit', function(e) {
        if (!validateForm('thirdPartyForm')) {
            e.preventDefault();
            return false;
        }
        return true;
    });
    
    // Agreement date handling
    $('input[name="agreement_date"]').on('change', function() {
        if ($(this).val() && !$('input[name="agreement_expiry_date"]').val()) {
            // Suggest expiry date (1 year from agreement date)
            var agreementDate = new Date($(this).val());
            var expiryDate = new Date(agreementDate);
            expiryDate.setFullYear(expiryDate.getFullYear() + 1);
            
            var formattedExpiry = expiryDate.toISOString().split('T')[0];
            $('input[name="agreement_expiry_date"]').val(formattedExpiry);
        }
    });
    </script>
    <?php
}

function include_audit_log_content($page, $per_page) {
    global $current_user;
    $conn = create_db_connection();
    
    // Simple filters from GET parameters
    $action_filter = isset($_GET['action_filter']) ? $_GET['action_filter'] : '';
    $user_filter = isset($_GET['user_filter']) ? $_GET['user_filter'] : '';
    $date_filter = isset($_GET['date_filter']) ? $_GET['date_filter'] : '';
    
    // Build WHERE clause
    $where_clause = "WHERE 1=1";
    $params = [];
    $types = "";
    
    if ($action_filter) {
        $where_clause .= " AND s.action = ?";
        $params[] = $action_filter;
        $types .= "s";
    }
    
    if ($user_filter) {
        $where_clause .= " AND s.changed_by = ?";
        $params[] = $user_filter;
        $types .= "i";
    }
    
    if ($date_filter) {
        $where_clause .= " AND DATE(s.changed_at) = ?";
        $params[] = $date_filter;
        $types .= "s";
    }
    
    // Get total count
    $count_sql = "SELECT COUNT(*) as total FROM system_changes s $where_clause";
    $count_stmt = $conn->prepare($count_sql);
    if (!empty($params)) {
        $count_stmt->bind_param($types, ...$params);
    }
    $count_stmt->execute();
    $total_result = $count_stmt->get_result();
    $total = $total_result->fetch_assoc()['total'];
    $total_pages = ceil($total / $per_page);
    
    // Calculate offset
    $offset = ($page - 1) * $per_page;
    
    // Get audit logs with change data
    $sql = "
        SELECT s.id, s.table_name, s.record_id, s.action, 
               s.changed_at, s.changed_by, s.user_ip,
               s.old_data, s.new_data, s.changed_fields,
               u.username, u.full_name as user_full_name
        FROM system_changes s
        LEFT JOIN system_users u ON s.changed_by = u.id
        $where_clause
        ORDER BY s.changed_at DESC
        LIMIT ?, ?
    ";
    
    $params[] = $offset;
    $params[] = $per_page;
    $types .= "ii";
    
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = false;
    }
    
    // Get unique actions for filter dropdown
    $actions_result = $conn->query("SELECT DISTINCT action FROM system_changes ORDER BY action");
    $actions = [];
    if ($actions_result) {
        while ($row = $actions_result->fetch_assoc()) {
            $actions[] = $row['action'];
        }
    }
    
    // Get users for filter dropdown
    $users = get_all_users(false);
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Audit Log</h5>
            <div>
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="clearFilters()">
                    <i class="bi bi-x-circle me-1"></i> Clear Filters
                </button>
            </div>
        </div>
        <div class="card-body">
            <!-- Simple Filters -->
            <div class="row mb-4 g-3">
                <div class="col-md-3">
                    <label class="form-label">Action</label>
                    <select class="form-select" name="action_filter" id="actionFilter" onchange="applyFilters()">
                        <option value="">All Actions</option>
                        <?php foreach ($actions as $action): ?>
                        <option value="<?php echo htmlspecialchars($action); ?>"
                            <?php echo $action_filter == $action ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($action); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">User</label>
                    <select class="form-select" name="user_filter" id="userFilter" onchange="applyFilters()">
                        <option value="">All Users</option>
                        <?php foreach ($users as $user): ?>
                        <option value="<?php echo $user['id']; ?>"
                            <?php echo $user_filter == $user['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($user['full_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Date</label>
                    <input type="date" class="form-control" name="date_filter" id="dateFilter" 
                           value="<?php echo htmlspecialchars($date_filter); ?>" 
                           onchange="applyFilters()">
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label>
                    <div>
                        <button type="button" class="btn btn-secondary w-100" onclick="applyFilters()">
                            <i class="bi bi-funnel me-1"></i> Apply Filters
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Simple Table -->
            <div class="table-responsive">
                <table class="table table-hover table-sm">
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Table</th>
                            <th>Record</th>
                            <th>Changes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <small><?php echo format_date($row['changed_at']); ?></small>
                                </td>
                                <td>
                                    <?php if ($row['user_full_name']): ?>
                                        <?php echo htmlspecialchars($row['user_full_name']); ?>
                                        <br><small class="text-muted">@<?php echo htmlspecialchars($row['username']); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">Deleted User</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                    $action_colors = [
                                        'INSERT' => 'success',
                                        'UPDATE' => 'warning',
                                        'DELETE' => 'danger',
                                        'LOGIN' => 'info',
                                        'LOGOUT' => 'secondary',
                                        'PRINT' => 'secondary',
                                        'VIEW' => 'info'
                                    ];
                                    $color = $action_colors[$row['action']] ?? 'secondary';
                                    ?>
                                    <span class="badge bg-<?php echo $color; ?>">
                                        <?php echo htmlspecialchars($row['action']); ?>
                                    </span>
                                </td>
                                <td>
                                    <small><?php echo htmlspecialchars($row['table_name']); ?></small>
                                </td>
                                <td>
                                    <code>#<?php echo htmlspecialchars($row['record_id']); ?></code>
                                </td>
                                <td>
                                    <?php if ($row['action'] == 'UPDATE'): ?>
                                        <button type="button" class="btn btn-sm btn-outline-info" 
                                                onclick="showChanges(<?php echo $row['id']; ?>)">
                                            <i class="bi bi-arrows-expand"></i> View Changes
                                        </button>
                                    <?php elseif ($row['action'] == 'INSERT'): ?>
                                        <span class="badge bg-success">New Record</span>
                                    <?php elseif ($row['action'] == 'DELETE'): ?>
                                        <span class="badge bg-danger">Deleted</span>
                                    <?php else: ?>
                                        <small class="text-muted">-</small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="bi bi-clock-history fs-1"></i>
                                        <h5 class="mt-3">No audit logs found</h5>
                                        <p>Try changing your filters or check back later.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Simple Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?action=audit_log&page=<?php echo $page - 1; ?><?php echo getFilterQueryString(); ?>">
                            Previous
                        </a>
                    </li>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?action=audit_log&page=<?php echo $i; ?><?php echo getFilterQueryString(); ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    
                    <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?action=audit_log&page=<?php echo $page + 1; ?><?php echo getFilterQueryString(); ?>">
                            Next
                        </a>
                    </li>
                </ul>
            </nav>
            <?php endif; ?>
            
            <!-- Summary -->
            <div class="mt-3 text-muted">
                <small>Showing <?php echo $per_page; ?> of <?php echo $total; ?> total records</small>
            </div>
        </div>
    </div>
    
    <!-- Changes Modal -->
    <div class="modal fade" id="changesModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Change Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="changesContent">
                    <!-- Content will be loaded here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <style>
    .change-old {
        background-color: #f8d7da; /* Light red for removed */
        text-decoration: line-through;
        padding: 2px 4px;
        border-radius: 3px;
    }
    
    .change-new {
        background-color: #d4edda; /* Light green for added */
        padding: 2px 4px;
        border-radius: 3px;
    }
    
    .change-field {
        font-weight: bold;
        color: #495057;
    }
    </style>
    
    <script>
    // Simple filter functions
    function applyFilters() {
        var actionFilter = document.getElementById('actionFilter').value;
        var userFilter = document.getElementById('userFilter').value;
        var dateFilter = document.getElementById('dateFilter').value;
        
        var params = [];
        if (actionFilter) params.push('action_filter=' + encodeURIComponent(actionFilter));
        if (userFilter) params.push('user_filter=' + encodeURIComponent(userFilter));
        if (dateFilter) params.push('date_filter=' + encodeURIComponent(dateFilter));
        
        var queryString = params.length ? '&' + params.join('&') : '';
        window.location.href = '?action=audit_log' + queryString;
    }
    
    function clearFilters() {
        window.location.href = '?action=audit_log';
    }
    
    // Show changes with red/green formatting
    function showChanges(logId) {
        fetch('?action=get_changes&id=' + logId)
            .then(response => response.text())
            .then(html => {
                document.getElementById('changesContent').innerHTML = html;
                $('#changesModal').modal('show');
            })
            .catch(error => {
                document.getElementById('changesContent').innerHTML = 
                    '<div class="alert alert-danger">Error loading changes: ' + error + '</div>';
                $('#changesModal').modal('show');
            });
    }
    
    // Auto-submit on Enter in date field
    document.getElementById('dateFilter').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            applyFilters();
        }
    });
    </script>
    <?php
}

// Helper function for filter query string
function getFilterQueryString() {
    $query = '';
    if (isset($_GET['action_filter']) && $_GET['action_filter']) {
        $query .= '&action_filter=' . urlencode($_GET['action_filter']);
    }
    if (isset($_GET['user_filter']) && $_GET['user_filter']) {
        $query .= '&user_filter=' . urlencode($_GET['user_filter']);
    }
    if (isset($_GET['date_filter']) && $_GET['date_filter']) {
        $query .= '&date_filter=' . urlencode($_GET['date_filter']);
    }
    return $query;
}





function include_users_content($page, $per_page) {
    global $current_user, $user_roles, $app_config;
    $conn = create_db_connection();
    
    // Only admin can manage users
    if (!has_permission('manage_users')) {
        echo '<div class="alert alert-danger">Access denied. Only administrators can manage users.</div>';
        return;
    }
    
    // Calculate offset
    $offset = ($page - 1) * $per_page;
    
    // Get total count
    $result = $conn->query("SELECT COUNT(*) as total FROM system_users");
    $total = $result ? $result->fetch_assoc()['total'] : 0;
    $total_pages = ceil($total / $per_page);
    
    // Get users
    $stmt = $conn->prepare("
        SELECT * FROM system_users 
        ORDER BY role, full_name
        LIMIT ?, ?
    ");
    $stmt->bind_param("ii", $offset, $per_page);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">User Management</h5>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addUserModal">
                <i class="bi bi-plus-circle me-1"></i> Add User
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td>
                                <?php 
                                $role_badges = [
                                    'admin' => 'danger',
                                    'dpo' => 'warning',
                                    'editor' => 'primary',
                                    'viewer' => 'info'
                                ];
                                $color = $role_badges[$row['role']] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?php echo $color; ?>"><?php echo ucfirst($row['role']); ?></span>
                            </td>
                            <td>
                                <?php if ($row['is_active']): ?>
                                <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php 
                                if ($row['last_login'] && $row['last_login'] != '0000-00-00 00:00:00') {
                                    echo format_date($row['last_login']);
                                } else {
                                    echo '<span class="text-muted">Never</span>';
                                }
                                ?>
                            </td>
                            <td class="no-print">
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-primary" 
                                            onclick="editUser(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['username'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($row['full_name'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($row['email'], ENT_QUOTES); ?>', '<?php echo $row['role']; ?>', <?php echo $row['is_active']; ?>, '<?php echo format_date($row['created_at']); ?>', '<?php echo format_date($row['updated_at']); ?>', '<?php echo $row['last_login'] ? format_date($row['last_login']) : 'Never'; ?>', <?php echo $row['failed_login_attempts'] ?? 0; ?>)"
                                            title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <?php if ($row['id'] != $current_user['id']): ?>
                                    <button type="button" class="btn btn-outline-danger confirm-delete" 
                                            data-bs-toggle="modal" data-bs-target="#deleteUserModal" 
                                            data-id="<?php echo $row['id']; ?>"
                                            data-name="<?php echo htmlspecialchars($row['username']); ?>"
                                            title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="addUserForm">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Username</label>
                                    <input type="text" name="username" class="form-control" required
                                           placeholder="Enter username">
                                    <small class="field-hint">Letters, numbers and underscores only</small>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Full Name</label>
                                    <input type="text" name="full_name" class="form-control" required
                                           placeholder="Enter full name">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Email</label>
                                    <input type="email" name="email" class="form-control" required
                                           placeholder="Enter email address">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Role</label>
                                    <select name="role" class="form-select" required>
                                        <?php foreach ($user_roles as $role => $permissions): ?>
                                        <option value="<?php echo $role; ?>">
                                            <?php echo ucfirst($role); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Password</label>
                                    <div class="input-group">
                                        <input type="password" name="password" class="form-control" required
                                               placeholder="Enter password" id="newPassword">
                                        <button class="btn btn-outline-secondary toggle-password" type="button">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                    <small class="field-hint">Minimum <?php echo $app_config['password_min_length']; ?> characters</small>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Confirm Password</label>
                                    <div class="input-group">
                                        <input type="password" name="confirm_password" class="form-control" required
                                               placeholder="Confirm password" id="confirmPassword">
                                        <button class="btn btn-outline-secondary toggle-password" type="button">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" name="is_active" id="isActive" checked>
                                        <label class="form-check-label" for="isActive">Active</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Generate Password</label>
                                    <button type="button" class="btn btn-sm btn-outline-secondary w-100" 
                                            onclick="generatePassword()">
                                        <i class="bi bi-key me-1"></i> Generate Strong Password
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="save_user" class="btn btn-primary">Add User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editUserForm">
                    <input type="hidden" name="user_id" id="editUserId">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Username</label>
                                    <input type="text" name="username" id="editUsername" class="form-control" required>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Full Name</label>
                                    <input type="text" name="full_name" id="editFullName" class="form-control" required>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Email</label>
                                    <input type="email" name="email" id="editEmail" class="form-control" required>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label required-field">Role</label>
                                    <select name="role" id="editRole" class="form-select" required>
                                        <?php foreach ($user_roles as $role => $permissions): ?>
                                        <option value="<?php echo $role; ?>">
                                            <?php echo ucfirst($role); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Change Password (Optional)</label>
                                    <div class="input-group">
                                        <input type="password" name="new_password" class="form-control"
                                               placeholder="Leave empty to keep current" id="editNewPassword">
                                        <button class="btn btn-outline-secondary toggle-password" type="button">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                    <small class="field-hint">Minimum <?php echo $app_config['password_min_length']; ?> characters</small>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Confirm New Password</label>
                                    <div class="input-group">
                                        <input type="password" name="confirm_new_password" class="form-control"
                                               placeholder="Confirm new password" id="editConfirmPassword">
                                        <button class="btn btn-outline-secondary toggle-password" type="button">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" name="is_active" id="editIsActive">
                                        <label class="form-check-label" for="editIsActive">Active</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Generate Password</label>
                                    <button type="button" class="btn btn-sm btn-outline-secondary w-100" 
                                            onclick="generateEditPassword()">
                                        <i class="bi bi-key me-1"></i> Generate Strong Password
                                    </button>
                                </div>
                            </div>
                            
                            <div class="col-12">
                                <div class="alert alert-info">
                                    <i class="bi bi-info-circle me-2"></i>
                                    <strong>User Information:</strong>
                                    <div id="editUserInfo" class="mt-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="save_user" class="btn btn-primary">Update User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Delete User Modal -->
    <div class="modal fade" id="deleteUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this user?</p>
                    <p id="deleteUserName" class="fw-bold"></p>
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong>Warning:</strong> This action cannot be undone. The user will no longer be able to access the system.
                    </div>
                    <div class="alert alert-danger">
                        <i class="bi bi-x-circle me-2"></i>
                        <strong>Restriction:</strong> You cannot delete your own account.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="user_id" id="deleteUserId">
                        <button type="submit" name="delete_user" class="btn btn-danger">Delete User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    // Edit user function - UPDATED VERSION
    function editUser(userId, username, fullName, email, role, isActive, created, updated, lastLogin, failedLogins) {
        $('#editUserId').val(userId);
        $('#editUsername').val(username);
        $('#editFullName').val(fullName);
        $('#editEmail').val(email);
        $('#editRole').val(role);
        $('#editIsActive').prop('checked', isActive == 1);
        
        // Clear password fields
        $('#editNewPassword').val('');
        $('#editConfirmPassword').val('');
        
        // Update user info
        var userInfo = '';
        userInfo += '<strong>Created:</strong> ' + created + '<br>';
        userInfo += '<strong>Last Updated:</strong> ' + updated + '<br>';
        userInfo += '<strong>Last Login:</strong> ' + (lastLogin || 'Never') + '<br>';
        userInfo += '<strong>Failed Login Attempts:</strong> ' + (failedLogins || '0');
        
        $('#editUserInfo').html(userInfo);
        
        $('#editUserModal').modal('show');
    }
    
    // Generate password for add user form
    function generatePassword() {
        var password = generateRandomPassword(12);
        $('#newPassword').val(password);
        $('#confirmPassword').val(password);
        showToast('Success', 'Strong password generated and copied to both fields', 'success');
    }
    
    // Generate password for edit user form
    function generateEditPassword() {
        var password = generateRandomPassword(12);
        $('#editNewPassword').val(password);
        $('#editConfirmPassword').val(password);
        showToast('Success', 'Strong password generated and copied to both fields', 'success');
    }
    
    // Random password generator
    function generateRandomPassword(length) {
        var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-+=<>?";
        var password = "";
        for (var i = 0; i < length; i++) {
            password += charset.charAt(Math.floor(Math.random() * charset.length));
        }
        return password;
    }
    
    // Delete modal handler
    $('#deleteUserModal').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var name = button.data('name');
        
        var modal = $(this);
        modal.find('#deleteUserId').val(id);
        modal.find('#deleteUserName').text(name);
    });
    
    // Form validation for add user
    $('#addUserForm').on('submit', function(e) {
        var password = $('#newPassword').val();
        var confirmPassword = $('#confirmPassword').val();
        
        if (password !== confirmPassword) {
            showToast('Error', 'Passwords do not match!', 'danger');
            e.preventDefault();
            return false;
        }
        
        if (password.length < <?php echo $app_config['password_min_length']; ?>) {
            showToast('Error', 'Password must be at least <?php echo $app_config['password_min_length']; ?> characters long!', 'danger');
            e.preventDefault();
            return false;
        }
        
        // Validate username format
        var username = $('input[name="username"]').val();
        if (!/^[a-zA-Z0-9_]+$/.test(username)) {
            showToast('Error', 'Username can only contain letters, numbers and underscores!', 'danger');
            e.preventDefault();
            return false;
        }
        
        // Validate email format
        var email = $('input[name="email"]').val();
        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            showToast('Error', 'Please enter a valid email address!', 'danger');
            e.preventDefault();
            return false;
        }
        
        return true;
    });
    
    // Form validation for edit user
    $('#editUserForm').on('submit', function(e) {
        var newPassword = $('#editNewPassword').val();
        var confirmNewPassword = $('#editConfirmPassword').val();
        
        if (newPassword && newPassword !== confirmNewPassword) {
            showToast('Error', 'New passwords do not match!', 'danger');
            e.preventDefault();
            return false;
        }
        
        if (newPassword && newPassword.length < <?php echo $app_config['password_min_length']; ?>) {
            showToast('Error', 'New password must be at least <?php echo $app_config['password_min_length']; ?> characters long!', 'danger');
            e.preventDefault();
            return false;
        }
        
        // Validate username format
        var username = $('#editUsername').val();
        if (!/^[a-zA-Z0-9_]+$/.test(username)) {
            showToast('Error', 'Username can only contain letters, numbers and underscores!', 'danger');
            e.preventDefault();
            return false;
        }
        
        // Validate email format
        var email = $('#editEmail').val();
        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            showToast('Error', 'Please enter a valid email address!', 'danger');
            e.preventDefault();
            return false;
        }
        
        return true;
    });
    
    // Initialize form validation
    $(document).ready(function() {
        // Add Bootstrap validation classes
        $('#addUserForm, #editUserForm').addClass('needs-validation');
        
        // Real-time password match validation for add form
        $('#newPassword, #confirmPassword').on('keyup', function() {
            var password = $('#newPassword').val();
            var confirmPassword = $('#confirmPassword').val();
            
            if (confirmPassword) {
                if (password !== confirmPassword) {
                    $('#confirmPassword').addClass('is-invalid');
                    $('#confirmPassword').removeClass('is-valid');
                } else {
                    $('#confirmPassword').addClass('is-valid');
                    $('#confirmPassword').removeClass('is-invalid');
                }
            }
        });
        
        // Real-time password match validation for edit form
        $('#editNewPassword, #editConfirmPassword').on('keyup', function() {
            var newPassword = $('#editNewPassword').val();
            var confirmPassword = $('#editConfirmPassword').val();
            
            if (confirmPassword && newPassword) {
                if (newPassword !== confirmPassword) {
                    $('#editConfirmPassword').addClass('is-invalid');
                    $('#editConfirmPassword').removeClass('is-valid');
                } else {
                    $('#editConfirmPassword').addClass('is-valid');
                    $('#editConfirmPassword').removeClass('is-invalid');
                }
            }
        });
        
        // Clear validation states when modals are closed
        $('#addUserModal, #editUserModal').on('hidden.bs.modal', function() {
            $(this).find('.form-control').removeClass('is-invalid is-valid');
        });
    });
    </script>
    <?php
}