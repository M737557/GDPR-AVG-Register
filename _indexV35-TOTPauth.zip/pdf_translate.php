<?php
/**
 * pdf_translate.php — extra vertalingen toevoegen aan de gegenereerde export.
 *
 * Drop-in module voor index.php (contractregister). Op het tabblad "Nieuw
 * contract" kan de gebruiker, ná het invullen van het formulier, aanvinken
 * welke extra talen (uit de volledige DeepL-talenlijst) achter de
 * contracttekst moeten worden toegevoegd. Bij het genereren (action=
 * generate_json) worden zowel de ingevulde velden (verwerkingsdetails,
 * commerciële voorwaarden, aangepaste artikeltekst) als de sjabloontekst
 * (de artikelen uit contracts/<key>.json) live via DeepL vertaald naar elke
 * gekozen taal, en achter elkaar gezet: eerst de taal van de webinterface,
 * daarna taal 1, taal 2, taal 3, enzovoort. De bestandsnaam en functienamen
 * in deze module dateren nog van toen de export een PDF was; de export is nu
 * een .mhtml-bestand (zie exportContractAsMhtml() in index.php), maar de
 * markering blijft ongewijzigd: in die export begint elke extra taal op een
 * nieuwe (afdruk)pagina, zodat je door de talen heen kunt scrollen/bladeren.
 *
 * Voor eigen (niet-beschermde) contractsjablonen wordt de vertaling van de
 * sjabloontekst hergebruikt via translate_contract_definition() uit
 * contract_translate.php: die schrijft (net als het paneel "Automatisch
 * vertalen" in Configuratie contracten) de vertaling terug naar
 * contracts/<key>.json, met dezelfde hash-cache, zodat een volgende export in
 * dezelfde taal geen nieuwe DeepL-aanroepen meer kost en de vertaling
 * achteraf gecontroleerd/bewerkt kan worden. Voor het ingebouwde, beschermde
 * safeguard_scc-sjabloon kan niets worden weggeschreven; daar wordt alleen
 * in het geheugen vertaald, uitsluitend voor deze ene export.
 *
 * Installatie: require_once dit bestand in index.php, ná contract_translate.php
 * (die levert deepl_translate_block(), deepl_entry_status(), enz.) en ná
 * index.php's eigen functies (load_contract_definition(), generate_contract_body(),
 * enz. — dit bestand wordt daarom pas geladen vlak vóór de POST-afhandeling,
 * net als de andere twee modules).
 */

declare(strict_types=1);

// Velden uit het record die vrije tekst bevatten en dus vertaald moeten
// worden voor een extra taal. Bedrijfsnamen, adressen, e-mailadressen,
// telefoonnummers, KVK/btw/IBAN-nummers en bedragen worden bewust NIET
// vertaald (dat zijn geen taalgebonden gegevens); de rolvelden
// (company1_role/company2_role) worden al apart per taal weergegeven via
// ph_role_label() in ph(), dus die hoeven hier ook niet vertaald te worden.
const PDF_TRANSLATE_RECORD_FIELDS = [
    'purpose', 'dataCategories', 'dataSubjects', 'duration', 'noticePeriod',
    'paymentTerms', 'penaltyClause', 'subProcessors', 'confidentiality',
    'governingLaw', 'jurisdiction', 'extraNotes', 'insurance', 'auditRights',
    'company1_rep_title', 'company2_rep_title',
    'annexA_custom', 'annex_common_custom',
];

// Herkenbare, unieke regel die de client-side MHTML-opmaak
// (exportContractAsMhtml in index.php) laat herkennen als "start een nieuwe
// (afdruk)pagina hier". Komt vrijwel zeker nooit voor in een echte
// contracttekst. De constantenaam dateert nog van de vroegere PDF-export.
const PDF_PAGEBREAK_MARKER = '<<<PAGEBREAK>>>';

// ===============================================================
// CIRCUIT BREAKER — bij een DeepL-storing niet elk veld/artikel apart
// laten falen-en-hertellen.
// ---------------------------------------------------------------
// deepl_http() (contract_translate.php) probeert elk verzoek zelf al tot 3x
// met oplopende wachttijd, vóórdat het een fout teruggeeft. Bij een echte
// storing (DNS/verbinding/auth/quota) leidt dat, vermenigvuldigd over tientallen
// velden en artikelen in één PDF-generatie, tot een verzoek dat minutenlang
// blijft hangen — met kans dat PHP's max_execution_time de hele aanvraag
// (inclusief de al klaar staande brontaaltekst!) fataal afbreekt. Zodra één
// vertaalpoging in de huidige generatie mislukt, "springt" deze circuit
// breaker open: alle volgende vertaalpogingen in dezelfde aanvraag worden
// overgeslagen (geen nieuwe DeepL-aanroepen meer) en vallen terug op de
// brontaaltekst, net zoals translate_contract_definition() al doet met zijn
// "break 2 bij API-fouten" voor eigen sjablonen.
function &pdf_translate_circuit(): array {
    static $state = ['open' => false, 'reason' => ''];
    return $state;
}
function pdf_translate_circuit_reset(): void {
    $c = &pdf_translate_circuit();
    $c['open']   = false;
    $c['reason'] = '';
}
function pdf_translate_circuit_trip(string $reason): void {
    $c = &pdf_translate_circuit();
    if (!$c['open']) { $c['open'] = true; $c['reason'] = $reason; }
}
function pdf_translate_circuit_open(): bool {
    return pdf_translate_circuit()['open'];
}
function pdf_translate_circuit_reason(): string {
    return pdf_translate_circuit()['reason'];
}

// Wrapper om deepl_translate_block(): slaat de aanroep helemaal over zodra
// de circuit breaker open staat (geen netwerk meer), en trip't de breaker
// zelf bij de eerste mislukking. Geeft altijd ['ok'=>bool,'text'=>string,
// 'engine'=>?string] terug, met $text als fallback wanneer er niet (meer)
// vertaald werd. $context is een vrije, optionele aanduiding voor in
// translate_error.log (zie translate_log_error() in contract_translate.php).
function pdf_translate_try(string $text, string $srcLang, string $tgtLang, string $context = ''): array {
    if (pdf_translate_circuit_open()) {
        return ['ok' => false, 'text' => $text];
    }
    $res = deepl_translate_block($text, $srcLang, $tgtLang, $context);
    if (!$res['ok']) {
        pdf_translate_circuit_trip((string)($res['message'] ?? ($res['error'] ?? 'unknown')));
        return ['ok' => false, 'text' => $text];
    }
    return ['ok' => true, 'text' => (string)($res['text'] ?? $text), 'engine' => $res['engine'] ?? null];
}

// Vertaalt de vrije-tekstvelden van een record naar $tgtLang. Geeft een
// kopie van het record terug met 'lang' op $tgtLang gezet, zodat alle
// downstream-functies (ph(), render_contract_from_definition(),
// contract_summary_section()) automatisch de juiste taal gebruiken.
function pdf_translate_record(array $record, string $srcLang, string $tgtLang): array {
    $out = $record;
    $out['lang'] = $tgtLang;
    $recKey = (string)($record['safeguard'] ?? 'record');

    foreach (PDF_TRANSLATE_RECORD_FIELDS as $field) {
        if (pdf_translate_circuit_open()) break;
        $val = (string)($record[$field] ?? '');
        if (trim($val) === '') continue;
        $res = pdf_translate_try($val, $srcLang, $tgtLang, "pdf-export:$recKey/field:$field");
        if ($res['ok']) $out[$field] = $res['text'];
    }

    if (!empty($record['articleText']) && is_array($record['articleText'])) {
        $translated = [];
        foreach ($record['articleText'] as $key => $text) {
            $text = (string)$text;
            if (trim($text) === '' || pdf_translate_circuit_open()) { $translated[$key] = $text; continue; }
            $res = pdf_translate_try($text, $srcLang, $tgtLang, "pdf-export:$recKey/customArticle:$key");
            $translated[$key] = $res['text'];
        }
        $out['articleText'] = $translated;
    }

    return $out;
}

// Zorgt dat de contractdefinitie van $key de artikelen ook in $tgtLang
// bevat, en geeft die (eventueel aangevulde) definitie terug. Beschermde
// sjablonen (safeguard_scc) worden alleen in het geheugen aangevuld; eigen
// sjablonen worden via translate_contract_definition() ook naar schijf
// geschreven (hergebruikt de bestaande hash-cache/_mt-status).
function pdf_translate_definition(string $key, string $srcLang, string $tgtLang): ?array {
    $def = load_contract_definition($key);
    if ($def === null) return null;
    if ($srcLang === $tgtLang || !deepl_enabled() || !deepl_lang_known($srcLang) || !deepl_lang_known($tgtLang)) {
        return $def;
    }

    if (!is_protected_contract($key)) {
        if (pdf_translate_circuit_open()) return $def; // storing eerder in deze generatie: geen nieuwe aanroep
        $stats = translate_contract_definition($key, $srcLang, [$tgtLang], false, false);
        if (!empty($stats['errors'])) {
            pdf_translate_circuit_trip((string)$stats['errors'][0]);
        }
        return load_contract_definition($key) ?? $def;
    }

    // Beschermd sjabloon: niet naar schijf schrijven, alleen tijdelijk in het
    // geheugen aanvullen voor déze PDF.
    $languages = $def['languages'] ?? ['en'];
    if (!in_array($tgtLang, $languages, true)) $languages[] = $tgtLang;
    $def['languages'] = $languages;

    if (!is_array($def['articles'] ?? null)) return $def;

    foreach ($def['articles'] as $artKey => $byLang) {
        if (pdf_translate_circuit_open()) break; // storing eerder in deze generatie: niet verder proberen
        if (!is_array($byLang)) continue;
        $srcEntry = $byLang[$srcLang] ?? null;
        if (!is_array($srcEntry)) continue;

        $srcTitle = (string)($srcEntry['title'] ?? '');
        $srcBody  = (string)($srcEntry['body'] ?? '');
        if (trim($srcTitle) === '' && trim($srcBody) === '') continue;

        $status = deepl_entry_status($srcEntry, $byLang[$tgtLang] ?? null);
        if ($status === 'current' || $status === 'human') continue;

        $ctx    = "pdf-export:$key/article:$artKey";
        $rTitle = pdf_translate_try($srcTitle, $srcLang, $tgtLang, "$ctx/title");
        if (!$rTitle['ok']) break; // circuit is nu open; stop met dit artikel en alle volgende
        $rBody  = pdf_translate_try($srcBody, $srcLang, $tgtLang, "$ctx/body");
        if (!$rBody['ok']) break;

        $def['articles'][$artKey][$tgtLang] = [
            'title' => $rTitle['text'],
            'body'  => $rBody['text'],
            '_mt'   => [
                'engine' => $rBody['engine'] ?? $rTitle['engine'] ?? 'deepl',
                'src'    => $srcLang,
                'hash'   => deepl_source_hash($srcEntry),
                'at'     => date('c'),
            ],
        ];
    }

    return $def;
}

// Bouwt de contractbody (zonder integriteits-header) in één extra taal, met
// dezelfde opbouw als generate_contract_body(): eerst het overzicht
// (bedrijfsgegevens/verwerkingsdetails/commerciële voorwaarden), dan de
// sjabloonartikelen.
function pdf_translate_body(array $record, string $srcLang, string $tgtLang): string {
    $translatedRecord = pdf_translate_record($record, $srcLang, $tgtLang);
    $key = (string)($record['safeguard'] ?? 'safeguard_scc');
    $jsonDef = pdf_translate_definition($key, $srcLang, $tgtLang);

    $summary = contract_summary_section($translatedRecord);
    if ($jsonDef !== null) {
        return $summary . render_contract_from_definition($jsonDef, $translatedRecord);
    }
    return $summary . contract_missing_json_notice($tgtLang);
}

// Zet de brontaal-body en de body's van alle gekozen extra talen achter
// elkaar, gescheiden door een paginabreek + leesbare taalkop. $extraLangs is
// de ruwe lijst taalcodes uit het formulier (checkboxes "extra_langs[]");
// ongeldige/dubbele/de brontaal zelf worden genegeerd.
function build_multilang_body(array $record, array $types, array $extraLangs): string {
    $srcLang = (string)($record['lang'] ?? current_lang());
    $body = generate_contract_body($record, $types);

    if (!deepl_enabled()) return $body;

    // Circuit breaker reset: elke generatie (elk POST-verzoek) start met een
    // schone lei, ook al bleef de breaker open staan van een vorig, mislukt
    // verzoek binnen hetzelfde PHP-proces (bv. bij PHP-FPM/persistente workers).
    // De label-vertaalbreker (label_translate.php — vaste labels/placeholder-
    // fallbacks als "Doel:" en "verwerkingsverantwoordelijke" in elke DeepL-
    // taal, zie t()/ph_defaults()/ph_role_label()/scc_module() in index.php)
    // wordt hier ook gereset, om dezelfde reden.
    pdf_translate_circuit_reset();
    if (function_exists('label_translate_circuit_reset')) label_translate_circuit_reset();

    $seen = [$srcLang => true];
    $interrupted = [];
    foreach ($extraLangs as $tgtLang) {
        $tgtLang = strtolower(trim((string)$tgtLang));
        if ($tgtLang === '' || isset($seen[$tgtLang]) || !deepl_lang_known($tgtLang)) continue;
        $seen[$tgtLang] = true;

        if (pdf_translate_circuit_open()) {
            // DeepL is al eerder in deze generatie onbereikbaar gebleken: geen
            // nieuwe aanroepen meer proberen, gewoon overslaan (snel, geen netwerk).
            $interrupted[] = $tgtLang;
            continue;
        }

        $sectionTitle = mb_strtoupper(deepl_lang_label($tgtLang), 'UTF-8') . ' (' . strtoupper($tgtLang) . ')';
        $body .= "\n\n================================\n"
               . PDF_PAGEBREAK_MARKER . "\n"
               . $sectionTitle . "\n"
               . "================================\n\n";
        $body .= pdf_translate_body($record, $srcLang, $tgtLang);

        if (pdf_translate_circuit_open()) {
            // De storing trad tijdens déze taal op (de breaker was nog dicht bij
            // binnenkomst — anders had de continue hierboven al toegeslagen): deze
            // sectie kan dus deels vertaald en deels (nog) in de brontaal zijn.
            $body .= "\n\n>>> " . strtoupper($srcLang)
                   . ": Automatic translation was interrupted (translation error: " . pdf_translate_circuit_reason() . "). "
                   . "Some text above may still be shown in the source language.\n";
        }
    }

    if ($interrupted !== []) {
        $body .= "\n\n================================\n"
               . ">>> " . strtoupper($srcLang) . ": The following additional language(s) could not be translated "
               . "because no translation engine (DeepL/translateapi.ai/Lingvanex/Microsoft Translator) was reachable during this generation: " . strtoupper(implode(', ', $interrupted)) . ". "
               . "Please try generating the contract again once a translation engine is reachable again.\n"
               . "================================\n";
    }

    return $body;
}

// Leest en normaliseert de gekozen extra talen uit $_POST['extra_langs'].
function extra_langs_from_post(): array {
    $raw = $_POST['extra_langs'] ?? [];
    if (!is_array($raw)) return [];
    $out = [];
    foreach ($raw as $l) {
        $l = strtolower(trim((string)$l));
        if ($l !== '' && deepl_lang_known($l) && !in_array($l, $out, true)) $out[] = $l;
    }
    return $out;
}