<?php
/**
 * auth_gate.php
 * -----------------------------------------------------------------
 * Include dit bestand als ALLERELERSTE regel na `declare(strict_types=1);`
 * bovenaan index.php:
 *
 *     declare(strict_types=1);
 *     require_once __DIR__ . '/auth_gate.php';
 *
 * Dit bestand:
 *  - start de sessie,
 *  - laadt configmain.php + totp.php,
 *  - toont een minimaal login-scherm (6-cijferige code) als de
 *    gebruiker nog niet is ingelogd,
 *  - handelt logout af via ?logout=1,
 *  - stopt de verdere uitvoering (exit) zolang er niet is ingelogd,
 *    zodat de rest van index.php nooit bereikt wordt zonder geldige
 *    TOTP-code.
 * -----------------------------------------------------------------
 */

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/configmain.php';
require_once __DIR__ . '/totp.php';

// Uitloggen. Wist de sessie volledig (niet alleen de login-vlag), zodat
// ook rate-limit/activity-restjes niet blijven hangen.
if (isset($_GET['logout'])) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    header('Location: ' . strtok($_SERVER['REQUEST_URI'] ?? '/', '?'));
    exit;
}

// Al ingelogd? Check dan of de sessie niet is verlopen door inactiviteit.
if (!empty($_SESSION[TOTP_SESSION_KEY])) {
    $lastActivity = $_SESSION[TOTP_LAST_ACTIVITY_KEY] ?? 0;
    if (time() - $lastActivity > TOTP_SESSION_TIMEOUT) {
        // Sessie verlopen: wis 'm en val door naar het login-scherm.
        $_SESSION = [];
        session_regenerate_id(true);
    } else {
        // Nog geldig: activiteit bijwerken en doorgaan naar index.php.
        $_SESSION[TOTP_LAST_ACTIVITY_KEY] = time();
        return;
    }
}

// --- simpele rate-limiting tegen bruteforce (per sessie) -----------------
$_SESSION['totp_attempts'] ??= [];
$_SESSION['totp_attempts'] = array_filter(
    $_SESSION['totp_attempts'],
    fn(int $t) => $t > time() - TOTP_LOCKOUT_SECONDS
);

$error = null;
$lockedOut = count($_SESSION['totp_attempts']) >= TOTP_MAX_ATTEMPTS;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['totp_code'])) {
    if ($lockedOut) {
        $error = 'Te veel mislukte pogingen. Probeer het over enkele minuten opnieuw.';
    } else {
        $code = (string)$_POST['totp_code'];
        if (totp_verify(totp_get_secret(), $code, TOTP_WINDOW)) {
            $_SESSION[TOTP_SESSION_KEY] = true;
            $_SESSION[TOTP_LAST_ACTIVITY_KEY] = time();
            $_SESSION['totp_attempts'] = [];
            session_regenerate_id(true);
            header('Location: ' . strtok($_SERVER['REQUEST_URI'] ?? '/', '?'));
            exit;
        } else {
            $_SESSION['totp_attempts'][] = time();
            $lockedOut = count($_SESSION['totp_attempts']) >= TOTP_MAX_ATTEMPTS;
            $error = 'Onjuiste code. Probeer het opnieuw.';
        }
    }
}

// --- login-scherm ----------------------------------------------------------
?><!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Inloggen — Verificatiecode</title>
<style>
  :root { color-scheme: light dark; }
  body {
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
    background: #f4f5f7; display: flex; align-items: center; justify-content: center;
    min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box;
  }
  .card {
    background: #fff; border-radius: 12px; padding: 32px 28px; width: 100%;
    max-width: 360px; box-shadow: 0 4px 24px rgba(0,0,0,.08);
  }
  h1 { font-size: 18px; margin: 0 0 4px; }
  p.sub { color: #666; font-size: 13px; margin: 0 0 22px; }
  input[type="text"] {
    width: 100%; box-sizing: border-box; font-size: 24px; letter-spacing: 6px;
    text-align: center; padding: 12px; border-radius: 8px; border: 1px solid #ccc;
    margin-bottom: 14px;
  }
  button {
    width: 100%; padding: 12px; border: 0; border-radius: 8px; background: #2563eb;
    color: #fff; font-size: 15px; font-weight: 600; cursor: pointer;
  }
  button:hover { background: #1d4ed8; }
  .error {
    background: #fee2e2; color: #991b1b; padding: 10px 12px; border-radius: 8px;
    font-size: 13px; margin-bottom: 14px;
  }
</style>
</head>
<body>
  <form class="card" method="post" autocomplete="off">
    <h1>Verificatiecode</h1>
    <p class="sub">Voer de 6-cijferige code uit je authenticator-app in.</p>
    <?php if ($error): ?>
      <div class="error"><?= htmlspecialchars($error, ENT_QUOTES) ?></div>
    <?php endif; ?>
    <input type="text" name="totp_code" id="totpCode" inputmode="numeric" pattern="\d{6}"
           maxlength="6" placeholder="000000" autofocus required
           <?= $lockedOut ? 'disabled' : '' ?>>
    <button type="submit" <?= $lockedOut ? 'disabled' : '' ?>>Inloggen</button>
  </form>
  <script>
    // Filtert niet-cijfers en dient het formulier automatisch in zodra er
    // 6 cijfers zijn ingevoerd — geen "Inloggen"-klik meer nodig.
    (function() {
      var input = document.getElementById('totpCode');
      if (!input) return;
      var submitted = false;
      input.addEventListener('input', function() {
        input.value = input.value.replace(/\D/g, '').slice(0, 6);
        if (input.value.length === 6 && !submitted) {
          submitted = true;
          input.form.submit();
        }
      });
    })();
  </script>
</body>
</html>
<?php
exit;