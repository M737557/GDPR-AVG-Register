<?php
/**
 * deepl.config.example.php
 *
 * Kopieer naar deepl.config.php (zelfde map als index.php) en vul de sleutel in.
 * Alternatief en veiliger: zet DEEPL_API_KEY als omgevingsvariabele
 * (Apache: SetEnv DEEPL_API_KEY "..."; systemd: Environment=DEEPL_API_KEY=...).
 * De omgevingsvariabele heeft voorrang op dit bestand.
 *
 * Neem deepl.config.php NIET mee in versiebeheer.
 */

return [
    // Gratis sleutels eindigen op ":fx" en gebruiken automatisch api-free.deepl.com.
    'key' => 'ec81e8ae-a682-4218-9599-c1fc4aacb214:fx',

    // Formaliteit. Voor contracten is 'prefer_more' (u-vorm / Sie / vous) meestal juist.
    // Talen zonder formaliteitsondersteuning negeren dit stilzwijgend.
    // Opties: 'prefer_more', 'prefer_less', 'default'.
    'formality' => 'prefer_more',

    // Optioneel: DeepL-glossaria per taalpaar, voor consistente juridische termen
    // ("verwerkingsverantwoordelijke", "processor", "Auftragsverarbeiter", ...).
    // Aanmaken via de DeepL API (/v2/glossaries); hier alleen het id invullen.
    'glossaries' => [
        // 'en:nl' => '2b5e5b3a-...',
        // 'en:de' => '9f1c77de-...',
    ],

    // Optioneel: nieuwere DeepL-modellen (alleen Pro).
    // 'model_type' => 'prefer_quality_optimized',

    // Optioneel: afwijkende host (bedrijfsproxy of testopstelling).
    // 'host' => 'https://api.deepl.com',

    // Time-out per API-verzoek in 120 seconden.
    'timeout' => 120,
];
