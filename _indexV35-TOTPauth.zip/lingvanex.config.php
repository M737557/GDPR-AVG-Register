<?php
/**
 * lingvanex.config.example.php
 *
 * Kopieer naar lingvanex.config.php (zelfde map als index.php) en vul de
 * sleutel in. Alternatief en veiliger: zet LINGVANEX_API_KEY als
 * omgevingsvariabele (Apache: SetEnv LINGVANEX_API_KEY "..."; systemd:
 * Environment=LINGVANEX_API_KEY=...). De omgevingsvariabele heeft voorrang
 * op dit bestand.
 *
 * Neem lingvanex.config.php NIET mee in versiebeheer.
 *
 * LET OP: de sleutel hieronder is in de chat met Claude gedeeld en staat dus
 * ook in de sessiegeschiedenis. Behandel hem voor de zekerheid als
 * gecompromitteerd: overweeg om in het Lingvanex-dashboard een nieuwe
 * sleutel te genereren en deze te vervangen vóór dit bestand op een
 * productieserver komt te staan.
 */

return [
    'key' => 'a_xwV4AsM5Ln3PyHDnsRXLGr8bzuB5Ueez41RbL2HpgGowaJyzCBByKdp79z8O1Xy2clK0ksiELtDUIyHh',

    // Optioneel: afwijkende host (bedrijfsproxy of testopstelling).
    // 'host' => 'https://api-b2b.backenster.com',

    // Time-out per API-verzoek in seconden.
    // default 120 seconden
    'timeout' => 120,
];
