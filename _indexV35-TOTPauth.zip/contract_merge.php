<?php
declare(strict_types=1);

/**
 * contract_merge.php — Contract als QR-ZIP exporteren + overeenkomst uit twee
 * contracten (partij 1 + partij 2) samenstellen.
 *
 * Drop-in module voor index.php, zelfde patroon als contract_translate.php /
 * presets.php. Wordt ná pdf_translate.php ingeladen (vóór de POST-afhandeling).
 *
 * 1) CONFIGURATIE CONTRACTEN — "Exporteer als QR-ZIP"
 *    De contractdefinitie (alleen de artikelen, in de gekozen talen) wordt
 *    als PAYLOAD verpakt (JSON → gzcompress → base64), exact zoals bij
 *    contractgeneratie. Die payload wordt in de browser opgeknipt in
 *    QR-codes (PARTx/y:…, 700 tekens per code) en via de bestaande actie
 *    qrzip_json als AES-256-ZIP ingepakt. Wachtwoord = md5(PAYLOAD), net als
 *    bij een gegenereerd contract.
 *
 * 2) NIEUW CONTRACT + TEKENEN — "Overeenkomst uit contracten partij 1 + 2"
 *    Stap 1: QR-ZIP van partij 1 + wachtwoord (MD5) inladen.
 *    Stap 2: QR-ZIP van partij 2 + wachtwoord (MD5) inladen.
 *    Stap 3: drie kolommen per artikel: partij 1 | partij 2 | overeengekomen.
 *    Stap 4: overeenkomst vertalen naar een te kiezen taal (+ optioneel een
 *            tweede taal). Vertalingen zijn vóór het genereren te controleren
 *            en bij te werken.
 *    Stap 5: de standaard knop "Genereer" + QR. De overeengekomen tekst (in de
 *            gekozen taal/talen) zit in de payload, zodat "Her-genereren" het
 *            contract 1-op-1 terugzet zonder de ZIP's of een vertaal-API.
 *
 *    Uit de ZIP worden UITSLUITEND de artikelen gelezen. Bedrijfsgegevens,
 *    Verwerkingsdetails en Commerciële voorwaarden worden nooit uit de ZIP
 *    overgenomen; die blijven de velden van het formulier zelf.
 */

const CM_QR_SCHEMA      = 'contractregister/contract-qr/v1';
const CM_MERGE_SCHEMA   = 'contractregister/overeenkomst/v1';
const CM_MAX_ZIP_BYTES  = 30 * 1024 * 1024;
const CM_MAX_IMG_BYTES  = 3 * 1024 * 1024;
const CM_MAX_IMAGES     = 600;
const CM_MAX_TEXT_BYTES = 2 * 1024 * 1024;

// ---------------------------------------------------------------
// Hulpfuncties
// ---------------------------------------------------------------
function cm_json_out(array $data): void {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function cm_lang_code(string $raw): string {
    $raw = trim($raw);
    return preg_match('/^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,4})?$/', $raw) ? $raw : '';
}

function cm_article_key(string $raw): string {
    return (string)preg_replace('/[^A-Za-z0-9._]/', '', $raw);
}

function cm_lang_label(string $lang): string {
    if (function_exists('deepl_lang_label')) {
        $l = (string)deepl_lang_label($lang);
        if ($l !== '') return $l;
    }
    return strtoupper($lang);
}

/** Alle {{TOKENS}} in een tekst, gesorteerd (voor placeholder-controle na vertalen). */
function cm_placeholders(string $text): array {
    preg_match_all('/\{\{[A-Za-z0-9_]+\}\}/', $text, $m);
    $list = $m[0];
    sort($list);
    return $list;
}

/** Alleen artikelen (titel + tekst per taal) uit een definitie — niets anders. */
function cm_sanitize_articles($articles, array $onlyLangs = []): array {
    $out = [];
    if (!is_array($articles)) return $out;
    foreach ($articles as $k => $byLang) {
        $key = cm_article_key((string)$k);
        if ($key === '' || !is_array($byLang)) continue;
        foreach ($byLang as $l => $entry) {
            $lang = cm_lang_code((string)$l);
            if ($lang === '' || !is_array($entry)) continue;
            if ($onlyLangs !== [] && !in_array($lang, $onlyLangs, true)) continue;
            $out[$key][$lang] = [
                'title' => (string)($entry['title'] ?? ''),
                'body'  => str_replace("\r\n", "\n", (string)($entry['body'] ?? '')),
            ];
        }
    }
    return $out;
}

// ===============================================================
// 1) CONFIGURATIE — payload voor de QR-ZIP
// ===============================================================
function cm_build_config_payload(string $key, array $langs): array {
    $def = load_contract_definition($key);
    if ($def === null) return ['ok' => false, 'error' => 'Contract niet gevonden.'];

    $defLangs = array_values(array_filter(array_map('strval', $def['languages'] ?? [])));
    $langs = array_values(array_intersect($defLangs, $langs));
    if ($langs === []) return ['ok' => false, 'error' => 'Kies minstens één taal die in dit contract voorkomt.'];

    // Bewust alléén de artikelen: geen bedrijfsgegevens, verwerkingsdetails of
    // commerciële voorwaarden (die staan ook niet in een contractdefinitie).
    $data = [
        'schema'    => CM_QR_SCHEMA,
        'key'       => contract_safe_key($key),
        'title'     => (string)($def['title'] ?? contract_display_label($key)),
        'version'   => (int)($def['version'] ?? 1),
        'languages' => $langs,
        'articles'  => cm_sanitize_articles($def['articles'] ?? [], $langs),
    ];
    $payload = make_payload($data);
    return [
        'ok'      => true,
        'key'     => $data['key'],
        'title'   => $data['title'],
        'payload' => $payload,
        'md5'     => payload_md5($payload),
        'parts'   => max(1, (int)ceil(strlen($payload) / 700)),
    ];
}

function cm_handle_config_qr_payload(): void {
    $key = contract_safe_key((string)($_POST['key'] ?? ''));
    $langs = [];
    foreach ((array)($_POST['langs'] ?? []) as $l) {
        $l = cm_lang_code((string)$l);
        if ($l !== '') $langs[] = $l;
    }
    if ($key === '') cm_json_out(['ok' => false, 'error' => 'Geen contract gekozen.']);
    cm_json_out(cm_build_config_payload($key, $langs));
}

// ===============================================================
// 2a) QR-ZIP openen met wachtwoord (MD5) → afbeeldingen terug naar de
//     browser, die ze met jsQR decodeert. Er wordt niets bewaard.
// ===============================================================
function cm_handle_qrzip_extract(): void {
    if (!class_exists('ZipArchive')) cm_json_out(['ok' => false, 'error' => 'PHP-extensie zip ontbreekt op de server.']);

    $password = strtolower(trim((string)($_POST['password'] ?? '')));
    if (!preg_match('/^[a-f0-9]{32}$/', $password)) {
        cm_json_out(['ok' => false, 'error' => 'Het wachtwoord is de MD5 van het contract: 32 tekens (0-9, a-f).']);
    }
    $file = $_FILES['zipfile'] ?? null;
    if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string)$file['tmp_name'])) {
        cm_json_out(['ok' => false, 'error' => 'Upload mislukt of geen ZIP-bestand gekozen.']);
    }
    if ((int)$file['size'] > CM_MAX_ZIP_BYTES) cm_json_out(['ok' => false, 'error' => 'ZIP-bestand is te groot.']);

    $zip = new ZipArchive();
    if ($zip->open((string)$file['tmp_name']) !== true) cm_json_out(['ok' => false, 'error' => 'Dit is geen geldig ZIP-bestand.']);
    $zip->setPassword($password);

    $entries = [];
    $unencrypted = 0;
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $st = $zip->statIndex($i);
        if (!is_array($st)) continue;
        $name = (string)$st['name'];
        if (str_ends_with($name, '/') || str_contains($name, '..')) continue;
        if (!preg_match('/\.(png|jpe?g)$/i', $name)) continue;
        if ((int)$st['size'] > CM_MAX_IMG_BYTES) continue;
        if ((int)($st['encryption_method'] ?? 0) === 0) $unencrypted++;
        $entries[] = ['i' => $i, 'name' => $name];
        if (count($entries) > CM_MAX_IMAGES) {
            $zip->close();
            cm_json_out(['ok' => false, 'error' => 'Te veel afbeeldingen in de ZIP.']);
        }
    }
    if ($entries === []) {
        $zip->close();
        cm_json_out(['ok' => false, 'error' => 'Geen QR-afbeeldingen (PNG/JPG) gevonden in de ZIP.']);
    }
    usort($entries, static fn(array $a, array $b): int => strnatcasecmp($a['name'], $b['name']));

    $images = [];
    foreach ($entries as $en) {
        $bin = $zip->getFromIndex($en['i']);
        if ($bin === false || $bin === '') {
            $zip->close();
            cm_json_out(['ok' => false, 'error' => 'Onjuist wachtwoord (MD5) of beschadigde ZIP.']);
        }
        $mime = str_starts_with($bin, "\x89PNG") ? 'image/png' : (str_starts_with($bin, "\xFF\xD8") ? 'image/jpeg' : '');
        if ($mime === '') continue;
        $images[] = 'data:' . $mime . ';base64,' . base64_encode($bin);
    }
    $zip->close();

    cm_json_out([
        'ok' => true,
        'images' => $images,
        'warning' => $unencrypted > 0 ? 'Let op: deze ZIP bevat onversleutelde bestanden.' : '',
    ]);
}

// ===============================================================
// 2b) Samengevoegde QR-payload controleren (MD5) en uitpakken.
//     Alleen de artikelen worden teruggegeven.
// ===============================================================
function cm_decode_contract_payload(string $payload, string $expectedMd5): array {
    $payload = (string)preg_replace('/\s+/', '', $payload);
    if ($payload === '') return ['ok' => false, 'error' => 'Geen QR-inhoud gevonden.'];
    if (strlen($payload) > CM_MAX_TEXT_BYTES) return ['ok' => false, 'error' => 'QR-inhoud is te groot.'];

    $md5 = payload_md5($payload);
    if (!hash_equals($expectedMd5, $md5)) {
        return ['ok' => false, 'error' => 'MD5 komt niet overeen (verwacht ' . $expectedMd5 . ', berekend ' . $md5 . '). Ontbreekt er een QR-code of hoort het wachtwoord bij een ander contract?'];
    }
    $data = read_payload($payload);
    if (!is_array($data)) return ['ok' => false, 'error' => 'De QR-inhoud kon niet worden gedecodeerd.'];

    // Een gewone contract-payload (uit "Nieuw contract") bevat geen
    // contractdefinitie en is hier niet bruikbaar.
    if (($data['schema'] ?? '') !== CM_QR_SCHEMA || !is_array($data['articles'] ?? null)) {
        return ['ok' => false, 'error' => 'Dit is geen contract-QR uit "Configuratie contracten" (maar bv. een getekend contract).'];
    }

    $articles = cm_sanitize_articles($data['articles']);
    if ($articles === []) return ['ok' => false, 'error' => 'Het contract bevat geen artikelen.'];

    $langs = [];
    foreach ((array)($data['languages'] ?? []) as $l) {
        $l = cm_lang_code((string)$l);
        if ($l !== '') $langs[] = $l;
    }
    if ($langs === []) {
        foreach ($articles as $byLang) $langs = array_merge($langs, array_keys($byLang));
        $langs = array_values(array_unique($langs));
    }

    $list = [];
    foreach ($articles as $k => $byLang) {
        $list[] = ['key' => (string)$k, 'label' => config_article_label((string)$k), 'byLang' => $byLang];
    }

    // Bedrijfsgegevens, verwerkingsdetails en commerciële voorwaarden worden
    // hier bewust NIET teruggegeven, ook niet als ze in de payload zouden staan.
    return ['ok' => true, 'contract' => [
        'key'       => contract_safe_key((string)($data['key'] ?? '')),
        'title'     => (string)($data['title'] ?? ''),
        'version'   => (int)($data['version'] ?? 0),
        'languages' => $langs,
        'md5'       => $md5,
        'articles'  => $list,
    ]];
}

function cm_handle_payload_decode(): void {
    $md5 = strtolower(trim((string)($_POST['md5'] ?? '')));
    if (!preg_match('/^[a-f0-9]{32}$/', $md5)) cm_json_out(['ok' => false, 'error' => 'Ongeldig wachtwoord (MD5).']);
    cm_json_out(cm_decode_contract_payload((string)($_POST['payload'] ?? ''), $md5));
}

// ===============================================================
// 2c) Eén overeengekomen artikel vertalen (titel + tekst)
// ===============================================================
function cm_handle_translate_article(): void {
    if (!function_exists('deepl_enabled') || !function_exists('deepl_translate_block') || !deepl_enabled()) {
        cm_json_out(['ok' => false, 'error' => 'Er is geen vertaalengine geconfigureerd.']);
    }
    $src = cm_lang_code((string)($_POST['src'] ?? ''));
    $tgt = cm_lang_code((string)($_POST['tgt'] ?? ''));
    $key = cm_article_key((string)($_POST['key'] ?? ''));
    if ($src === '' || $tgt === '' || !deepl_lang_known($src) || !deepl_lang_known($tgt)) {
        cm_json_out(['ok' => false, 'error' => 'Onbekende taal.']);
    }
    $title = (string)($_POST['title'] ?? '');
    $body  = str_replace("\r\n", "\n", (string)($_POST['body'] ?? ''));
    if (strlen($title) + strlen($body) > 200000) cm_json_out(['ok' => false, 'error' => 'Artikel is te lang om te vertalen.']);

    $out = ['title' => '', 'body' => ''];
    foreach (['title' => $title, 'body' => $body] as $field => $text) {
        if (trim($text) === '') continue;
        $res = deepl_translate_block($text, $src, $tgt, 'merge:' . $key . '/' . $field);
        if (!is_array($res) || empty($res['ok'])) {
            cm_json_out(['ok' => false, 'error' => (string)($res['message'] ?? ($res['error'] ?? 'vertaling mislukt'))]);
        }
        $out[$field] = (string)($res['text'] ?? $text);
    }
    $out['ok'] = true;
    $out['placeholdersOk'] = cm_placeholders($title . "\n" . $body) === cm_placeholders($out['title'] . "\n" . $out['body']);
    cm_json_out($out);
}

// ===============================================================
// 3) RECORD — overeenkomst in de payload van het gegenereerde contract
// ===============================================================
$GLOBALS['__cm_post_error'] = null;

function merged_contract_post_error(): ?string {
    return $GLOBALS['__cm_post_error'] ?? null;
}

function cm_side_meta($raw): array {
    $raw = is_array($raw) ? $raw : [];
    $md5 = strtolower((string)($raw['md5'] ?? ''));
    return [
        'key'     => contract_safe_key((string)($raw['key'] ?? '')),
        'title'   => mb_substr((string)($raw['title'] ?? ''), 0, 200),
        'version' => (int)($raw['version'] ?? 0),
        'md5'     => preg_match('/^[a-f0-9]{32}$/', $md5) ? $md5 : '',
    ];
}

/** Leest en valideert het verborgen veld merged_contract (JSON uit de browser). */
function merged_contract_from_post(?string &$error): ?array {
    $error = null;
    $raw = (string)($_POST['merged_contract'] ?? '');
    if ($raw === '' || strlen($raw) > CM_MAX_TEXT_BYTES * 3) { $error = 'De overeenkomst is nog niet afgerond (stap 1 t/m 4).'; return null; }
    $in = json_decode($raw, true);
    if (!is_array($in)) { $error = 'De overeenkomst kon niet worden gelezen.'; return null; }

    $src   = cm_lang_code((string)($in['sourceLang'] ?? ''));
    $lang  = cm_lang_code((string)($in['lang'] ?? ''));
    $extra = cm_lang_code((string)($in['extraLang'] ?? ''));
    if ($extra === $lang) $extra = '';
    if ($src === '' || $lang === '') { $error = 'Kies de taal van de overeenkomst.'; return null; }
    $known = static fn(string $l): bool => $l === $src || (function_exists('deepl_lang_known') && deepl_lang_known($l));
    if (!$known($lang) || ($extra !== '' && !$known($extra))) { $error = 'Onbekende contracttaal.'; return null; }

    $p1 = cm_side_meta($in['p1'] ?? null);
    $p2 = cm_side_meta($in['p2'] ?? null);
    if ($p1['md5'] === '' || $p2['md5'] === '') { $error = 'Laad eerst de contracten van partij 1 én partij 2.'; return null; }

    $wanted = array_values(array_filter([$lang, $extra]));
    $articles = [];
    $seen = [];
    $total = 0;
    foreach ((array)($in['articles'] ?? []) as $a) {
        if (!is_array($a)) continue;
        $k = cm_article_key((string)($a['k'] ?? ''));
        if ($k === '' || isset($seen[$k])) continue;
        $t = [];
        foreach ($wanted as $l) {
            $e = $a['t'][$l] ?? null;
            if (!is_array($e)) { $error = 'Artikel ' . $k . ' mist de tekst in ' . strtoupper($l) . ' — vertaal opnieuw.'; return null; }
            $title = (string)($e['title'] ?? '');
            $body  = str_replace("\r\n", "\n", (string)($e['body'] ?? ''));
            $total += strlen($title) + strlen($body);
            $t[$l] = ['title' => $title, 'body' => $body];
        }
        $seen[$k] = true;
        $articles[] = ['k' => $k, 't' => $t];
    }
    if ($articles === []) { $error = 'De overeenkomst bevat geen artikelen.'; return null; }
    if ($total > CM_MAX_TEXT_BYTES) { $error = 'De overeenkomst is te groot.'; return null; }

    $excluded = [];
    foreach ((array)($in['excluded'] ?? []) as $x) {
        $x = cm_article_key((string)$x);
        if ($x !== '' && !isset($seen[$x])) $excluded[] = $x;
    }

    return [
        'schema'     => CM_MERGE_SCHEMA,
        'sourceLang' => $src,
        'lang'       => $lang,
        'extraLang'  => $extra,
        'p1'         => $p1,
        'p2'         => $p2,
        'excluded'   => array_values(array_unique($excluded)),
        'articles'   => $articles,
    ];
}

/**
 * Aangeroepen vanuit build_record_from_post(). In de modus "overeenkomst"
 * bepaalt de overeenkomst de contracttaal en vervangt ze de artikelen van het
 * sjabloon; per-artikel-aanpassingen van het sjabloon gelden dan niet.
 * Bedrijfsgegevens/verwerking/commercieel blijven de formuliervelden.
 */
function merged_contract_apply_to_record(array $record): array {
    $GLOBALS['__cm_post_error'] = null;
    if ((string)($_POST['merge_mode'] ?? '0') !== '1') return $record;

    $err = null;
    $mc = merged_contract_from_post($err);
    if ($mc === null) {
        $GLOBALS['__cm_post_error'] = $err ?? 'Ongeldige overeenkomst.';
        return $record;
    }
    $record['mergedContract'] = $mc;
    $record['lang']           = $mc['lang'];
    $record['articleEnabled'] = [];
    $record['articleText']    = [];
    return $record;
}

/** Contractdefinitie (zelfde vorm als contracts/*.json) uit een record met overeenkomst. */
function merged_contract_definition(array $d): ?array {
    $mc = $d['mergedContract'] ?? null;
    if (!is_array($mc) || ($mc['schema'] ?? '') !== CM_MERGE_SCHEMA || !is_array($mc['articles'] ?? null)) return null;
    $langs = array_values(array_filter([(string)($mc['lang'] ?? ''), (string)($mc['extraLang'] ?? '')]));
    if ($langs === []) return null;
    $articles = [];
    foreach ($mc['articles'] as $a) {
        if (!is_array($a) || !is_array($a['t'] ?? null)) continue;
        $k = cm_article_key((string)($a['k'] ?? ''));
        if ($k === '') continue;
        $articles[$k] = $a['t'];
    }
    if ($articles === []) return null;
    return ['schema' => 'contractregister/contract/v1', 'languages' => $langs, 'articles' => $articles];
}

function merged_contract_intro(array $d): string {
    $mc = $d['mergedContract'] ?? [];
    $lang = (string)($d['lang'] ?? 'nl');
    $p1 = trim(($mc['p1']['title'] ?? '') . ' (MD5 ' . ($mc['p1']['md5'] ?? '') . ')');
    $p2 = trim(($mc['p2']['title'] ?? '') . ' (MD5 ' . ($mc['p2']['md5'] ?? '') . ')');
    $tpl = match ($lang) {
        'nl' => "OVEREENKOMST — samengesteld uit het contract van partij 1: %1\$s\nen het contract van partij 2: %2\$s",
        'de' => "VEREINBARUNG — zusammengestellt aus dem Vertrag von Partei 1: %1\$s\nund dem Vertrag von Partei 2: %2\$s",
        'fr' => "ACCORD — établi à partir du contrat de la partie 1 : %1\$s\net du contrat de la partie 2 : %2\$s",
        'es' => "ACUERDO — elaborado a partir del contrato de la parte 1: %1\$s\ny del contrato de la parte 2: %2\$s",
        default => "AGREEMENT — compiled from the contract of party 1: %1\$s\nand the contract of party 2: %2\$s",
    };
    if (!in_array($lang, ['nl', 'de', 'fr', 'es', 'en'], true) && function_exists('translate_doc_label')) {
        $translated = (string)translate_doc_label('merge_intro_v1', $lang, $tpl);
        if (substr_count($translated, '%1$s') === 1 && substr_count($translated, '%2$s') === 1) $tpl = $translated;
    }
    try {
        return sprintf($tpl, $p1, $p2) . "\n\n";
    } catch (\Throwable $e) {
        return "AGREEMENT — party 1: $p1 / party 2: $p2\n\n";
    }
}

function merged_contract_lang_separator(string $lang): string {
    return str_repeat('=', 32) . "\n=== " . strtoupper($lang) . ' — ' . cm_lang_label($lang) . " ===\n" . str_repeat('=', 32);
}

/**
 * Volledige contracttekst voor een record met overeenkomst (primaire taal +
 * eventuele tweede taal), of null als het record geen overeenkomst bevat.
 * $summaryFn = contract_summary_section (uit index.php).
 */
function merged_contract_body(array $d, callable $summaryFn): ?string {
    $def = merged_contract_definition($d);
    if ($def === null) return null;
    $out = $summaryFn($d) . merged_contract_intro($d) . render_contract_from_definition($def, $d);
    $extra = (string)($d['mergedContract']['extraLang'] ?? '');
    if ($extra !== '' && $extra !== ($d['lang'] ?? '') && in_array($extra, $def['languages'], true)) {
        $d2 = $d;
        $d2['lang'] = $extra;
        $out .= "\n\n" . merged_contract_lang_separator($extra) . "\n\n"
              . $summaryFn($d2) . merged_contract_intro($d2) . render_contract_from_definition($def, $d2);
    }
    return $out;
}

/** Samenvatting voor het velden-JSON-bestand. */
function merged_contract_fields_summary(array $record): ?array {
    $mc = $record['mergedContract'] ?? null;
    if (!is_array($mc)) return null;
    return [
        'partij1Contract' => $mc['p1'] ?? null,
        'partij2Contract' => $mc['p2'] ?? null,
        'brontaal'        => $mc['sourceLang'] ?? null,
        'taal'            => $mc['lang'] ?? null,
        'tweedeTaal'      => ($mc['extraLang'] ?? '') !== '' ? $mc['extraLang'] : null,
        'aantalArtikelen' => count($mc['articles'] ?? []),
        'weggelaten'      => $mc['excluded'] ?? [],
    ];
}

// ===============================================================
// UI — Configuratie contracten: paneel "Exporteer als QR-ZIP"
// ===============================================================
function render_merge_config_panel(string $key, array $def): string {
    $langs = array_values(array_map('strval', $def['languages'] ?? ['nl']));
    $preview = cm_build_config_payload($key, in_array('nl', $langs, true) ? ['nl'] : [$langs[0] ?? 'nl']);
    ob_start(); ?>
    <div class="panel" id="cmQrExportPanel">
      <div class="section-title" style="font-size:15px;margin-top:0;">Exporteren als QR-ZIP <small>voor "Nieuw contract + tekenen"</small></div>
      <p style="margin-bottom:10px;">
        Het contract (alleen de artikelen) wordt net als een gegenereerd contract als PAYLOAD verpakt en in QR-codes omgezet.
        De QR-afbeeldingen komen in een AES-256-ZIP. <strong>Het wachtwoord van de ZIP is de MD5 van die payload</strong> —
        geef dit wachtwoord samen met de ZIP aan de andere partij.
        Bedrijfsgegevens, verwerkingsdetails en commerciële voorwaarden zitten er niet in.
      </p>
      <div class="form-group">
        <label>Talen in de QR-codes <small>(minder talen = minder QR-codes)</small></label>
        <div style="display:flex;flex-wrap:wrap;gap:12px;">
          <?php foreach ($langs as $l): ?>
            <label style="font-weight:400;display:flex;align-items:center;gap:6px;">
              <input type="checkbox" class="cm-export-lang" value="<?= e($l) ?>" <?= ($l === 'nl' || (!in_array('nl', $langs, true) && $l === ($langs[0] ?? ''))) ? 'checked' : '' ?>>
              <?= e(strtoupper($l) . ' — ' . cm_lang_label($l)) ?>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="row"><span class="label">ZIP-wachtwoord (MD5 payload)</span> <code id="cmExportMd5"><?= e($preview['md5'] ?? '—') ?></code>
        <button type="button" class="btn btn-sm btn-outline" id="cmExportCopy" style="margin-left:8px;">Kopiëren</button></div>
      <div class="row"><span class="label">Aantal QR-codes</span> <code id="cmExportParts"><?= e((string)($preview['parts'] ?? '—')) ?></code></div>
      <div style="margin-top:12px;">
        <button type="button" class="btn btn-outline" id="cmExportBtn" data-key="<?= e($key) ?>">🔐 Exporteer als QR-ZIP</button>
      </div>
      <div id="cmExportMsg" class="message" style="display:none;margin-top:10px;"></div>
    </div>
    <script>
    (function() {
      'use strict';
      var panel = document.getElementById('cmQrExportPanel');
      if (!panel) return;
      var btn = document.getElementById('cmExportBtn');
      var msg = document.getElementById('cmExportMsg');
      var md5El = document.getElementById('cmExportMd5');
      var partsEl = document.getElementById('cmExportParts');
      var lastPayload = null;

      function show(text, cls) { msg.className = 'message' + (cls ? ' ' + cls : ''); msg.textContent = text; msg.style.display = text ? 'block' : 'none'; }
      function langs() { return Array.prototype.map.call(panel.querySelectorAll('.cm-export-lang:checked'), function(c) { return c.value; }); }

      async function fetchPayload() {
        var fd = new FormData();
        fd.append('action', 'cm_config_qr_payload');
        fd.append('key', btn.getAttribute('data-key'));
        langs().forEach(function(l) { fd.append('langs[]', l); });
        var res = await fetch(window.location.pathname, { method: 'POST', body: fd });
        var data = await res.json();
        if (!data.ok) throw new Error(data.error || 'Fout');
        md5El.textContent = data.md5;
        partsEl.textContent = String(data.parts);
        lastPayload = data;
        return data;
      }

      panel.querySelectorAll('.cm-export-lang').forEach(function(c) {
        c.addEventListener('change', function() { fetchPayload().then(function() { show(''); }).catch(function(e) { show(e.message, 'danger'); }); });
      });

      document.getElementById('cmExportCopy').addEventListener('click', function() {
        if (navigator.clipboard) navigator.clipboard.writeText(md5El.textContent.trim()).then(function() { show('Wachtwoord gekopieerd.', 'success'); });
      });

      btn.addEventListener('click', async function() {
        if (typeof QRCode === 'undefined') { show('QR-bibliotheek (qrcode.js) niet geladen.', 'danger'); return; }
        var orig = btn.textContent; btn.disabled = true;
        try {
          show('Payload opbouwen…', 'info');
          var data = await fetchPayload();
          var images = await window.CM_QR.makeImages(data.payload, function(i, n) { show('QR-code ' + i + '/' + n + ' maken…', 'info'); });
          if (!images.length) throw new Error('Geen QR-codes gemaakt.');
          show('ZIP versleutelen…', 'info');
          var fd = new FormData();
          fd.append('action', 'qrzip_json');
          fd.append('md5', data.md5);
          fd.append('id', data.key + '-contract');
          images.forEach(function(src) { fd.append('images[]', src); });
          var res = await fetch(window.location.pathname, { method: 'POST', body: fd });
          if ((res.headers.get('Content-Type') || '').indexOf('application/json') !== -1) {
            var err = await res.json(); throw new Error(err.error || 'Fout');
          }
          if (!res.ok) throw new Error('HTTP ' + res.status);
          var blob = await res.blob();
          var url = URL.createObjectURL(blob);
          var a = document.createElement('a'); a.href = url; a.download = data.key + '_contract_qr.zip';
          document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
          show('ZIP met ' + images.length + ' QR-code(s) gedownload. Wachtwoord: ' + data.md5, 'success');
        } catch (e) { show(e.message || String(e), 'danger'); }
        finally { btn.disabled = false; btn.textContent = orig; }
      });
    })();
    </script>
    <?php
    return cm_qr_js() . (string)ob_get_clean();
}

// ===============================================================
// Gedeelde browser-helpers: QR maken (zelfde formaat als index.php:
// PARTx/y:…, 700 tekens) en QR-afbeeldingen decoderen (jsQR).
// ===============================================================
function cm_qr_js(): string {
    static $done = false;
    if ($done) return '';
    $done = true;
    return <<<'HTML'
<script>
window.CM_QR = window.CM_QR || (function() {
  'use strict';
  var CHUNK = 700, SIZE = 500;
  function waitRender(tmp) {
    return new Promise(function(resolve) {
      var tries = 0;
      (function check() {
        var img = tmp.querySelector('img'), canvas = tmp.querySelector('canvas');
        if (img && img.src && img.src.indexOf('data:image') === 0 && img.complete) return resolve();
        if (!img && canvas) return resolve();
        if (++tries > 25) return resolve();
        setTimeout(check, 30);
      })();
    });
  }
  async function makeImages(text, onProgress) {
    var total = Math.max(1, Math.ceil(text.length / CHUNK)), out = [];
    for (var i = 0; i < total; i++) {
      if (onProgress) onProgress(i + 1, total);
      var part = total === 1 ? text : 'PART' + (i + 1) + '/' + total + ':' + text.slice(i * CHUNK, (i + 1) * CHUNK);
      var tmp = document.createElement('div');
      tmp.style.position = 'absolute'; tmp.style.left = '-9999px';
      document.body.appendChild(tmp);
      try {
        new QRCode(tmp, { text: part, width: SIZE, height: SIZE, correctLevel: QRCode.CorrectLevel.L });
        await waitRender(tmp);
        // qrcode.js vult eerst een canvas en zet daarna pas de <img>; de canvas
        // is altijd direct bruikbaar.
        var canvas = tmp.querySelector('canvas'), img = tmp.querySelector('img');
        var src = canvas ? canvas.toDataURL('image/png') : (img ? img.src : '');
        if (src) out.push(src);
      } finally { document.body.removeChild(tmp); }
    }
    return out;
  }
  function decodeSrc(src) {
    return new Promise(function(resolve) {
      var img = new Image();
      img.onload = function() {
        try {
          var c = document.createElement('canvas');
          c.width = img.naturalWidth || img.width; c.height = img.naturalHeight || img.height;
          var ctx = c.getContext('2d');
          ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
          ctx.drawImage(img, 0, 0);
          var d = ctx.getImageData(0, 0, c.width, c.height);
          var code = jsQR(d.data, d.width, d.height);
          resolve(code && code.data ? code.data : null);
        } catch (e) { resolve(null); }
      };
      img.onerror = function() { resolve(null); };
      img.src = src;
    });
  }
  // Voegt een lijst QR-teksten samen tot één payload. Geeft
  // {ok, payload} of {ok:false, error}.
  function assemble(texts) {
    var parts = {}, total = 0, single = null;
    texts.forEach(function(t) {
      if (!t) return;
      var m = /^PART(\d+)\/(\d+):([\s\S]*)$/.exec(t);
      if (!m) { single = t; return; }
      total = parseInt(m[2], 10);
      parts[parseInt(m[1], 10) - 1] = m[3];
    });
    if (!total) return single ? { ok: true, payload: single } : { ok: false, error: 'Geen QR-codes herkend.' };
    var missing = [];
    for (var i = 0; i < total; i++) if (!(i in parts)) missing.push(i + 1);
    if (missing.length) return { ok: false, error: 'Ontbrekende QR-delen: ' + missing.join(', ') + ' (van ' + total + ').' };
    var full = '';
    for (var j = 0; j < total; j++) full += parts[j];
    return { ok: true, payload: full };
  }
  return { makeImages: makeImages, decodeSrc: decodeSrc, assemble: assemble };
})();
</script>
HTML;
}

// ===============================================================
// UI — Nieuw contract + tekenen: sectie "Overeenkomst uit twee contracten"
// ===============================================================
function render_merge_generate_section(): string {
    $targets = [];
    if (function_exists('deepl_enabled') && deepl_enabled() && function_exists('deepl_languages_sorted')) {
        foreach (deepl_languages_sorted() as $code => $meta) {
            $targets[(string)$code] = (string)($meta['label'] ?? strtoupper((string)$code));
        }
    }
    $legal = function_exists('tr_t') ? (string)tr_t('legal') : '';
    $tokens = [];
    if (function_exists('placeholder_tokens')) {
        foreach (placeholder_tokens() as $pt) {
            $tokens[] = ['token' => '{{' . $pt['token'] . '}}', 'desc' => t((string)$pt['descKey'])];
        }
    }
    ob_start(); ?>
    <style>
      .cm-steps { display:grid; gap:14px; }
      .cm-step { border:1px solid var(--line, #ddd); border-radius:8px; padding:14px; }
      .cm-step h4 { margin:0 0 10px; font-size:14px; }
      .cm-step.is-disabled { opacity:.5; pointer-events:none; }
      .cm-load-row { display:flex; flex-wrap:wrap; gap:10px; align-items:flex-end; }
      .cm-load-row .form-group { margin-bottom:0; }
      .cm-table-wrap { overflow-x:auto; }
      .cm-table { display:grid; grid-template-columns: 150px repeat(3, minmax(240px,1fr)); min-width:960px; border-top:1px solid var(--line, #ddd); }
      .cm-table > div { padding:8px; border-bottom:1px solid var(--line, #ddd); font-size:12.5px; }
      .cm-head { font-weight:600; background:var(--paper-2, #f5f5f0); position:sticky; top:0; }
      /* Eén gedeelde tekstopmaak voor partij 1, partij 2 en Overeengekomen */
      .cm-box, .cm-ed-back, .cm-ed textarea {
        font-family:'IBM Plex Mono', monospace; font-size:11.5px; line-height:1.5; letter-spacing:normal;
        white-space:pre-wrap; overflow-wrap:break-word; word-break:normal; tab-size:4;
        padding:8px; margin:0; border:1px solid var(--line, #ddd); border-radius:4px;
        box-sizing:border-box; width:100%; scrollbar-gutter:stable;
      }
      .cm-box { background:#fff; max-height:340px; overflow-y:auto; }
      .cm-ed { position:relative; background:#fff; border-radius:4px; }
      .cm-ed-back { position:absolute; inset:0; overflow:hidden; color:transparent; border-color:transparent; pointer-events:none; }
      .cm-ed textarea { position:relative; display:block; background:transparent; color:inherit; resize:none; min-height:0; max-height:340px; overflow-y:auto; }
      .cm-ed textarea:focus { outline:2px solid var(--gold, #c9a227); outline-offset:-1px; }
      .cm-var { background:#e3e9fa; color:#2f4a8a; border-radius:3px; box-shadow:0 0 0 1px #c5d1f3; }
      .cm-ed-back .cm-var { color:transparent; }
      .cm-vars-wrap { margin:4px 0; font-size:11.5px; }
      .cm-vars-wrap summary { cursor:pointer; color:#2f4a8a; }
      .cm-vars { display:flex; flex-wrap:wrap; gap:3px; margin:4px 0; }
      .cm-vars button { font-family:'IBM Plex Mono', monospace; font-size:10.5px; padding:1px 5px; border:1px solid #c5d1f3; background:#eef2fc; color:#2f4a8a; border-radius:3px; cursor:pointer; }
      .cm-text ins { background:#d7f5dd; text-decoration:none; }
      .cm-text del { background:#fbd5d5; }
      .cm-badge { display:inline-block; padding:1px 7px; border-radius:10px; font-size:11px; margin-top:4px; }
      .cm-same { background:#e3f1e6; color:#2a7a4d; }
      .cm-diff { background:#fde8d4; color:#9a4b00; }
      .cm-only { background:#e4e9f7; color:#2f4a8a; }
      .cm-open { outline:2px solid #e0a040; outline-offset:-2px; }
      .cm-agreed .cm-btns { display:flex; flex-wrap:wrap; gap:4px; margin:4px 0; }
      .cm-agreed label { font-weight:400; font-size:12px; margin-right:10px; }
      .cm-excluded { opacity:.45; }
      .cm-preview { display:grid; gap:10px; }
      .cm-preview .cm-prev-art { border-left:3px solid var(--line, #ddd); padding-left:10px; }
      .cm-preview .cm-warn { border-left-color:#c0392b; }
      .cm-tabs { display:flex; gap:6px; margin-bottom:8px; }
    </style>

    <div class="section-title" style="font-size:15px;">Werkwijze <small>sjabloon of overeenkomst uit twee contracten</small></div>
    <div class="form-group" style="display:flex;flex-wrap:wrap;gap:18px;">
      <label style="font-weight:400;"><input type="radio" name="merge_mode" value="0" checked> Standaard: contractsjabloon</label>
      <label style="font-weight:400;"><input type="radio" name="merge_mode" value="1"> Overeenkomst uit contract partij 1 + contract partij 2 (QR-ZIP)</label>
    </div>

    <div id="cmBody" style="display:none;">
      <input type="hidden" name="merged_contract" id="cmMergedInput" value="">
      <div class="message info" style="margin-bottom:12px;">
        Uit de QR-ZIP's worden alleen de contractartikelen gelezen. <strong>Bedrijfsgegevens, Verwerkingsdetails en Commerciële voorwaarden worden niet uit de contracten geladen</strong> — die vult u hieronder in het formulier in.
        Het contractsjabloon, de contracttaalkiezer, "Bijlagen aanpassen" en "Extra vertalingen" hieronder worden in deze werkwijze niet gebruikt.
      </div>

      <div class="cm-steps">
        <?php foreach ([1, 2] as $p): ?>
        <div class="cm-step<?= $p === 2 ? ' is-disabled' : '' ?>" id="cmStepP<?= $p ?>">
          <h4>Stap <?= $p ?> — Contract partij <?= $p ?></h4>
          <div class="cm-load-row">
            <div class="form-group">
              <label>QR-ZIP (of losse QR-afbeeldingen)</label>
              <input type="file" id="cmFileP<?= $p ?>" accept=".zip,application/zip,image/png,image/jpeg" multiple>
            </div>
            <div class="form-group" style="min-width:300px;">
              <label>Wachtwoord (MD5 van het contract)</label>
              <input type="text" id="cmPwP<?= $p ?>" class="mono" maxlength="32" autocomplete="off" spellcheck="false" placeholder="32 tekens, 0-9 a-f">
            </div>
            <button type="button" class="btn btn-outline" id="cmLoadP<?= $p ?>">Contract partij <?= $p ?> laden</button>
          </div>
          <div id="cmStatusP<?= $p ?>" class="message" style="display:none;margin-top:10px;"></div>
        </div>
        <?php endforeach; ?>

        <div class="cm-step is-disabled" id="cmStep3">
          <h4>Stap 3 — Wat is overeengekomen?</h4>
          <div style="display:flex;flex-wrap:wrap;gap:14px;align-items:flex-end;margin-bottom:10px;">
            <div class="form-group" style="margin-bottom:0;">
              <label>Vergelijken in taal</label>
              <select id="cmCmpLang"></select>
            </div>
            <label style="font-weight:400;"><input type="checkbox" id="cmOnlyDiff"> Alleen verschillen tonen</label>
            <button type="button" class="btn btn-sm btn-outline" id="cmAllP1">Alle open verschillen: partij 1</button>
            <button type="button" class="btn btn-sm btn-outline" id="cmAllP2">Alle open verschillen: partij 2</button>
            <span id="cmCounters" style="font-size:12px;"></span>
          </div>
          <div class="cm-table-wrap"><div class="cm-table" id="cmTable"></div></div>
        </div>

        <div class="cm-step is-disabled" id="cmStep4">
          <h4>Stap 4 — Taal van de overeenkomst</h4>
          <div style="display:flex;flex-wrap:wrap;gap:14px;align-items:flex-end;">
            <div class="form-group" style="margin-bottom:0;">
              <label>Contracttaal</label>
              <select id="cmLang"></select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label>Extra tweede taal (optioneel)</label>
              <select id="cmExtraLang"></select>
            </div>
            <button type="button" class="btn btn-outline" id="cmTranslateBtn">Vertaal overeenkomst</button>
          </div>
          <?php if ($targets === []): ?>
            <div class="message" style="margin-top:10px;">Er is geen vertaalengine geconfigureerd: alleen de taal waarin vergeleken is, kan worden gekozen.</div>
          <?php elseif ($legal !== ''): ?>
            <div class="message info" style="margin-top:10px;"><?= e($legal) ?></div>
          <?php endif; ?>
          <div id="cmTrStatus" class="message" style="display:none;margin-top:10px;"></div>
          <div id="cmPreviewWrap" style="display:none;margin-top:12px;">
            <div class="cm-tabs" id="cmPreviewTabs"></div>
            <div class="cm-preview" id="cmPreview"></div>
          </div>
        </div>

        <div class="cm-step" id="cmStep5">
          <h4>Stap 5 — Genereren</h4>
          <div id="cmReady" class="message">Nog niet klaar.</div>
          <p style="font-size:12px;margin:6px 0 0;">Vul hieronder de bedrijfsgegevens, verwerkingsdetails en commerciële voorwaarden in, laat beide partijen tekenen en gebruik de standaard knop <em>Genereer</em>. De overeenkomst zit in de payload/QR, dus het contract kan later 1-op-1 worden her-genereerd.</p>
        </div>
      </div>
    </div>

    <?= cm_qr_js() ?>
    <script>
    (function() {
      'use strict';
      var TARGETS = <?= json_encode($targets, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
      var TOKENS = <?= json_encode($tokens, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
      var URL_ = window.location.pathname;
      var $ = function(id) { return document.getElementById(id); };
      var S = {
        p: { 1: null, 2: null },
        cmpLang: '', rows: [], version: 0,
        lang: '', extra: '',
        tr: {},          // tr[lang][key] = {title, body, warn}
        trVersion: {},   // trVersion[lang] = S.version op moment van vertalen
      };

      function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
      function msg(el, text, cls) { el.className = 'message' + (cls ? ' ' + cls : ''); el.textContent = text; el.style.display = text ? 'block' : 'none'; }
      function mode() { var r = document.querySelector('input[name="merge_mode"]:checked'); return r ? r.value : '0'; }
      function langName(l) { return l.toUpperCase() + (TARGETS[l] ? ' — ' + TARGETS[l] : ''); }
      // Titel + tekst als één blok (eerste regel = titel), precies zoals de
      // kolommen partij 1/2 het tonen.
      function fullText(e) { return e ? ((e.title || '') + '\n' + (e.body || '')) : ''; }
      function splitText(v) {
        v = String(v).replace(/\r\n/g, '\n');
        var i = v.indexOf('\n');
        return i < 0 ? { title: v, body: '' } : { title: v.slice(0, i), body: v.slice(i + 1) };
      }
      // Markeert {{VARIABELEN}} in al ge-escapete HTML (ook binnen diff-tags).
      function hl(html) { return html.replace(/\{\{[A-Za-z0-9_]+\}\}/g, '<span class="cm-var">$&</span>'); }

      // Bewerkbaar blok met dezelfde opmaak als .cm-box; een onzichtbare
      // achterlaag toont de variabele-markering exact onder de tekst.
      function editorHtml(value, attrs) {
        var chips = TOKENS.map(function(t) {
          return '<button type="button" data-token="' + esc(t.token) + '" title="' + esc(t.desc) + '">' + esc(t.token) + '</button>';
        }).join('');
        return '<div class="cm-ed"><div class="cm-ed-back" aria-hidden="true">' + hl(esc(value)) + '\n</div>' +
          // Extra '\n': HTML verwijdert het eerste regeleinde direct na <textarea>
          // (bv. de Preamble, die met een lege titelregel begint).
          '<textarea rows="1" spellcheck="false" ' + attrs + '>\n' + esc(value) + '</textarea></div>' +
          (chips ? '<details class="cm-vars-wrap"><summary>Variabele invoegen</summary><div class="cm-vars">' + chips + '</div></details>' : '');
      }
      function syncEditor(ta) {
        var back = ta.previousElementSibling;
        ta.style.height = 'auto';
        ta.style.height = Math.min(ta.scrollHeight + 2, 340) + 'px';
        if (back) { back.innerHTML = hl(esc(ta.value)) + '\n'; back.scrollTop = ta.scrollTop; }
      }
      function initEditors(root) { root.querySelectorAll('.cm-ed textarea').forEach(syncEditor); }
      function wireEditors(root, onEdit) {
        root.addEventListener('scroll', function(e) {
          var ta = e.target; if (ta.tagName !== 'TEXTAREA' || !ta.closest('.cm-ed')) return;
          ta.previousElementSibling.scrollTop = ta.scrollTop;
        }, true);
        root.addEventListener('input', function(e) {
          var ta = e.target; if (ta.tagName !== 'TEXTAREA' || !ta.closest('.cm-ed')) return;
          syncEditor(ta); onEdit(ta);
        });
        root.addEventListener('mousedown', function(e) { if (e.target.closest('.cm-vars button')) e.preventDefault(); });
        root.addEventListener('click', function(e) {
          var chip = e.target.closest('.cm-vars button'); if (!chip) return;
          var ta = chip.closest('.cm-agreed, .cm-prev-art').querySelector('.cm-ed textarea');
          var tok = chip.getAttribute('data-token');
          var a = ta.selectionStart != null ? ta.selectionStart : ta.value.length;
          var b = ta.selectionEnd != null ? ta.selectionEnd : ta.value.length;
          ta.value = ta.value.slice(0, a) + tok + ta.value.slice(b);
          ta.focus(); ta.setSelectionRange(a + tok.length, a + tok.length);
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        });
      }

      // ---------- werkwijze wisselen ----------
      function applyMode() {
        var on = mode() === '1';
        $('cmBody').style.display = on ? '' : 'none';
        ['templatePickerSection', 'annexEditorSection', 'extraLangsSection'].forEach(function(id) {
          var el = $(id); if (!el) return;
          el.style.display = on ? 'none' : '';
          el.querySelectorAll('input,select,textarea').forEach(function(x) { x.disabled = on; });
        });
        if (!on) $('cmMergedInput').value = '';
        updateReady();
      }
      document.querySelectorAll('input[name="merge_mode"]').forEach(function(r) { r.addEventListener('change', applyMode); });

      // ---------- stap 1 + 2: laden ----------
      async function post(fd) {
        var res = await fetch(URL_, { method: 'POST', body: fd });
        var data = await res.json();
        if (!data.ok) throw new Error(data.error || 'Fout');
        return data;
      }
      function fileToDataUrl(f) {
        return new Promise(function(resolve, reject) { var r = new FileReader(); r.onload = function() { resolve(r.result); }; r.onerror = reject; r.readAsDataURL(f); });
      }

      async function loadParty(n) {
        var status = $('cmStatusP' + n);
        var files = Array.prototype.slice.call($('cmFileP' + n).files || []);
        var pw = ($('cmPwP' + n).value || '').trim().toLowerCase();
        if (!files.length) { msg(status, 'Kies eerst de QR-ZIP van partij ' + n + '.', 'danger'); return; }
        if (!/^[a-f0-9]{32}$/.test(pw)) { msg(status, 'Het wachtwoord is de MD5 van het contract (32 tekens, 0-9 en a-f).', 'danger'); return; }
        if (typeof jsQR === 'undefined') { msg(status, 'QR-lezer (jsQR) niet geladen.', 'danger'); return; }
        var btn = $('cmLoadP' + n); btn.disabled = true;
        try {
          var sources = [], warning = '';
          for (var i = 0; i < files.length; i++) {
            var f = files[i];
            if (/\.zip$/i.test(f.name) || f.type.indexOf('zip') !== -1) {
              msg(status, 'ZIP openen met wachtwoord…', 'info');
              var fd = new FormData();
              fd.append('action', 'cm_qrzip_extract');
              fd.append('password', pw);
              fd.append('zipfile', f);
              var z = await post(fd);
              if (z.warning) warning = z.warning;
              sources = sources.concat(z.images);
            } else {
              sources.push(await fileToDataUrl(f));
            }
          }
          var texts = [];
          for (var j = 0; j < sources.length; j++) {
            msg(status, 'QR-code ' + (j + 1) + '/' + sources.length + ' lezen…', 'info');
            texts.push(await window.CM_QR.decodeSrc(sources[j]));
          }
          var asm = window.CM_QR.assemble(texts);
          if (!asm.ok) throw new Error(asm.error);
          var fd2 = new FormData();
          fd2.append('action', 'cm_payload_decode');
          fd2.append('payload', asm.payload);
          fd2.append('md5', pw);
          var d = await post(fd2);
          S.p[n] = d.contract;
          msg(status, '✔ Geladen: ' + (d.contract.title || d.contract.key) + ' · versie ' + d.contract.version + ' · ' +
            d.contract.articles.length + ' artikelen · talen ' + d.contract.languages.join(', ').toUpperCase() +
            ' · MD5 ' + d.contract.md5 + (warning ? ' — ' + warning : ''), warning ? '' : 'success');
          if (n === 1) {
            $('cmStepP2').classList.remove('is-disabled');
            if (S.p[2]) buildRows();
          } else {
            buildRows();
          }
        } catch (e) {
          S.p[n] = null;
          msg(status, e.message || String(e), 'danger');
          if (n === 1) $('cmStepP2').classList.add('is-disabled');
          resetMerge();
        } finally { btn.disabled = false; }
      }
      $('cmLoadP1').addEventListener('click', function() { loadParty(1); });
      $('cmLoadP2').addEventListener('click', function() { loadParty(2); });

      function resetMerge() {
        S.rows = []; S.tr = {}; S.trVersion = {}; S.version++;
        $('cmStep3').classList.add('is-disabled'); $('cmStep4').classList.add('is-disabled');
        $('cmTable').innerHTML = ''; $('cmPreviewWrap').style.display = 'none';
        updateReady();
      }

      // ---------- stap 3: drie kolommen ----------
      function buildRows() {
        if (!S.p[1] || !S.p[2]) return;
        var common = S.p[1].languages.filter(function(l) { return S.p[2].languages.indexOf(l) !== -1; });
        var sel = $('cmCmpLang');
        if (!common.length) {
          resetMerge();
          msg($('cmStatusP2'), 'De contracten hebben geen gemeenschappelijke taal. Exporteer beide in dezelfde taal (bv. NL).', 'danger');
          return;
        }
        var prev = S.cmpLang;
        sel.innerHTML = common.map(function(l) { return '<option value="' + esc(l) + '">' + esc(langName(l)) + '</option>'; }).join('');
        S.cmpLang = common.indexOf(prev) !== -1 ? prev : (common.indexOf('nl') !== -1 ? 'nl' : common[0]);
        sel.value = S.cmpLang;
        rebuildRows();
      }

      $('cmCmpLang').addEventListener('change', function() {
        var touched = S.rows.some(function(r) { return r.touched; });
        if (touched && !confirm('Van vergelijkingstaal wisselen zet alle gemaakte keuzes terug. Doorgaan?')) { this.value = S.cmpLang; return; }
        S.cmpLang = this.value; rebuildRows();
      });

      function rebuildRows() {
        var lang = S.cmpLang, map = {}, order = [];
        [1, 2].forEach(function(n) {
          S.p[n].articles.forEach(function(a) {
            if (!map[a.key]) { map[a.key] = { key: a.key, label: a.label, p1: null, p2: null }; order.push(a.key); }
            var e = a.byLang[lang];
            map[a.key]['p' + n] = e ? { title: e.title || '', body: e.body || '' } : null;
          });
        });
        S.rows = order.map(function(k) {
          var r = map[k];
          if (r.p1 && r.p2) r.status = (r.p1.title === r.p2.title && r.p1.body === r.p2.body) ? 'same' : 'diff';
          else r.status = r.p1 ? 'only1' : 'only2';
          r.include = true;
          r.touched = false;
          if (r.status === 'same') { r.agreed = { title: r.p1.title, body: r.p1.body }; r.ok = true; }
          else if (r.status === 'diff') { r.agreed = { title: '', body: '' }; r.ok = false; }
          else { var src = r.p1 || r.p2; r.agreed = { title: src.title, body: src.body }; r.ok = false; }
          return r;
        });
        S.tr = {}; S.trVersion = {}; S.version++;
        $('cmStep3').classList.remove('is-disabled');
        $('cmStep4').classList.remove('is-disabled');
        fillLangSelects();
        renderTable();
      }

      // Woord-diff (LCS); valt terug op platte tekst bij zeer lange artikelen.
      function diffHtml(a, b) {
        var A = a.split(/(\s+)/), B = b.split(/(\s+)/);
        if (A.length * B.length > 400000) return { a: esc(a), b: esc(b), tooBig: true };
        var n = A.length, m = B.length, i, j;
        var dp = new Array(n + 1);
        for (i = 0; i <= n; i++) dp[i] = new Uint32Array(m + 1);
        for (i = n - 1; i >= 0; i--) for (j = m - 1; j >= 0; j--)
          dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
        var outA = '', outB = '';
        i = 0; j = 0;
        while (i < n && j < m) {
          if (A[i] === B[j]) { outA += esc(A[i]); outB += esc(B[j]); i++; j++; }
          else if (dp[i + 1][j] >= dp[i][j + 1]) { outA += '<del>' + esc(A[i]) + '</del>'; i++; }
          else { outB += '<ins>' + esc(B[j]) + '</ins>'; j++; }
        }
        while (i < n) outA += '<del>' + esc(A[i++]) + '</del>';
        while (j < m) outB += '<ins>' + esc(B[j++]) + '</ins>';
        return { a: outA, b: outB };
      }

      function badge(r) {
        return {
          same: '<span class="cm-badge cm-same">gelijk</span>',
          diff: '<span class="cm-badge cm-diff">verschil</span>',
          only1: '<span class="cm-badge cm-only">alleen partij 1</span>',
          only2: '<span class="cm-badge cm-only">alleen partij 2</span>',
        }[r.status];
      }

      function renderTable() {
        var onlyDiff = $('cmOnlyDiff').checked;
        var html = '<div class="cm-head">Artikel</div><div class="cm-head">Partij 1 — ' + esc(S.p[1].title || S.p[1].key) +
          '</div><div class="cm-head">Partij 2 — ' + esc(S.p[2].title || S.p[2].key) + '</div><div class="cm-head">Overeengekomen</div>';
        S.rows.forEach(function(r, idx) {
          if (onlyDiff && r.status === 'same') return;
          var d = (r.p1 && r.p2 && r.status === 'diff') ? diffHtml(fullText(r.p1), fullText(r.p2)) : null;
          var t1 = r.p1 ? hl(d ? d.a : esc(fullText(r.p1))) : '<em>— komt niet voor —</em>';
          var t2 = r.p2 ? hl(d ? d.b : esc(fullText(r.p2))) : '<em>— komt niet voor —</em>';
          var cls = (r.include ? '' : ' cm-excluded') + (r.include && !r.ok ? ' cm-open' : '');
          html += '<div class="' + cls + '"><strong>' + esc(r.label) + '</strong><br><small>' + esc(r.key) + '</small><br>' + badge(r) + '</div>' +
            '<div class="' + cls + '"><div class="cm-box cm-text">' + t1 + '</div></div>' +
            '<div class="' + cls + '"><div class="cm-box cm-text">' + t2 + '</div></div>' +
            '<div class="cm-agreed' + cls + '" data-idx="' + idx + '">' +
              editorHtml(fullText(r.agreed), 'data-f="text" placeholder="Titel (eerste regel)&#10;Overeengekomen tekst"') +
              '<div class="cm-btns">' +
                (r.p1 ? '<button type="button" class="btn btn-sm btn-outline" data-act="p1">← Partij 1</button>' : '') +
                (r.p2 ? '<button type="button" class="btn btn-sm btn-outline" data-act="p2">Partij 2 →</button>' : '') +
                '<button type="button" class="btn btn-sm btn-outline" data-act="clear">Wissen</button>' +
              '</div>' +
              '<label><input type="checkbox" data-f="include"' + (r.include ? ' checked' : '') + '> Opnemen</label>' +
              '<label><input type="checkbox" data-f="ok"' + (r.ok ? ' checked' : '') + '> Akkoord</label>' +
            '</div>';
        });
        $('cmTable').innerHTML = html;
        initEditors($('cmTable'));
        updateCounters();
      }

      function rowOf(el) { var box = el.closest('.cm-agreed'); return box ? { box: box, r: S.rows[+box.getAttribute('data-idx')] } : null; }
      function changed(r) { r.touched = true; S.version++; updateCounters(); markStale(); }

      $('cmTable').addEventListener('click', function(e) {
        var b = e.target.closest('button[data-act]'); if (!b) return;
        var x = rowOf(b); if (!x) return;
        var act = b.getAttribute('data-act');
        var src = act === 'p1' ? x.r.p1 : act === 'p2' ? x.r.p2 : { title: '', body: '' };
        x.r.agreed = { title: src.title, body: src.body };
        x.r.ok = act !== 'clear';
        changed(x.r); renderTable();
      });
      wireEditors($('cmTable'), function(ta) {
        var x = rowOf(ta); if (!x) return;
        x.r.agreed = splitText(ta.value);
        if (!x.r.ok) { x.r.ok = true; var cb = x.box.querySelector('[data-f="ok"]'); if (cb) cb.checked = true; }
        changed(x.r);
      });
      $('cmTable').addEventListener('change', function(e) {
        var x = rowOf(e.target); if (!x) return;
        var f = e.target.getAttribute('data-f');
        if (f === 'text') return;
        if (f === 'include') { x.r.include = e.target.checked; changed(x.r); renderTable(); }
        if (f === 'ok') { x.r.ok = e.target.checked; changed(x.r); renderTable(); }
      });
      $('cmOnlyDiff').addEventListener('change', renderTable);
      function takeAll(n) {
        S.rows.forEach(function(r) {
          if (r.include && !r.ok && r['p' + n]) { r.agreed = { title: r['p' + n].title, body: r['p' + n].body }; r.ok = true; r.touched = true; }
        });
        S.version++; renderTable(); markStale();
      }
      $('cmAllP1').addEventListener('click', function() { takeAll(1); });
      $('cmAllP2').addEventListener('click', function() { takeAll(2); });

      function openRows() { return S.rows.filter(function(r) { return r.include && (!r.ok || !String(r.agreed.body).trim()); }); }
      function updateCounters() {
        var c = { same: 0, diff: 0, only: 0, excl: 0 };
        S.rows.forEach(function(r) {
          if (!r.include) c.excl++;
          if (r.status === 'same') c.same++; else if (r.status === 'diff') c.diff++; else c.only++;
        });
        $('cmCounters').textContent = c.same + ' gelijk · ' + c.diff + ' verschillend · ' + c.only + ' bij één partij · ' +
          c.excl + ' weggelaten · ' + openRows().length + ' nog open';
        updateReady();
      }

      // ---------- stap 4: taal + vertalen ----------
      function fillLangSelects() {
        var opts = {}; opts[S.cmpLang] = langName(S.cmpLang);
        Object.keys(TARGETS).forEach(function(l) { opts[l] = langName(l); });
        var keys = Object.keys(opts);
        var html = keys.map(function(l) { return '<option value="' + esc(l) + '">' + esc(opts[l]) + '</option>'; }).join('');
        $('cmLang').innerHTML = html;
        $('cmExtraLang').innerHTML = '<option value="">— geen —</option>' + html;
        $('cmLang').value = keys.indexOf(S.lang) !== -1 ? S.lang : S.cmpLang;
        $('cmExtraLang').value = keys.indexOf(S.extra) !== -1 ? S.extra : '';
        readLangs();
      }
      function readLangs() {
        S.lang = $('cmLang').value;
        S.extra = $('cmExtraLang').value === S.lang ? '' : $('cmExtraLang').value;
        renderPreview();
        updateReady();
      }
      $('cmLang').addEventListener('change', readLangs);
      $('cmExtraLang').addEventListener('change', readLangs);

      function neededLangs() {
        return [S.lang, S.extra].filter(function(l, i, arr) { return l && l !== S.cmpLang && arr.indexOf(l) === i; });
      }
      function included() { return S.rows.filter(function(r) { return r.include; }); }
      function isStale(l) { return S.trVersion[l] !== S.version; }
      function markStale() {
        if (neededLangs().some(function(l) { return S.tr[l] && isStale(l); }))
          msg($('cmTrStatus'), 'De overeenkomst is gewijzigd na het vertalen — vertaal opnieuw.', 'danger');
        updateReady();
      }

      $('cmTranslateBtn').addEventListener('click', async function() {
        var st = $('cmTrStatus'), btn = this;
        var open = openRows();
        if (open.length) { msg(st, 'Los eerst alle open punten in stap 3 op (' + open.length + ').', 'danger'); return; }
        var langs = neededLangs();
        if (!langs.length) { msg(st, 'Geen vertaling nodig: de overeenkomst staat al in ' + S.cmpLang.toUpperCase() + '.', 'success'); renderPreview(); updateReady(); return; }
        btn.disabled = true;
        var rows = included(), total = rows.length * langs.length, done = 0, warns = 0;
        var startVersion = S.version;
        try {
          for (var li = 0; li < langs.length; li++) {
            var l = langs[li], out = {};
            for (var ri = 0; ri < rows.length; ri++) {
              var r = rows[ri];
              msg(st, 'Vertalen naar ' + langName(l) + ': ' + (++done) + '/' + total + '…', 'info');
              var fd = new FormData();
              fd.append('action', 'cm_translate_article');
              fd.append('src', S.cmpLang); fd.append('tgt', l); fd.append('key', r.key);
              fd.append('title', r.agreed.title); fd.append('body', r.agreed.body);
              var d = await post(fd);
              out[r.key] = { title: d.title, body: d.body, warn: !d.placeholdersOk };
              if (!d.placeholdersOk) warns++;
            }
            S.tr[l] = out;
            S.trVersion[l] = startVersion;
          }
          if (S.version !== startVersion) msg(st, 'Tijdens het vertalen is de overeenkomst gewijzigd — vertaal opnieuw.', 'danger');
          else msg(st, '✔ Vertaald. Controleer de vertaling hieronder' + (warns ? ' — let op: bij ' + warns + ' artikel(en) kloppen de {{variabelen}} niet meer (rood gemarkeerd).' : '.'), warns ? '' : 'success');
        } catch (e) {
          msg(st, 'Vertalen mislukt: ' + (e.message || e), 'danger');
        } finally { btn.disabled = false; renderPreview(); updateReady(); }
      });

      var previewLang = '';
      function renderPreview() {
        var langs = neededLangs().filter(function(l) { return S.tr[l]; });
        var wrap = $('cmPreviewWrap');
        if (!langs.length) { wrap.style.display = 'none'; return; }
        if (langs.indexOf(previewLang) === -1) previewLang = langs[0];
        wrap.style.display = '';
        $('cmPreviewTabs').innerHTML = langs.map(function(l) {
          return '<button type="button" class="btn btn-sm ' + (l === previewLang ? 'btn-primary' : 'btn-outline') + '" data-l="' + esc(l) + '">' + esc(langName(l)) + (isStale(l) ? ' ⚠' : '') + '</button>';
        }).join('');
        var tr = S.tr[previewLang] || {};
        $('cmPreview').innerHTML = included().map(function(r) {
          var e = tr[r.key] || { title: '', body: '', warn: true };
          return '<div class="cm-prev-art' + (e.warn ? ' cm-warn' : '') + '" data-key="' + esc(r.key) + '">' +
            '<small>' + esc(r.label) + ' (' + esc(r.key) + ')' + (e.warn ? ' — {{variabelen}} controleren' : '') + '</small>' +
            editorHtml(fullText(e), 'data-f="text"') + '</div>';
        }).join('');
        initEditors($('cmPreview'));
      }
      $('cmPreviewTabs').addEventListener('click', function(e) {
        var b = e.target.closest('button[data-l]'); if (!b) return;
        previewLang = b.getAttribute('data-l'); renderPreview();
      });
      wireEditors($('cmPreview'), function(ta) {
        var art = ta.closest('.cm-prev-art'); if (!art) return;
        var t = S.tr[previewLang] && S.tr[previewLang][art.getAttribute('data-key')];
        if (t) { var v = splitText(ta.value); t.title = v.title; t.body = v.body; t.warn = false; }
      });

      // ---------- stap 5: klaar? ----------
      function problems() {
        var p = [];
        if (!S.p[1]) p.push('contract partij 1 is nog niet geladen');
        if (!S.p[2]) p.push('contract partij 2 is nog niet geladen');
        if (!S.rows.length) return p;
        var open = openRows().length;
        if (open) p.push(open + ' artikel(en) nog niet overeengekomen');
        if (!included().length) p.push('er zijn geen artikelen opgenomen');
        neededLangs().forEach(function(l) {
          if (!S.tr[l]) p.push('nog niet vertaald naar ' + l.toUpperCase());
          else if (isStale(l)) p.push('vertaling ' + l.toUpperCase() + ' is verouderd');
        });
        return p;
      }
      function updateReady() {
        var el = $('cmReady'); if (!el) return;
        var p = problems();
        if (p.length) msg(el, 'Nog niet klaar: ' + p.join('; ') + '.', '');
        else msg(el, '✔ Klaar: overeenkomst in ' + langName(S.lang) + (S.extra ? ' + ' + langName(S.extra) : '') + ' (' + included().length + ' artikelen). Gebruik de knop Genereer onderaan.', 'success');
      }

      function buildMerged() {
        var art = included().map(function(r) {
          var t = {};
          [S.lang, S.extra].forEach(function(l) {
            if (!l) return;
            t[l] = l === S.cmpLang ? { title: r.agreed.title, body: r.agreed.body }
                                   : { title: S.tr[l][r.key].title, body: S.tr[l][r.key].body };
          });
          return { k: r.key, t: t };
        });
        var meta = function(c) { return { key: c.key, title: c.title, version: c.version, md5: c.md5 }; };
        return {
          sourceLang: S.cmpLang, lang: S.lang, extraLang: S.extra,
          p1: meta(S.p[1]), p2: meta(S.p[2]),
          excluded: S.rows.filter(function(r) { return !r.include; }).map(function(r) { return r.key; }),
          articles: art,
        };
      }

      // Onderschept de standaard Genereer-knop (capture-fase, vóór de handler
      // in index.php) zodat alleen een afgeronde overeenkomst wordt verstuurd.
      document.addEventListener('click', function(e) {
        if (!e.target.closest || !e.target.closest('#generateBtn')) return;
        if (mode() !== '1') { $('cmMergedInput').value = ''; return; }
        var p = problems();
        if (p.length) {
          e.preventDefault(); e.stopImmediatePropagation();
          var box = $('genError');
          if (box) { box.textContent = 'Overeenkomst nog niet klaar: ' + p.join('; ') + '.'; box.style.display = 'block'; }
          $('cmStep5').scrollIntoView({ behavior: 'smooth', block: 'center' });
          return;
        }
        $('cmMergedInput').value = JSON.stringify(buildMerged());
      }, true);

      applyMode();
    })();
    </script>
    <?php
    return (string)ob_get_clean();
}

// ===============================================================
// Zelf-registratie van de AJAX-acties (vóór de POST-afhandeling van index.php)
// ===============================================================
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    switch ((string)($_POST['action'] ?? '')) {
        case 'cm_config_qr_payload': cm_handle_config_qr_payload(); break;
        case 'cm_qrzip_extract':     cm_handle_qrzip_extract(); break;
        case 'cm_payload_decode':    cm_handle_payload_decode(); break;
        case 'cm_translate_article': cm_handle_translate_article(); break;
    }
}