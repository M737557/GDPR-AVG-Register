<?php
/**
 * label_translate.php — vertaalt en cachet de VASTE labels en placeholder-
 * fallbackteksten die in het GEGENEREERDE CONTRACT zelf voorkomen (de
 * samenvatting-kopjes als "Doel:"/"Looptijd:" uit contract_summary_section(),
 * en placeholder-fallbacks als de standaardrol "verwerkingsverantwoordelijke"
 * / "controller" uit ph()/ph_defaults()/ph_role_label()) naar een
 * WILLEKEURIGE DeepL-taal — dus NIET de webinterface zelf, die blijft vast
 * Nederlands (current_lang() in index.php blijft 'nl' opleveren).
 *
 * Voor de vijf "bekende" content-talen (UI_LANGS = en/nl/de/es/fr, zie
 * index.php) bestaan deze teksten al statisch: lang_dict_en()/lang_dict_nl()/
 * enz. voor t(), en de vaste match()-blokken in ph_defaults()/ph_role_label().
 * Voor elke andere taal die DeepL kent (bv. Arabisch "ar", Russisch "ru" —
 * zie deepl_languages() in contract_translate.php, gebruikt door de
 * "Extra vertalingen"-checkboxes bij "Nieuw contract") worden ze hier LUI
 * (on-demand) vertaald vanuit de Engelse brontekst, de eerste keer dat die
 * taal+label-combinatie nodig is, en daarna per taal gecached in
 * i18n_cache/<taal>.json — zodat DeepL niet bij elke contractgeneratie
 * opnieuw hoeft te worden aangeroepen voor exact dezelfde vaste tekst.
 *
 * Installatie: require_once dit bestand in index.php, samen met de andere
 * drop-in modules — ná contract_translate.php (dat deepl_translate_block(),
 * deepl_enabled() en deepl_lang_known() levert). t()/ph()/ph_defaults()/
 * ph_role_label()/contract_missing_json_notice() in index.php roepen
 * translate_doc_label() zelf aan zodra de gevraagde taal buiten UI_LANGS
 * valt; voor talen ín UI_LANGS gebeurt er niets en verandert er niets aan
 * het bestaande gedrag.
 */

declare(strict_types=1);

define('I18N_CACHE_DIR', __DIR__ . '/i18n_cache');

// ===============================================================
// CIRCUIT BREAKER — zelfde patroon als pdf_translate_circuit() in
// pdf_translate.php: bij een DeepL-storing niet elk los label apart laten
// falen-en-hertellen. Eén contractgeneratie kan tientallen labels voor een
// nieuwe taal opvragen (samenvatting-kopjes + placeholder-fallbacks); zodra
// de eerste aanroep mislukt, "springt" deze breaker open en vallen alle
// volgende labels in dezelfde aanvraag direct terug op de Engelse tekst
// (geen nieuwe DeepL-aanroepen meer, dus snel i.p.v. minutenlang hangen).
// ===============================================================
function &label_translate_circuit(): array {
    static $state = ['open' => false];
    return $state;
}
function label_translate_circuit_reset(): void {
    $c = &label_translate_circuit();
    $c['open'] = false;
}
function label_translate_circuit_trip(): void {
    $c = &label_translate_circuit();
    $c['open'] = true;
}
function label_translate_circuit_open(): bool {
    return label_translate_circuit()['open'];
}

// ===============================================================
// CACHE — i18n_cache/<taal>.json = { labelsleutel => vertaalde tekst }.
// Eén bestand per taal, atomisch geschreven (tmp + rename), zelfde patroon
// als save_presets() in presets.php. In-memory per taal binnen dit PHP-proces
// bijgehouden (label_cache_registry()) zodat een taal met veel labels het
// bestand niet bij elk label opnieuw hoeft in te lezen.
// ===============================================================
function &label_cache_registry(): array {
    static $mem = [];
    return $mem;
}

function label_cache_lang_key(string $lang): string {
    $k = strtolower(trim($lang));
    $k = preg_replace('/[^a-z0-9_-]/', '', $k) ?? '';
    return $k !== '' ? $k : 'xx';
}

function label_cache_path(string $lang): string {
    return I18N_CACHE_DIR . '/' . label_cache_lang_key($lang) . '.json';
}

function load_label_cache(string $lang): array {
    $path = label_cache_path($lang);
    if (!is_file($path)) return [];
    $raw = @file_get_contents($path);
    if ($raw === false || trim($raw) === '') return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function save_label_cache(string $lang, array $cache): bool {
    if (!is_dir(I18N_CACHE_DIR)) @mkdir(I18N_CACHE_DIR, 0775, true);
    $path = label_cache_path($lang);
    $encoded = json_encode($cache, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) return false;
    $tmp = $path . '.tmp' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $encoded) === false) return false;
    if (!@rename($tmp, $path)) { @unlink($tmp); return false; }
    return true;
}

function label_cache_get(string $lang, string $key): ?string {
    $reg = &label_cache_registry();
    if (!array_key_exists($lang, $reg)) $reg[$lang] = load_label_cache($lang);
    return $reg[$lang][$key] ?? null;
}

function label_cache_set(string $lang, string $key, string $value): void {
    $reg = &label_cache_registry();
    if (!array_key_exists($lang, $reg)) $reg[$lang] = load_label_cache($lang);
    $reg[$lang][$key] = $value;
    save_label_cache($lang, $reg[$lang]);
}

// ===============================================================
// VERTALEN — kernfunctie, door t()/ph()/ph_defaults()/ph_role_label()/
// contract_missing_json_notice() aangeroepen zodra $lang buiten UI_LANGS
// valt. $key identificeert het label uniek binnen de cache (bv.
// "t:summary_heading", "ph_default:LAW", "ph_role:verwerker"); $enText is de
// al-opgeloste Engelse tekst die als brontekst voor DeepL dient (Engels i.p.v.
// Nederlands, omdat dat ook de bestaande fallback-taal is voor onbekende
// talen — zie lang_dict_for()/ph()/ph_defaults() in index.php).
//
// Valt terug op $enText zodra: DeepL niet geconfigureerd is, de taal niet
// door DeepL wordt herkend, de tekst leeg is, of de circuit breaker al open
// staat door een eerdere mislukking in dezelfde aanvraag. Bij een geslaagde
// vertaling wordt die meteen weggeschreven naar i18n_cache/<taal>.json, zodat
// elke volgende contractgeneratie in dezelfde taal dit label uit de cache
// krijgt — geen hernieuwde DeepL-aanroep nodig.
// ===============================================================
function translate_doc_label(string $key, string $lang, string $enText): string {
    if (trim($enText) === '') return $enText;
    if (!function_exists('deepl_enabled') || !deepl_enabled()) return $enText;
    if (!function_exists('deepl_lang_known') || !deepl_lang_known($lang)) return $enText;

    $cached = label_cache_get($lang, $key);
    if ($cached !== null && trim($cached) !== '') return $cached;

    if (label_translate_circuit_open()) return $enText;
    if (!function_exists('deepl_translate_block')) return $enText;

    $res = deepl_translate_block($enText, 'en', $lang, 'label:' . $key);
    if (!is_array($res) || empty($res['ok'])) {
        label_translate_circuit_trip();
        return $enText;
    }

    $translated = (string)($res['text'] ?? $enText);
    if (trim($translated) === '') return $enText;
    label_cache_set($lang, $key, $translated);
    return $translated;
}