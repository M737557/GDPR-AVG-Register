<?php
/**
 * translateapi.config.php
 *
 * Configuratie voor translateapi.ai (https://translateapi.ai/), de aanvullende
 * vertaalengine naast DeepL (zie deepl.config.php ernaast). DeepL blijft de
 * eerste keus voor de talen die het kent — betere kwaliteit voor juridische
 * tekst, plus formaliteit/glossaria. translateapi.ai springt automatisch bij:
 *
 *   - zodra een DeepL-aanroep mislukt (quotum op, storing, netwerkfout, ...),
 *     wordt dezelfde vertaling meteen via translateapi.ai opnieuw geprobeerd;
 *   - voor een taal die DeepL niet aanbiedt (translateapi.ai kent 180+ talen
 *     tegenover DeepL's ~30) wordt translateapi.ai rechtstreeks gebruikt.
 *
 * Er is geen wijziging in index.php nodig: contract_translate.php haalt deze
 * sleutel vanzelf op zodra dit bestand naast index.php staat.
 *
 * Alternatief en veiliger: zet TRANSLATEAPI_KEY als omgevingsvariabele
 * (Apache: SetEnv TRANSLATEAPI_KEY "..."; systemd: Environment=TRANSLATEAPI_KEY=...).
 * De omgevingsvariabele heeft voorrang op dit bestand.
 *
 * Neem translateapi.config.php NIET mee in versiebeheer.
 */

return [
    // API-sleutel, begint met "ta_".
    'key' => 'ta_a41c58adcfa7b0905d96fdd870eddf3691a4dc7c1ec944e8d7909de8',

    // Optioneel: welk vertaalmodel translateapi.ai moet gebruiken.
    // 'auto' (standaard) laat translateapi.ai zelf kiezen.
    // Opties: 'auto', 'huggingface' (Helsinki-NLP/opus-mt, snel),
    // 'madlad' (Google MADLAD-400, dekt de meeste van de 180+ talen).
    'engine' => 'auto',

    // Optioneel: afwijkende host (bedrijfsproxy of testopstelling).
    // 'host' => 'https://api.translateapi.ai/api/v1',

    // Time-out per API-verzoek in seconden.
    'timeout' => 60,
];