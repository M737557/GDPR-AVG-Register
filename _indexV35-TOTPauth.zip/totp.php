<?php
/**
 * totp.php
 * -----------------------------------------------------------------
 * Kleine, zelfstandige TOTP-implementatie (RFC 6238 / RFC 4226).
 * Geen externe dependencies — gebruikt alleen hash_hmac().
 * -----------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * ROT47: verschuift elk printable ASCII-teken (33–126) 47 posities op
 * in de tabel. Is zijn eigen inverse: rot47(rot47($s)) === $s.
 */
function totp_rot47(string $s): string {
    $out = '';
    $len = strlen($s);
    for ($i = 0; $i < $len; $i++) {
        $o = ord($s[$i]);
        $out .= ($o >= 33 && $o <= 126) ? chr(33 + (($o + 14) % 94)) : $s[$i];
    }
    return $out;
}

/** Haalt de echte (terug-geroteerde) TOTP-secret op uit configmain.php. */
function totp_get_secret(): string {
    if (!defined('TOTP_SECRET_ROT47')) {
        throw new RuntimeException('TOTP_SECRET_ROT47 is niet gedefinieerd — is configmain.php geladen?');
    }
    return totp_rot47(TOTP_SECRET_ROT47);
}

/** Genereert een nieuwe willekeurige Base32-secret (voor eenmalige setup). */
function totp_generate_secret(int $bytes = 20): string {
    return totp_base32_encode(random_bytes($bytes));
}

function totp_base32_encode(string $data): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($data) as $char) {
        $bits .= str_pad(decbin(ord($char)), 8, '0', STR_PAD_LEFT);
    }
    $output = '';
    foreach (str_split($bits, 5) as $chunk) {
        if (strlen($chunk) < 5) {
            $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
        }
        $output .= $alphabet[bindec($chunk)];
    }
    return $output;
}

function totp_base32_decode(string $secret): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = strtoupper(preg_replace('/[^A-Z2-7]/i', '', $secret));
    $bits = '';
    foreach (str_split($secret) as $char) {
        $pos = strpos($alphabet, $char);
        if ($pos === false) continue;
        $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    foreach (str_split($bits, 8) as $chunk) {
        if (strlen($chunk) < 8) break; // restbits negeren
        $bytes .= chr(bindec($chunk));
    }
    return $bytes;
}

/** Berekent de 6-cijferige TOTP-code voor een gegeven tijdstap (RFC 6238). */
function totp_code_at(string $base32Secret, int $timeStep, int $period = 30, int $digits = 6): string {
    $key = totp_base32_decode($base32Secret);
    $counter = intdiv($timeStep, $period);
    $binCounter = pack('N*', 0) . pack('N*', $counter); // 8 bytes, big-endian

    $hash = hash_hmac('sha1', $binCounter, $key, true);
    $offset = ord($hash[strlen($hash) - 1]) & 0x0F;

    $part = ((ord($hash[$offset]) & 0x7F) << 24)
        | ((ord($hash[$offset + 1]) & 0xFF) << 16)
        | ((ord($hash[$offset + 2]) & 0xFF) << 8)
        | (ord($hash[$offset + 3]) & 0xFF);

    $code = $part % (10 ** $digits);
    return str_pad((string)$code, $digits, '0', STR_PAD_LEFT);
}

/**
 * Verifieert een door de gebruiker ingevoerde code tegen de huidige tijd,
 * met een tolerantie van $window stappen vóór/na (kloktolerantie).
 * Gebruikt hash_equals() om timing-aanvallen te bemoeilijken.
 */
function totp_verify(string $base32Secret, string $userCode, int $window = 1, int $period = 30): bool {
    $userCode = trim($userCode);
    if (!preg_match('/^\d{6}$/', $userCode)) {
        return false;
    }
    $now = time();
    for ($i = -$window; $i <= $window; $i++) {
        $candidate = totp_code_at($base32Secret, $now + ($i * $period), $period);
        if (hash_equals($candidate, $userCode)) {
            return true;
        }
    }
    return false;
}

/** Bouwt een otpauth:// URI, te gebruiken om een QR-setupcode van te maken. */
function totp_provisioning_uri(string $base32Secret, string $issuer, string $account): string {
    $label = rawurlencode($issuer . ':' . $account);
    $params = http_build_query([
        'secret' => $base32Secret,
        'issuer' => $issuer,
        'algorithm' => 'SHA1',
        'digits' => 6,
        'period' => 30,
    ]);
    return "otpauth://totp/{$label}?{$params}";
}