<?php
/**
 * configmain.php
 * -----------------------------------------------------------------
 * Centrale configuratie voor TOTP-authenticatie (2FA login-scherm
 * vóór toegang tot index.php).
 *
 * De secret key hieronder staat NIET in leesbare vorm in de config-
 * variabele — hij is ROT47-geroteerd opgeslagen. ROT47 is GEEN
 * encryptie (het is met de hand in enkele seconden om te draaien),
 * dus dit biedt geen echte beveiliging tegen iemand die deze file
 * kan lezen. Het voorkomt alleen dat de secret er bij een vluchtige
 * blik / grep op "secret" / per ongeluk in een screenshot direct
 * leesbaar bij staat.
 *
 * -----------------------------------------------------------------
 * NOTITIE (leesbaar, voor jezelf — verwijder deze notitie als je
 * dat liever niet in deze file hebt staan):
 *
 *   De echte (niet-geroteerde) TOTP-secret is:
 *
 *       2U3PCB3E2YI2S6O5IVDC4GFNUJ3HU4RF
 *
 *   Dit is de string die je invoert in een authenticator-app
 *   (Google Authenticator, Microsoft Authenticator, Aegis, 1Password,
 *   enz.) als je "handmatige invoer" / "enter setup key" kiest, of
 *   die gebruikt wordt om de QR-code hieronder te genereren.
 *
 *   Wil je een NIEUWE secret? Genereer die met bv.:
 *     php -r "echo rtrim(base64_encode(random_bytes(20)),'=')...;"
 *   of gebruik totp.php::totp_generate_secret(), en vervang dan
 *   zowel deze notitie als de ROT47-waarde in TOTP_SECRET_ROT47
 *   hieronder (gebruik totp_rot47() om 'm te roteren).
 * -----------------------------------------------------------------
 */

declare(strict_types=1);

// De TOTP-secret, ROT47-geroteerd. Wordt in totp.php terug-geroteerd
// met totp_rot47() (ROT47 is zijn eigen inverse — hetzelfde toepassen
// draait 'm weer terug).
const TOTP_SECRET_ROT47 = "a&b!rqbta*xa\$e~dx'srcvu}&ybw&c#u";

// Naam die in de authenticator-app verschijnt, bv. "Bedrijf (gebruiker)".
const TOTP_ISSUER  = 'Contractregister';
const TOTP_ACCOUNT = 'admin';

// Aantal TOTP-tijdstappen (van 30s) vóór/na de huidige die nog als
// geldig geaccepteerd worden — vangt kleine kloktolerantie op.
const TOTP_WINDOW = 1;

// Sessie-sleutel waarmee onthouden wordt dat iemand is ingelogd.
const TOTP_SESSION_KEY = 'totp_authenticated';

// Max. aantal mislukte pogingen binnen TOTP_LOCKOUT_SECONDS voordat
// er tijdelijk geblokkeerd wordt (basale bruteforce-remming).
const TOTP_MAX_ATTEMPTS     = 5;
const TOTP_LOCKOUT_SECONDS  = 300;

// Sessie verloopt automatisch na dit aantal seconden zonder activiteit
// (standaard: 
const TOTP_SESSION_TIMEOUT = 100000000;

// Sessie-sleutel waarin het tijdstip van de laatste activiteit staat,
// gebruikt om TOTP_SESSION_TIMEOUT af te dwingen.
const TOTP_LAST_ACTIVITY_KEY = 'totp_last_activity';