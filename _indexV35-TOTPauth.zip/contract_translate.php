<?php
/**
 * contract_translate.php — automatische vertaling van contract-JSON via DeepL,
 * aangevuld met translateapi.ai, Lingvanex en Microsoft Translator.
 *
 * Drop-in module voor index.php (contractregister). Vertaalt per artikel de
 * velden title/body van een brontaal naar één of meer doeltalen en schrijft het
 * resultaat terug in contracts/<key>.json, in exact hetzelfde schema
 * (contractregister/contract/v1) dat render_contract_from_definition() leest.
 *
 * VIER VERTAALENGINES, SAMEN INGEZET
 * ---------------------------------------------------------------
 * DeepL blijft de eerste keus voor de talen die het kent: betere kwaliteit
 * voor juridische tekst, plus formaliteit/glossaria. translateapi.ai
 * (https://translateapi.ai/), Lingvanex (https://lingvanex.com/) en Microsoft
 * Translator (Azure AI services) zijn de aanvulling, in die volgorde — samen
 * de terugval-ketting:
 *   - Voor een taal die DeepL WEL kent, maar waarbij de DeepL-aanroep
 *     mislukt (quotum op, storing, netwerkfout, ...): automatische terugval
 *     op translateapi.ai voor diezelfde batch; mislukt dát ook (of is het
 *     niet geconfigureerd), dan Lingvanex; mislukt ook dát (of niet
 *     geconfigureerd), dan ten slotte Microsoft Translator.
 *   - Voor een taal die DeepL NIET kent: rechtstreeks translateapi.ai, met
 *     Lingvanex en daarna Microsoft Translator als terugval zodra die talen
 *     ook daar niet lukken of niet bekend zijn.
 *   - Voor een taal die alleen Microsoft Translator (of alleen Lingvanex)
 *     kent: rechtstreeks die engine.
 * Alle bestaande aanroepers (label_translate.php, presets.php,
 * pdf_translate.php) blijven ongewijzigd werken: zij roepen nog steeds
 * deepl_enabled() / deepl_lang_known() / deepl_languages() /
 * deepl_translate_block() aan. Die functies zijn hieronder "engine-neutraal"
 * gemaakt — welke engine daadwerkelijk vertaalt, wordt intern beslist door
 * mt_translate_batch(). Er is dus GEEN wijziging nodig in index.php of in de
 * andere drop-in modules.
 *
 * Microsoft Translator heeft op het moment van schrijven nog GEEN sleutel:
 * zie microsoft.config.php. Zolang die leeg is (en geen omgevingsvariabele
 * gezet is), doet deze engine gewoon niet mee — precies zoals bij elke andere
 * engine zonder sleutel. Zodra de sleutel later wordt ingevuld werkt alles
 * hieronder automatisch mee, zonder verdere codewijziging.
 *
 * FOUTLOGGING
 * ---------------------------------------------------------------
 * Elke mislukte vertaalpoging — van elke engine, voor elke taal, ook als een
 * volgende engine in de ketting het daarna wél overneemt — wordt weggeschreven
 * naar translate_error.log naast dit bestand (zie translate_log_error()
 * hieronder). Zo blijft een stille terugval (bv. DeepL faalt, translateapi.ai
 * springt bij) zichtbaar in plaats van onopgemerkt.
 *
 * Uitgangspunten (ongewijzigd):
 *  - {{PLACEHOLDER}}-tokens worden NOOIT vertaald.
 *  - Regelstructuur blijft 1-op-1 behouden: elke regel wordt apart vertaald en
 *    in dezelfde volgorde teruggezet, inclusief lege regels en inspringing.
 *  - Handmatig geschreven vertalingen worden niet overschreven, tenzij expliciet
 *    aangevinkt. Machinevertalingen (van alle vier de engines) krijgen een
 *    _mt-stempel met een hash van de brontekst, zodat alleen écht gewijzigde
 *    artikelen opnieuw vertaald worden.
 *  - Beschermde contracten (safeguard_scc) worden geweigerd — kloon eerst.
 *  - Elke schrijfactie maakt eerst een back-up in contracts/.backup/.
 *
 * Installatie: zie INSTALL.md (3 kleine wijzigingen in index.php). Voor
 * translateapi.ai, Lingvanex en Microsoft Translator is geen extra wijziging
 * in index.php nodig — alleen een sleutel via TRANSLATEAPI_KEY/
 * translateapi.config.php resp. LINGVANEX_API_KEY/lingvanex.config.php resp.
 * MICROSOFT_TRANSLATOR_KEY/microsoft.config.php (zie die bestanden).
 */

declare(strict_types=1);

// ===============================================================
// CONFIGURATIE — DeepL
// ---------------------------------------------------------------
// API-sleutel, in volgorde van voorkeur:
//   1. omgevingsvariabele DEEPL_API_KEY (aanbevolen: SetEnv / systemd)
//   2. deepl.config.php naast index.php, met: <?php return ['key' => '...'];
// Een gratis sleutel eindigt op ":fx" en gebruikt automatisch api-free.deepl.com.
// ===============================================================

function deepl_config(): array {
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    $file = [];
    $path = __DIR__ . '/deepl.config.php';
    if (is_file($path)) {
        $loaded = @include $path;
        if (is_array($loaded)) $file = $loaded;
    }

    $key = (string)(getenv('DEEPL_API_KEY') ?: ($_SERVER['DEEPL_API_KEY'] ?? ($file['key'] ?? '')));
    $key = trim($key);

    $cfg = [
        'key'        => $key,
        // Gratis sleutels eindigen op ":fx" en horen bij api-free.deepl.com.
        // Een eigen host (proxy, testopstelling) kan in deepl.config.php.
        'host'       => (string)($file['host'] ?? (str_ends_with($key, ':fx') ? 'https://api-free.deepl.com' : 'https://api.deepl.com')),
        'formality'  => (string)($file['formality'] ?? 'prefer_more'), // juridische tekst: formeel
        'glossaries' => is_array($file['glossaries'] ?? null) ? $file['glossaries'] : [], // "en:nl" => glossary_id
        'timeout'    => (int)($file['timeout'] ?? 60),
        'model_type' => (string)($file['model_type'] ?? ''), // bv. 'prefer_quality_optimized' (Pro)
    ];
    return $cfg;
}

// DeepL specifiek "is er een DeepL-sleutel" — gebruikt door mt_translate_batch()
// om te beslissen of DeepL geprobeerd mag worden. Het publieke deepl_enabled()
// verderop betekent voortaan "is er MINSTENS ÉÉN vertaalengine geconfigureerd"
// (DeepL, translateapi.ai, Lingvanex of Microsoft Translator), zodat alle
// bestaande aanroepers (label_translate.php, presets.php, pdf_translate.php,
// index.php) vanzelf blijven werken zodra er bijvoorbeeld alleen een
// Lingvanex- of Microsoft-sleutel staat.
function deepl_key_enabled(): bool {
    $c = deepl_config();
    return $c['key'] !== '' && extension_loaded('curl');
}

function deepl_enabled(): bool {
    return deepl_key_enabled() || translateapi_enabled() || lingvanex_enabled() || microsoft_enabled();
}

// ===============================================================
// CONFIGURATIE — translateapi.ai
// ---------------------------------------------------------------
// API-sleutel, in volgorde van voorkeur:
//   1. omgevingsvariabele TRANSLATEAPI_KEY
//   2. translateapi.config.php naast index.php, met: <?php return ['key' => 'ta_...'];
// Sleutels beginnen met "ta_". Zie https://translateapi.ai/api/ voor de API.
// ===============================================================
function translateapi_config(): array {
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    $file = [];
    $path = __DIR__ . '/translateapi.config.php';
    if (is_file($path)) {
        $loaded = @include $path;
        if (is_array($loaded)) $file = $loaded;
    }

    $key = (string)(getenv('TRANSLATEAPI_KEY') ?: ($_SERVER['TRANSLATEAPI_KEY'] ?? ($file['key'] ?? '')));
    $key = trim($key);

    $cfg = [
        'key'     => $key,
        'host'    => rtrim((string)($file['host'] ?? 'https://api.translateapi.ai/api/v1'), '/'),
        'timeout' => (int)($file['timeout'] ?? 60),
        // 'auto' laat translateapi.ai zelf het model kiezen. Andere opties:
        // 'huggingface' (Helsinki-NLP/opus-mt, snel) of 'madlad' (Google
        // MADLAD-400, dekt de meeste van de 180+ talen).
        'engine'  => (string)($file['engine'] ?? 'auto'),
    ];
    return $cfg;
}

function translateapi_enabled(): bool {
    $c = translateapi_config();
    return $c['key'] !== '' && extension_loaded('curl');
}

// ===============================================================
// CONFIGURATIE — Lingvanex
// ---------------------------------------------------------------
// API-sleutel, in volgorde van voorkeur:
//   1. omgevingsvariabele LINGVANEX_API_KEY
//   2. lingvanex.config.php naast index.php, met: <?php return ['key' => 'a_...'];
// Lingvanex (https://lingvanex.com/) is de TWEEDE terugval, ná translateapi.ai:
//   - zodra zowel DeepL als (indien geconfigureerd) translateapi.ai een
//     vertaling niet konden leveren, wordt dezelfde batch nog één keer via
//     Lingvanex geprobeerd, vóórdat de vertaling daadwerkelijk als mislukt
//     wordt beschouwd;
//   - voor een taal die noch DeepL noch translateapi.ai kent, maar die
//     Lingvanex wel aanbiedt, wordt Lingvanex rechtstreeks gebruikt.
// Net als bij translateapi.ai is hiervoor GEEN wijziging in index.php nodig:
// dit bestand haalt de sleutel vanzelf op zodra lingvanex.config.php naast
// index.php staat (of de omgevingsvariabele gezet is).
// ===============================================================
function lingvanex_config(): array {
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    $file = [];
    $path = __DIR__ . '/lingvanex.config.php';
    if (is_file($path)) {
        $loaded = @include $path;
        if (is_array($loaded)) $file = $loaded;
    }

    $key = (string)(getenv('LINGVANEX_API_KEY') ?: ($_SERVER['LINGVANEX_API_KEY'] ?? ($file['key'] ?? '')));
    $key = trim($key);

    $cfg = [
        'key'     => $key,
        'host'    => rtrim((string)($file['host'] ?? 'https://api-b2b.backenster.com'), '/'),
        'timeout' => (int)($file['timeout'] ?? 60),
    ];
    return $cfg;
}

function lingvanex_enabled(): bool {
    $c = lingvanex_config();
    return $c['key'] !== '' && extension_loaded('curl');
}

// ===============================================================
// CONFIGURATIE — Microsoft Translator (Azure AI Translator)
// ---------------------------------------------------------------
// API-sleutel, in volgorde van voorkeur:
//   1. omgevingsvariabele MICROSOFT_TRANSLATOR_KEY (en, indien nodig,
//      MICROSOFT_TRANSLATOR_REGION)
//   2. microsoft.config.php naast index.php, met:
//      <?php return ['key' => '...', 'region' => '...'];
// Microsoft Translator is de DERDE terugval, ná translateapi.ai en Lingvanex:
//   - zodra DeepL, translateapi.ai én Lingvanex een vertaling geen van drie
//     konden leveren, wordt dezelfde batch nog één keer via Microsoft
//     Translator geprobeerd, vóórdat de vertaling daadwerkelijk als mislukt
//     wordt beschouwd;
//   - voor een taal die geen van de andere drie kent, maar die Microsoft
//     Translator wel aanbiedt, wordt Microsoft Translator rechtstreeks
//     gebruikt.
// 'region' is alleen nodig bij een REGIONALE of "multi-service" Cognitive
// Services-resource — bij een globale, alleen-Translator-resource blijft dat
// veld leeg. Er is nu nog GEEN sleutel ingevuld (zie microsoft.config.php):
// zolang dat zo is, blijft microsoft_enabled() false en doet deze engine
// niets mee in de terugval-ketting — precies zoals bij de andere engines
// wanneer hun sleutel ontbreekt. Zodra de sleutel later wordt ingevuld (in
// microsoft.config.php of via de omgevingsvariabele) werkt de rest van deze
// module automatisch mee, zonder verdere wijzigingen.
// ===============================================================
function microsoft_config(): array {
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    $file = [];
    $path = __DIR__ . '/microsoft.config.php';
    if (is_file($path)) {
        $loaded = @include $path;
        if (is_array($loaded)) $file = $loaded;
    }

    $key = (string)(getenv('MICROSOFT_TRANSLATOR_KEY') ?: ($_SERVER['MICROSOFT_TRANSLATOR_KEY'] ?? ($file['key'] ?? '')));
    $key = trim($key);
    $region = (string)(getenv('MICROSOFT_TRANSLATOR_REGION') ?: ($_SERVER['MICROSOFT_TRANSLATOR_REGION'] ?? ($file['region'] ?? '')));

    $cfg = [
        'key'     => $key,
        'region'  => trim($region),
        'host'    => rtrim((string)($file['host'] ?? 'https://api.cognitive.microsofttranslator.com'), '/'),
        'timeout' => (int)($file['timeout'] ?? 60),
    ];
    return $cfg;
}

function microsoft_enabled(): bool {
    $c = microsoft_config();
    return $c['key'] !== '' && extension_loaded('curl');
}

// ===============================================================
// FOUTLOGGING — vertaalproblemen voor ALLE talen
// ---------------------------------------------------------------
// Elke mislukte aanroep van een vertaalengine (DeepL, translateapi.ai of
// Lingvanex), voor elke taal, wordt hier weggeschreven naar
// translate_error.log naast dit bestand — ook wanneer de volgende engine in
// de terugval-ketting het daarna alsnog overneemt. Zonder deze log zou zo'n
// tussentijdse mislukking (bv. DeepL-quotum op, translateapi.ai springt bij)
// onopgemerkt blijven, terwijl het wel degelijk een signaal is dat er iets
// mis is met één van de geconfigureerde engines.
//
// $context is een vrije, korte aanduiding van de aanroeper (bv.
// "contract:mijncontract/article:art1/title", "label:t:summary_heading",
// "pdf-export:purpose", "preset:processing/purpose") — optioneel, altijd
// veilig leeg te laten. Elke regel is één mislukte poging.
// ===============================================================
define('TRANSLATE_ERROR_LOG', __DIR__ . '/translate_error.log');

function translate_log_error(string $srcLang, string $tgtLang, string $engine, string $message, string $context = ''): void {
    $src = strtoupper(trim($srcLang)) !== '' ? strtoupper(trim($srcLang)) : '?';
    $tgt = strtoupper(trim($tgtLang)) !== '' ? strtoupper(trim($tgtLang)) : '?';
    $line = sprintf(
        '[%s] lang=%s->%s engine=%s%s message=%s',
        date('c'),
        $src,
        $tgt,
        $engine !== '' ? $engine : 'unknown',
        $context !== '' ? ' context=' . $context : '',
        str_replace(["\r", "\n"], ' ', trim($message))
    );
    @file_put_contents(TRANSLATE_ERROR_LOG, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
}

// ===============================================================
// TAALCODES
// ---------------------------------------------------------------
// Interne contracttaalcode => brontaal/doeltaalcode per engine. DeepL eist
// een variant voor EN, PT en ZH als doeltaal; als brontaal juist de basiscode.
// deepl_languages() is de "gecombineerde" lijst die de rest van de tool
// gebruikt: eerst alle DeepL-talen (engine=deepl), aangevuld met de extra
// talen die alleen translateapi.ai kent (engine=translateapi) en die niet al
// in de DeepL-lijst voorkomen. Zo blijven bestaande aanroepers (die simpelweg
// "elke bekende taal" opvragen) vanzelf ook de nieuwe talen zien.
// ===============================================================
function deepl_native_languages(): array {
    return [
        'en'    => ['src' => 'EN', 'tgt' => 'EN-GB', 'label' => 'English (UK)'],
        'en_us' => ['src' => 'EN', 'tgt' => 'EN-US', 'label' => 'English (US)'],
        'nl'    => ['src' => 'NL', 'tgt' => 'NL',    'label' => 'Nederlands'],
        'de'    => ['src' => 'DE', 'tgt' => 'DE',    'label' => 'Deutsch'],
        'fr'    => ['src' => 'FR', 'tgt' => 'FR',    'label' => 'Français'],
        'es'    => ['src' => 'ES', 'tgt' => 'ES',    'label' => 'Español'],
        'it'    => ['src' => 'IT', 'tgt' => 'IT',    'label' => 'Italiano'],
        'pt'    => ['src' => 'PT', 'tgt' => 'PT-PT', 'label' => 'Português (PT)'],
        'pt_br' => ['src' => 'PT', 'tgt' => 'PT-BR', 'label' => 'Português (BR)'],
        'pl'    => ['src' => 'PL', 'tgt' => 'PL',    'label' => 'Polski'],
        'da'    => ['src' => 'DA', 'tgt' => 'DA',    'label' => 'Dansk'],
        'sv'    => ['src' => 'SV', 'tgt' => 'SV',    'label' => 'Svenska'],
        'fi'    => ['src' => 'FI', 'tgt' => 'FI',    'label' => 'Suomi'],
        'nb'    => ['src' => 'NB', 'tgt' => 'NB',    'label' => 'Norsk bokmål', 'ta' => 'no'],
        'cs'    => ['src' => 'CS', 'tgt' => 'CS',    'label' => 'Čeština'],
        'sk'    => ['src' => 'SK', 'tgt' => 'SK',    'label' => 'Slovenčina'],
        'sl'    => ['src' => 'SL', 'tgt' => 'SL',    'label' => 'Slovenščina'],
        'hu'    => ['src' => 'HU', 'tgt' => 'HU',    'label' => 'Magyar'],
        'ro'    => ['src' => 'RO', 'tgt' => 'RO',    'label' => 'Română'],
        'bg'    => ['src' => 'BG', 'tgt' => 'BG',    'label' => 'Български'],
        'el'    => ['src' => 'EL', 'tgt' => 'EL',    'label' => 'Ελληνικά'],
        'et'    => ['src' => 'ET', 'tgt' => 'ET',    'label' => 'Eesti'],
        'lv'    => ['src' => 'LV', 'tgt' => 'LV',    'label' => 'Latviešu'],
        'lt'    => ['src' => 'LT', 'tgt' => 'LT',    'label' => 'Lietuvių'],
        'tr'    => ['src' => 'TR', 'tgt' => 'TR',    'label' => 'Türkçe'],
        'id'    => ['src' => 'ID', 'tgt' => 'ID',    'label' => 'Bahasa Indonesia'],
        'uk'    => ['src' => 'UK', 'tgt' => 'UK',    'label' => 'Українська'],
        'ru'    => ['src' => 'RU', 'tgt' => 'RU',    'label' => 'Русский'],
        'ja'    => ['src' => 'JA', 'tgt' => 'JA',    'label' => '日本語'],
        'ko'    => ['src' => 'KO', 'tgt' => 'KO',    'label' => '한국어'],
        'zh'    => ['src' => 'ZH', 'tgt' => 'ZH-HANS','label' => '中文 (简体)'],
        'ar'    => ['src' => 'AR', 'tgt' => 'AR',    'label' => 'العربية'],
    ];
}

// Kleine, ingebouwde reservelijst voor talen die translateapi.ai aanbiedt maar
// DeepL niet — gebruikt zodra de live taalopvraging (translateapi_fetch_languages())
// niet lukt (geen sleutel, offline, API-wijziging) én er nog geen cachebestand
// bestaat. Dit is bewust een selectie van veelgevraagde talen, niet de
// volledige 180+ die translateapi.ai kent; zodra de live opvraging wél lukt,
// wordt die (grotere, actuele) lijst gebruikt en gecachet.
function translateapi_fallback_languages(): array {
    $names = [
        'af' => 'Afrikaans', 'sq' => 'Shqip', 'am' => 'አማርኛ', 'hy' => 'Հայերեն',
        'az' => 'Azərbaycan', 'eu' => 'Euskara', 'be' => 'Беларуская', 'bn' => 'বাংলা',
        'bs' => 'Bosanski', 'ca' => 'Català', 'ceb' => 'Cebuano', 'ny' => 'Chichewa',
        'co' => 'Corsu', 'hr' => 'Hrvatski', 'eo' => 'Esperanto', 'tl' => 'Filipino',
        'gl' => 'Galego', 'ka' => 'ქართული', 'gu' => 'ગુજરાતી', 'ht' => 'Kreyòl Ayisyen',
        'ha' => 'Hausa', 'haw' => 'ʻŌlelo Hawaiʻi', 'he' => 'עברית', 'hi' => 'हिन्दी',
        'hmn' => 'Hmoob', 'is' => 'Íslenska', 'ig' => 'Igbo', 'ga' => 'Gaeilge',
        'jw' => 'Basa Jawa', 'kn' => 'ಕನ್ನಡ', 'kk' => 'Қазақ', 'km' => 'ខ្មែរ',
        'rw' => 'Kinyarwanda', 'ku' => 'Kurdî', 'ky' => 'Кыргызча', 'lo' => 'ລາວ',
        'la' => 'Latina', 'lb' => 'Lëtzebuergesch', 'mk' => 'Македонски', 'mg' => 'Malagasy',
        'ms' => 'Bahasa Melayu', 'ml' => 'മലയാളം', 'mt' => 'Malti', 'mi' => 'Māori',
        'mr' => 'मराठी', 'mn' => 'Монгол', 'my' => 'မြန်မာ', 'ne' => 'नेपाली',
        'no' => 'Norsk', 'or' => 'ଓଡ଼ିଆ', 'ps' => 'پښتو', 'fa' => 'فارسی',
        'pa' => 'ਪੰਜਾਬੀ', 'sm' => 'Gagana Sāmoa', 'gd' => 'Gàidhlig', 'sr' => 'Српски',
        'st' => 'Sesotho', 'sn' => 'ChiShona', 'sd' => 'سنڌي', 'si' => 'සිංහල',
        'so' => 'Soomaali', 'su' => 'Basa Sunda', 'sw' => 'Kiswahili', 'tg' => 'Тоҷикӣ',
        'ta' => 'தமிழ்', 'tt' => 'Татар', 'te' => 'తెలుగు', 'th' => 'ไทย',
        'tk' => 'Türkmen', 'ur' => 'اردو', 'ug' => 'ئۇيغۇرچە', 'uz' => 'Oʻzbek',
        'vi' => 'Tiếng Việt', 'cy' => 'Cymraeg', 'xh' => 'isiXhosa', 'yi' => 'ייִדיש',
        'yo' => 'Yorùbá', 'zu' => 'isiZulu',
    ];
    $out = [];
    foreach ($names as $code => $label) {
        $out[$code] = ['src' => strtoupper($code), 'tgt' => $code, 'label' => $label];
    }
    return $out;
}

define('TRANSLATEAPI_LANG_CACHE_FILE', __DIR__ . '/i18n_cache/_translateapi_languages.json');

function translateapi_read_lang_cache(): ?array {
    if (!is_file(TRANSLATEAPI_LANG_CACHE_FILE)) return null;
    $raw = @file_get_contents(TRANSLATEAPI_LANG_CACHE_FILE);
    if ($raw === false || trim($raw) === '') return null;
    $data = json_decode($raw, true);
    return (is_array($data) && $data !== []) ? $data : null;
}

function translateapi_write_lang_cache(array $langs): void {
    $dir = dirname(TRANSLATEAPI_LANG_CACHE_FILE);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $encoded = json_encode($langs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) return;
    $tmp = TRANSLATEAPI_LANG_CACHE_FILE . '.tmp' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $encoded) === false) return;
    @rename($tmp, TRANSLATEAPI_LANG_CACHE_FILE);
}

// Haalt de actuele talenlijst op bij translateapi.ai (GET /translate/languages/).
// De precieze vorm van dat antwoord staat niet vast gedocumenteerd, dus dit
// leest een paar gangbare vormen (lijst van objecten met code/name, of een
// object van code => naam). Geeft null terug bij twijfel, zodat de aanroeper
// op de cache of de ingebouwde reservelijst terugvalt i.p.v. een kapotte
// talenlijst te tonen.
function translateapi_fetch_languages(): ?array {
    $res = translateapi_http('/translate/languages/', [], 'GET');
    if (!$res['ok']) return null;

    $data = $res['data'];
    $list = $data['languages'] ?? $data['results'] ?? $data['data'] ?? $data;
    if (!is_array($list)) return null;

    $out = [];
    foreach ($list as $k => $v) {
        $code = '';
        $name = '';
        if (is_array($v)) {
            $code = (string)($v['code'] ?? $v['language_code'] ?? $v['iso'] ?? (is_string($k) ? $k : ''));
            $name = (string)($v['name'] ?? $v['label'] ?? $v['language'] ?? '');
        } elseif (is_string($v) && is_string($k)) {
            $code = $k;
            $name = $v;
        } elseif (is_string($v)) {
            $code = $v;
        } else {
            continue;
        }
        $code = strtolower((string)preg_replace('/[^a-zA-Z-]/', '', $code));
        $code = explode('-', $code)[0]; // "zh-cn" e.d. -> basiscode
        if ($code === '' || strlen($code) > 3) continue;
        if ($name === '') $name = strtoupper($code);
        $out[$code] = ['src' => strtoupper($code), 'tgt' => $code, 'label' => $name];
    }
    return $out === [] ? null : $out;
}

function translateapi_languages(): array {
    static $langs = null;
    if ($langs !== null) return $langs;
    if (!translateapi_enabled()) return $langs = [];

    $fetched = translateapi_fetch_languages();
    if ($fetched !== null) {
        translateapi_write_lang_cache($fetched);
        return $langs = $fetched;
    }
    $cached = translateapi_read_lang_cache();
    if ($cached !== null) return $langs = $cached;

    return $langs = translateapi_fallback_languages();
}

// Kleine, ingebouwde reservelijst voor talen die Lingvanex aanbiedt, gebruikt
// zodra de live taalopvraging (lingvanex_fetch_languages()) niet lukt (geen
// sleutel, offline, API-wijziging) én er nog geen cachebestand bestaat.
// Lingvanex werkt intern met taal+regiocodes (bv. "nl_NL", "en_GB") — die
// staan hier onder 'lv' zodat lingvanex_lang_code()/lingvanex_full_code_map()
// ze kunnen hergebruiken; de gewone tweeletterige code blijft de sleutel
// waarmee de rest van de tool (net als bij DeepL/translateapi.ai) werkt.
function lingvanex_fallback_languages(): array {
    $names = [
        'af' => ['af_ZA', 'Afrikaans'], 'sq' => ['sq_AL', 'Shqip'], 'am' => ['am_ET', 'አማርኛ'],
        'hy' => ['hy_AM', 'Հայերեն'], 'az' => ['az_AZ', 'Azərbaycan'], 'eu' => ['eu_ES', 'Euskara'],
        'be' => ['be_BY', 'Беларуская'], 'bn' => ['bn_BD', 'বাংলা'], 'bs' => ['bs_BA', 'Bosanski'],
        'ca' => ['ca_ES', 'Català'], 'hr' => ['hr_HR', 'Hrvatski'], 'eo' => ['eo_EO', 'Esperanto'],
        'gl' => ['gl_ES', 'Galego'], 'ka' => ['ka_GE', 'ქართული'], 'gu' => ['gu_IN', 'ગુજરાતી'],
        'ht' => ['ht_HT', 'Kreyòl Ayisyen'], 'ha' => ['ha_NG', 'Hausa'], 'he' => ['he_IL', 'עברית'],
        'hi' => ['hi_IN', 'हिन्दी'], 'is' => ['is_IS', 'Íslenska'], 'ig' => ['ig_NG', 'Igbo'],
        'ga' => ['ga_IE', 'Gaeilge'], 'kn' => ['kn_IN', 'ಕನ್ನಡ'], 'kk' => ['kk_KZ', 'Қазақ'],
        'km' => ['km_KH', 'ខ្មែរ'], 'rw' => ['rw_RW', 'Kinyarwanda'], 'ku' => ['ku_TR', 'Kurdî'],
        'ky' => ['ky_KG', 'Кыргызча'], 'lo' => ['lo_LA', 'ລາວ'], 'la' => ['la_VA', 'Latina'],
        'lb' => ['lb_LU', 'Lëtzebuergesch'], 'mk' => ['mk_MK', 'Македонски'], 'mg' => ['mg_MG', 'Malagasy'],
        'ms' => ['ms_MY', 'Bahasa Melayu'], 'ml' => ['ml_IN', 'മലയാളം'], 'mt' => ['mt_MT', 'Malti'],
        'mi' => ['mi_NZ', 'Māori'], 'mr' => ['mr_IN', 'मराठी'], 'mn' => ['mn_MN', 'Монгол'],
        'my' => ['my_MM', 'မြန်မာ'], 'ne' => ['ne_NP', 'नेपाली'], 'no' => ['nb_NO', 'Norsk'],
        'or' => ['or_IN', 'ଓଡ଼ିଆ'], 'ps' => ['ps_AF', 'پښتو'], 'fa' => ['fa_IR', 'فارسی'],
        'pa' => ['pa_IN', 'ਪੰਜਾਬੀ'], 'sm' => ['sm_WS', 'Gagana Sāmoa'], 'gd' => ['gd_GB', 'Gàidhlig'],
        'sr' => ['sr_RS', 'Српски'], 'st' => ['st_LS', 'Sesotho'], 'sn' => ['sn_ZW', 'ChiShona'],
        'sd' => ['sd_PK', 'سنڌي'], 'si' => ['si_LK', 'සිංහල'], 'so' => ['so_SO', 'Soomaali'],
        'su' => ['su_ID', 'Basa Sunda'], 'sw' => ['sw_KE', 'Kiswahili'], 'tg' => ['tg_TJ', 'Тоҷикӣ'],
        'ta' => ['ta_IN', 'தமிழ்'], 'tt' => ['tt_RU', 'Татар'], 'te' => ['te_IN', 'తెలుగు'],
        'th' => ['th_TH', 'ไทย'], 'tk' => ['tk_TM', 'Türkmen'], 'ur' => ['ur_PK', 'اردو'],
        'ug' => ['ug_CN', 'ئۇيغۇرچە'], 'uz' => ['uz_UZ', 'Oʻzbek'], 'vi' => ['vi_VN', 'Tiếng Việt'],
        'cy' => ['cy_GB', 'Cymraeg'], 'xh' => ['xh_ZA', 'isiXhosa'], 'yi' => ['yi_YI', 'ייִדיש'],
        'yo' => ['yo_NG', 'Yorùbá'], 'zu' => ['zu_ZA', 'isiZulu'],
    ];
    $out = [];
    foreach ($names as $code => $pair) {
        [$full, $label] = $pair;
        $out[$code] = ['src' => $code, 'tgt' => $code, 'label' => $label, 'lv' => $full];
    }
    return $out;
}

define('LINGVANEX_LANG_CACHE_FILE', __DIR__ . '/i18n_cache/_lingvanex_languages.json');

function lingvanex_read_lang_cache(): ?array {
    if (!is_file(LINGVANEX_LANG_CACHE_FILE)) return null;
    $raw = @file_get_contents(LINGVANEX_LANG_CACHE_FILE);
    if ($raw === false || trim($raw) === '') return null;
    $data = json_decode($raw, true);
    return (is_array($data) && $data !== []) ? $data : null;
}

function lingvanex_write_lang_cache(array $langs): void {
    $dir = dirname(LINGVANEX_LANG_CACHE_FILE);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $encoded = json_encode($langs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) return;
    $tmp = LINGVANEX_LANG_CACHE_FILE . '.tmp' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $encoded) === false) return;
    @rename($tmp, LINGVANEX_LANG_CACHE_FILE);
}

// Haalt de actuele talenlijst op bij Lingvanex (GET /b1/api/v3/getLanguages).
// Elk element heeft "full_code" (bv. "nl_NL") en "englishName". De taal wordt
// hier teruggebracht tot de basiscode vóór het underscore-deel ("nl_NL" ->
// "nl"), met de volledige code bewaard onder 'lv' zodat lingvanex_lang_code()
// die er weer bij kan pakken — Lingvanex accepteert geen kale taalcode zonder
// regio. Bij meerdere regiovarianten van dezelfde taal wint de eerste die de
// API teruggeeft.
function lingvanex_fetch_languages(): ?array {
    $res = lingvanex_http('/b1/api/v3/getLanguages', ['platform' => 'api'], 'GET');
    if (!$res['ok']) return null;

    $list = $res['data']['result'] ?? null;
    if (!is_array($list)) return null;

    $out = [];
    foreach ($list as $entry) {
        if (!is_array($entry)) continue;
        $full = (string)($entry['full_code'] ?? $entry['code'] ?? '');
        if ($full === '') continue;
        $base = strtolower((string)explode('_', $full)[0]);
        $base = (string)preg_replace('/[^a-z]/', '', $base);
        if ($base === '' || strlen($base) > 3 || isset($out[$base])) continue;
        $name = (string)($entry['englishName'] ?? strtoupper($base));
        $out[$base] = ['src' => strtoupper($base), 'tgt' => $base, 'label' => $name, 'lv' => $full];
    }
    return $out === [] ? null : $out;
}

function lingvanex_languages(): array {
    static $langs = null;
    if ($langs !== null) return $langs;
    if (!lingvanex_enabled()) return $langs = [];

    $fetched = lingvanex_fetch_languages();
    if ($fetched !== null) {
        lingvanex_write_lang_cache($fetched);
        return $langs = $fetched;
    }
    $cached = lingvanex_read_lang_cache();
    if ($cached !== null) return $langs = $cached;

    return $langs = lingvanex_fallback_languages();
}

// Kleine, ingebouwde reservelijst voor talen die Microsoft Translator
// aanbiedt, gebruikt zodra de live taalopvraging (microsoft_fetch_languages())
// niet lukt én er nog geen cachebestand bestaat. Microsoft Translator werkt
// meestal met kale ISO-codes, maar voor een aantal talen met een schrift- of
// regiovariant (bv. "zh-Hans", "pt-pt") — die staan hier onder 'ms', zelfde
// patroon als 'lv' bij Lingvanex.
function microsoft_fallback_languages(): array {
    $names = [
        'af' => ['af', 'Afrikaans'], 'sq' => ['sq', 'Shqip'], 'am' => ['am', 'አማርኛ'],
        'hy' => ['hy', 'Հայերեն'], 'az' => ['az', 'Azərbaycan'], 'bn' => ['bn', 'বাংলা'],
        'bs' => ['bs', 'Bosanski'], 'ca' => ['ca', 'Català'], 'hr' => ['hr', 'Hrvatski'],
        'fa' => ['fa', 'فارسی'], 'fj' => ['fj', 'Na Vosa Vakaviti'], 'gu' => ['gu', 'ગુજરાતી'],
        'ht' => ['ht', 'Kreyòl Ayisyen'], 'he' => ['he', 'עברית'], 'hi' => ['hi', 'हिन्दी'],
        'is' => ['is', 'Íslenska'], 'ga' => ['ga', 'Gaeilge'], 'kn' => ['kn', 'ಕನ್ನಡ'],
        'kk' => ['kk', 'Қазақ'], 'km' => ['km', 'ខ្មែរ'], 'ku' => ['ku', 'Kurdî'],
        'ky' => ['ky', 'Кыргызча'], 'lo' => ['lo', 'ລາວ'], 'lv' => ['lv', 'Latviešu'],
        'lt' => ['lt', 'Lietuvių'], 'mg' => ['mg', 'Malagasy'], 'ms' => ['ms', 'Bahasa Melayu'],
        'ml' => ['ml', 'മലയാളം'], 'mt' => ['mt', 'Malti'], 'mr' => ['mr', 'मराठी'],
        'mn' => ['mn', 'Монгол'], 'my' => ['my', 'မြန်မာ'], 'ne' => ['ne', 'नेपाली'],
        'nb' => ['nb', 'Norsk'], 'or' => ['or', 'ଓଡ଼ିଆ'], 'ps' => ['ps', 'پښتو'],
        'pa' => ['pa', 'ਪੰਜਾਬੀ'], 'sm' => ['sm', 'Gagana Sāmoa'], 'sr' => ['sr-Cyrl', 'Српски'],
        'sd' => ['sd', 'سنڌي'], 'si' => ['si', 'සිංහල'], 'sw' => ['sw', 'Kiswahili'],
        'ta' => ['ta', 'தமிழ்'], 'tt' => ['tt', 'Татар'], 'te' => ['te', 'తెలుగు'],
        'th' => ['th', 'ไทย'], 'ti' => ['ti', 'ትግርኛ'], 'ur' => ['ur', 'اردو'],
        'ug' => ['ug', 'ئۇيغۇرچە'], 'uz' => ['uz', 'Oʻzbek'], 'vi' => ['vi', 'Tiếng Việt'],
        'cy' => ['cy', 'Cymraeg'], 'yo' => ['yo', 'Yorùbá'], 'zu' => ['zu', 'isiZulu'],
        'yue' => ['yue', '粵語'], 'zh_hant' => ['zh-Hant', '中文 (繁體)'],
    ];
    $out = [];
    foreach ($names as $code => $pair) {
        [$full, $label] = $pair;
        $out[$code] = ['src' => $code, 'tgt' => $code, 'label' => $label, 'ms' => $full];
    }
    return $out;
}

define('MICROSOFT_LANG_CACHE_FILE', __DIR__ . '/i18n_cache/_microsoft_languages.json');

function microsoft_read_lang_cache(): ?array {
    if (!is_file(MICROSOFT_LANG_CACHE_FILE)) return null;
    $raw = @file_get_contents(MICROSOFT_LANG_CACHE_FILE);
    if ($raw === false || trim($raw) === '') return null;
    $data = json_decode($raw, true);
    return (is_array($data) && $data !== []) ? $data : null;
}

function microsoft_write_lang_cache(array $langs): void {
    $dir = dirname(MICROSOFT_LANG_CACHE_FILE);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $encoded = json_encode($langs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) return;
    $tmp = MICROSOFT_LANG_CACHE_FILE . '.tmp' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $encoded) === false) return;
    @rename($tmp, MICROSOFT_LANG_CACHE_FILE);
}

// Haalt de actuele talenlijst op bij Microsoft Translator (GET /languages,
// scope=translation) — dit endpoint vereist GEEN sleutel, maar wordt hier
// toch alleen gebruikt zodra microsoft_enabled() aanstaat, voor hetzelfde
// gedrag als de andere engines (zonder sleutel doet Microsoft Translator
// nergens aan mee). Response: {"translation":{"<code>":{"name":...,
// "nativeName":...,"dir":...}}}. De taal wordt teruggebracht tot de
// basiscode vóór het koppelteken-deel ("zh-Hans" -> "zh"), met de volledige
// code bewaard onder 'ms' zodat microsoft_lang_code() die er weer bij kan
// pakken.
function microsoft_fetch_languages(): ?array {
    $res = microsoft_http('/languages', ['api-version' => '3.0', 'scope' => 'translation'], 'GET', false);
    if (!$res['ok']) return null;

    $list = $res['data']['translation'] ?? null;
    if (!is_array($list)) return null;

    $out = [];
    foreach ($list as $full => $entry) {
        $full = (string)$full;
        if ($full === '') continue;
        $base = strtolower((string)preg_replace('/[^a-z]/', '', explode('-', $full)[0]));
        if ($base === '' || strlen($base) > 3 || isset($out[$base])) continue;
        $name = is_array($entry) ? (string)($entry['name'] ?? strtoupper($base)) : strtoupper($base);
        $out[$base] = ['src' => strtoupper($base), 'tgt' => $base, 'label' => $name, 'ms' => $full];
    }
    return $out === [] ? null : $out;
}

function microsoft_languages(): array {
    static $langs = null;
    if ($langs !== null) return $langs;
    if (!microsoft_enabled()) return $langs = [];

    $fetched = microsoft_fetch_languages();
    if ($fetched !== null) {
        microsoft_write_lang_cache($fetched);
        return $langs = $fetched;
    }
    $cached = microsoft_read_lang_cache();
    if ($cached !== null) return $langs = $cached;

    return $langs = microsoft_fallback_languages();
}

// ===============================================================
// NEDERLANDSE TAALNAMEN
// ---------------------------------------------------------------
// De webinterface is vast Nederlands, maar de 'label'-waarden hierboven
// komen uit drie verschillende bronnen door elkaar: DeepL's eigen namen
// (deels Nederlands/Engels/native, bv. "Deutsch", "Français"), de vaste
// reservelijsten van translateapi.ai/Lingvanex (native namen, bv. "አማርኛ",
// "Հայերեն") en — zodra de live talenlijst van translateapi.ai of Lingvanex
// wordt opgehaald — de Engelse naam die die API's zelf teruggeven. In een
// verder volledig Nederlandse interface (alle opties, checkboxes en
// taalkiezers) is dat inconsistent en niet in één oogopslag duidelijk. Deze
// tabel geeft er één Nederlandse naam per taalcode voor terug; wordt een taal
// hierin niet herkend (een zeldzame, niet vooraf bekende taal uit een live
// opgehaalde lijst), dan blijft gewoon de oorspronkelijke naam staan als
// terugval — beter een naam in een andere taal tonen dan niets.
// ===============================================================
function lang_dutch_names(): array {
    return [
        'en' => 'Engels', 'en_us' => 'Engels (VS)', 'nl' => 'Nederlands', 'de' => 'Duits',
        'fr' => 'Frans', 'es' => 'Spaans', 'it' => 'Italiaans', 'pt' => 'Portugees',
        'pt_br' => 'Portugees (Brazilië)', 'pl' => 'Pools', 'da' => 'Deens', 'sv' => 'Zweeds',
        'fi' => 'Fins', 'nb' => 'Noors (Bokmål)', 'no' => 'Noors', 'cs' => 'Tsjechisch',
        'sk' => 'Slowaaks', 'sl' => 'Sloveens', 'hu' => 'Hongaars', 'ro' => 'Roemeens',
        'bg' => 'Bulgaars', 'el' => 'Grieks', 'et' => 'Estisch', 'lv' => 'Lets',
        'lt' => 'Litouws', 'tr' => 'Turks', 'id' => 'Indonesisch', 'uk' => 'Oekraïens',
        'ru' => 'Russisch', 'ja' => 'Japans', 'ko' => 'Koreaans', 'zh' => 'Chinees (vereenvoudigd)',
        'ar' => 'Arabisch', 'af' => 'Afrikaans', 'sq' => 'Albanees', 'am' => 'Amhaars',
        'hy' => 'Armeens', 'az' => 'Azerbeidzjaans', 'eu' => 'Baskisch', 'be' => 'Wit-Russisch',
        'bn' => 'Bengaals', 'bs' => 'Bosnisch', 'ca' => 'Catalaans', 'ceb' => 'Cebuano',
        'ny' => 'Nyanja (Chichewa)', 'co' => 'Corsicaans', 'hr' => 'Kroatisch', 'eo' => 'Esperanto',
        'tl' => 'Filipijns (Tagalog)', 'gl' => 'Galicisch', 'ka' => 'Georgisch', 'gu' => 'Gujarati',
        'ht' => 'Haïtiaans Creools', 'ha' => 'Hausa', 'haw' => 'Hawaïaans', 'he' => 'Hebreeuws',
        'hi' => 'Hindi', 'hmn' => 'Hmong', 'is' => 'IJslands', 'ig' => 'Igbo',
        'ga' => 'Iers', 'jw' => 'Javaans', 'kn' => 'Kannada', 'kk' => 'Kazachs',
        'km' => 'Khmer', 'rw' => 'Kinyarwanda', 'ku' => 'Koerdisch', 'ky' => 'Kirgizisch',
        'lo' => 'Laotiaans', 'la' => 'Latijn', 'lb' => 'Luxemburgs', 'mk' => 'Macedonisch',
        'mg' => 'Malagassisch', 'ms' => 'Maleis', 'ml' => 'Malayalam', 'mt' => 'Maltees',
        'mi' => 'Maori', 'mr' => 'Marathi', 'mn' => 'Mongools', 'my' => 'Birmaans (Myanmar)',
        'ne' => 'Nepalees', 'or' => 'Odia', 'ps' => 'Pasjtoe', 'fa' => 'Perzisch (Farsi)',
        'pa' => 'Punjabi', 'sm' => 'Samoaans', 'gd' => 'Schots-Gaelisch', 'sr' => 'Servisch',
        'st' => 'Sesotho', 'sn' => 'Shona', 'sd' => 'Sindhi', 'si' => 'Singalees',
        'so' => 'Somalisch', 'su' => 'Soendanees', 'sw' => 'Swahili', 'tg' => 'Tadzjieks',
        'ta' => 'Tamil', 'tt' => 'Tataars', 'te' => 'Telugu', 'th' => 'Thai',
        'tk' => 'Turkmeens', 'ur' => 'Urdu', 'ug' => 'Oeigoers', 'uz' => 'Oezbeeks',
        'vi' => 'Vietnamees', 'cy' => 'Welsh', 'xh' => 'Xhosa', 'yi' => 'Jiddisch',
        'yo' => 'Yoruba', 'zu' => 'Zoeloe',
    ];
}

function lang_dutch_label(string $code): ?string {
    $names = lang_dutch_names();
    return $names[strtolower(trim($code))] ?? null;
}

// Gecombineerde talenlijst: DeepL eerst (engine=deepl), aangevuld met de
// translateapi.ai-talen die DeepL niet kent (engine=translateapi), aangevuld
// met de Lingvanex-talen die geen van de twee al kennen (engine=lingvanex), en
// ten slotte aangevuld met de Microsoft Translator-talen die geen van de drie
// al kennen (engine=microsoft). Bij een codebotsing wint altijd de eerder
// genoemde engine — DeepL blijft dus de eerste keus voor de talen die het
// aankan, translateapi.ai de tweede, Lingvanex de derde. Elke 'label' wordt
// daarna, waar bekend, vervangen door de Nederlandse taalnaam
// (lang_dutch_label() hierboven) zodat alle taalopties overal in de (vaste
// Nederlandse) interface consequent in het Nederlands worden getoond.
function deepl_languages(): array {
    static $merged = null;
    if ($merged !== null) return $merged;

    $out = [];
    foreach (deepl_native_languages() as $code => $meta) {
        $meta['engine'] = 'deepl';
        $out[$code] = $meta;
    }
    if (translateapi_enabled()) {
        foreach (translateapi_languages() as $code => $meta) {
            if (isset($out[$code])) continue;
            $meta['engine'] = 'translateapi';
            $out[$code] = $meta;
        }
    }
    if (lingvanex_enabled()) {
        foreach (lingvanex_languages() as $code => $meta) {
            if (isset($out[$code])) continue;
            $meta['engine'] = 'lingvanex';
            $out[$code] = $meta;
        }
    }
    if (microsoft_enabled()) {
        foreach (microsoft_languages() as $code => $meta) {
            if (isset($out[$code])) continue;
            $meta['engine'] = 'microsoft';
            $out[$code] = $meta;
        }
    }

    foreach ($out as $code => &$meta) {
        $dutch = lang_dutch_label($code);
        if ($dutch !== null) $meta['label'] = $dutch;
    }
    unset($meta);

    return $merged = $out;
}

function deepl_lang_known(string $lang): bool {
    return isset(deepl_languages()[$lang]);
}

function deepl_lang_label(string $lang): string {
    return deepl_languages()[$lang]['label'] ?? strtoupper($lang);
}

// Zelfde inhoud als deepl_languages(), maar alfabetisch geordend op de
// (Nederlandse, waar bekend) taalnaam ('label') i.p.v. de willekeurige
// DeepL-native volgorde. Losse functie — deepl_languages() zelf blijft
// ongesorteerd, voor aanroepers die alleen "is deze taal bekend"/"geef de
// meta van deze taal" willen (deepl_lang_known(), deepl_lang_label(), enz.).
// Gebruikt door elke plek in de interface die de volledige talenlijst als
// keuzelijst (checkboxes/<select>) toont, zodat die overal A-Z loopt.
function deepl_languages_sorted(): array {
    $out = deepl_languages();
    uasort($out, function (array $a, array $b): int {
        return strnatcasecmp((string)($a['label'] ?? ''), (string)($b['label'] ?? ''));
    });
    return $out;
}

// De taalcode zoals translateapi.ai die verwacht (ISO 639-1, kleine letters,
// zonder regiovariant): 'en_us' en 'pt_br' worden 'en'/'pt', 'nb' wordt 'no'
// (expliciete override hierboven in deepl_native_languages()). Een taal die
// via translateapi_languages() zelf is opgehaald draagt zijn eigen code al in
// de juiste vorm.
function translateapi_lang_code(string $lang): string {
    $map = deepl_languages();
    if (isset($map[$lang]['ta'])) return (string)$map[$lang]['ta'];
    $base = strtolower((string)preg_replace('/[^a-z]/i', '', explode('_', $lang)[0]));
    return $base !== '' ? $base : strtolower($lang);
}

// Volledige taal+regiocode zoals Lingvanex die verwacht (bv. "nl_NL",
// "en_GB") voor ELKE taalcode die deepl_languages() kent — dus ook de
// "eigen" DeepL-talen (en/nl/de/...), niet alleen de talen die Lingvanex als
// enige aanbiedt. Dat laatste is nodig omdat Lingvanex ook als terugval moet
// werken zodra DeepL (of translateapi.ai) een taal wél kent maar de aanroep
// mislukt: de vaste $overrides hieronder dekken die "bekende" talen met een
// gangbare regiovariant, en worden aangevuld/overschreven door wat de live
// (of gecachete) Lingvanex-talenlijst zelf als full_code teruggeeft — die is
// leidend zodra hij beschikbaar is. Onbekende codes krijgen een simpele gok
// ("<taal>_<TAAL>", bv. "fr" -> "fr_FR") als laatste redmiddel.
function lingvanex_full_code_map(): array {
    static $map = null;
    if ($map !== null) return $map;

    $overrides = [
        'en' => 'en_GB', 'en_us' => 'en_US', 'nl' => 'nl_NL', 'de' => 'de_DE',
        'fr' => 'fr_FR', 'es' => 'es_ES', 'it' => 'it_IT', 'pt' => 'pt_PT',
        'pt_br' => 'pt_BR', 'pl' => 'pl_PL', 'da' => 'da_DK', 'sv' => 'sv_SE',
        'fi' => 'fi_FI', 'nb' => 'nb_NO', 'cs' => 'cs_CZ', 'sk' => 'sk_SK',
        'sl' => 'sl_SI', 'hu' => 'hu_HU', 'ro' => 'ro_RO', 'bg' => 'bg_BG',
        'el' => 'el_GR', 'et' => 'et_EE', 'lv' => 'lv_LV', 'lt' => 'lt_LT',
        'tr' => 'tr_TR', 'id' => 'id_ID', 'uk' => 'uk_UA', 'ru' => 'ru_RU',
        'ja' => 'ja_JP', 'ko' => 'ko_KR', 'zh' => 'zh_CN', 'ar' => 'ar_SA',
    ];

    $map = $overrides;
    foreach (lingvanex_languages() as $code => $meta) {
        if (is_array($meta) && !empty($meta['lv'])) $map[$code] = (string)$meta['lv'];
    }
    return $map;
}

function lingvanex_lang_code(string $lang): string {
    $map = lingvanex_full_code_map();
    if (isset($map[$lang])) return $map[$lang];
    $base = strtolower((string)preg_replace('/[^a-z]/i', '', explode('_', $lang)[0]));
    if ($base === '') $base = strtolower($lang);
    return $base . '_' . strtoupper($base);
}

// Taalcode zoals Microsoft Translator die verwacht: meestal een kale
// ISO 639-1-code ("nl", "de", "tr", ...), maar voor een paar talen met een
// schrift- of regiovariant een langere code ("zh-Hans", "pt-pt", "sr-Cyrl").
// Zelfde opzet als lingvanex_full_code_map(): vaste overrides voor de talen
// die contract_translate.php al langer kent (zodat Microsoft Translator ook
// als terugval werkt voor DIE talen, niet alleen voor talen die het als
// enige aanbiedt), aangevuld/overschreven door wat de live (of gecachete)
// Microsoft-talenlijst zelf teruggeeft. Onbekende codes gaan gewoon kaal (in
// kleine letters) mee — dat is voor de meeste talen al de juiste vorm.
function microsoft_full_code_map(): array {
    static $map = null;
    if ($map !== null) return $map;

    $overrides = [
        'en' => 'en', 'en_us' => 'en', 'nl' => 'nl', 'de' => 'de',
        'fr' => 'fr', 'es' => 'es', 'it' => 'it', 'pt' => 'pt-pt',
        'pt_br' => 'pt-br', 'pl' => 'pl', 'da' => 'da', 'sv' => 'sv',
        'fi' => 'fi', 'nb' => 'nb', 'cs' => 'cs', 'sk' => 'sk',
        'sl' => 'sl', 'hu' => 'hu', 'ro' => 'ro', 'bg' => 'bg',
        'el' => 'el', 'et' => 'et', 'lv' => 'lv', 'lt' => 'lt',
        'tr' => 'tr', 'id' => 'id', 'uk' => 'uk', 'ru' => 'ru',
        'ja' => 'ja', 'ko' => 'ko', 'zh' => 'zh-Hans', 'ar' => 'ar',
    ];

    $map = $overrides;
    foreach (microsoft_languages() as $code => $meta) {
        if (is_array($meta) && !empty($meta['ms'])) $map[$code] = (string)$meta['ms'];
    }
    return $map;
}

function microsoft_lang_code(string $lang): string {
    $map = microsoft_full_code_map();
    if (isset($map[$lang])) return $map[$lang];
    $base = strtolower((string)preg_replace('/[^a-z]/i', '', explode('_', $lang)[0]));
    return $base !== '' ? $base : strtolower($lang);
}

// ===============================================================
// PLACEHOLDER-BESCHERMING
// ---------------------------------------------------------------
// De contracttekst bevat {{P1}}, {{LAW}}, {{MODULE}} enz. Die mogen letterlijk
// niet veranderen, anders werkt ph() niet meer. Voor DeepL sturen we de tekst
// als XML en zetten elk token in een <ph>-tag die DeepL moet negeren
// (ignore_tags) — dat blijft deepl_protect()/deepl_unprotect() hieronder.
//
// translateapi.ai kent geen ignore_tags/XML-modus, dus daar gebruiken we een
// andere, engine-neutrale truc (translateapi_protect()/unprotect() verderop):
// elk token wordt vervangen door een kort, uniek "codewoord" zonder spaties of
// leestekens (bv. "zzph0zz"), dat de meeste vertaalmodellen met rust laten
// omdat het op geen bestaand woord lijkt. Na vertaling wordt het codewoord
// (hoofdletterongevoelig, voor het geval het model het aanpast) weer
// teruggezet naar het originele {{TOKEN}}. Dit is minder waterdicht dan
// DeepL's ignore_tags, maar translateapi.ai wordt hier alleen ingezet als
// terugval of voor talen die DeepL niet aankan — niet als hoofdroute.
// ===============================================================
define('DEEPL_PH_PATTERN', '/\{\{[A-Za-z0-9_]+\}\}/');

function deepl_protect(string $text): string {
    $xml = htmlspecialchars($text, ENT_NOQUOTES | ENT_XML1, 'UTF-8');
    return (string)preg_replace(DEEPL_PH_PATTERN, '<ph>$0</ph>', $xml);
}

function deepl_unprotect(string $text): string {
    $text = str_replace(['<ph>', '</ph>', '<ph/>', '<ph />'], '', $text);
    return html_entity_decode($text, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function translateapi_protect(string $text, array &$map): string {
    $map = [];
    $i = 0;
    return (string)preg_replace_callback(DEEPL_PH_PATTERN, function (array $m) use (&$map, &$i): string {
        $token = 'zzph' . $i . 'zz';
        $map[$token] = $m[0];
        $i++;
        return $token;
    }, $text);
}

function translateapi_unprotect(string $text, array $map): string {
    foreach ($map as $token => $original) {
        $text = (string)preg_replace('/' . preg_quote($token, '/') . '/i', $original, $text);
    }
    return $text;
}

// Regels zonder enige letter (scheidingslijnen, losse placeholders, nummers)
// hoeven niet naar een vertaalengine: scheelt tekens en voorkomt rare output.
function deepl_line_translatable(string $line): bool {
    $stripped = (string)preg_replace(DEEPL_PH_PATTERN, '', $line);
    return preg_match('/\p{L}/u', $stripped) === 1;
}

// Telt exact de tekens die deepl_translate_block() zou versturen: alleen
// vertaalbare regels, zonder inspringing. Gebruikt door de proefdraai, zodat
// de schatting overeenkomt met het werkelijke verbruik.
function deepl_count_chars(string $text): int {
    $n = 0;
    foreach (explode("\n", str_replace("\r\n", "\n", $text)) as $line) {
        if (!deepl_line_translatable($line)) continue;
        $n += mb_strlen(ltrim($line), 'UTF-8');
    }
    return $n;
}

// ===============================================================
// HTTP — DeepL /v2/translate
// ===============================================================
function deepl_http(string $endpoint, array $payload): array {
    $cfg = deepl_config();
    if ($cfg['key'] === '') {
        return ['ok' => false, 'error' => 'nokey', 'message' => 'DEEPL_API_KEY ontbreekt.'];
    }
    if (!extension_loaded('curl')) {
        return ['ok' => false, 'error' => 'nocurl', 'message' => 'PHP-extensie curl ontbreekt.'];
    }

    $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($body === false) {
        return ['ok' => false, 'error' => 'encode', 'message' => 'Kon verzoek niet als JSON coderen.'];
    }

    $attempt = 0;
    $lastMessage = '';
    while ($attempt < 3) {
        $attempt++;
        $ch = curl_init($cfg['host'] . $endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST           => $endpoint !== '/v2/usage',
            CURLOPT_POSTFIELDS     => $endpoint !== '/v2/usage' ? $body : null,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $cfg['timeout'],
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTPHEADER     => [
                'Authorization: DeepL-Auth-Key ' . $cfg['key'],
                'Content-Type: application/json',
                'User-Agent: contractregister/1.0',
            ],
        ]);
        $raw  = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            $lastMessage = 'Netwerkfout: ' . $err;
            if ($attempt < 3) { sleep($attempt); continue; }
            return ['ok' => false, 'error' => 'network', 'message' => $lastMessage];
        }

        if ($code === 200) {
            $data = json_decode((string)$raw, true);
            if (!is_array($data)) {
                return ['ok' => false, 'error' => 'decode', 'message' => 'Onleesbaar antwoord van DeepL.'];
            }
            return ['ok' => true, 'data' => $data];
        }

        // 429 (te veel verzoeken) en 5xx zijn tijdelijk: opnieuw proberen.
        if ($code === 429 || $code >= 500) {
            $lastMessage = 'DeepL antwoordde met HTTP ' . $code . '.';
            if ($attempt < 3) { sleep(2 ** $attempt); continue; }
            return ['ok' => false, 'error' => 'busy', 'message' => $lastMessage];
        }

        return match ($code) {
            403 => ['ok' => false, 'error' => 'auth',  'message' => 'DeepL weigert de sleutel (403).'],
            456 => ['ok' => false, 'error' => 'quota', 'message' => 'Tekenlimiet van het DeepL-abonnement bereikt (456).'],
            413, 414 => ['ok' => false, 'error' => 'toolarge', 'message' => 'Verzoek te groot (HTTP ' . $code . ').'],
            default  => ['ok' => false, 'error' => 'http', 'message' => 'DeepL HTTP ' . $code . ': ' . substr((string)$raw, 0, 300)],
        };
    }

    return ['ok' => false, 'error' => 'retry', 'message' => $lastMessage];
}

// Tekenverbruik/quotum ophalen (voor het informatieblok in de configuratie).
function deepl_usage(): ?array {
    if (!deepl_key_enabled()) return null;
    $res = deepl_http('/v2/usage', []);
    if (!$res['ok']) return null;
    $d = $res['data'];
    return [
        'count' => (int)($d['character_count'] ?? 0),
        'limit' => (int)($d['character_limit'] ?? 0),
    ];
}

/**
 * Vertaalt een batch losse regels via DeepL. Geeft ['ok'=>bool, 'texts'=>string[]]
 * terug. De volgorde van $lines blijft gegarandeerd behouden (DeepL antwoordt
 * in dezelfde volgorde als de aangeleverde text-array). $lines zijn de RAUWE
 * (nog niet beschermde) regels; de placeholder-bescherming gebeurt hierbinnen.
 */
function deepl_translate_batch(array $lines, string $srcLang, string $tgtLang): array {
    if ($lines === []) return ['ok' => true, 'texts' => []];

    $cfg  = deepl_config();
    $map  = deepl_languages();
    $src  = $map[$srcLang]['src'] ?? strtoupper($srcLang);
    $tgt  = $map[$tgtLang]['tgt'] ?? strtoupper($tgtLang);

    $payload = [
        'text'              => array_map('deepl_protect', array_values($lines)),
        'source_lang'       => $src,
        'target_lang'       => $tgt,
        'tag_handling'      => 'xml',
        'ignore_tags'       => ['ph'],
        'outline_detection' => false, // wij leveren zelf geen document-structuur aan
        'preserve_formatting' => true,
        'split_sentences'   => '1',
    ];
    if ($cfg['formality'] !== '' && $cfg['formality'] !== 'default') {
        $payload['formality'] = $cfg['formality']; // prefer_* faalt niet op talen zonder formaliteit
    }
    if ($cfg['model_type'] !== '') {
        $payload['model_type'] = $cfg['model_type'];
    }
    $glossary = $cfg['glossaries'][$srcLang . ':' . $tgtLang] ?? null;
    if (is_string($glossary) && $glossary !== '') {
        $payload['glossary_id'] = $glossary;
    }

    $res = deepl_http('/v2/translate', $payload);
    if (!$res['ok']) return ['ok' => false, 'error' => $res['error'], 'message' => $res['message']];

    $out = [];
    foreach (($res['data']['translations'] ?? []) as $tr) {
        $out[] = deepl_unprotect((string)($tr['text'] ?? ''));
    }
    if (count($out) !== count($lines)) {
        return ['ok' => false, 'error' => 'count', 'message' => 'DeepL gaf een ander aantal regels terug dan verzonden.'];
    }
    return ['ok' => true, 'texts' => $out];
}

// ===============================================================
// HTTP — translateapi.ai
// ---------------------------------------------------------------
// Zie https://translateapi.ai/api/. Authenticatie via Bearer-token, JSON-body.
// De publieke enkelvoudige vertaalendpoint (/translate/) accepteert één tekst
// per aanroep (geen array), dus translateapi_translate_batch() hieronder doet
// één aanroep per regel. Dat is trager dan DeepL's echte batch-aanroep, maar
// translateapi.ai wordt hier alleen ingezet als terugval (DeepL-fout) of voor
// talen buiten DeepL's bereik — niet als hoofdroute voor het dagelijkse werk.
// ===============================================================
function translateapi_http(string $endpoint, array $payload = [], string $method = 'POST'): array {
    $cfg = translateapi_config();
    if ($cfg['key'] === '') {
        return ['ok' => false, 'error' => 'nokey', 'message' => 'TRANSLATEAPI_KEY ontbreekt.'];
    }
    if (!extension_loaded('curl')) {
        return ['ok' => false, 'error' => 'nocurl', 'message' => 'PHP-extensie curl ontbreekt.'];
    }

    $body = '';
    if ($method !== 'GET') {
        $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
        if ($body === false) {
            return ['ok' => false, 'error' => 'encode', 'message' => 'Kon verzoek niet als JSON coderen.'];
        }
    }

    $attempt = 0;
    $lastMessage = '';
    while ($attempt < 3) {
        $attempt++;
        $ch = curl_init($cfg['host'] . $endpoint);
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $cfg['timeout'],
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $cfg['key'],
                'Content-Type: application/json',
                'User-Agent: contractregister/1.0',
            ],
        ];
        if ($method === 'GET') {
            $opts[CURLOPT_HTTPGET] = true;
        } else {
            $opts[CURLOPT_POST] = true;
            $opts[CURLOPT_POSTFIELDS] = $body;
        }
        curl_setopt_array($ch, $opts);

        $raw  = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            $lastMessage = 'Netwerkfout: ' . $err;
            if ($attempt < 3) { sleep($attempt); continue; }
            return ['ok' => false, 'error' => 'network', 'message' => $lastMessage];
        }

        if ($code === 200 || $code === 202) {
            $data = json_decode((string)$raw, true);
            if (!is_array($data)) {
                return ['ok' => false, 'error' => 'decode', 'message' => 'Onleesbaar antwoord van translateapi.ai.'];
            }
            return ['ok' => true, 'data' => $data];
        }

        if ($code === 503 || $code >= 500) {
            $lastMessage = 'translateapi.ai antwoordde met HTTP ' . $code . '.';
            if ($attempt < 3) { sleep(2 ** $attempt); continue; }
            return ['ok' => false, 'error' => 'busy', 'message' => $lastMessage];
        }

        $data    = json_decode((string)$raw, true);
        $errCode = is_array($data) ? (string)($data['error'] ?? '') : '';

        return match ($code) {
            401 => ['ok' => false, 'error' => 'auth',  'message' => 'translateapi.ai weigert de sleutel (401).'],
            402 => ['ok' => false, 'error' => 'quota', 'message' => 'translateapi.ai-tegoed op (402)'
                        . (is_array($data) && isset($data['credits_remaining']) ? ', resterend: ' . $data['credits_remaining'] : '') . '.'],
            403 => ['ok' => false, 'error' => 'auth',  'message' => 'translateapi.ai weigert toegang (403).'],
            400 => ['ok' => false, 'error' => 'badrequest', 'message' => 'translateapi.ai: ongeldig verzoek'
                        . ($errCode !== '' ? ' (' . $errCode . ')' : '') . '.'],
            default => ['ok' => false, 'error' => 'http', 'message' => 'translateapi.ai HTTP ' . $code . ': ' . substr((string)$raw, 0, 300)],
        };
    }

    return ['ok' => false, 'error' => 'retry', 'message' => $lastMessage];
}

/**
 * Vertaalt een batch losse regels via translateapi.ai (één aanroep per regel;
 * zie de toelichting hierboven). Zelfde returnvorm als deepl_translate_batch().
 */
function translateapi_translate_batch(array $lines, string $srcLang, string $tgtLang): array {
    if ($lines === []) return ['ok' => true, 'texts' => []];
    if (!translateapi_enabled()) {
        return ['ok' => false, 'error' => 'nokey', 'message' => 'TRANSLATEAPI_KEY ontbreekt.'];
    }

    $cfg = translateapi_config();
    $src = translateapi_lang_code($srcLang);
    $tgt = translateapi_lang_code($tgtLang);

    $out = [];
    foreach (array_values($lines) as $line) {
        $map = [];
        $protected = translateapi_protect($line, $map);

        $payload = [
            'text'             => $protected,
            'source_language'  => $src,
            'target_language'  => $tgt,
        ];
        if ($cfg['engine'] !== '' && $cfg['engine'] !== 'auto') {
            $payload['engine'] = $cfg['engine'];
        }

        $res = translateapi_http('/translate/', $payload, 'POST');
        if (!$res['ok']) return ['ok' => false, 'error' => $res['error'], 'message' => $res['message']];

        $data = $res['data'];
        $translated = (string)($data['translated_text'] ?? ($data['translations'][$tgt] ?? ''));
        $out[] = translateapi_unprotect($translated, $map);
    }

    return ['ok' => true, 'texts' => $out];
}

// ===============================================================
// HTTP — Lingvanex (/b1/api/v3/*)
// ---------------------------------------------------------------
// Zie https://docs.lingvanex.com/. Authenticatie via de header
// "Authorization: <sleutel>" (geen "Bearer "-prefix), JSON-body voor POST,
// query-string voor GET (getLanguages). Response geeft bij succes altijd een
// "result"-veld terug (tekst bij vertalen, array bij getLanguages) en soms,
// ook bij HTTP 200, een gevuld "err"-veld — dat wordt hieronder ook als fout
// behandeld.
// ===============================================================
function lingvanex_http(string $endpoint, array $payload = [], string $method = 'POST'): array {
    $cfg = lingvanex_config();
    if ($cfg['key'] === '') {
        return ['ok' => false, 'error' => 'nokey', 'message' => 'LINGVANEX_API_KEY ontbreekt.'];
    }
    if (!extension_loaded('curl')) {
        return ['ok' => false, 'error' => 'nocurl', 'message' => 'PHP-extensie curl ontbreekt.'];
    }

    $url  = $cfg['host'] . $endpoint;
    $body = '';
    if ($method === 'GET') {
        if ($payload !== []) $url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($payload);
    } else {
        $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
        if ($body === false) {
            return ['ok' => false, 'error' => 'encode', 'message' => 'Kon verzoek niet als JSON coderen.'];
        }
    }

    $attempt = 0;
    $lastMessage = '';
    while ($attempt < 3) {
        $attempt++;
        $ch = curl_init($url);
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $cfg['timeout'],
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTPHEADER     => [
                'Authorization: ' . $cfg['key'],
                'Content-Type: application/json',
                'Accept: application/json',
                'User-Agent: contractregister/1.0',
            ],
        ];
        if ($method === 'GET') {
            $opts[CURLOPT_HTTPGET] = true;
        } else {
            $opts[CURLOPT_POST] = true;
            $opts[CURLOPT_POSTFIELDS] = $body;
        }
        curl_setopt_array($ch, $opts);

        $raw  = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            $lastMessage = 'Netwerkfout: ' . $err;
            if ($attempt < 3) { sleep($attempt); continue; }
            return ['ok' => false, 'error' => 'network', 'message' => $lastMessage];
        }

        if ($code === 429 || $code >= 500) {
            $lastMessage = 'Lingvanex antwoordde met HTTP ' . $code . '.';
            if ($attempt < 3) { sleep(2 ** $attempt); continue; }
            return ['ok' => false, 'error' => 'busy', 'message' => $lastMessage];
        }

        if ($code === 200) {
            $data = json_decode((string)$raw, true);
            if (!is_array($data)) {
                return ['ok' => false, 'error' => 'decode', 'message' => 'Onleesbaar antwoord van Lingvanex.'];
            }
            $apiErr = trim((string)($data['err'] ?? ''));
            if ($apiErr !== '') {
                return ['ok' => false, 'error' => 'api', 'message' => 'Lingvanex: ' . $apiErr];
            }
            return ['ok' => true, 'data' => $data];
        }

        return match ($code) {
            401, 403 => ['ok' => false, 'error' => 'auth',  'message' => 'Lingvanex weigert de sleutel (HTTP ' . $code . ').'],
            402      => ['ok' => false, 'error' => 'quota', 'message' => 'Lingvanex-tegoed op (402).'],
            default  => ['ok' => false, 'error' => 'http', 'message' => 'Lingvanex HTTP ' . $code . ': ' . substr((string)$raw, 0, 300)],
        };
    }

    return ['ok' => false, 'error' => 'retry', 'message' => $lastMessage];
}

/**
 * Vertaalt een batch losse regels via Lingvanex (één aanroep per regel, net als
 * translateapi_translate_batch() — de /translate-endpoint van Lingvanex
 * accepteert één tekst per verzoek). Zelfde returnvorm als de andere twee
 * *_translate_batch()-functies. Hergebruikt dezelfde codewoord-placeholder-
 * bescherming als translateapi.ai (translateapi_protect()/_unprotect() — een
 * generieke, niet-engine-specifieke truc): Lingvanex kent evenmin een
 * ignore-tags-achtige optie.
 */
function lingvanex_translate_batch(array $lines, string $srcLang, string $tgtLang): array {
    if ($lines === []) return ['ok' => true, 'texts' => []];
    if (!lingvanex_enabled()) {
        return ['ok' => false, 'error' => 'nokey', 'message' => 'LINGVANEX_API_KEY ontbreekt.'];
    }

    $src = lingvanex_lang_code($srcLang);
    $tgt = lingvanex_lang_code($tgtLang);

    $out = [];
    foreach (array_values($lines) as $line) {
        $map = [];
        $protected = translateapi_protect($line, $map);

        $payload = [
            'platform' => 'api',
            'from'     => $src,
            'to'       => $tgt,
            'data'     => $protected,
        ];

        $res = lingvanex_http('/b1/api/v3/translate', $payload, 'POST');
        if (!$res['ok']) return ['ok' => false, 'error' => $res['error'], 'message' => $res['message']];

        $translated = (string)($res['data']['result'] ?? '');
        $out[] = translateapi_unprotect($translated, $map);
    }

    return ['ok' => true, 'texts' => $out];
}

// ===============================================================
// HTTP — Microsoft Translator (Azure AI services, /translate en /languages)
// ---------------------------------------------------------------
// Zie https://learn.microsoft.com/azure/ai-services/translator/. Query-
// parameters (api-version, from, to, ...) gaan in de URL, niet in de body;
// $body (indien niet null) wordt als JSON meegestuurd voor POST-verzoeken.
// Authenticatie via de header "Ocp-Apim-Subscription-Key: <sleutel>", plus
// "Ocp-Apim-Subscription-Region: <regio>" zodra een regio is ingesteld
// (alleen nodig bij een regionale/multi-service resource). Het
// /languages-endpoint heeft GEEN sleutel nodig ($requireKey=false hieronder),
// maar wordt hier alleen aangeroepen zodra microsoft_enabled() al aanstaat.
// ===============================================================
function microsoft_http(string $endpoint, array $query = [], string $method = 'GET', $body = null, bool $requireKey = true): array {
    $cfg = microsoft_config();
    if ($requireKey && $cfg['key'] === '') {
        return ['ok' => false, 'error' => 'nokey', 'message' => 'MICROSOFT_TRANSLATOR_KEY ontbreekt.'];
    }
    if (!extension_loaded('curl')) {
        return ['ok' => false, 'error' => 'nocurl', 'message' => 'PHP-extensie curl ontbreekt.'];
    }

    $url = $cfg['host'] . $endpoint;
    if ($query !== []) $url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($query);

    $encodedBody = '';
    if ($method !== 'GET' && $body !== null) {
        $encodedBody = json_encode($body, JSON_UNESCAPED_UNICODE);
        if ($encodedBody === false) {
            return ['ok' => false, 'error' => 'encode', 'message' => 'Kon verzoek niet als JSON coderen.'];
        }
    }

    $attempt = 0;
    $lastMessage = '';
    while ($attempt < 3) {
        $attempt++;
        $ch = curl_init($url);
        $headers = ['Content-Type: application/json; charset=UTF-8', 'User-Agent: contractregister/1.0'];
        if ($cfg['key'] !== '') $headers[] = 'Ocp-Apim-Subscription-Key: ' . $cfg['key'];
        if ($cfg['region'] !== '') $headers[] = 'Ocp-Apim-Subscription-Region: ' . $cfg['region'];

        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $cfg['timeout'],
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTPHEADER     => $headers,
        ];
        if ($method === 'GET') {
            $opts[CURLOPT_HTTPGET] = true;
        } else {
            $opts[CURLOPT_POST] = true;
            $opts[CURLOPT_POSTFIELDS] = $encodedBody;
        }
        curl_setopt_array($ch, $opts);

        $raw  = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            $lastMessage = 'Netwerkfout: ' . $err;
            if ($attempt < 3) { sleep($attempt); continue; }
            return ['ok' => false, 'error' => 'network', 'message' => $lastMessage];
        }

        if ($code === 429 || $code >= 500) {
            $lastMessage = 'Microsoft Translator antwoordde met HTTP ' . $code . '.';
            if ($attempt < 3) { sleep(2 ** $attempt); continue; }
            return ['ok' => false, 'error' => 'busy', 'message' => $lastMessage];
        }

        if ($code === 200) {
            $data = json_decode((string)$raw, true);
            if (!is_array($data)) {
                return ['ok' => false, 'error' => 'decode', 'message' => 'Onleesbaar antwoord van Microsoft Translator.'];
            }
            return ['ok' => true, 'data' => $data];
        }

        return match ($code) {
            401 => ['ok' => false, 'error' => 'auth',  'message' => 'Microsoft Translator weigert de sleutel (401).'],
            403 => ['ok' => false, 'error' => 'quota', 'message' => 'Microsoft Translator: niet geautoriseerd / limiet bereikt (403).'],
            400 => ['ok' => false, 'error' => 'badrequest', 'message' => 'Microsoft Translator: ongeldig verzoek (400) — ' . substr((string)$raw, 0, 300)],
            default => ['ok' => false, 'error' => 'http', 'message' => 'Microsoft Translator HTTP ' . $code . ': ' . substr((string)$raw, 0, 300)],
        };
    }

    return ['ok' => false, 'error' => 'retry', 'message' => $lastMessage];
}

/**
 * Vertaalt een batch losse regels via Microsoft Translator in ÉÉN verzoek
 * (in tegenstelling tot translateapi.ai/Lingvanex, die één aanroep per regel
 * doen): de /translate-endpoint accepteert een array van teksten en geeft ze
 * terug in dezelfde volgorde. Gebruikt dezelfde codewoord-placeholder-
 * bescherming als translateapi.ai/Lingvanex (translateapi_protect()/
 * _unprotect()) — Microsoft Translator kent voor tekst-vertalen (zonder
 * aangepast woordenboek) geen ignore-tags-achtige optie.
 */
function microsoft_translate_batch(array $lines, string $srcLang, string $tgtLang): array {
    if ($lines === []) return ['ok' => true, 'texts' => []];
    if (!microsoft_enabled()) {
        return ['ok' => false, 'error' => 'nokey', 'message' => 'MICROSOFT_TRANSLATOR_KEY ontbreekt.'];
    }

    $src = microsoft_lang_code($srcLang);
    $tgt = microsoft_lang_code($tgtLang);

    $maps = [];
    $payload = [];
    foreach (array_values($lines) as $line) {
        $map = [];
        $payload[] = ['text' => translateapi_protect($line, $map)];
        $maps[] = $map;
    }

    $res = microsoft_http('/translate', ['api-version' => '3.0', 'from' => $src, 'to' => $tgt], 'POST', $payload);
    if (!$res['ok']) return ['ok' => false, 'error' => $res['error'], 'message' => $res['message']];

    $data = $res['data'];
    if (!is_array($data) || count($data) !== count($lines)) {
        return ['ok' => false, 'error' => 'count', 'message' => 'Microsoft Translator gaf een ander aantal regels terug dan verzonden.'];
    }

    $out = [];
    foreach (array_values($data) as $pos => $entry) {
        $translated = (string)($entry['translations'][0]['text'] ?? '');
        $out[] = translateapi_unprotect($translated, $maps[$pos] ?? []);
    }

    return ['ok' => true, 'texts' => $out];
}

/**
 * Kiest de vertaalengine voor deze batch en regelt de terugval-ketting tussen
 * DeepL, translateapi.ai, Lingvanex en Microsoft Translator:
 *  - Taal die DeepL kent + DeepL geconfigureerd: eerst DeepL. Mislukt dat
 *    verzoek, dan (als translateapi.ai geconfigureerd is) dezelfde batch via
 *    translateapi.ai opnieuw proberen; mislukt dát ook (of niet
 *    geconfigureerd), dan Lingvanex; mislukt ook dát (of niet geconfigureerd),
 *    dan als laatste Microsoft Translator (indien geconfigureerd).
 *  - Taal die DeepL niet kent maar translateapi.ai wel: direct translateapi.ai,
 *    met Lingvanex en daarna Microsoft Translator als terugval.
 *  - Taal die alleen Microsoft Translator (of alleen Lingvanex) kent: direct
 *    die engine.
 *  - Geen van vier (of geen van vier kent de taal): foutmelding.
 * Elke mislukte engine-poging wordt weggeschreven naar translate_error.log
 * (translate_log_error()), ook als een latere engine het alsnog overneemt —
 * zo blijft een stille terugval zichtbaar. $context is een vrije, optionele
 * aanduiding van de aanroeper, puur voor in die logregel.
 * Geeft, naast 'ok'/'texts', ook 'engine' terug ('deepl', 'translateapi',
 * 'lingvanex' of 'microsoft') — gebruikt voor het _mt-stempel in
 * translate_contract_definition().
 */
function mt_translate_batch(array $lines, string $srcLang, string $tgtLang, string $context = ''): array {
    $langs   = deepl_languages();
    $srcMeta = $langs[$srcLang] ?? null;
    $tgtMeta = $langs[$tgtLang] ?? null;

    $srcIsDeepl = $srcMeta !== null && ($srcMeta['engine'] ?? 'deepl') === 'deepl';
    $tgtIsDeepl = $tgtMeta !== null && ($tgtMeta['engine'] ?? 'deepl') === 'deepl';
    $canDeepl   = $srcIsDeepl && $tgtIsDeepl && deepl_key_enabled();
    $canTa      = translateapi_enabled() && $srcMeta !== null && $tgtMeta !== null;
    $canLv      = lingvanex_enabled() && $srcMeta !== null && $tgtMeta !== null;
    $canMs      = microsoft_enabled() && $srcMeta !== null && $tgtMeta !== null;

    // $attempts verzamelt de foutmelding van elke geprobeerde engine, zodat de
    // uiteindelijke foutmelding (mt_combine_failure()) — als ALLE geprobeerde
    // engines mislukten — ze allemaal kan tonen i.p.v. alleen de eerste.
    $attempts = [];

    $tryEngine = static function (string $engine, array $lines, string $srcLang, string $tgtLang) use ($context, &$attempts): ?array {
        $res = match ($engine) {
            'deepl'        => deepl_translate_batch($lines, $srcLang, $tgtLang),
            'translateapi' => translateapi_translate_batch($lines, $srcLang, $tgtLang),
            'lingvanex'    => lingvanex_translate_batch($lines, $srcLang, $tgtLang),
            'microsoft'    => microsoft_translate_batch($lines, $srcLang, $tgtLang),
        };
        if ($res['ok']) { $res['engine'] = $engine; return $res; }
        $msg = (string)($res['message'] ?? $res['error'] ?? 'onbekende fout');
        $attempts[$engine] = $msg;
        translate_log_error($srcLang, $tgtLang, $engine, $msg, $context);
        return null;
    };

    if ($canDeepl) {
        $res = $tryEngine('deepl', $lines, $srcLang, $tgtLang);
        if ($res !== null) return $res;

        if ($canTa) {
            $res = $tryEngine('translateapi', $lines, $srcLang, $tgtLang);
            if ($res !== null) return $res;
        }
        if ($canLv) {
            $res = $tryEngine('lingvanex', $lines, $srcLang, $tgtLang);
            if ($res !== null) return $res;
        }
        if ($canMs) {
            $res = $tryEngine('microsoft', $lines, $srcLang, $tgtLang);
            if ($res !== null) return $res;
        }
        return mt_combine_failure($attempts);
    }

    if ($canTa) {
        $res = $tryEngine('translateapi', $lines, $srcLang, $tgtLang);
        if ($res !== null) return $res;

        if ($canLv) {
            $res = $tryEngine('lingvanex', $lines, $srcLang, $tgtLang);
            if ($res !== null) return $res;
        }
        if ($canMs) {
            $res = $tryEngine('microsoft', $lines, $srcLang, $tgtLang);
            if ($res !== null) return $res;
        }
        return mt_combine_failure($attempts);
    }

    if ($canLv) {
        $res = $tryEngine('lingvanex', $lines, $srcLang, $tgtLang);
        if ($res !== null) return $res;

        if ($canMs) {
            $res = $tryEngine('microsoft', $lines, $srcLang, $tgtLang);
            if ($res !== null) return $res;
        }
        return mt_combine_failure($attempts);
    }

    if ($canMs) {
        $res = $tryEngine('microsoft', $lines, $srcLang, $tgtLang);
        if ($res !== null) return $res;
        return mt_combine_failure($attempts);
    }

    if ($srcMeta === null || $tgtMeta === null) {
        $msg = 'Taal wordt door geen van de geconfigureerde vertaalengines ondersteund.';
        translate_log_error($srcLang, $tgtLang, 'none', $msg, $context);
        return ['ok' => false, 'error' => 'badlang', 'message' => $msg];
    }
    $msg = 'Geen vertaalengine geconfigureerd (DeepL, translateapi.ai, Lingvanex of Microsoft Translator).';
    translate_log_error($srcLang, $tgtLang, 'none', $msg, $context);
    return ['ok' => false, 'error' => 'nokey', 'message' => $msg];
}

// Bouwt de uiteindelijke foutmelding wanneer ALLE voor deze batch geprobeerde
// engines zijn mislukt: somt op welke engine wat teruggaf, zodat de
// UI-foutmelding hetzelfde totaalbeeld toont als het logbestand, i.p.v.
// alleen de allereerste fout te tonen.
function mt_combine_failure(array $attempts): array {
    if ($attempts === []) {
        return ['ok' => false, 'error' => 'unknown', 'message' => 'Onbekende vertaalfout.'];
    }
    if (count($attempts) === 1) {
        $engine = array_key_first($attempts);
        return ['ok' => false, 'error' => $engine, 'message' => $attempts[$engine]];
    }
    $parts = [];
    foreach ($attempts as $engine => $msg) {
        $parts[] = tr_engine_label($engine) . ': ' . $msg;
    }
    return ['ok' => false, 'error' => 'allfailed', 'message' => implode(' — ', $parts)];
}

/**
 * Vertaalt een volledig tekstblok (titel of body) met behoud van regelindeling.
 *
 * Werkwijze: splitsen op \n, alleen regels mét letters versturen (in blokken van
 * max 45 regels / ~70 KB ruwe tekst — met wat marge voor de placeholder-
 * bescherming die per engine intern wordt toegepast), inspringing per regel
 * apart bewaren en na de vertaling terugzetten. Zo blijft de nummering
 * ("1.2 ...") en de lay-out van bijlagen exact staan, ook als de vertaalengine
 * zinnen anders verdeelt.
 *
 * $context is een vrije, optionele aanduiding van de aanroeper (bv.
 * "contract:key/article:art1/title", "label:t:summary_heading"), puur voor in
 * translate_error.log wanneer een engine deze batch niet kan vertalen.
 *
 * @return array{ok:bool, text?:string, chars?:int, engine?:?string, error?:string, message?:string}
 */
function deepl_translate_block(string $text, string $srcLang, string $tgtLang, string $context = ''): array {
    if (trim($text) === '') return ['ok' => true, 'text' => $text, 'chars' => 0, 'engine' => null];

    $lines   = explode("\n", str_replace("\r\n", "\n", $text));
    $queue   = [];  // index in $lines => rauwe (onbeschermde) payloadtekst
    $indents = [];  // index in $lines => oorspronkelijke inspringing
    $chars   = 0;

    foreach ($lines as $i => $line) {
        $line = rtrim($line, "\r");
        $lines[$i] = $line;
        if (!deepl_line_translatable($line)) continue;
        preg_match('/^\s*/u', $line, $m);
        $indents[$i] = $m[0] ?? '';
        $payloadLine = ltrim($line);
        $chars      += mb_strlen($payloadLine, 'UTF-8');
        $queue[$i]   = $payloadLine;
    }

    if ($queue === []) return ['ok' => true, 'text' => implode("\n", $lines), 'chars' => 0, 'engine' => null];

    // Blokken: DeepL staat max 50 teksten en ~128 KiB per verzoek toe; de
    // placeholder-bescherming (per engine intern toegepast) voegt daar nog wat
    // bytes aan toe, vandaar de marge t.o.v. die 128 KiB.
    $chunk = [];
    $chunkBytes = 0;
    $usedEngines = [];
    $flush = function (array $chunk) use (&$lines, $indents, $srcLang, $tgtLang, $context, &$usedEngines): ?array {
        if ($chunk === []) return null;
        $res = mt_translate_batch(array_values($chunk), $srcLang, $tgtLang, $context);
        if (!$res['ok']) return $res;
        if (!empty($res['engine'])) $usedEngines[$res['engine']] = true;
        $keys = array_keys($chunk);
        foreach ($res['texts'] as $pos => $translated) {
            $idx = $keys[$pos];
            // De oorspronkelijke inspringing is leidend; whitespace die de
            // vertaalengine zelf toevoegt of weglaat wordt genegeerd.
            $lines[$idx] = ($indents[$idx] ?? '') . trim($translated);
        }
        return null;
    };

    foreach ($queue as $idx => $payload) {
        $len = strlen($payload);
        if (count($chunk) >= 45 || ($chunkBytes + $len) > 70000) {
            $fail = $flush($chunk);
            if ($fail !== null) return $fail;
            $chunk = [];
            $chunkBytes = 0;
        }
        $chunk[$idx] = $payload;
        $chunkBytes += $len;
    }
    $fail = $flush($chunk);
    if ($fail !== null) return $fail;

    $engineCount = count($usedEngines);
    $engine = $engineCount === 1 ? array_key_first($usedEngines) : ($engineCount > 1 ? 'mixed' : null);

    return ['ok' => true, 'text' => implode("\n", $lines), 'chars' => $chars, 'engine' => $engine];
}

// ===============================================================
// VERTAALSTATUS PER ARTIKEL
// ---------------------------------------------------------------
// Elke machinaal gevulde taalvariant krijgt een _mt-blok:
//   "_mt": {"engine":"deepl"|"translateapi"|"lingvanex","src":"en","hash":"<md5 brontekst>","at":"<ISO>"}
// Daarmee weten we of een vertaling nog actueel is (hash gelijk), verouderd
// (bron gewijzigd) of met de hand geschreven (geen _mt aanwezig). Alle drie de
// engines tellen hier als "machinevertaling" — welke van de drie gebruikt is,
// verandert niets aan de actueel/verouderd/handmatig-logica.
// ===============================================================
function deepl_source_hash(array $entry): string {
    return md5(($entry['title'] ?? '') . "\x00" . ($entry['body'] ?? ''));
}

function deepl_entry_status(array $srcEntry, $tgtEntry): string {
    if (!is_array($tgtEntry)) return 'empty';
    $hasText = trim((string)($tgtEntry['title'] ?? '')) !== '' || trim((string)($tgtEntry['body'] ?? '')) !== '';
    if (!$hasText) return 'empty';
    $mt = $tgtEntry['_mt'] ?? null;
    if (!is_array($mt) || !in_array($mt['engine'] ?? '', ['deepl', 'translateapi', 'lingvanex', 'microsoft'], true)) return 'human';
    return ($mt['hash'] ?? '') === deepl_source_hash($srcEntry) ? 'current' : 'stale';
}

// ===============================================================
// HOOFDROUTINE — contractdefinitie vertalen
// ---------------------------------------------------------------
// @return array met per doeltaal de tellingen, plus 'errors', 'written' en
// 'engines' (de set engines die daadwerkelijk gebruikt zijn tijdens deze run).
// ===============================================================
function translate_contract_definition(
    string $key,
    string $srcLang,
    array $targets,
    bool $overwriteHuman = false,
    bool $dryRun = false
): array {
    $stats = ['key' => $key, 'src' => $srcLang, 'targets' => [], 'errors' => [], 'written' => false, 'chars' => 0, 'engines' => []];

    $def = load_contract_definition($key);
    if ($def === null) {
        $stats['errors'][] = 'notfound';
        return $stats;
    }
    if (is_protected_contract($key)) {
        $stats['errors'][] = 'protected';
        return $stats;
    }
    if (!deepl_enabled()) {
        $stats['errors'][] = 'nokey';
        return $stats;
    }
    if (!deepl_lang_known($srcLang)) {
        $stats['errors'][] = 'badsource';
        return $stats;
    }

    $targets = array_values(array_unique(array_filter(
        $targets,
        static fn($l) => is_string($l) && $l !== $srcLang && deepl_lang_known($l)
    )));
    if ($targets === []) {
        $stats['errors'][] = 'notargets';
        return $stats;
    }

    $articles = $def['articles'];
    $changed  = false;

    foreach ($targets as $tgt) {
        $stats['targets'][$tgt] = ['translated' => 0, 'skipped_current' => 0, 'skipped_human' => 0, 'skipped_empty_source' => 0, 'chars' => 0];

        foreach ($articles as $artKey => $byLang) {
            if (!is_array($byLang)) continue;
            $srcEntry = $byLang[$srcLang] ?? null;
            if (!is_array($srcEntry)) { $stats['targets'][$tgt]['skipped_empty_source']++; continue; }

            $srcTitle = (string)($srcEntry['title'] ?? '');
            $srcBody  = (string)($srcEntry['body'] ?? '');
            if (trim($srcTitle) === '' && trim($srcBody) === '') {
                $stats['targets'][$tgt]['skipped_empty_source']++;
                continue;
            }

            $status = deepl_entry_status($srcEntry, $byLang[$tgt] ?? null);
            if ($status === 'current') { $stats['targets'][$tgt]['skipped_current']++; continue; }
            if ($status === 'human' && !$overwriteHuman) { $stats['targets'][$tgt]['skipped_human']++; continue; }

            if ($dryRun) {
                $estimate = deepl_count_chars($srcTitle) + deepl_count_chars($srcBody);
                $stats['targets'][$tgt]['translated']++;
                $stats['targets'][$tgt]['chars'] += $estimate;
                $stats['chars'] += $estimate;
                continue;
            }

            $context = 'contract:' . $key . '/article:' . $artKey;
            $rTitle = deepl_translate_block($srcTitle, $srcLang, $tgt, $context . '/title');
            if (!$rTitle['ok']) {
                $stats['errors'][] = $tgt . '/' . $artKey . ': ' . ($rTitle['message'] ?? 'fout');
                break 2; // bij API-fouten (quota, auth) direct stoppen
            }
            $rBody = deepl_translate_block($srcBody, $srcLang, $tgt, $context . '/body');
            if (!$rBody['ok']) {
                $stats['errors'][] = $tgt . '/' . $artKey . ': ' . ($rBody['message'] ?? 'fout');
                break 2;
            }

            $engine = $rBody['engine'] ?? $rTitle['engine'] ?? 'deepl';
            $articles[$artKey][$tgt] = [
                'title' => $rTitle['text'],
                'body'  => $rBody['text'],
                '_mt'   => [
                    'engine' => $engine,
                    'src'    => $srcLang,
                    'hash'   => deepl_source_hash($srcEntry),
                    'at'     => date('c'),
                ],
            ];
            $changed = true;
            if ($engine) $stats['engines'][$engine] = true;
            $used = (int)($rTitle['chars'] ?? 0) + (int)($rBody['chars'] ?? 0);
            $stats['targets'][$tgt]['translated']++;
            $stats['targets'][$tgt]['chars'] += $used;
            $stats['chars'] += $used;
        }
    }

    if ($dryRun || !$changed) return $stats;

    // Doeltalen toevoegen aan de talenlijst van het contract, volgorde behouden.
    $languages = $def['languages'] ?? ['en'];
    foreach ($targets as $tgt) {
        if (!in_array($tgt, $languages, true)) $languages[] = $tgt;
    }

    $def['languages'] = $languages;
    $def['articles']  = $articles;
    $def['version']   = (int)($def['version'] ?? 0) + 1;

    $stats['written'] = deepl_write_definition($key, $def);
    if (!$stats['written']) $stats['errors'][] = 'write';
    return $stats;
}

/**
 * Schrijft de definitie weg: eerst een back-up van de huidige versie, dan
 * atomisch (tmp + rename) zodat een half geschreven JSON nooit zichtbaar wordt.
 */
function deepl_write_definition(string $key, array $def): bool {
    $encoded = json_encode($def, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) return false;

    if (!is_dir(CONTRACTS_DIR)) @mkdir(CONTRACTS_DIR, 0775, true);

    $path = contract_json_path($key);
    $old  = contract_json_raw($key);
    if ($old !== null) {
        $backupDir = CONTRACTS_DIR . '/.backup';
        if (!is_dir($backupDir)) @mkdir($backupDir, 0775, true);
        @file_put_contents(
            $backupDir . '/' . contract_safe_key($key) . '.' . date('Ymd-His') . '.json',
            $old
        );
    }

    $tmp = $path . '.tmp' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $encoded) === false) return false;
    if (!@rename($tmp, $path)) { @unlink($tmp); return false; }
    return true;
}

// ===============================================================
// UI-TEKSTEN — eigen mini-woordenboek, zodat index.php niet op drie
// plaatsen aangepast hoeft te worden. Verhuizen naar lang_dict_*()
// kan later, de sleutels zijn hetzelfde opgezet.
// ===============================================================
function tr_t(string $k): string {
    $dict = [
        'nl' => [
            'title'        => 'Automatisch vertalen (DeepL + translateapi.ai + Lingvanex + Microsoft Translator)',
            'sub'          => 'Vertaalt alle artikelen van dit contract vanuit de brontaal naar de gekozen doeltalen, via DeepL. Voor talen die DeepL niet kent, of zodra DeepL een fout geeft, springt automatisch translateapi.ai bij; mislukt of kent ook dat de taal niet, dan Lingvanex; lukt ook dat niet, dan ten slotte Microsoft Translator. Placeholders zoals {{P1}} en de regelindeling blijven ongewijzigd.',
            'source'       => 'Brontaal',
            'contractlang' => 'Taal van het contract',
            'targets'      => 'Doeltalen',
            'targets_extra_hint' => 'Talen met dit sterretje (*) kent alleen translateapi.ai, Lingvanex of Microsoft Translator, niet DeepL.',
            'overwrite'    => 'Ook handmatig geschreven vertalingen overschrijven',
            'dry'          => 'Eerst alleen tellen (proefdraaien, geen API-verbruik)',
            'btn'          => 'Vertalen',
            'nokey'        => 'Geen DeepL-, translateapi.ai-, Lingvanex- of Microsoft Translator-sleutel gevonden. Zet DEEPL_API_KEY / TRANSLATEAPI_KEY / LINGVANEX_API_KEY / MICROSOFT_TRANSLATOR_KEY in de omgeving, of maak deepl.config.php / translateapi.config.php / lingvanex.config.php / microsoft.config.php aan.',
            'protected'    => 'Dit contract is beschermd en kan niet worden vertaald. Maak eerst een kloon.',
            'usage'        => 'DeepL-verbruik',
            'legal'        => 'Let op: een machinevertaling is geen rechtsgeldige vertaling. Laat de tekst juridisch nakijken en leg vast welke taalversie leidend is.',
            'impact'       => 'Het vertalen verhoogt het versienummer van contracts/%s.json. Contracten die eerder met dit contract zijn gegenereerd en later opnieuw uit de payload worden opgebouwd, volgen de nieuwe tekst.',
            'done'         => 'Vertaling afgerond: %d artikelen vertaald, %d al actueel, %d handmatig (overgeslagen), %s tekens verstuurd.',
            'dryresult'    => 'Proefdraai: %d artikelen zouden vertaald worden, %s tekens.',
            'error'        => 'Vertalen mislukt: %s',
            'engines_used' => 'Gebruikte vertaalengine(s): %s.',
            'status_head'  => 'Status per taal',
            'st_current'   => 'actueel',
            'st_stale'     => 'bron gewijzigd',
            'st_human'     => 'handmatig',
            'st_empty'     => 'leeg',
            'health_title' => 'Online/offline per vertaalengine (nu getest)',
            'health_hint'  => 'Online = zojuist getest en er is nog tegoed. Offline = geen sleutel ingesteld, of de test laat zien dat het tegoed op is / de sleutel niet werkt. De regel "laatste fout uit log" eronder is alleen ter info uit translate_error.log en bepaalt de status zelf niet.',
            'status_online'  => 'Online',
            'status_offline' => 'Offline',
            'health_log_last' => 'Laatste fout uit log (%s): %s',
        ],
        'de' => [
            'title'        => 'Automatisch übersetzen (DeepL + translateapi.ai + Lingvanex + Microsoft Translator)',
            'sub'          => 'Übersetzt alle Artikel dieses Vertrags aus der Ausgangssprache in die gewählten Zielsprachen, über DeepL. Für Sprachen, die DeepL nicht kennt, oder sobald DeepL einen Fehler liefert, springt automatisch translateapi.ai ein; schlägt auch das fehl oder kennt die Sprache nicht, Lingvanex; schlägt auch das fehl, schließlich Microsoft Translator. Platzhalter wie {{P1}} und die Zeilenstruktur bleiben unverändert.',
            'source'       => 'Ausgangssprache',
            'contractlang' => 'Vertragssprache',
            'targets'      => 'Zielsprachen',
            'targets_extra_hint' => 'Sprachen mit diesem Sternchen (*) kennt nur translateapi.ai, Lingvanex oder Microsoft Translator, nicht DeepL.',
            'overwrite'    => 'Auch manuell geschriebene Übersetzungen überschreiben',
            'dry'          => 'Zuerst nur zählen (Probelauf, kein API-Verbrauch)',
            'btn'          => 'Übersetzen',
            'nokey'        => 'Kein DeepL-, translateapi.ai-, Lingvanex- oder Microsoft-Translator-Schlüssel gefunden. Setzen Sie DEEPL_API_KEY / TRANSLATEAPI_KEY / LINGVANEX_API_KEY / MICROSOFT_TRANSLATOR_KEY oder legen Sie deepl.config.php / translateapi.config.php / lingvanex.config.php / microsoft.config.php an.',
            'protected'    => 'Dieser Vertrag ist geschützt und kann nicht übersetzt werden. Erstellen Sie zuerst einen Klon.',
            'usage'        => 'DeepL-Verbrauch',
            'legal'        => 'Hinweis: Eine maschinelle Übersetzung ist keine rechtsverbindliche Übersetzung. Lassen Sie den Text juristisch prüfen und halten Sie fest, welche Sprachfassung maßgeblich ist.',
            'impact'       => 'Die Übersetzung erhöht die Versionsnummer von contracts/%s.json. Bereits erzeugte Verträge, die später erneut aus der Payload aufgebaut werden, folgen dem neuen Text.',
            'done'         => 'Übersetzung fertig: %d Artikel übersetzt, %d bereits aktuell, %d manuell (übersprungen), %s Zeichen gesendet.',
            'dryresult'    => 'Probelauf: %d Artikel würden übersetzt, %s Zeichen.',
            'error'        => 'Übersetzung fehlgeschlagen: %s',
            'engines_used' => 'Verwendete Übersetzungsengine(s): %s.',
            'status_head'  => 'Status je Sprache',
            'st_current'   => 'aktuell',
            'st_stale'     => 'Quelle geändert',
            'st_human'     => 'manuell',
            'st_empty'     => 'leer',
        ],
        'en' => [
            'title'        => 'Automatic translation (DeepL + translateapi.ai + Lingvanex + Microsoft Translator)',
            'sub'          => 'Translates every article of this contract from the source language into the selected target languages, via DeepL. For languages DeepL does not know, or whenever DeepL returns an error, translateapi.ai steps in automatically; if that also fails or does not know the language either, Lingvanex is tried; if that also fails, Microsoft Translator is used as the last resort. Placeholders such as {{P1}} and the line layout stay untouched.',
            'source'       => 'Source language',
            'contractlang' => 'Contract language',
            'targets'      => 'Target languages',
            'targets_extra_hint' => 'Languages marked with an asterisk (*) are only known to translateapi.ai, Lingvanex or Microsoft Translator, not DeepL.',
            'overwrite'    => 'Also overwrite hand-written translations',
            'dry'          => 'Count only first (dry run, no API usage)',
            'btn'          => 'Translate',
            'nokey'        => 'No DeepL, translateapi.ai, Lingvanex or Microsoft Translator key found. Set DEEPL_API_KEY / TRANSLATEAPI_KEY / LINGVANEX_API_KEY / MICROSOFT_TRANSLATOR_KEY in the environment or create deepl.config.php / translateapi.config.php / lingvanex.config.php / microsoft.config.php.',
            'protected'    => 'This contract is protected and cannot be translated. Create a clone first.',
            'usage'        => 'DeepL usage',
            'legal'        => 'Note: a machine translation is not a legally binding translation. Have the text reviewed and record which language version prevails.',
            'impact'       => 'Translating increments the version of contracts/%s.json. Contracts generated earlier and later rebuilt from their payload will follow the new text.',
            'done'         => 'Translation finished: %d articles translated, %d already current, %d hand-written (skipped), %s characters sent.',
            'dryresult'    => 'Dry run: %d articles would be translated, %s characters.',
            'error'        => 'Translation failed: %s',
            'engines_used' => 'Translation engine(s) used: %s.',
            'status_head'  => 'Status per language',
            'st_current'   => 'current',
            'st_stale'     => 'source changed',
            'st_human'     => 'hand-written',
            'st_empty'     => 'empty',
            'health_title' => 'Online/offline per translation engine (tested now)',
            'health_hint'  => 'Online = just tested and credit is still available. Offline = no key configured, or the test shows the credit is used up / the key does not work. The "last error from log" line below is informational only (from translate_error.log) and does not decide the status itself.',
            'status_online'  => 'Online',
            'status_offline' => 'Offline',
            'health_log_last' => 'Last error from log (%s): %s',
        ],
    ];
    $lang = function_exists('current_lang') ? current_lang() : 'en';
    return $dict[$lang][$k] ?? ($dict['en'][$k] ?? $k);
}

// Leesbare naam voor een engine-sleutel ('deepl'/'translateapi'/'lingvanex'/
// 'mixed'/'none'), gebruikt in het "gebruikte engine(s)"-regeltje na een
// vertaalronde en in de gecombineerde foutmelding van mt_combine_failure().
function tr_engine_label(string $engine): string {
    return match ($engine) {
        'deepl'        => 'DeepL',
        'translateapi' => 'translateapi.ai',
        'lingvanex'    => 'Lingvanex',
        'microsoft'    => 'Microsoft Translator',
        'mixed'        => 'DeepL + translateapi.ai + Lingvanex + Microsoft Translator',
        'none'         => '—',
        default        => $engine,
    };
}

// ===============================================================
// GEZONDHEIDSCHECK — live API-test per vertaalengine: ONLINE/OFFLINE
// ---------------------------------------------------------------
// Op verzoek: vóórdat de pagina verder gaat (index.php roept
// translate_engines_health_check() aan meteen bij het inladen, ná de
// POST-/AJAX-afhandeling maar vóór de HTML-uitvoer), wordt voor ELK van de
// vier vertaalengines — DeepL, translateapi.ai, Lingvanex, Microsoft
// Translator — een status bepaald:
//   ONLINE  = de engine is geconfigureerd (heeft een sleutel) EN de zojuist
//             uitgevoerde, ECHTE API-aanroep laat zien dat er nog tegoed is.
//   OFFLINE = ofwel er is helemaal geen sleutel voor deze engine ingesteld,
//             ofwel de echte API-aanroep faalde — meestal doordat het
//             tegoed op is (HTTP 402, "quota"), maar evengoed door een
//             ongeldige sleutel of een netwerk-/serverfout: in alle gevallen
//             kan deze engine op dit moment niet daadwerkelijk vertalen.
//
// Dit is bewust GEEN afgeleide van translate_error.log: dat logbestand
// toont alleen mislukkingen die toevallig al zijn opgetreden tijdens
// eerder gebruik (bv. het genereren van een contract) en geeft geen
// actuele status als er sindsdien niets meer is aangeroepen, of andersom:
// een oude fout erin kan intussen allang zijn opgelost (nieuwe sleutel,
// tegoed bijgekocht) zonder dat het log dat ooit "rechtzet". Een live test
// is dus valider dan het log lezen. Het logbestand wordt er wél NAAST
// getoond (zie translate_error_log_recent() hieronder) als aanvullende,
// puur informatieve context — bv. "laatste keer dat dit misging" — maar
// bepaalt nooit zelf de ONLINE/OFFLINE-status.
//
// Per engine:
//  - DeepL: GET /v2/usage (deepl_usage()) — bestaand, kosteloos endpoint
//    (verbruikt geen vertaal-tekenquotum), valideert sleutel + bereikbaarheid
//    en levert meteen count/limit; OFFLINE zodra count >= limit (limit > 0).
//  - translateapi.ai / Lingvanex / Microsoft Translator: geen van drie heeft
//    in deze integratie een gratis "ping"/usage-endpoint, dus daar wordt één
//    minimale ECHTE vertaling ("Test", EN->NL) gedaan — de enige manier om
//    een 402/quotumfout (zoals translateapi.ai hierboven al meermaals gaf,
//    zie translate_error.log) daadwerkelijk vooraf te zien, in plaats van
//    pas wanneer een gebruiker een heel contract wil vertalen.
//
// Om niet bij ELKE paginaverversing opnieuw een stukje van het (mogelijk
// toch al schaarse) tegoed te verbruiken, wordt de uitslag van een
// GECONFIGUREERDE engine ENGINE_HEALTH_TTL seconden gecached in
// i18n_cache/_engine_health.json (zelfde atomic-write-patroon als de
// labelcache hierboven). Een engine zonder sleutel kost geen netwerkaanroep
// en wordt daarom nooit gecached — dat resultaat (OFFLINE, "geen sleutel")
// staat toch al meteen vast. "Vooraf bij het inladen" blijft dus een ECHTE,
// actuele test — alleen niet noodzakelijk bij elke losse HTTP-request
// binnen dezelfde paar minuten.
// ===============================================================
define('ENGINE_HEALTH_CACHE_FILE', __DIR__ . '/i18n_cache/_engine_health.json');
define('ENGINE_HEALTH_TTL', 300); // 5 minuten

// Vaste volgorde waarin de vier engines altijd getoond worden, ongeacht
// welke wel/niet geconfigureerd zijn.
function engine_health_all_keys(): array {
    return ['deepl', 'translateapi', 'lingvanex', 'microsoft'];
}

function engine_health_read_cache(): array {
    if (!is_file(ENGINE_HEALTH_CACHE_FILE)) return [];
    $raw = @file_get_contents(ENGINE_HEALTH_CACHE_FILE);
    if ($raw === false || trim($raw) === '') return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function engine_health_write_cache(array $data): void {
    $dir = dirname(ENGINE_HEALTH_CACHE_FILE);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $encoded = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) return;
    $tmp = ENGINE_HEALTH_CACHE_FILE . '.tmp' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $encoded) === false) return;
    if (!@rename($tmp, ENGINE_HEALTH_CACHE_FILE)) @unlink($tmp);
}

// Test één GECONFIGUREERDE engine (de aanroeper heeft *_enabled() al
// gecontroleerd). Geeft altijd terug:
// ['online'=>bool, 'configured'=>true, 'message'=>string, 'checked_at'=>int].
function engine_health_probe(string $engine): array {
    $now = time();
    switch ($engine) {
        case 'deepl':
            $usage = deepl_usage();
            if ($usage === null) {
                // deepl_usage() geeft alleen null terug bij een mislukte aanroep
                // (geen sleutel/curl, of de HTTP-aanroep zelf faalde) — haal die
                // aanroep hier los nog eens op voor een bruikbare foutmelding.
                $res = deepl_http('/v2/usage', []);
                $msg = trim((string)($res['message'] ?? '')) !== '' ? (string)$res['message'] : 'DeepL: onbekende fout.';
                return ['online' => false, 'configured' => true, 'message' => $msg, 'checked_at' => $now];
            }
            if ($usage['limit'] > 0 && $usage['count'] >= $usage['limit']) {
                return [
                    'online' => false,
                    'configured' => true,
                    'message' => 'Tegoed op: ' . number_format($usage['count'], 0, ',', '.')
                        . ' / ' . number_format($usage['limit'], 0, ',', '.') . ' tekens gebruikt.',
                    'checked_at' => $now,
                ];
            }
            $countLabel = number_format($usage['count'], 0, ',', '.')
                . ($usage['limit'] > 0 ? ' / ' . number_format($usage['limit'], 0, ',', '.') : '');
            return ['online' => true, 'configured' => true, 'message' => 'Tegoed beschikbaar (' . $countLabel . ' tekens).', 'checked_at' => $now];

        case 'translateapi':
            $res = translateapi_translate_batch(['Test'], 'en', 'nl');
            $ok  = (bool)($res['ok'] ?? false);
            return [
                'online'     => $ok,
                'configured' => true,
                'message'    => $ok ? 'Tegoed beschikbaar.' : (trim((string)($res['message'] ?? '')) !== '' ? (string)$res['message'] : 'translateapi.ai: onbekende fout.'),
                'checked_at' => $now,
            ];

        case 'lingvanex':
            $res = lingvanex_translate_batch(['Test'], 'en', 'nl');
            $ok  = (bool)($res['ok'] ?? false);
            return [
                'online'     => $ok,
                'configured' => true,
                'message'    => $ok ? 'Tegoed beschikbaar.' : (trim((string)($res['message'] ?? '')) !== '' ? (string)$res['message'] : 'Lingvanex: onbekende fout.'),
                'checked_at' => $now,
            ];

        case 'microsoft':
            $res = microsoft_translate_batch(['Test'], 'en', 'nl');
            $ok  = (bool)($res['ok'] ?? false);
            return [
                'online'     => $ok,
                'configured' => true,
                'message'    => $ok ? 'Tegoed beschikbaar.' : (trim((string)($res['message'] ?? '')) !== '' ? (string)$res['message'] : 'Microsoft Translator: onbekende fout.'),
                'checked_at' => $now,
            ];

        default:
            return ['online' => false, 'configured' => false, 'message' => 'Onbekende engine.', 'checked_at' => $now];
    }
}

/**
 * Live ONLINE/OFFLINE-check van ALLE VIER de vertaalengines (DeepL,
 * translateapi.ai, Lingvanex, Microsoft Translator) — ook de engines zonder
 * sleutel worden getoond (als OFFLINE, "geen sleutel geconfigureerd"), zodat
 * altijd alle vier zichtbaar zijn. Geeft een array terug, sleutel = engine,
 * waarde = ['online'=>bool, 'configured'=>bool, 'message'=>string,
 * 'checked_at'=>int].
 *
 * Alleen GECONFIGUREERDE engines doen een echte (netwerk)aanroep, en die
 * wordt ENGINE_HEALTH_TTL seconden gecached. Een niet-geconfigureerde engine
 * kost geen aanroep en wordt bij elke keer opnieuw (kosteloos) vastgesteld.
 *
 * $force=true negeert de cache en test elke geconfigureerde engine opnieuw
 * (bv. voor een handmatige "nu testen"-actie).
 */
function translate_engines_health_check(bool $force = false): array {
    $cache = $force ? [] : engine_health_read_cache();
    $now   = time();
    $isConfigured = [
        'deepl'        => deepl_key_enabled(),
        'translateapi' => translateapi_enabled(),
        'lingvanex'    => lingvanex_enabled(),
        'microsoft'    => microsoft_enabled(),
    ];

    $result  = [];
    $changed = false;
    foreach (engine_health_all_keys() as $engine) {
        if (!$isConfigured[$engine]) {
            $result[$engine] = ['online' => false, 'configured' => false, 'message' => 'Geen sleutel geconfigureerd.', 'checked_at' => $now];
            continue;
        }
        $cached = $cache[$engine] ?? null;
        if (!$force && is_array($cached) && !empty($cached['configured']) && ($now - (int)($cached['checked_at'] ?? 0)) < ENGINE_HEALTH_TTL) {
            $result[$engine] = $cached;
            continue;
        }
        $result[$engine] = engine_health_probe($engine);
        $changed = true;
    }

    if ($changed) engine_health_write_cache($result);
    return $result;
}

// True zodra minstens één GECONFIGUREERDE engine OFFLINE is (tegoed op,
// ongeldige sleutel, netwerkfout, ...). Een engine die simpelweg nooit een
// sleutel heeft gekregen (bv. Microsoft, zie microsoft.config.php) telt hier
// niet als "probleem" — dat is een bewuste configuratiekeuze, geen storing.
// Gebruikt voor de waarschuwingsbalk bovenaan elke pagina in index.php.
function translate_engines_have_problem(array $health): bool {
    foreach ($health as $status) {
        if (!empty($status['configured']) && empty($status['online'])) return true;
    }
    return false;
}

// ===============================================================
// FOUTENLOG ALS AANVULLENDE CONTEXT — laatste bekende regel per engine uit
// translate_error.log, puur ter INFORMATIE naast de live ONLINE/OFFLINE-
// status hierboven (die blijft bepalend; zie de toelichting bovenaan dit
// blok). Nuttig om te laten zien WANNEER en met welke foutmelding een engine
// voor het laatst misging tijdens echt gebruik (contractgeneratie, labels,
// presets, PDF-vertaling, ...), ook als die engine op dit moment weer
// ONLINE test.
//
// Leest alleen het STAARTJE van het bestand (default: laatste 2 MB), zodat
// een groot logbestand niet bij elke paginaweergave volledig wordt
// ingelezen. $maxLines begrenst daarna het aantal regels dat daadwerkelijk
// wordt geparsed.
// ===============================================================
function translate_error_log_tail_lines(int $maxLines = 2000, int $maxBytes = 2097152): array {
    $path = defined('TRANSLATE_ERROR_LOG') ? TRANSLATE_ERROR_LOG : (__DIR__ . '/translate_error.log');
    if (!is_file($path)) return [];

    $size = @filesize($path);
    if ($size === false || $size === 0) return [];

    $fh = @fopen($path, 'rb');
    if ($fh === false) return [];

    $readBytes = $size > $maxBytes ? $maxBytes : $size;
    if ($readBytes > 0 && $readBytes < $size) {
        fseek($fh, -$readBytes, SEEK_END);
    }
    $chunk = stream_get_contents($fh);
    fclose($fh);
    if (!is_string($chunk) || $chunk === '') return [];

    $lines = explode("\n", str_replace("\r\n", "\n", $chunk));
    // Als er minder is ingelezen dan de bestandsgrootte, is de EERSTE regel
    // vrijwel zeker halverwege afgekapt — die negeren we.
    if ($readBytes < $size && $lines !== []) array_shift($lines);

    $lines = array_values(array_filter($lines, static fn(string $l): bool => trim($l) !== ''));
    if (count($lines) > $maxLines) $lines = array_slice($lines, -$maxLines);
    return $lines;
}

// Meest recente loggegel per engine ('deepl'/'translateapi'/'lingvanex'/
// 'microsoft'), geparsed uit het formaat dat translate_log_error() schrijft:
// "[iso-tijd] lang=SRC->TGT engine=<engine> [context=...] message=...".
// Geeft terug: engine => ['ts'=>string, 'message'=>string]. Een engine
// zonder regel in het (gelezen deel van het) log ontbreekt gewoon in de
// uitkomst.
function translate_error_log_recent(): array {
    $lines = translate_error_log_tail_lines();
    $out = [];
    // Van nieuw naar oud doorlopen: de EERSTE match per engine is de meest
    // recente — zodra alle vier gevonden zijn (of de regels op zijn) stoppen.
    for ($i = count($lines) - 1; $i >= 0 && count($out) < 4; $i--) {
        if (!preg_match(
            '/^\[(?P<ts>[^\]]+)\]\s+lang=(?P<lang>\S+)\s+engine=(?P<engine>\S+)(?:\s+context=(?P<context>\S+))?\s+message=(?P<message>.*)$/',
            $lines[$i],
            $m
        )) continue;

        $engine = strtolower(trim($m['engine']));
        if ($engine === '' || isset($out[$engine])) continue;

        $out[$engine] = ['ts' => (string)$m['ts'], 'message' => trim((string)$m['message'])];
    }
    return $out;
}

// ===============================================================
// POST-AFHANDELING — action=translate_contract
// Wordt aangeroepen vanuit het POST-blok van index.php.
// ===============================================================
function handle_contract_translate_post(): void {
    $key     = contract_safe_key((string)($_POST['key'] ?? ''));
    $srcLang = (string)($_POST['src_lang'] ?? 'en');
    $targets = $_POST['tgt_lang'] ?? [];
    $targets = is_array($targets) ? array_map('strval', $targets) : [];
    $over    = !empty($_POST['overwrite_human']);
    $dry     = !empty($_POST['dry_run']);

    $back = static function (array $params) use ($key): void {
        $params = array_merge(['tab' => 'config', 'lang' => current_lang(), 'key' => $key], $params);
        header('Location: ?' . http_build_query($params));
        exit;
    };

    $stats = translate_contract_definition($key, $srcLang, $targets, $over, $dry);

    if ($stats['errors'] !== []) {
        $back(['mterror' => substr((string)$stats['errors'][0], 0, 200)]);
    }

    $translated = 0; $current = 0; $human = 0;
    foreach ($stats['targets'] as $t) {
        $translated += $t['translated'];
        $current    += $t['skipped_current'];
        $human      += $t['skipped_human'];
    }

    $back([
        'mt'     => $dry ? 'dry' : 'ok',
        'mt_t'   => $translated,
        'mt_c'   => $current,
        'mt_h'   => $human,
        'mt_ch'  => $stats['chars'],
        'mt_eng' => implode(',', array_keys($stats['engines'] ?? [])),
    ]);
}

// ===============================================================
// UI — paneel in het tabblad "Configuratie contracten"
// ===============================================================
function render_contract_translate_panel(string $key, ?array $def, bool $isProtected): string {
    if ($def === null) return '';

    $langs   = deepl_languages_sorted();
    $defined = $def['languages'] ?? ['en'];
    $srcDefault = in_array('en', $defined, true) ? 'en' : (string)($defined[0] ?? 'en');
    $hasExtraLangs = false;
    foreach ($langs as $meta) { if (($meta['engine'] ?? 'deepl') !== 'deepl') { $hasExtraLangs = true; break; } }

    // $defined zelf staat in de volgorde van het JSON-bestand (contracts/<key>.json),
    // niet alfabetisch — sorteer een kopie op dezelfde (Nederlandse) taalnaam als
    // de rest van de lijst, zodat de brontaal-keuzelijst hieronder ook A-Z loopt.
    $definedSorted = $defined;
    usort($definedSorted, function ($a, $b) use ($langs): int {
        return strnatcasecmp((string)($langs[$a]['label'] ?? $a), (string)($langs[$b]['label'] ?? $b));
    });

    ob_start(); ?>
    <div class="panel">
      <div class="section-title" style="font-size:15px;margin-top:0;"><?= e(tr_t('title')) ?></div>
      <p style="margin-bottom:14px;"><?= e(tr_t('sub')) ?></p>

      <?php if (!empty($_GET['mterror'])): ?>
        <div class="message danger"><?= e(sprintf(tr_t('error'), (string)$_GET['mterror'])) ?></div>
      <?php elseif (($_GET['mt'] ?? '') === 'ok'): ?>
        <div class="message">
          <?= e(sprintf(
            tr_t('done'),
            (int)($_GET['mt_t'] ?? 0),
            (int)($_GET['mt_c'] ?? 0),
            (int)($_GET['mt_h'] ?? 0),
            number_format((int)($_GET['mt_ch'] ?? 0), 0, ',', '.')
          )) ?>
          <?php $mtEng = trim((string)($_GET['mt_eng'] ?? '')); if ($mtEng !== ''): ?>
            <br><small><?= e(sprintf(tr_t('engines_used'), implode(', ', array_map('tr_engine_label', explode(',', $mtEng))))) ?></small>
          <?php endif; ?>
        </div>
      <?php elseif (($_GET['mt'] ?? '') === 'dry'): ?>
        <div class="message"><?= e(sprintf(
            tr_t('dryresult'),
            (int)($_GET['mt_t'] ?? 0),
            number_format((int)($_GET['mt_ch'] ?? 0), 0, ',', '.')
        )) ?></div>
      <?php endif; ?>

      <?php if ($isProtected): ?>
        <div class="message"><?= e(tr_t('protected')) ?></div>
      <?php elseif (!deepl_enabled()): ?>
        <div class="message danger"><?= e(tr_t('nokey')) ?></div>
      <?php else: ?>

        <div class="message" style="margin-bottom:14px;"><?= e(tr_t('legal')) ?></div>

        <?php
        $__health  = translate_engines_health_check();
        $__logInfo = translate_error_log_recent();
        if ($__health !== []): ?>
          <div class="panel" style="margin-bottom:14px;padding:10px 14px;">
            <div style="font-weight:600;font-size:12.5px;margin-bottom:6px;"><?= e(tr_t('health_title')) ?></div>
            <?php foreach ($__health as $__eng => $__st): $__online = !empty($__st['online']); $__log = $__logInfo[$__eng] ?? null; ?>
              <div style="margin-bottom:6px;">
                <div class="row" style="font-size:12.5px;">
                  <span class="label"><?= e(tr_engine_label((string)$__eng)) ?></span>
                  <code style="color:<?= $__online ? '#2a7a4d' : '#c0392b' ?>;font-weight:600;">
                    <?= $__online ? '&#9679; ' . e(tr_t('status_online')) : '&#9679; ' . e(tr_t('status_offline')) ?>
                  </code>
                  <span style="font-size:11.5px;color:var(--ink-3,#666);"><?= e((string)($__st['message'] ?? '')) ?></span>
                </div>
                <?php if ($__log !== null): ?>
                  <div style="font-size:11px;color:var(--ink-4,#888);margin-left:2px;">
                    <?= e(sprintf(tr_t('health_log_last'), (string)$__log['ts'], (string)$__log['message'])) ?>
                  </div>
                <?php endif; ?>
              </div>
            <?php endforeach; unset($__eng, $__st, $__online, $__log); ?>
            <p style="margin:6px 0 0;font-size:11px;color:var(--ink-4,#888);"><?= e(tr_t('health_hint')) ?></p>
          </div>
        <?php endif; ?>

        <?php
        // Quotum alleen opvragen ná een vertaalronde: dat scheelt een API-call
        // bij elke keer dat het configuratietabblad wordt geopend. (Alleen
        // DeepL heeft een gedocumenteerde quotum-endpoint.)
        $usage = (isset($_GET['mt']) && deepl_key_enabled()) ? deepl_usage() : null;
        if ($usage !== null && $usage['limit'] > 0): ?>
          <div class="row">
            <span class="label"><?= e(tr_t('usage')) ?></span>
            <code><?= e(number_format($usage['count'], 0, ',', '.') . ' / ' . number_format($usage['limit'], 0, ',', '.')) ?></code>
          </div>
        <?php endif; ?>

        <form method="post">
          <input type="hidden" name="action" value="translate_contract">
          <input type="hidden" name="key" value="<?= e($key) ?>">

          <div class="form-group">
            <label><?= e(tr_t('source')) ?></label>
            <select name="src_lang">
              <?php foreach ($definedSorted as $l): if (!isset($langs[$l])) continue; ?>
                <option value="<?= e($l) ?>" <?= $l === $srcDefault ? 'selected' : '' ?>>
                  <?= e(strtoupper($l) . ' — ' . deepl_lang_label($l)) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label><?= e(tr_t('targets')) ?></label>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:6px;">
              <?php foreach ($langs as $code => $meta): ?>
                <label style="font-weight:400;display:flex;align-items:center;gap:6px;">
                  <input type="checkbox" name="tgt_lang[]" value="<?= e($code) ?>"
                         <?= in_array($code, $defined, true) && $code !== $srcDefault ? 'checked' : '' ?>>
                  <span><?= e(strtoupper($code)) ?> — <?= e($meta['label']) ?><?= ($meta['engine'] ?? 'deepl') !== 'deepl' ? ' *' : '' ?></span>
                </label>
              <?php endforeach; ?>
            </div>
            <?php if ($hasExtraLangs): ?>
              <p style="margin:6px 0 0;font-size:12px;color:var(--ink-3,#666);"><?= e(tr_t('targets_extra_hint')) ?></p>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label style="font-weight:400;display:flex;align-items:center;gap:6px;">
              <input type="checkbox" name="overwrite_human" value="1">
              <span><?= e(tr_t('overwrite')) ?></span>
            </label>
            <label style="font-weight:400;display:flex;align-items:center;gap:6px;">
              <input type="checkbox" name="dry_run" value="1" checked>
              <span><?= e(tr_t('dry')) ?></span>
            </label>
          </div>

          <p style="margin:10px 0;"><?= e(sprintf(tr_t('impact'), $key)) ?></p>

          <div style="text-align:right;">
            <button type="submit" class="btn btn-gold"><?= e(tr_t('btn')) ?></button>
          </div>
        </form>

        <?= render_translation_status_table($def) ?>

      <?php endif; ?>
    </div>
    <?php
    return (string)ob_get_clean();
}

// Overzicht: per taal hoeveel artikelen actueel / verouderd / handmatig / leeg zijn.
function render_translation_status_table(array $def): string {
    $defined = $def['languages'] ?? ['en'];
    $src     = in_array('en', $defined, true) ? 'en' : (string)($defined[0] ?? 'en');
    $rows    = [];

    // Alfabetisch op (Nederlandse) taalnaam, net als de andere taallijsten in
    // de interface, i.p.v. de opslagvolgorde uit het JSON-bestand.
    usort($defined, function ($a, $b): int {
        return strnatcasecmp(deepl_lang_label((string)$a), deepl_lang_label((string)$b));
    });

    foreach ($defined as $l) {
        if ($l === $src) continue;
        $c = ['current' => 0, 'stale' => 0, 'human' => 0, 'empty' => 0];
        foreach ($def['articles'] as $byLang) {
            if (!is_array($byLang) || !is_array($byLang[$src] ?? null)) continue;
            $c[deepl_entry_status($byLang[$src], $byLang[$l] ?? null)]++;
        }
        $rows[$l] = $c;
    }
    if ($rows === []) return '';

    ob_start(); ?>
    <div style="margin-top:18px;">
      <div class="section-title" style="font-size:13px;"><?= e(tr_t('status_head')) ?></div>
      <?php foreach ($rows as $l => $c): ?>
        <div class="row">
          <span class="label"><?= e(strtoupper($l)) ?></span>
          <code><?= e(sprintf(
            '%d %s · %d %s · %d %s · %d %s',
            $c['current'], tr_t('st_current'),
            $c['stale'],   tr_t('st_stale'),
            $c['human'],   tr_t('st_human'),
            $c['empty'],   tr_t('st_empty')
          )) ?></code>
        </div>
      <?php endforeach; ?>
    </div>
    <?php
    return (string)ob_get_clean();
}

// ===============================================================
// CONTRACTTAAL BIJ GENEREREN
// ---------------------------------------------------------------
// De interface is EN/NL/DE, maar een contract kan na vertaling meer talen
// bevatten. Deze twee functies koppelen de uitvoertaal los van de UI-taal:
// contract_output_lang() bepaalt de taal voor het record (en dus de payload),
// render_contract_lang_selector() tekent de keuzelijst in "Nieuw contract".
// ===============================================================
function contract_output_lang(string $contractKey): string {
    $langs = contract_definition_languages($contractKey);
    if (!is_array($langs) || $langs === []) $langs = ['en'];

    $req = (string)($_POST['contract_lang'] ?? '');
    if ($req !== '' && in_array($req, $langs, true)) return $req;

    $ui = current_lang();
    return in_array($ui, $langs, true) ? $ui : (string)($langs[0] ?? 'en');
}

function render_contract_lang_selector(): string {
    $map = [];
    foreach (array_keys(list_available_contracts()) as $k) {
        $langs = contract_definition_languages($k);
        $map[$k] = array_values(array_filter(is_array($langs) ? $langs : [], 'is_string'));
    }
    if ($map === []) return '';

    $labels = [];
    foreach ($map as $langs) {
        foreach ($langs as $l) $labels[$l] = deepl_lang_label($l);
    }
    $ui = current_lang();

    ob_start(); ?>
    <div class="form-group" id="contractLangGroup">
      <label><?= e(tr_t('contractlang')) ?></label>
      <select name="contract_lang" id="contractLangSelect"></select>
    </div>
    <script>
    (function() {
      'use strict';
      var MAP    = <?= json_encode($map, JSON_UNESCAPED_UNICODE) ?>;
      var LABELS = <?= json_encode($labels, JSON_UNESCAPED_UNICODE) ?>;
      var UI     = <?= json_encode($ui) ?>;
      var pick   = document.querySelector('select[name="safeguard"]');
      var sel    = document.getElementById('contractLangSelect');
      var group  = document.getElementById('contractLangGroup');
      if (!pick || !sel || !group) return;

      function fill() {
        var langs = (MAP[pick.value] || ['en']).slice();
        // Alfabetisch op (Nederlandse) taalnaam, net als de andere taallijsten
        // in de interface, i.p.v. de opslagvolgorde uit het JSON-bestand.
        langs.sort(function(a, b) {
          return (LABELS[a] || a).localeCompare(LABELS[b] || b, 'nl', { sensitivity: 'base' });
        });
        var keep  = sel.value;
        sel.innerHTML = '';
        langs.forEach(function(l) {
          var o = document.createElement('option');
          o.value = l;
          o.textContent = l.toUpperCase() + ' — ' + (LABELS[l] || l);
          sel.appendChild(o);
        });
        // Voorkeur: eerdere keuze, anders de UI-taal, anders de eerste taal.
        if (langs.indexOf(keep) >= 0)    sel.value = keep;
        else if (langs.indexOf(UI) >= 0) sel.value = UI;
        // Eén taal beschikbaar? Dan is de keuze niet interessant.
        group.style.display = langs.length > 1 ? '' : 'none';
      }

      pick.addEventListener('change', fill);
      fill();
    })();
    </script>
    <?php
    return (string)ob_get_clean();
}

// Zelf-registratie: als index.php ons vóór zijn eigen POST-afhandeling inlaadt,
// pakken we action=translate_contract hier al op.
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['action'] ?? '') === 'translate_contract') {
    handle_contract_translate_post();
}