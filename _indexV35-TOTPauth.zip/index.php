<?php
/**
 * Contract register — pure MD5 her-generatie + digitale handtekening.
 * Single-file build: language dictionaries + sample data embedded (EN + NL).
 *
 * Concept:
 *  - Alle velden + handtekeningen → JSON → gzcompress → base64 = PAYLOAD
 *  - MD5 = md5(PAYLOAD)
 *  - Contract wordt NIET opgeslagen (geen disk, geen database)
 *  - Her-generatie: plak PAYLOAD + MD5 → 1-op-1 reconstructie (identieke MD5)
 *  - Handtekeningen (base64 PNG) zitten ín de payload
 *
 * Taal:
 *  - De webinterface zelf (tabbladen, knoppen, labels) is UITSLUITEND
 *    Nederlands — er is geen taalkeuze meer voor de interface.
 *  - Alles wordt geregistreerd in de brontaal Nederlands (contracten en
 *    presets krijgen lang='nl'). Via de "Vertalen"-knoppen (DeepL) worden
 *    contracten en presets vanuit het Nederlands vertaald naar Engels,
 *    Duits, Frans en Spaans — dat blijft ongewijzigd bestaan.
 */

declare(strict_types=1);

// TOTP-authenticatie: toont een login-scherm (6-cijferige code) en stopt
// de uitvoering hier zolang de gebruiker niet is ingelogd. Zie
// configmain.php voor de secret en auth_gate.php / totp.php voor de logica.
require_once __DIR__ . '/auth_gate.php';

// ===============================================================
// TAAL — interface is vast Nederlands; content (contracten/presets)
// ondersteunt nl + de vertaalde talen en/de/es/fr via DeepL.
// ===============================================================
// UI_LANGS is de lijst "bekende" content-talen: gebruikt om een opgeslagen
// contract-/preset-taal (record['lang'], viewlang, sample-taal e.d.) te
// valideren en om terug te vallen op de juiste taal-dictionary. Dit is NIET
// meer de taalkeuze van de interface zelf (die is vast 'nl', zie
// current_lang() hieronder) — het is losstaand van de contracttalen uit
// deepl_languages() in contract_translate.php, die een veel grotere lijst
// omvatten (een contract kan bv. ook in het Pools staan).
const UI_LANGS = ['en', 'nl', 'de', 'es', 'fr'];

// De webinterface is uitsluitend Nederlands. Geen ?lang=, cookie of
// Accept-Language-detectie meer — dit gaf voorheen EN/NL/DE/ES/FR voor de
// interface zelf. Blijft als functie bestaan omdat t(), sample_values(),
// safeguard_labels() e.d. hier nog steeds naar verwijzen; de vertaalknoppen
// voor contracten en presets (DeepL, NL → EN/DE/ES/FR) zijn hier los van en
// blijven gewoon werken.
function current_lang(): string {
    return 'nl';
}

// Tijdelijke taal-override voor t(), gebruikt door contract_summary_section()
// zodat de labels in het overzichtsblok ("Doel:", "Looptijd:", ...) altijd
// in de TAAL VAN HET CONTRACT (record['lang']) staan, ook als die afwijkt
// van de taal van de webinterface — bv. bij een Frans extra-vertaalde PDF-
// sectie terwijl de interface op Nederlands staat, of bij het kiezen van een
// andere contracttaal via de contracttaalkiezer. Zonder deze override bleven
// die labels altijd in de interfacetaal staan (t() cachete het woordenboek
// eenmalig op current_lang()).
function render_lang(): string {
    return $GLOBALS['__render_lang_override'] ?? current_lang();
}

function with_render_lang(string $lang, callable $fn) {
    $prev = $GLOBALS['__render_lang_override'] ?? null;
    $GLOBALS['__render_lang_override'] = $lang;
    try {
        return $fn();
    } finally {
        $GLOBALS['__render_lang_override'] = $prev;
    }
}

function lang_dict_for(string $lang): array {
    static $cache = [];
    if (!isset($cache[$lang])) {
        $cache[$lang] = match ($lang) {
            'nl' => lang_dict_nl(),
            'de' => lang_dict_de(),
            'es' => function_exists('lang_dict_es') ? lang_dict_es() : lang_dict_en(),
            'fr' => function_exists('lang_dict_fr') ? lang_dict_fr() : lang_dict_en(),
            default => lang_dict_en(),
        };
    }
    return $cache[$lang];
}

function t(string $key, array $args = []): string {
    $lang = render_lang();
    if (in_array($lang, UI_LANGS, true) || !function_exists('translate_doc_label')) {
        $dict = lang_dict_for($lang);
        $s = $dict[$key] ?? $key;
    } else {
        // $lang is een contracttaal buiten UI_LANGS (bv. 'ar', 'ru' — gekozen
        // via de "Extra vertalingen"-checkboxes bij "Nieuw contract", zie
        // deepl_languages() in contract_translate.php). De statische
        // woordenboeken (lang_dict_*()) kennen die taal niet; in plaats van
        // stilzwijgend op Engels terug te vallen wordt het Engelse label hier
        // lui via DeepL vertaald en per taal gecached (label_translate.php),
        // zodat ook deze vaste labels in de gekozen taal verschijnen.
        $en = lang_dict_en()[$key] ?? $key;
        $s = translate_doc_label('t:' . $key, $lang, $en);
    }
    if (!icons_enabled()) $s = strip_icons($s);
    return $args ? vsprintf($s, $args) : $s;
}

// ===============================================================
// ICONS — aan (default) of uit via ?icons=off, cookie
// ===============================================================
function icons_enabled(): bool {
    static $val = null;
    if ($val !== null) return $val;

    if (!empty($_GET['icons']) && in_array($_GET['icons'], ['on', 'off'], true)) {
        $val = $_GET['icons'] === 'on';
        if (!headers_sent()) setcookie('icons', $_GET['icons'], time() + 86400 * 365, '/');
        return $val;
    }
    if (!empty($_COOKIE['icons']) && in_array($_COOKIE['icons'], ['on', 'off'], true)) {
        $val = $_COOKIE['icons'] === 'on';
        return $val;
    }
    $val = true; // default: icons aan
    return $val;
}

// Verwijdert een leidend cluster van emoji/symbool-iconen (incl. variatieselector
// en zero-width joiner) plus de spatie erna, zodat labels als "📄 Genereer" een
// kale "Genereer" worden wanneer iconen uitgeschakeld zijn.
function strip_icons(string $s): string {
    $pattern = '/^(?:[\x{1F000}-\x{1FFFF}\x{2100}-\x{2BFF}]\x{FE0F}?\x{200D}?)+\s*/u';
    return (string)preg_replace($pattern, '', $s);
}

function lang_dict_en(): array {
    return [
        'title' => 'Contract · MD5 re-generation · Digital signing',
        'subtitle' => 'Chapter V GDPR · self-contained',
        'sub' => 'GDPR · Chapter V · Self-contained',
        'stripe_no_disk' => 'No disk · no database · no session',
        'stripe_full' => 'Full contract + signatures inside the PAYLOAD',
        'stripe_integrity' => 'integrity check',
        'tab_generate' => '📄 New contract + sign',
        'tab_regen' => '🔄 Re-generate',
        'tab_about' => 'ℹ️ How it works',
        'section_new' => 'New contract',
        'section_new_sub' => 'Fill in · sign · download .txt',
        'section_safeguard' => 'Contract template',
        'section_company' => 'Company details',
        'summary_heading' => 'OVERVIEW OF SUBMITTED DATA',
        'summary_company_p1' => 'Party 1',
        'summary_company_p2' => 'Party 2',
        'summary_annex_included' => 'included',
        'summary_annex_removed' => 'removed',
        'summary_empty' => '— not provided —',
        'section_safeguard_sub' => 'Choose which contract to generate',
        'section_processing' => 'Processing details',
        'section_commercial' => 'Commercial terms',
        'section_annexes' => 'Edit annexes',
        'section_annexes_sub' => 'Tick articles on/off or edit them',
        'annex_instance_note' => 'These changes apply only to this specific contract. To change the reusable template for every future contract, use the "Contract configuration" tab.',
        'annex_include_label' => 'Include this article in this contract',
        'annex_removed_badge' => 'Removed for this contract',
        'annex_reset_btn' => '↺ Reset to standard text',
        'annex_reset_all_btn' => '↺ Reset all articles',
        'annex_empty' => 'No articles found for the selected contract type.',
        'section_sign' => 'Digital signing',
        'section_sign_sub' => 'Sign with mouse or finger',
        'help_title' => 'How does it work?',
        'help_body' => 'All fields + signatures are packed as JSON, compressed and base64-encoded. That is the PAYLOAD. The MD5 is computed over that payload. Both appear on the .txt contract, and the PAYLOAD is also shown as QR code(s) so you can put them on the printed contract and scan them back later instead of retyping. Nothing is stored on disk or in a database.',
        'quick_fill' => 'Quick fill:',
        'btn_fill_sample' => '📋 Fill sample text',
        'btn_clear_all' => '🧹 Clear all fields',
        'btn_clear_signatures' => '✍️ Clear signatures',
        'load_json_title' => 'Load company data from JSON',
        'load_json_hint' => 'Upload a .json file per party to fill in its fields automatically. Recognised fields: name, address, country, kvk, vat, iban, rep, rep_title, email, phone, role (controller/processor/joint).',
        'btn_load_json_p1' => '📂 Load party 1 (JSON)',
        'btn_load_json_p2' => '📂 Load party 2 (JSON)',
        'btn_json_template_p1' => '⬇ Example JSON',
        'btn_json_template_p2' => '⬇ Example JSON',
        'load_json_ok' => 'Company data for %s loaded from JSON.',
        'load_json_error' => 'Could not read this JSON file: %s',
        'load_json_empty' => 'This JSON file did not contain any recognised fields.',
        'wizard_title' => 'Wizard',
        'wizard_sub' => 'Which contract do I need?',
        'wizard_info' => 'Answer a few questions. The wizard proposes the right safeguard mechanism under Chapter V GDPR and fills in the correct contract type and SCC module automatically.',
        'w1_q' => '1. Are personal data transferred outside the European Economic Area (EEA)?',
        'w2_q' => '2. Does the destination country have a valid adequacy decision from the European Commission?',
        'w3_q' => '3. What is the role of each party?',
        'w3_role_p1' => 'Role Party 1 (exporter)',
        'w3_role_p2' => 'Role Party 2 (importer)',
        'w4_q' => '4. Is the transfer structural or occasional?',
        'w4_structural' => 'Structural / ongoing',
        'w4_incidental' => 'Occasional / one-off',
        'w5_q' => '5. Are additional safeguards already in place?',
        'w5_group' => 'Within a group with approved BCRs',
        'w5_certified' => 'Approved certification mechanism in place',
        'w5_code' => 'Approved code of conduct applies',
        'yes' => 'Yes', 'no' => 'No', 'unknown' => "I don't know",
        'next' => 'Next →', 'prev' => '← Previous',
        'wizard_finish' => 'Show advice →',
        'wizard_advice' => 'Advice',
        'wizard_proposed' => 'Proposed mechanism:',
        'wizard_scc_module' => 'Recommended SCC module:',
        'wizard_restart' => '↺ Restart',
        'wizard_apply' => '✔ Apply to form',
        'role_controller' => 'Controller',
        'role_processor' => 'Processor',
        'role_joint' => 'Joint controller',
        'p1_name' => 'Party 1 name', 'p2_name' => 'Party 2 name',
        'p1_role' => 'Party 1 role', 'p2_role' => 'Party 2 role',
        'p1_address' => 'Party 1 address', 'p2_address' => 'Party 2 address',
        'p1_country' => 'Party 1 country', 'p2_country' => 'Party 2 country',
        'p1_kvk' => 'Party 1 registration no.', 'p2_kvk' => 'Party 2 registration no.',
        'p1_vat' => 'Party 1 VAT', 'p2_vat' => 'Party 2 VAT',
        'p1_iban' => 'Party 1 IBAN', 'p2_iban' => 'Party 2 IBAN',
        'p1_rep' => 'Party 1 representative', 'p2_rep' => 'Party 2 representative',
        'p1_rep_title' => 'Party 1 job title', 'p2_rep_title' => 'Party 2 job title',
        'p1_email' => 'Party 1 email', 'p2_email' => 'Party 2 email',
        'p1_phone' => 'Party 1 phone', 'p2_phone' => 'Party 2 phone',
        'safeguard_label' => 'Contract',
        'safeguard_note' => 'The standard SCC contract is built in and read-only. Custom contracts you create under <strong>Contract configuration</strong> also appear in this list.',
        'purpose' => 'Purpose',
        'data_categories' => 'Categories of personal data',
        'data_subjects' => 'Categories of data subjects',
        'effective_date' => 'Effective date',
        'duration' => 'Duration',
        'notice_period' => 'Notice period',
        'field_remove_title' => 'Remove this field from the contract',
        'contract_value' => 'Contract value',
        'currency' => 'Currency',
        'liability_cap' => 'Liability cap',
        'payment_terms' => 'Payment terms',
        'penalty_clause' => 'Penalty clause',
        'sla_uptime' => 'SLA uptime',
        'sla_response' => 'SLA response time',
        'sub_processors' => 'Sub-processors',
        'confidentiality' => 'Confidentiality (years)',
        'governing_law' => 'Governing law',
        'jurisdiction' => 'Competent court',
        'insurance' => 'Insurance requirement',
        'audit_rights' => 'Audit rights',
        'extra_notes' => 'Additional remarks',
        'annex_a_title' => 'Annex A — Legal basis',
        'annex_a_remove_all' => 'Remove Annex A entirely',
        'annex_a_remove_all_sub' => 'all articles below',
        'annex_a_custom' => 'Replacement / supplementary text Annex A',
        'annex_c_title' => 'Annexes I, II and III — Parties, measures, sub-processors',
        'annex_c_remove_all' => 'Remove Annexes I, II and III entirely',
        'annex_c_remove_all_sub' => 'all articles below',
        'annex_c_custom' => 'Replacement / supplementary text Annexes I/II/III',
        'annex_custom_ph' => 'Leave empty to use the standard text. If you enter something, it is added as replacement text.',
        'annex_grow_hint' => 'The textarea grows automatically with its content.',
        'annex_info' => 'The annexes are generated automatically based on the chosen safeguard mechanism. Here you can <strong>tick each article</strong> on/off and <strong>edit the text</strong>. If you leave an article untouched, the standard text is used. If you switch mechanism, the annexes below are replaced immediately by the articles of the new mechanism.',
        'article_include' => 'Include article %s',
        'article_edit_hint' => 'Edit the text if needed',
        'article_remove_btn' => '🗑️ Remove',
        'article_text' => 'Text',
        'article_removed' => '[Article %s has been removed by the parties.]',
        'annex_removed' => '[Annex %s has been removed by the parties.]',
        'optional' => '(optional)',
        'editable' => '(editable)',
        'sig_p1' => 'Signature Party 1',
        'sig_p2' => 'Signature Party 2',
        'sig_rep' => 'Representative:',
        'sig_not_signed' => '— Not signed yet —',
        'status_signed' => 'Signed',
        'unit_chars' => 'chars',
        'msg_parts_reset' => 'Scanned parts reset.',
        'msg_qr_scanned_filled' => 'QR scanned and filled in.',
        'sig_clear' => 'Clear',
        'btn_generate' => '📄 Generate contract + QR code',
        'result_title' => 'Result',
        'result_sub' => 'Print the QR along with the contract',
        'result_note' => 'The QR code(s) contain the full PAYLOAD. Print them together with the contract — when re-generating, no one has to retype this text, just scan.',
        'qr_hint' => 'Scan to read the PAYLOAD back',
        'qr_single' => 'Scan to read the PAYLOAD back',
        'qr_multi' => 'This PAYLOAD is split into multiple QR codes. Scan them one by one — they are combined automatically.',
        'meta_id' => 'Contract ID',
        'meta_md5' => 'MD5 (of PAYLOAD)',
        'meta_len' => 'Payload length',
        'meta_payload' => 'PAYLOAD',
        'btn_download' => '⬇ Download .txt',
        'btn_download_json' => '⬇ Download .json (fields)',
        'btn_pdf' => '📑 Download MHTML (contract + QR)',
        'regen_title' => 'Re-generate from MD5 + PAYLOAD',
        'regen_sub' => '1-to-1 reconstruction · identical MD5',
        'regen_info' => '<strong>Paste the integrity block</strong> or <strong>scan the QR code(s)</strong> from the printed contract. The system reconstructs the contract <strong>1-to-1</strong>, including the digital signatures. With multiple QR codes: scan them one by one — they are combined automatically. The <strong>MD5 stays exactly the same</strong> as the original, because the PAYLOAD is reused byte-identically. Nothing is stored.',
        'regen_label' => 'Integrity block or PAYLOAD',
        'regen_ph' => "=== CONTRACT INTEGRITY ===\nContract ID:  c3f8a9b2d1e4\nMD5:          8f14e45fceea167a5a36dedd4bea2543\n…",
        'regen_qr_hint' => 'Same PAYLOAD → same QR',
        'btn_regen' => '🔄 Re-generate contract',
        'regen_result_sub' => 'Byte-identical reconstruction',
        'scan_start' => '📷 Scan QR with camera',
        'scan_stop' => '⏹ Stop camera',
        'scan_upload' => '🖼️ Upload QR photo(s)',
        'scan_reset' => '🗑️ Reset scanned parts',
        'scan_camera_on' => 'Camera active — point at the QR code…',
        'scan_camera_err' => 'Could not start camera: ',
        'scan_no_qr' => '⚠️ No QR code recognised in the photo.',
        'scan_part' => 'Part ',
        'scan_all_done' => '✅ All parts scanned and combined.',
        'about_title' => 'How does it work?',
        'about_sub' => 'No disk · no database',
        'about_body' => '<strong>On generation:</strong><br>1. All fields + signatures → JSON<br>2. gzcompress()<br>3. base64_encode() → PAYLOAD<br>4. MD5 = md5(PAYLOAD)<br>5. PAYLOAD + MD5 in the .txt contract, and as QR code(s).<br><br><strong>On re-generation:</strong><br>1. Paste the block, or scan the QR(s).<br>2. base64_decode() → gzuncompress() → JSON<br>3. MD5 is checked against the PAYLOAD.<br>4. The original PAYLOAD is reused byte-identically.<br>5. Contract + signatures are reconstructed 1-to-1.<br>6. The MD5 is exactly the same as in the original.<br>7. The file itself is byte-identical — md5sum contract.txt returns the same value.<br><br><strong>Why QR codes (possibly several)?</strong> The PAYLOAD is a long base64 string. Retyping from paper is unreliable. A QR code on the printed contract can be scanned with a phone or webcam and fills the input automatically. A single QR can hold ~2,900 characters; larger payloads are split automatically (each code contains PARTn/total:…). On scan the parts are combined automatically.<br><br><strong>Important:</strong> always keep the full integrity block (including PAYLOAD) or all printed QR codes. The MD5 alone (32 hex characters) is not enough to reconstruct a contract — that is mathematically impossible with a one-way hash.<br><br><strong>Nothing is stored:</strong> no disk, no database, no session.',
        'about_tip' => 'Tip:',
        'about_tip_body' => 'Signatures are automatically downsized (max 300×100 px) and saved as PNG, which compresses line-art strokes far better than a photo format, to keep the payload small enough to fit in as few QR codes as possible.',
        'note_scc' => 'Annex A: Implementing Decision (EU) 2021/914 — module follows from the role distribution. Text is loaded live from contracts/safeguard_scc.json — edit it in the \'Contract configuration\' tab.',
        'note_bcr' => 'Annex A: Article 47 GDPR — requires an approved BCR document',
        'note_shield' => 'NOTE: invalid since Schrems II (16-07-2020) — Annex A documents the transition',
        'note_adequacy' => 'Annex A: Article 45 GDPR — including fallback if the decision is withdrawn',
        'note_consent' => 'Annex A: Article 49(1)(a) GDPR — with model text for the declaration',
        'note_model' => 'Annex A: Article 46(2)(c)/(d) GDPR — unchanged adoption required',
        'note_cert' => 'Annex A: Article 42 and 46(2)(f) GDPR — with validity monitoring',
        'note_code' => 'Annex A: Article 40 and 46(2)(e) GDPR — with declaration of undertaking',
        'note_dpia' => 'Annex A: Article 35 GDPR — not an independent transfer basis',
        'note_tia' => 'Annex A: EDPB 01/2020 six-step plan — not an independent transfer basis',
        'error_parties' => 'Both parties must have a name.',
        'error_empty_input' => 'Paste or scan the integrity block or the PAYLOAD first.',
        'error_decode' => 'Could not decode the PAYLOAD. Check the scan/input.',
        'error_md5' => 'MD5 does NOT match the PAYLOAD. Expected: %1$s, computed: %2$s',
        'error_zip_ext' => 'The PHP "zip" extension (ext-zip) is not available on this server, so a password-protected ZIP cannot be created.',
        'error_zip_md5' => 'Invalid MD5 — the ZIP password could not be set.',
        'error_zip_empty' => 'No QR images were received to zip.',
        'error_zip_tmp' => 'Could not create a temporary file for the ZIP.',
        'error_zip_open' => 'Could not create the ZIP archive.',
        'error_zip_encrypt' => 'This server\'s zip extension cannot encrypt the archive (AES support missing in libzip).',
        'btn_zip' => '🔐 Download QR codes (.zip, password-protected)',
        'zip_hint' => 'The ZIP is encrypted (AES-256). Password = the MD5 above, exactly as shown (32 lowercase hex characters).',
        'icons_switch_label' => 'Icons',
        'icons_on' => 'ON',
        'icons_off' => 'OFF',
        'footer' => 'Contract Register · Pure MD5 re-generation · digital signing · no disk · no database',

        'tab_config' => '⚙️ Contract configuration',
        'tab_presets' => '🧩 Presets',
        'tab_contracts' => '📚 Contracts',
        'preset_none' => '— none —',
        'presets_title' => 'preset',
        'presets_sub' => 'Reusable text blocks for the processing details and commercial terms fields in "New contract"',
        'presets_info' => 'Presets are global: every preset is available regardless of which contract template is chosen at the top of "New contract". Each preset has its own text per interface language (EN/NL/DE/ES/FR); if the current language is empty, the English version is used, and otherwise the first language that is filled in.',
        'presets_none' => 'No presets yet. Create one below.',
        'presets_edit' => 'Edit',
        'presets_delete' => 'Delete',
        'presets_delete_confirm' => 'Delete this preset? This cannot be undone.',
        'presets_edit_title' => 'Edit preset',
        'presets_new_title' => 'New preset',
        'presets_name' => 'Preset name',
        'presets_cancel_edit' => 'Cancel',
        'presets_save' => 'Save changes',
        'presets_create' => 'Create preset',
        'presets_error' => 'Could not save the preset. Check the form and try again.',
        'presets_saved' => 'Preset saved.',
        'presets_deleted' => 'Preset deleted.',
        'presets_manage_hint' => 'Manage presets under',
        'pdf_extra_langs_title' => 'Extra translations for the MHTML export',
        'pdf_extra_langs_sub' => 'Optional: add one or more extra languages after the contract text above, via DeepL',
        'view_title' => 'Contracts',
        'view_sub' => 'Read-only overview of every contract that has been created',
        'view_intro' => 'This tab only shows what already exists — nothing here can be changed. To edit, translate, clone or delete a contract, use the "Contract configuration" tab.',
        'view_list_title' => 'All contracts',
        'view_col_key' => 'Key',
        'view_col_title' => 'Title',
        'view_col_version' => 'Version',
        'view_col_languages' => 'Languages',
        'view_col_articles' => 'Articles',
        'view_col_protected' => 'Protected',
        'view_protected_yes' => 'Yes',
        'view_protected_no' => 'No',
        'view_picker_label' => 'Inspect contract:',
        'view_lang_label' => 'Language:',
        'view_not_found' => 'This contract could not be found.',
        'view_empty' => 'No contracts have been created yet.',
        'view_sample_note' => 'The highlighted values below (company names, addresses, dates, roles, …) are illustrative sample data, filled in the same way as the default preview on the "New contract" tab — not a real, signed contract. Hover a highlighted value to see which {{TOKEN}} it stands for.',
        'view_mode_label' => 'Display:',
        'view_mode_filled' => 'Sample values (e.g. "Gemeente Amsterdam")',
        'view_mode_raw' => 'Raw placeholders (e.g. "{{P1}}")',
        'view_raw_note' => 'The raw {{TOKEN}} placeholders are shown below, exactly as stored in the contract template — not filled in with sample data.',
        'view_generate_title' => 'Generate now',
        'view_generate_sub' => 'Generate this contract with the sample data shown above, and produce a downloadable text file, JSON, MHTML and scannable QR code — using the same mechanism as the "New contract" tab.',
        'view_generate_btn' => '⚡ Generate now',
        'view_generate_result_sub' => '(generated from the sample data on this page)',
        'view_print_btn' => '🖨️ Print',
        'config_title' => 'Contract configuration',
        'config_sub' => 'Edit the source contracts, article by article, in every language',
        'config_intro' => 'The SCC contract is no longer stored inline in this tool. It lives as a separate JSON file (<code>contracts/safeguard_scc.json</code>), editable per article and per language below. Saving here immediately changes what gets generated in the \'New contract\' tab — the rest of the flow (payload, MD5, QR, signing) is unchanged.',
        'config_not_found' => 'contracts/safeguard_scc.json could not be found or read.',
        'config_current' => 'Current file',
        'config_version' => 'Version',
        'config_md5' => 'MD5 (= zip password)',
        'config_field_title' => 'Title',
        'config_field_body' => 'Body',
        'config_save_btn' => '💾 Save contract',
        'config_saved_msg' => 'Contract saved. The new text is used immediately for new contracts.',
        'config_save_error' => 'Could not save the contract configuration.',
        'config_export_title' => 'Export as password-protected ZIP',
        'config_export_body' => 'Packs the current <code>safeguard_scc.json</code> exactly as saved on disk into an AES-256 encrypted ZIP. The password is the MD5 hash of that JSON file — shown above, and recomputed automatically whenever you save.',
        'config_export_btn' => '🔐 Export password ZIP',
        'config_label_preamble' => 'Preamble',
        'config_label_article' => 'Article %s',
        'config_label_annex_a' => 'Annex A.%s',
        'config_label_annex_common' => 'Annex %s',
        'config_label_signatures' => 'Signatures',
        'config_add_article_btn' => '➕ Add new article',
        'config_new_article_key_label' => 'New article key',
        'config_new_article_key_placeholder' => 'e.g. 8, A.10, Custom',
        'config_duplicate_key_warning' => 'This key already exists — saving will overwrite that article.',
        'config_remove_article_btn' => '✕ Remove',
        'ph_vars_label' => 'Variables — click to insert:',
        'ph_p1' => 'Party 1 name',
        'ph_p2' => 'Party 2 name',
        'ph_a1' => 'Party 1 address + country',
        'ph_a2' => 'Party 2 address + country',
        'ph_c1' => 'Party 1 country',
        'ph_c2' => 'Party 2 country',
        'ph_r1' => 'Party 1 role',
        'ph_r2' => 'Party 2 role',
        'ph_e1' => 'Party 1 email',
        'ph_e2' => 'Party 2 email',
        'ph_rep1' => 'Party 1 representative',
        'ph_rep2' => 'Party 2 representative',
        'ph_law' => 'Governing law',
        'ph_forum' => 'Jurisdiction',
        'ph_date' => 'Contract date',
        'ph_eff' => 'Effective date',
        'ph_module' => 'SCC module (auto-computed from roles)',
        'ph_subs' => 'Sub-processors',
        'ph_purpose' => 'Purpose of processing',
        'ph_cats' => 'Categories of personal data',
        'ph_subj' => 'Categories of data subjects',
        'ph_dur' => 'Duration',
        'ph_notice' => 'Notice period',
        'ph_kvk1' => 'Party 1 chamber of commerce number',
        'ph_kvk2' => 'Party 2 chamber of commerce number',
        'ph_vat1' => 'Party 1 VAT number',
        'ph_vat2' => 'Party 2 VAT number',
        'ph_iban1' => 'Party 1 IBAN',
        'ph_iban2' => 'Party 2 IBAN',
        'ph_reptitle1' => 'Party 1 representative title',
        'ph_reptitle2' => 'Party 2 representative title',
        'ph_phone1' => 'Party 1 phone number',
        'ph_phone2' => 'Party 2 phone number',
        'ph_value' => 'Contract value',
        'ph_currency' => 'Currency',
        'ph_liability' => 'Liability cap',
        'ph_payment' => 'Payment terms',
        'ph_penalty' => 'Penalty clause',
        'ph_slauptime' => 'SLA uptime',
        'ph_slaresponse' => 'SLA response time',
        'ph_conf' => 'Confidentiality period (years)',
        'ph_insurance' => 'Insurance requirement',
        'ph_audit' => 'Audit rights',
        'ph_notes' => 'Additional notes',
        'config_undo_remove_btn' => '↺ Undo',
        'config_marked_for_removal' => 'This article will be removed when you save.',
        'config_move_up_label' => 'Move up',
        'config_move_down_label' => 'Move down',
        'contract_default_label' => 'Standard SCC contract',
        'config_protected_notice' => 'This is the built-in standard contract. It is read-only — use "Create new contract" below to customize a copy of it.',
        'config_protected_save_error' => 'This contract is protected and cannot be overwritten. Create a new contract to customize it.',
        'config_picker_label' => 'Contract:',
        'config_picker_protected_suffix' => '(standard, read-only)',
        'config_create_new_title' => 'Create new contract',
        'config_create_new_sub' => 'Start from a blank contract or a copy of an existing one — fully editable and saveable.',
        'config_new_contract_key_label' => 'Key (used as file name)',
        'config_new_contract_key_placeholder' => 'e.g. my_custom_nda',
        'config_new_contract_title_label' => 'Display name',
        'config_new_contract_title_placeholder' => 'e.g. Custom NDA',
        'config_new_contract_clone_label' => 'Start from a copy of',
        'config_new_contract_clone_blank' => '(blank contract)',
        'config_new_contract_create_btn' => '+ Create contract',
        'config_contract_created_msg' => 'New contract created. You can edit and save it below.',
        'config_contract_deleted_msg' => 'Contract deleted.',
        'config_new_contract_error_empty' => 'Enter a key for the new contract.',
        'config_new_contract_error_protected' => 'That key is reserved for the built-in standard contract.',
        'config_new_contract_error_exists' => 'A contract with that key already exists.',
        'config_new_contract_error_generic' => 'Could not create the new contract.',
        'config_delete_contract_btn' => '🗑 Delete this contract',
        'config_delete_contract_confirm_label' => 'Delete this contract permanently?',
        'config_delete_contract_yes' => 'Yes, delete',
        'config_delete_contract_cancel' => 'Cancel',
    ];
}

function lang_dict_nl(): array {
    return [
        'title' => 'Contract · MD5 her-generatie · Digitaal tekenen',
        'subtitle' => 'Hoofdstuk V AVG · self-contained',
        'sub' => 'AVG · Hoofdstuk V · Self-contained',
        'stripe_no_disk' => 'Geen disk · geen database · geen sessie',
        'stripe_full' => 'Volledig contract + handtekeningen in de PAYLOAD',
        'stripe_integrity' => 'integriteitscontrole',
        'tab_generate' => '📄 Nieuw contract + teken',
        'tab_regen' => '🔄 Her-genereren',
        'tab_about' => 'ℹ️ Hoe werkt het',
        'section_new' => 'Nieuw contract',
        'section_new_sub' => 'Vul in · teken · download .txt',
        'section_safeguard' => 'Contractsjabloon',
        'section_company' => 'Bedrijfsgegevens',
        'summary_heading' => 'OVERZICHT VAN INGEVOERDE GEGEVENS',
        'summary_company_p1' => 'Partij 1',
        'summary_company_p2' => 'Partij 2',
        'summary_annex_included' => 'opgenomen',
        'summary_annex_removed' => 'verwijderd',
        'summary_empty' => '— niet opgegeven —',
        'section_safeguard_sub' => 'Kies welk contract je wilt genereren',
        'section_processing' => 'Verwerkingsdetails',
        'section_commercial' => 'Commerciële voorwaarden',
        'section_annexes' => 'Contract aanpassen',
        'section_annexes_sub' => 'Vink artikelen aan/uit of bewerk ze',
        'annex_instance_note' => 'Deze wijzigingen gelden alleen voor dit specifieke contract. Wil je de herbruikbare sjabloon voor alle toekomstige contracten aanpassen, gebruik dan het tabblad "Configuratie contracten".',
        'annex_include_label' => 'Dit artikel opnemen in dit contract',
        'annex_removed_badge' => 'Verwijderd voor dit contract',
        'annex_reset_btn' => '↺ Terug naar standaardtekst',
        'annex_reset_all_btn' => '↺ Alle artikelen resetten',
        'annex_empty' => 'Geen artikelen gevonden voor het gekozen contracttype.',
        'section_sign' => 'Digitale ondertekening',
        'section_sign_sub' => 'Teken met de muis of vinger',
        'help_title' => 'Hoe werkt het?',
        'help_body' => 'Alle velden + handtekeningen worden als JSON verpakt, gecomprimeerd en base64-gecodeerd. Dat is de PAYLOAD. De MD5 wordt berekend over die payload. Beide komen op het .txt contract te staan, en de PAYLOAD wordt ook als QR-code getoond zodat je \'m op het geprinte contract kunt zetten en later kunt terug-scannen in plaats van overtypen. Er wordt niets op disk of in een database bewaard.',
        'quick_fill' => 'Snel invullen:',
        'btn_fill_sample' => '📋 Voorbeeldtekst invullen',
        'btn_clear_all' => '🧹 Alle velden leegmaken',
        'btn_clear_signatures' => '✍️ Handtekeningen wissen',
        'load_json_title' => 'Bedrijfsgegevens laden uit JSON',
        'load_json_hint' => 'Upload per partij een .json-bestand om de velden automatisch in te vullen. Herkende velden: name, address, country, kvk, vat, iban, rep, rep_title, email, phone, role (controller/processor/joint).',
        'btn_load_json_p1' => '📂 Partij 1 laden (JSON)',
        'btn_load_json_p2' => '📂 Partij 2 laden (JSON)',
        'btn_json_template_p1' => '⬇ Voorbeeld JSON',
        'btn_json_template_p2' => '⬇ Voorbeeld JSON',
        'load_json_ok' => 'Bedrijfsgegevens voor %s geladen uit JSON.',
        'load_json_error' => 'Kon dit JSON-bestand niet lezen: %s',
        'load_json_empty' => 'Dit JSON-bestand bevatte geen herkende velden.',
        'wizard_title' => 'Keuzehulp',
        'wizard_sub' => 'Welk contract heb ik nodig?',
        'wizard_info' => 'Beantwoord een paar vragen. De wizard stelt het juiste waarborgmechanisme voor onder Hoofdstuk V AVG en vult automatisch het juiste contracttype én de juiste SCC-module in.',
        'w1_q' => '1. Worden er persoonsgegevens doorgegeven buiten de Europese Economische Ruimte (EER)?',
        'w2_q' => '2. Heeft het land van bestemming een geldig adequaatheidsbesluit van de Europese Commissie?',
        'w3_q' => '3. Wat is de rol van elke partij?',
        'w3_role_p1' => 'Rol Partij 1 (exporteur)',
        'w3_role_p2' => 'Rol Partij 2 (importeur)',
        'w4_q' => '4. Is de doorgifte structureel of incidenteel?',
        'w4_structural' => 'Structureel / doorlopend',
        'w4_incidental' => 'Incidenteel / eenmalig',
        'w5_q' => '5. Zijn er al aanvullende waarborgen aanwezig?',
        'w5_group' => 'Binnen een concern met goedgekeurde BCR\'s',
        'w5_certified' => 'Goedgekeurd certificeringsmechanisme aanwezig',
        'w5_code' => 'Goedgekeurde gedragscode van toepassing',
        'yes' => 'Ja', 'no' => 'Nee', 'unknown' => 'Weet ik niet',
        'next' => 'Volgende →', 'prev' => '← Vorige',
        'wizard_finish' => 'Bekijk advies →',
        'wizard_advice' => 'Advies',
        'wizard_proposed' => 'Voorgesteld mechanisme:',
        'wizard_scc_module' => 'Aanbevolen SCC-module:',
        'wizard_restart' => '↺ Opnieuw',
        'wizard_apply' => '✔ Toepassen op formulier',
        'role_controller' => 'Verwerkingsverantwoordelijke',
        'role_processor' => 'Verwerker',
        'role_joint' => 'Gezamenlijke verwerkingsverantwoordelijke',
        'p1_name' => 'Naam Partij 1', 'p2_name' => 'Naam Partij 2',
        'p1_role' => 'Rol Partij 1', 'p2_role' => 'Rol Partij 2',
        'p1_address' => 'Adres Partij 1', 'p2_address' => 'Adres Partij 2',
        'p1_country' => 'Land Partij 1', 'p2_country' => 'Land Partij 2',
        'p1_kvk' => 'KvK Partij 1', 'p2_kvk' => 'KvK Partij 2',
        'p1_vat' => 'BTW Partij 1', 'p2_vat' => 'BTW Partij 2',
        'p1_iban' => 'IBAN Partij 1', 'p2_iban' => 'IBAN Partij 2',
        'p1_rep' => 'Vertegenwoordiger Partij 1', 'p2_rep' => 'Vertegenwoordiger Partij 2',
        'p1_rep_title' => 'Functie Partij 1', 'p2_rep_title' => 'Functie Partij 2',
        'p1_email' => 'E-mail Partij 1', 'p2_email' => 'E-mail Partij 2',
        'p1_phone' => 'Telefoon Partij 1', 'p2_phone' => 'Telefoon Partij 2',
        'safeguard_label' => 'Contract',
        'safeguard_note' => 'Het standaard SCC-contract is ingebouwd en alleen-lezen. Zelf aangemaakte contracten via <strong>Configuratie contracten</strong> verschijnen ook in deze lijst.',
        'purpose' => 'Doel',
        'data_categories' => 'Categorieën persoonsgegevens',
        'data_subjects' => 'Categorieën betrokkenen',
        'effective_date' => 'Ingangsdatum',
        'duration' => 'Duur',
        'notice_period' => 'Opzegtermijn',
        'field_remove_title' => 'Dit veld uit het contract verwijderen',
        'contract_value' => 'Contractwaarde',
        'currency' => 'Valuta',
        'liability_cap' => 'Aansprakelijkheidslimiet',
        'payment_terms' => 'Betalingsvoorwaarden',
        'penalty_clause' => 'Boetebeding',
        'sla_uptime' => 'SLA beschikbaarheid',
        'sla_response' => 'SLA reactietijd',
        'sub_processors' => 'Sub-verwerkers',
        'confidentiality' => 'Geheimhouding (jaren)',
        'governing_law' => 'Toepasselijk recht',
        'jurisdiction' => 'Bevoegde rechter',
        'insurance' => 'Verzekeringseis',
        'audit_rights' => 'Audit-rechten',
        'extra_notes' => 'Aanvullende opmerkingen',
        'annex_a_title' => 'Bijlage A — Juridische grondslag',
        'annex_a_remove_all' => 'Bijlage A volledig verwijderen',
        'annex_a_remove_all_sub' => 'alle artikelen hieronder',
        'annex_a_custom' => 'Vervangende / aanvullende tekst Bijlage A',
        'annex_c_title' => 'Bijlagen I, II en III — Partijen, maatregelen, sub-verwerkers',
        'annex_c_remove_all' => 'Bijlagen I, II en III volledig verwijderen',
        'annex_c_remove_all_sub' => 'alle artikelen hieronder',
        'annex_c_custom' => 'Vervangende / aanvullende tekst Bijlagen I/II/III',
        'annex_custom_ph' => 'Laat leeg om de standaardtekst te gebruiken. Vul je hier iets in, dan wordt dit als vervangende tekst opgenomen.',
        'annex_grow_hint' => 'De textarea groeit automatisch mee met de inhoud.',
        'annex_info' => 'De bijlagen worden automatisch gegenereerd op basis van het gekozen waarborgmechanisme. Hier kun je <strong>per artikel</strong> aanvinken of het wordt opgenomen, en de tekst <strong>aanpassen</strong>. Laat je een artikel ongemoeid, dan wordt de standaardtekst gebruikt. Wissel je van mechanisme, dan worden de bijlagen hieronder direct vervangen door de artikelen van het nieuwe mechanisme.',
        'article_include' => 'Artikel %s opnemen',
        'article_edit_hint' => 'Bewerk de tekst indien nodig',
        'article_remove_btn' => '🗑️ Verwijderen',
        'article_text' => 'Tekst',
        'article_removed' => '[Artikel %s is door partijen verwijderd.]',
        'annex_removed' => '[Bijlage %s is door partijen verwijderd.]',
        'optional' => '(optioneel)',
        'editable' => '(aanpasbaar)',
        'sig_p1' => 'Handtekening Partij 1',
        'sig_p2' => 'Handtekening Partij 2',
        'sig_rep' => 'Vertegenwoordiger:',
        'sig_not_signed' => '— Nog niet ondertekend —',
        'status_signed' => 'Ondertekend',
        'unit_chars' => 'tekens',
        'msg_parts_reset' => 'Gescande delen gereset.',
        'msg_qr_scanned_filled' => 'QR gescand en ingevuld.',
        'sig_clear' => 'Wissen',
        'btn_generate' => '📄 Genereer contract + QR-code',
        'result_title' => 'Resultaat',
        'result_sub' => 'Print de QR mee met het contract',
        'result_note' => 'De QR-code(s) bevatten de volledige PAYLOAD. Print ze mee op papier — bij her-generatie hoeft niemand deze tekst meer over te typen, gewoon scannen.',
        'qr_hint' => 'Scan om PAYLOAD terug te lezen',
        'qr_single' => 'Scan om PAYLOAD terug te lezen',
        'qr_multi' => 'Deze PAYLOAD is opgesplitst in meerdere QR-codes. Scan ze één voor één — ze worden automatisch samengevoegd.',
        'meta_id' => 'Contract-ID',
        'meta_md5' => 'MD5 (van PAYLOAD)',
        'meta_len' => 'Payload lengte',
        'meta_payload' => 'PAYLOAD',
        'btn_download' => '⬇ Download .txt',
        'btn_download_json' => '⬇ Download .json (velden)',
        'btn_pdf' => '📑 Download MHTML (contract + QR)',
        'regen_title' => 'Her-genereren uit MD5 + PAYLOAD',
        'regen_sub' => '1-op-1 reconstructie · identieke MD5',
        'regen_info' => '<strong>Plak het integriteitsblok</strong> óf <strong>scan de QR-code(s)</strong> die op het geprinte contract staan. Het systeem reconstrueert het contract <strong>1-op-1</strong>, inclusief de digitale handtekeningen. Bij meerdere QR-codes: scan ze één voor één — ze worden automatisch samengevoegd. De <strong>MD5 blijft exact gelijk</strong> aan het origineel, omdat de PAYLOAD byte-identiek wordt hergebruikt. Er wordt <strong>niets</strong> opgeslagen.',
        'regen_label' => 'Integriteitsblok of PAYLOAD',
        'regen_ph' => "=== CONTRACT INTEGRITEIT ===\nContract-ID:  c3f8a9b2d1e4\nMD5:          8f14e45fceea167a5a36dedd4bea2543\n…",
        'regen_qr_hint' => 'Zelfde PAYLOAD → zelfde QR',
        'btn_regen' => '🔄 Genereer contract opnieuw',
        'regen_result_sub' => 'Byte-identieke reconstructie',
        'scan_start' => '📷 Scan QR met camera',
        'scan_stop' => '⏹ Stop camera',
        'scan_upload' => '🖼️ Upload foto(\'s) van QR',
        'scan_reset' => '🗑️ Reset gescande delen',
        'scan_camera_on' => 'Camera actief — richt op de QR-code…',
        'scan_camera_err' => 'Kon camera niet starten: ',
        'scan_no_qr' => '⚠️ Geen QR-code herkend in de foto.',
        'scan_part' => 'Deel ',
        'scan_all_done' => '✅ Alle delen gescand en samengevoegd.',
        'about_title' => 'Hoe werkt het?',
        'about_sub' => 'Zonder disk · zonder database',
        'about_body' => '<strong>Bij generatie:</strong><br>1. Alle velden + handtekeningen → JSON<br>2. gzcompress()<br>3. base64_encode() → PAYLOAD<br>4. MD5 = md5(PAYLOAD)<br>5. PAYLOAD + MD5 op het .txt contract, én als QR-code(s).<br><br><strong>Bij her-generatie:</strong><br>1. Plak het blok, of scan de QR(\'s).<br>2. base64_decode() → gzuncompress() → JSON<br>3. MD5 wordt gecontroleerd tegen de PAYLOAD.<br>4. De originele PAYLOAD wordt byte-identiek hergebruikt.<br>5. Contract + handtekeningen worden 1-op-1 gereconstrueerd.<br>6. De MD5 is exact dezelfde als in het origineel.<br>7. Ook het bestand zelf is byte-identiek — md5sum contract.txt geeft dezelfde waarde.<br><br><strong>Waarom een QR-code (of meerdere)?</strong> De PAYLOAD is een lange base64-tekst. Overtypen vanaf papier is onbetrouwbaar. Een QR-code op het geprinte contract kan met een telefoon of webcam worden gescand en vult de invoer automatisch. Een enkele QR kan ~2.900 tekens aan; bij een grotere payload wordt hij automatisch in meerdere QR-codes gesplitst (elke code bevat PARTn/totaal:…). Bij het scannen worden de delen automatisch samengevoegd.<br><br><strong>Belangrijk:</strong> bewaar altijd het volledige integriteitsblok (inclusief PAYLOAD) of alle geprinte QR-codes. Alleen de MD5 (32 hex-tekens) is <em>niet</em> genoeg om een contract te reconstrueren — dat is wiskundig onmogelijk met een one-way hash.<br><br><strong>Er wordt niets bewaard:</strong> geen disk, geen database, geen sessie.',
        'about_tip' => 'Tip:',
        'about_tip_body' => 'Handtekeningen worden automatisch verkleind (max 300×100 px) en als PNG opgeslagen, wat lijntekeningen veel beter comprimeert dan een fotoformaat, zodat de payload in zo min mogelijk QR-codes past.',
        'note_scc' => 'Bijlage A: Uitvoeringsbesluit (EU) 2021/914 — module volgt uit de rolverdeling. Tekst wordt live geladen uit contracts/safeguard_scc.json — bewerk via het tabblad \'Configuratie contracten\'.',
        'note_bcr' => 'Bijlage A: artikel 47 AVG — vereist een goedgekeurd BCR-document',
        'note_shield' => 'LET OP: ongeldig sinds Schrems II (16-07-2020) — Bijlage A legt de overgang vast',
        'note_adequacy' => 'Bijlage A: artikel 45 AVG — inclusief terugvalregeling bij intrekking',
        'note_consent' => 'Bijlage A: artikel 49 lid 1 sub a AVG — met modeltekst voor de verklaring',
        'note_model' => 'Bijlage A: artikel 46 lid 2 sub c/d AVG — ongewijzigde overname vereist',
        'note_cert' => 'Bijlage A: artikel 42 en 46 lid 2 sub f AVG — met geldigheidsbewaking',
        'note_code' => 'Bijlage A: artikel 40 en 46 lid 2 sub e AVG — met toezeggingsverklaring',
        'note_dpia' => 'Bijlage A: artikel 35 AVG — geen zelfstandige doorgiftegrondslag',
        'note_tia' => 'Bijlage A: zesstappenplan EDPB 01/2020 — geen zelfstandige doorgiftegrondslag',
        'error_parties' => 'Beide partijen moeten een naam hebben.',
        'error_empty_input' => 'Plak of scan eerst het integriteitsblok of de PAYLOAD.',
        'error_decode' => 'Kon de PAYLOAD niet decoderen. Controleer de scan/invoer.',
        'error_md5' => 'MD5 komt NIET overeen met de PAYLOAD. Verwacht: %1$s, berekend: %2$s',
        'error_zip_ext' => 'De PHP "zip"-extensie (ext-zip) ontbreekt op deze server, dus kan er geen beveiligde ZIP gemaakt worden.',
        'error_zip_md5' => 'Ongeldige MD5 — het ZIP-wachtwoord kon niet worden ingesteld.',
        'error_zip_empty' => 'Er zijn geen QR-afbeeldingen ontvangen om te zippen.',
        'error_zip_tmp' => 'Kon geen tijdelijk bestand aanmaken voor de ZIP.',
        'error_zip_open' => 'Kon het ZIP-archief niet aanmaken.',
        'error_zip_encrypt' => 'De zip-extensie van deze server kan het archief niet versleutelen (AES-ondersteuning ontbreekt in libzip).',
        'btn_zip' => '🔐 Download QR-codes (.zip, met wachtwoord)',
        'zip_hint' => 'De ZIP is versleuteld (AES-256). Wachtwoord = de MD5 hierboven, exact zoals getoond (32 kleine hex-tekens).',
        'icons_switch_label' => 'Iconen',
        'icons_on' => 'AAN',
        'icons_off' => 'UIT',
        'footer' => 'Contract Register · Pure MD5 her-generatie · digitaal tekenen · geen disk · geen database',

        'tab_config' => '⚙️ Configuratie contracten',
        'tab_presets' => '🧩 Presets',
        'tab_contracts' => '📚 Contracten',
        'preset_none' => '— geen —',
        'presets_title' => 'preset',
        'presets_sub' => 'Herbruikbare tekstblokken voor de verwerkingsdetails- en commerciële-voorwaarden-velden in "Nieuw contract"',
        'presets_info' => 'Presets zijn globaal: elk preset staat altijd in de lijst, ongeacht welk contractsjabloon bovenaan "Nieuw contract" gekozen is. Elk preset heeft eigen tekst per interfacetaal (EN/NL/DE/ES/FR); is de huidige taal leeg, dan wordt de Engelse versie gebruikt, en anders de eerste taal die wél is ingevuld.',
        'presets_none' => 'Nog geen presets. Maak er hieronder een aan.',
        'presets_edit' => 'Bewerken',
        'presets_delete' => 'Verwijderen',
        'presets_delete_confirm' => 'Dit preset verwijderen? Dit kan niet ongedaan worden gemaakt.',
        'presets_edit_title' => 'Preset bewerken',
        'presets_new_title' => 'Nieuw preset',
        'presets_name' => 'Naam van het preset',
        'presets_cancel_edit' => 'Annuleren',
        'presets_save' => 'Wijzigingen opslaan',
        'presets_create' => 'Preset aanmaken',
        'presets_error' => 'Het preset kon niet worden opgeslagen. Controleer het formulier en probeer opnieuw.',
        'presets_saved' => 'Preset opgeslagen.',
        'presets_deleted' => 'Preset verwijderd.',
        'presets_manage_hint' => 'Presets beheren onder',
        'pdf_extra_langs_title' => 'Extra vertalingen voor de MHTML-export',
        'pdf_extra_langs_sub' => 'Optioneel: voeg via DeepL één of meer extra talen toe ná de contracttekst hierboven',
        'view_title' => 'Contracten',
        'view_sub' => 'Alleen-lezen overzicht van alle aangemaakte contracten',
        'view_intro' => 'Dit tabblad toont alleen wat er al bestaat — hier kan niets worden gewijzigd. Gebruik het tabblad "Configuratie contracten" om een contract te bewerken, te vertalen, te klonen of te verwijderen.',
        'view_list_title' => 'Alle contracten',
        'view_col_key' => 'Sleutel',
        'view_col_title' => 'Titel',
        'view_col_version' => 'Versie',
        'view_col_languages' => 'Talen',
        'view_col_articles' => 'Artikelen',
        'view_col_protected' => 'Beschermd',
        'view_protected_yes' => 'Ja',
        'view_protected_no' => 'Nee',
        'view_picker_label' => 'Contract bekijken:',
        'view_lang_label' => 'Taal:',
        'view_not_found' => 'Dit contract kon niet worden gevonden.',
        'view_empty' => 'Er zijn nog geen contracten aangemaakt.',
        'view_sample_note' => 'De gemarkeerde waarden hieronder (bedrijfsnamen, adressen, datums, rollen, …) zijn voorbeeldgegevens, op dezelfde manier ingevuld als de standaardinvulling in het tabblad "Nieuw contract" — geen echt, ondertekend contract. Beweeg over een gemarkeerde waarde om te zien voor welke {{TOKEN}} deze staat.',
        'view_mode_label' => 'Weergave:',
        'view_mode_filled' => 'Voorbeeldwaarden (bijv. "Gemeente Amsterdam")',
        'view_mode_raw' => 'Kale placeholders (bijv. "{{P1}}")',
        'view_raw_note' => 'Hieronder staan de kale {{TOKEN}}-placeholders, precies zoals opgeslagen in de contractsjabloon — niet ingevuld met voorbeeldgegevens.',
        'view_generate_title' => 'Genereer nu',
        'view_generate_sub' => 'Genereer dit contract met de hierboven getoonde voorbeeldgegevens en maak een downloadbaar tekstbestand, JSON, MHTML en scanbare QR-code aan — via hetzelfde mechanisme als het tabblad "Nieuw contract".',
        'view_generate_btn' => '⚡ Genereer nu',
        'view_generate_result_sub' => '(gegenereerd op basis van de voorbeeldgegevens op deze pagina)',
        'view_print_btn' => '🖨️ Afdrukken',
        'config_title' => 'Configuratie contracten',
        'config_sub' => 'Bewerk de brontekst van contracten, per artikel, in elke taal',
        'config_intro' => 'Het SCC-contract wordt niet meer inline in deze tool bewaard. Het staat als los JSON-bestand (<code>contracts/safeguard_scc.json</code>), hieronder per artikel en per taal te bewerken. Opslaan wijzigt direct wat er in het tabblad \'Nieuw contract\' wordt gegenereerd — de rest van de flow (payload, MD5, QR, ondertekenen) blijft ongewijzigd.',
        'config_not_found' => 'contracts/safeguard_scc.json kon niet worden gevonden of gelezen.',
        'config_current' => 'Huidig bestand',
        'config_version' => 'Versie',
        'config_md5' => 'MD5 (= zip-wachtwoord)',
        'config_field_title' => 'Titel',
        'config_field_body' => 'Tekst',
        'config_save_btn' => '💾 Contract opslaan',
        'config_saved_msg' => 'Contract opgeslagen. De nieuwe tekst wordt direct gebruikt voor nieuwe contracten.',
        'config_save_error' => 'Opslaan van de contractconfiguratie is mislukt.',
        'config_export_title' => 'Exporteren als ZIP met wachtwoord',
        'config_export_body' => 'Verpakt de huidige <code>safeguard_scc.json</code> precies zoals op schijf opgeslagen in een AES-256-versleutelde ZIP. Het wachtwoord is de MD5-hash van dat JSON-bestand — hierboven getoond, en automatisch herberekend bij elke keer opslaan.',
        'config_export_btn' => '🔐 ZIP met wachtwoord exporteren',
        'config_label_preamble' => 'Preambule',
        'config_label_article' => 'Artikel %s',
        'config_label_annex_a' => 'Bijlage A.%s',
        'config_label_annex_common' => 'Bijlage %s',
        'config_label_signatures' => 'Ondertekening',
        'config_add_article_btn' => '➕ Nieuw artikel toevoegen',
        'config_new_article_key_label' => 'Sleutel nieuw artikel',
        'config_new_article_key_placeholder' => 'bijv. 8, A.10, Custom',
        'config_duplicate_key_warning' => 'Deze sleutel bestaat al — opslaan overschrijft dat artikel.',
        'config_remove_article_btn' => '✕ Verwijderen',
        'ph_vars_label' => 'Variabelen — klik om in te voegen:',
        'ph_p1' => 'Naam Partij 1',
        'ph_p2' => 'Naam Partij 2',
        'ph_a1' => 'Adres + land Partij 1',
        'ph_a2' => 'Adres + land Partij 2',
        'ph_c1' => 'Land Partij 1',
        'ph_c2' => 'Land Partij 2',
        'ph_r1' => 'Rol Partij 1',
        'ph_r2' => 'Rol Partij 2',
        'ph_e1' => 'E-mail Partij 1',
        'ph_e2' => 'E-mail Partij 2',
        'ph_rep1' => 'Vertegenwoordiger Partij 1',
        'ph_rep2' => 'Vertegenwoordiger Partij 2',
        'ph_law' => 'Toepasselijk recht',
        'ph_forum' => 'Bevoegde rechter',
        'ph_date' => 'Contractdatum',
        'ph_eff' => 'Ingangsdatum',
        'ph_module' => 'SCC-module (automatisch bepaald op basis van rollen)',
        'ph_subs' => 'Sub-verwerkers',
        'ph_purpose' => 'Doel van de verwerking',
        'ph_cats' => 'Categorieën persoonsgegevens',
        'ph_subj' => 'Categorieën betrokkenen',
        'ph_dur' => 'Looptijd',
        'ph_notice' => 'Opzegtermijn',
        'ph_kvk1' => 'KvK-nummer Partij 1',
        'ph_kvk2' => 'KvK-nummer Partij 2',
        'ph_vat1' => 'Btw-nummer Partij 1',
        'ph_vat2' => 'Btw-nummer Partij 2',
        'ph_iban1' => 'IBAN Partij 1',
        'ph_iban2' => 'IBAN Partij 2',
        'ph_reptitle1' => 'Functietitel vertegenwoordiger Partij 1',
        'ph_reptitle2' => 'Functietitel vertegenwoordiger Partij 2',
        'ph_phone1' => 'Telefoonnummer Partij 1',
        'ph_phone2' => 'Telefoonnummer Partij 2',
        'ph_value' => 'Contractwaarde',
        'ph_currency' => 'Valuta',
        'ph_liability' => 'Aansprakelijkheidslimiet',
        'ph_payment' => 'Betalingsvoorwaarden',
        'ph_penalty' => 'Boeteclausule',
        'ph_slauptime' => 'SLA-beschikbaarheid',
        'ph_slaresponse' => 'SLA-reactietijd',
        'ph_conf' => 'Geheimhoudingsduur (jaren)',
        'ph_insurance' => 'Verzekeringseis',
        'ph_audit' => 'Auditrechten',
        'ph_notes' => 'Aanvullende opmerkingen',
        'config_undo_remove_btn' => '↺ Ongedaan maken',
        'config_marked_for_removal' => 'Dit artikel wordt verwijderd zodra je opslaat.',
        'config_move_up_label' => 'Naar boven',
        'config_move_down_label' => 'Naar beneden',
        'contract_default_label' => 'Standaard SCC-contract',
        'config_protected_notice' => 'Dit is het ingebouwde standaardcontract. Het is alleen-lezen — gebruik "Nieuw contract aanmaken" hieronder om een kopie ervan aan te passen.',
        'config_protected_save_error' => 'Dit contract is beschermd en kan niet worden overschreven. Maak een nieuw contract aan om het aan te passen.',
        'config_picker_label' => 'Contract:',
        'config_picker_protected_suffix' => '(standaard, alleen-lezen)',
        'config_create_new_title' => 'Nieuw contract aanmaken',
        'config_create_new_sub' => 'Begin met een leeg contract of een kopie van een bestaand contract — volledig bewerkbaar en op te slaan.',
        'config_new_contract_key_label' => 'Sleutel (gebruikt als bestandsnaam)',
        'config_new_contract_key_placeholder' => 'bijv. mijn_eigen_nda',
        'config_new_contract_title_label' => 'Weergavenaam',
        'config_new_contract_title_placeholder' => 'bijv. Eigen NDA',
        'config_new_contract_clone_label' => 'Begin met een kopie van',
        'config_new_contract_clone_blank' => '(leeg contract)',
        'config_new_contract_create_btn' => '+ Contract aanmaken',
        'config_contract_created_msg' => 'Nieuw contract aangemaakt. Je kunt het hieronder bewerken en opslaan.',
        'config_contract_deleted_msg' => 'Contract verwijderd.',
        'config_new_contract_error_empty' => 'Vul een sleutel in voor het nieuwe contract.',
        'config_new_contract_error_protected' => 'Die sleutel is gereserveerd voor het ingebouwde standaardcontract.',
        'config_new_contract_error_exists' => 'Er bestaat al een contract met die sleutel.',
        'config_new_contract_error_generic' => 'Kon het nieuwe contract niet aanmaken.',
        'config_delete_contract_btn' => '🗑 Dit contract verwijderen',
        'config_delete_contract_confirm_label' => 'Dit contract permanent verwijderen?',
        'config_delete_contract_yes' => 'Ja, verwijderen',
        'config_delete_contract_cancel' => 'Annuleren',
    ];
}

function lang_dict_de(): array {
    return [
        'title' => 'Vertrag · MD5-Neugenerierung · Digitale Signatur',
        'subtitle' => 'Kapitel V DSGVO · in sich geschlossen',
        'sub' => 'DSGVO · Kapitel V · In sich geschlossen',
        'stripe_no_disk' => 'Keine Festplatte · keine Datenbank · keine Sitzung',
        'stripe_full' => 'Vollständiger Vertrag + Signaturen im PAYLOAD',
        'stripe_integrity' => 'Integritätsprüfung',
        'tab_generate' => '📄 Neuer Vertrag + unterschreiben',
        'tab_regen' => '🔄 Neu generieren',
        'tab_about' => 'ℹ️ So funktioniert es',
        'section_new' => 'Neuer Vertrag',
        'section_new_sub' => 'Ausfüllen · unterschreiben · .txt herunterladen',
        'section_safeguard' => 'Vertragsvorlage',
        'section_company' => 'Firmendaten',
        'summary_heading' => 'ÜBERSICHT DER EINGEREICHTEN DATEN',
        'summary_company_p1' => 'Partei 1',
        'summary_company_p2' => 'Partei 2',
        'summary_annex_included' => 'aufgenommen',
        'summary_annex_removed' => 'entfernt',
        'summary_empty' => '— nicht angegeben —',
        'section_safeguard_sub' => 'Wählen Sie, welcher Vertrag erzeugt wird',
        'section_processing' => 'Verarbeitungsdetails',
        'section_commercial' => 'Geschäftsbedingungen',
        'section_annexes' => 'Anhänge anpassen',
        'section_annexes_sub' => 'Artikel ankreuzen/abwählen oder bearbeiten',
        'annex_instance_note' => 'Diese Änderungen gelten nur für diesen konkreten Vertrag. Um die wiederverwendbare Vorlage für alle künftigen Verträge zu ändern, nutzen Sie die Registerkarte „Vertragskonfiguration“.',
        'annex_include_label' => 'Diesen Artikel in diesen Vertrag aufnehmen',
        'annex_removed_badge' => 'Für diesen Vertrag entfernt',
        'annex_reset_btn' => '↺ Auf Standardtext zurücksetzen',
        'annex_reset_all_btn' => '↺ Alle Artikel zurücksetzen',
        'annex_empty' => 'Keine Artikel für den gewählten Vertragstyp gefunden.',
        'section_sign' => 'Digitale Signatur',
        'section_sign_sub' => 'Mit der Maus oder dem Finger unterschreiben',
        'help_title' => 'Wie funktioniert es?',
        'help_body' => 'Alle Felder + Unterschriften werden als JSON verpackt, komprimiert und Base64-kodiert. Das ist der PAYLOAD. Der MD5-Hash wird über diesen Payload berechnet. Beides wird in die .txt-Vertragsdatei aufgenommen, und der PAYLOAD wird zusätzlich als QR-Code angezeigt, sodass du ihn auf den ausgedruckten Vertrag aufbringen und später einscannen kannst, anstatt ihn abzutippen. Es wird nichts auf der Festplatte oder in einer Datenbank gespeichert.',
        'quick_fill' => 'Schnell ausfüllen:',
        'btn_fill_sample' => '📋 Beispieltext eingeben',
        'btn_clear_all' => '🧹 Alle Felder leeren',
        'btn_clear_signatures' => '✍️ Unterschriften löschen',
        'wizard_title' => 'Entscheidungshilfe',
        'wizard_sub' => 'Welchen Vertrag brauche ich?',
        'wizard_info' => 'Beantworten Sie ein paar Fragen. Der Assistent schlägt Ihnen den richtigen Schutzmechanismus gemäß Kapitel V der DSGVO vor und füllt automatisch die richtige Vertragsart sowie das richtige SCC-Modul aus.',
        'w1_q' => '1. Werden personenbezogene Daten außerhalb des Europäischen Wirtschaftsraums (EWR) übermittelt?',
        'w2_q' => '2. Verfügt das Bestimmungsland über einen gültigen Angemessenheitsbeschluss der Europäischen Kommission?',
        'w3_q' => '3. Welche Rolle spielt jede Partei?',
        'w3_role_p1' => 'Rolle von Partei 1 (Exporteur)',
        'w3_role_p2' => 'Rolle von Partei 2 (Importeur)',
        'w4_q' => '4. Erfolgt die Übermittlung strukturell oder gelegentlich?',
        'w4_structural' => 'Strukturell / fortlaufend',
        'w4_incidental' => 'Gelegentlich / einmalig',
        'w5_q' => '5. Gibt es bereits zusätzliche Garantien?',
        'w5_group' => 'Innerhalb eines Konzerns mit genehmigten BCRs',
        'w5_certified' => 'Genehmigter Zertifizierungsmechanismus vorhanden',
        'w5_code' => 'Genehmigter Verhaltenskodex gilt',
        'yes' => 'Ja',
        'no' => 'Nein',
        'unknown' => 'Ich weiß es nicht',
        'next' => 'Weiter →',
        'prev' => '← Zurück',
        'wizard_finish' => 'Empfehlung anzeigen →',
        'wizard_advice' => 'Empfehlung',
        'wizard_proposed' => 'Vorgeschlagener Mechanismus:',
        'wizard_scc_module' => 'Empfohlenes SCC-Modul:',
        'wizard_restart' => '↺ Erneut',
        'wizard_apply' => '✔ Auf Formular anwenden',
        'role_controller' => 'Verantwortlicher',
        'role_processor' => 'Auftragsverarbeiter',
        'role_joint' => 'Gemeinsamer Verantwortlicher',
        'p1_name' => 'Name Partei 1',
        'p2_name' => 'Name von Partei 2',
        'p1_role' => 'Rolle von Partei 1',
        'p2_role' => 'Rolle von Partei 2',
        'p1_address' => 'Adresse von Partei 1',
        'p2_address' => 'Adresse von Partei 2',
        'p1_country' => 'Land Partei 1',
        'p2_country' => 'Land Partei 2',
        'p1_kvk' => 'Handelsregister Partei 1',
        'p2_kvk' => 'Handelsregister Partei 2',
        'p1_vat' => 'USt.-IdNr. Partei 1',
        'p2_vat' => 'USt.-IdNr. Partei 2',
        'p1_iban' => 'IBAN Partei 1',
        'p2_iban' => 'IBAN Partei 2',
        'p1_rep' => 'Vertreter Partei 1',
        'p2_rep' => 'Vertreter Partei 2',
        'p1_rep_title' => 'Funktion Partei 1',
        'p2_rep_title' => 'Funktion Partei 2',
        'p1_email' => 'E-Mail Partei 1',
        'p2_email' => 'E-Mail Partei 2',
        'p1_phone' => 'Telefon Partei 1',
        'p2_phone' => 'Telefon Partei 2',
        'safeguard_label' => 'Vertrag',
        'safeguard_note' => 'Der Standard-SCC-Vertrag ist eingebaut und schreibgeschützt. Eigene Verträge, die Sie unter <strong>Vertragskonfiguration</strong> anlegen, erscheinen ebenfalls in dieser Liste.',
        'purpose' => 'Zweck',
        'data_categories' => 'Kategorien personenbezogener Daten',
        'data_subjects' => 'Kategorien der betroffenen Personen',
        'effective_date' => 'Gültigkeitsbeginn',
        'duration' => 'Laufzeit',
        'notice_period' => 'Kündigungsfrist',
        'field_remove_title' => 'Dieses Feld aus dem Vertrag entfernen',
        'contract_value' => 'Vertragswert',
        'currency' => 'Währung',
        'liability_cap' => 'Haftungshöchstbetrag',
        'payment_terms' => 'Zahlungsbedingungen',
        'penalty_clause' => 'Vertragsstrafe',
        'sla_uptime' => 'SLA-Verfügbarkeit',
        'sla_response' => 'SLA-Reaktionszeit',
        'sub_processors' => 'Unterauftragsverarbeiter',
        'confidentiality' => 'Geheimhaltungspflicht (Jahre)',
        'governing_law' => 'Anwendbares Recht',
        'jurisdiction' => 'Zuständiges Gericht',
        'insurance' => 'Versicherungspflicht',
        'audit_rights' => 'Prüfungsrechte',
        'extra_notes' => 'Zusätzliche Anmerkungen',
        'annex_a_title' => 'Anhang A – Rechtsgrundlage',
        'annex_a_remove_all' => 'Anhang A vollständig entfernen',
        'annex_a_remove_all_sub' => 'Alle Artikel unten',
        'annex_a_custom' => 'Ersetzender / ergänzender Text Anhang A',
        'annex_c_title' => 'Anhänge I, II und III – Parteien, Maßnahmen, Unterauftragsverarbeiter',
        'annex_c_remove_all' => 'Anhänge I, II und III vollständig entfernen',
        'annex_c_remove_all_sub' => 'alle Artikel unten',
        'annex_c_custom' => 'Ersetzender / ergänzender Text Anhänge I/II/III',
        'annex_custom_ph' => 'Lass das Feld leer, um den Standardtext zu verwenden. Wenn du hier etwas eingibst, wird dies als ersetzender Text übernommen.',
        'annex_grow_hint' => 'Das Textfeld passt sich automatisch an den Inhalt an.',
        'annex_info' => 'Die Anhänge werden automatisch auf der Grundlage des gewählten Sicherungsmechanismus generiert. Hier kannst du <strong>pro Artikel</strong> ankreuzen, ob er aufgenommen werden soll, und den Text <strong>anpassen</strong>. Wenn du einen Artikel unverändert lässt, wird der Standardtext verwendet. Wenn du den Mechanismus wechselst, werden die unten aufgeführten Anhänge sofort durch die Artikel des neuen Mechanismus ersetzt.',
        'article_include' => 'Artikel %s einfügen',
        'article_edit_hint' => 'Text bei Bedarf bearbeiten',
        'article_remove_btn' => '🗑️ Löschen',
        'article_text' => 'Text',
        'article_removed' => '[Artikel %s wurde von den Parteien gelöscht.]',
        'annex_removed' => '[Anhang %s wurde von den Parteien gelöscht.]',
        'optional' => '(optional)',
        'editable' => '(anpassbar)',
        'sig_p1' => 'Unterschrift Partei 1',
        'sig_p2' => 'Unterschrift Partei 2',
        'sig_rep' => 'Vertreter:',
        'sig_not_signed' => '— Noch nicht unterzeichnet —',
        'status_signed' => 'Unterschrieben',
        'unit_chars' => 'Zeichen',
        'msg_parts_reset' => 'Gescannte Teile zurückgesetzt.',
        'msg_qr_scanned_filled' => 'QR gescannt und ausgefüllt.',
        'sig_clear' => 'Löschen',
        'btn_generate' => '📄 Vertrag + QR-Code generieren',
        'result_title' => 'Ergebnis',
        'result_sub' => 'QR-Code zusammen mit dem Vertrag ausdrucken',
        'result_note' => 'Die QR-Codes enthalten den vollständigen PAYLOAD. Drucken Sie sie mit auf Papier aus – bei einer erneuten Generierung muss niemand diesen Text mehr abtippen, sondern kann ihn einfach scannen.',
        'qr_hint' => 'Scannen, um den PAYLOAD auszulesen',
        'qr_single' => 'Scannen, um den PAYLOAD auszulesen',
        'qr_multi' => 'Dieser PAYLOAD ist auf mehrere QR-Codes aufgeteilt. Scannen Sie sie nacheinander – sie werden automatisch zusammengefügt.',
        'meta_id' => 'Vertrags-ID',
        'meta_md5' => 'MD5 (von PAYLOAD)',
        'meta_len' => 'Länge der PAYLOAD',
        'meta_payload' => 'PAYLOAD',
        'btn_download' => '⬇ Als .txt herunterladen',
        'btn_download_json' => '⬇ Als .json (Felder) herunterladen',
        'btn_pdf' => '📑 MHTML herunterladen (Vertrag + QR)',
        'regen_title' => 'Aus MD5 + PAYLOAD neu generieren',
        'regen_sub' => '1:1-Rekonstruktion · identischer MD5',
        'regen_info' => '<strong>Fügen Sie den Integritätsblock</strong> ein oder <strong>scannen Sie den/die QR-Code(s)</strong>, die auf dem ausgedruckten Vertrag stehen. Das System rekonstruiert den Vertrag <strong>1:1</strong>, einschließlich der digitalen Signaturen. Bei mehreren QR-Codes: Scannen Sie diese nacheinander – sie werden automatisch zusammengefügt. Der <strong>MD5-Wert bleibt exakt gleich</strong> wie im Original, da der PAYLOAD byteweise identisch wiederverwendet wird. Es wird <strong>nichts</strong> gespeichert.',
        'regen_label' => 'Integritätsblock oder PAYLOAD',
        'regen_ph' => '=== VERTRAGSINTEGRITÄT ===
Vertrags-ID:  c3f8a9b2d1e4
MD5:          8f14e45fceea167a5a36dedd4bea2543
…',
        'regen_qr_hint' => 'Gleicher PAYLOAD → gleicher QR-Code',
        'btn_regen' => '🔄 Vertrag neu generieren',
        'regen_result_sub' => 'Byte-identische Rekonstruktion',
        'scan_start' => '📷 QR-Code mit der Kamera scannen',
        'scan_stop' => '⏹ Kamera stoppen',
        'scan_upload' => '🖼️ Foto(s) des QR-Codes hochladen',
        'scan_reset' => '🗑️ Gescannte Teile zurücksetzen',
        'scan_camera_on' => 'Kamera aktiv – auf den QR-Code richten…',
        'scan_camera_err' => 'Kamera konnte nicht gestartet werden: ',
        'scan_no_qr' => '⚠️ Kein QR-Code im Foto erkannt.',
        'scan_part' => 'Teil ',
        'scan_all_done' => '✅ Alle Teile gescannt und zusammengefügt.',
        'about_title' => 'Wie funktioniert es?',
        'about_sub' => 'Ohne Festplatte · ohne Datenbank',
        'about_body' => '<strong>Bei der Generierung:</strong><br>1. Alle Felder + Unterschriften → JSON<br>2. gzcompress()<br>3. base64_encode() → PAYLOAD<br>4. MD5 = md5(PAYLOAD)<br>5. PAYLOAD + MD5 in der .txt-Datei des Vertrags sowie als QR-Code(s). <br><br><strong>Bei der Neuerstellung:</strong><br>1. Fügen Sie den Block ein oder scannen Sie den/die QR-Code(s).<br>2. base64_decode() → gzuncompress() → JSON<br>3. Der MD5-Hash wird mit dem PAYLOAD abgeglichen.<br>4. Der ursprüngliche PAYLOAD wird byte-identisch wiederverwendet.<br>5. Vertrag + Signaturen werden 1:1 rekonstruiert.<br>6. Der MD5-Hash ist exakt derselbe wie im Original.<br>7. Auch die Datei selbst ist byteweise identisch – md5sum contract.txt liefert denselben Wert.<br><br><strong>Warum ein QR-Code (oder mehrere)?</strong> Die PAYLOAD ist ein langer Base64-Text. Das Abtippen vom Papier ist unzuverlässig. Ein QR-Code auf dem ausgedruckten Vertrag kann mit einem Smartphone oder einer Webcam gescannt werden und füllt die Eingabe automatisch aus. Ein einzelner QR-Code kann ~2.900 Zeichen fassen; bei einer größeren Payload wird er automatisch in mehrere QR-Codes aufgeteilt (jeder Code enthält PARTn/Gesamt:…). Beim Scannen werden die Teile automatisch zusammengefügt. <br><br><strong>Wichtig:</strong> Bewahren Sie immer den vollständigen Integritätsblock (einschließlich PAYLOAD) oder alle ausgedruckten QR-Codes auf. Nur der MD5-Hash (32 Hexadezimalzeichen) ist <em>nicht</em> ausreichend, um einen Vertrag zu rekonstruieren – das ist mit einem Einweg-Hash mathematisch unmöglich. <br><br><strong>Es wird nichts gespeichert:</strong> weder auf Festplatte, noch in einer Datenbank, noch in einer Sitzung.',
        'about_tip' => 'Tipp:',
        'about_tip_body' => 'Signaturen werden automatisch verkleinert (max. 300×100 px) und als PNG gespeichert, was Strichzeichnungen viel besser komprimiert als ein Fotoformat, damit die Payload in möglichst wenige QR-Codes passt.',
        'note_scc' => 'Anhang A: Durchführungsbeschluss (EU) 2021/914 – das Modul ergibt sich aus der Rollenverteilung. Der Text wird live aus „contracts/safeguard_scc.json“ geladen – bearbeiten Sie ihn über die Registerkarte „Vertragskonfiguration“.',
        'note_bcr' => 'Anhang A: Artikel 47 DSGVO – erfordert ein genehmigtes BCR-Dokument',
        'note_shield' => 'HINWEIS: ungültig seit Schrems II (16.07.2020) — Anhang A regelt den Übergang',
        'note_adequacy' => 'Anhang A: Artikel 45 DSGVO — einschließlich Rückfallregelung im Falle eines Widerrufs',
        'note_consent' => 'Anhang A: Artikel 49 Absatz 1 Buchstabe a DSGVO — mit Mustertext für die Erklärung',
        'note_model' => 'Anhang A: Artikel 46 Absatz 2 Buchstaben c/d DSGVO — unveränderte Übernahme erforderlich',
        'note_cert' => 'Anhang A: Artikel 42 und 46 Absatz 2 Buchstabe f DSGVO — mit Gültigkeitsüberwachung',
        'note_code' => 'Anhang A: Artikel 40 und 46 Absatz 2 Buchstabe e DSGVO – mit Verpflichtungserklärung',
        'note_dpia' => 'Anhang A: Artikel 35 DSGVO – keine eigenständige Rechtsgrundlage für die Weitergabe',
        'note_tia' => 'Anhang A: Sechs-Schritte-Plan des EDPB 01/2020 – keine eigenständige Rechtsgrundlage für die Weitergabe',
        'error_parties' => 'Beide Parteien müssen einen Namen haben.',
        'error_empty_input' => 'Fügen Sie zunächst den Integritätsblock oder den PAYLOAD ein oder scannen Sie ihn ein.',
        'error_decode' => 'Der PAYLOAD konnte nicht entschlüsselt werden. Überprüfen Sie den Scan/die Eingabe.',
        'error_md5' => 'MD5 stimmt NICHT mit dem PAYLOAD überein. Erwartet: %1$s, berechnet: %2$s',
        'error_zip_ext' => 'Die PHP-Erweiterung „zip“ (ext-zip) fehlt auf diesem Server, daher kann kein sicheres ZIP-Archiv erstellt werden.',
        'error_zip_md5' => 'Ungültiges MD5 – das ZIP-Passwort konnte nicht festgelegt werden.',
        'error_zip_empty' => 'Es wurden keine QR-Bilder zum Komprimieren empfangen.',
        'error_zip_tmp' => 'Es konnte keine temporäre Datei für die ZIP-Datei erstellt werden.',
        'error_zip_open' => 'Das ZIP-Archiv konnte nicht erstellt werden.',
        'error_zip_encrypt' => 'Die ZIP-Erweiterung dieses Servers kann das Archiv nicht verschlüsseln (AES-Unterstützung fehlt in libzip).',
        'btn_zip' => '🔐 QR-Codes herunterladen (.zip, mit Passwort)',
        'zip_hint' => 'Die ZIP-Datei ist verschlüsselt (AES-256). Passwort = der oben angegebene MD5-Hash, genau wie angezeigt (32 kleine Hexadezimalzeichen).',
        'icons_switch_label' => 'Symbole',
        'icons_on' => 'EIN',
        'icons_off' => 'AUS',
        'footer' => 'Vertragsregister · Reine MD5-Neugenerierung · digitale Signatur · keine Festplatte · keine Datenbank',
        'tab_config' => '⚙️ Konfiguration von Verträgen',
        'tab_presets' => '🧩 Presets',
        'tab_contracts' => '📚 Verträge',
        'preset_none' => '— keine —',
        'presets_title' => 'Preset',
        'presets_sub' => 'Wiederverwendbare Textbausteine für die Felder Verarbeitungsdetails und kommerzielle Bedingungen in „Neuer Vertrag"',
        'presets_info' => 'Presets sind global: Jedes Preset ist immer verfügbar, unabhängig davon, welche Vertragsvorlage oben in „Neuer Vertrag" gewählt ist. Jedes Preset hat eigenen Text je Interfacesprache (EN/NL/DE/ES/FR); ist die aktuelle Sprache leer, wird die englische Version verwendet, andernfalls die erste ausgefüllte Sprache.',
        'presets_none' => 'Noch keine Presets. Erstellen Sie unten eines.',
        'presets_edit' => 'Bearbeiten',
        'presets_delete' => 'Löschen',
        'presets_delete_confirm' => 'Dieses Preset löschen? Dies kann nicht rückgängig gemacht werden.',
        'presets_edit_title' => 'Preset bearbeiten',
        'presets_new_title' => 'Neues Preset',
        'presets_name' => 'Name des Presets',
        'presets_cancel_edit' => 'Abbrechen',
        'presets_save' => 'Änderungen speichern',
        'presets_create' => 'Preset erstellen',
        'presets_error' => 'Das Preset konnte nicht gespeichert werden. Prüfen Sie das Formular und versuchen Sie es erneut.',
        'presets_saved' => 'Preset gespeichert.',
        'presets_deleted' => 'Preset gelöscht.',
        'presets_manage_hint' => 'Presets verwalten unter',
        'pdf_extra_langs_title' => 'Zusätzliche Übersetzungen für den MHTML-Export',
        'pdf_extra_langs_sub' => 'Optional: Fügen Sie über DeepL eine oder mehrere zusätzliche Sprachen nach dem obigen Vertragstext hinzu',
        'view_title' => 'Verträge',
        'view_sub' => 'Schreibgeschützte Übersicht aller erstellten Verträge',
        'view_intro' => 'Dieser Tab zeigt nur, was bereits existiert — hier kann nichts geändert werden. Verwenden Sie die Registerkarte „Konfiguration von Verträgen“, um einen Vertrag zu bearbeiten, zu übersetzen, zu klonen oder zu löschen.',
        'view_list_title' => 'Alle Verträge',
        'view_col_key' => 'Schlüssel',
        'view_col_title' => 'Titel',
        'view_col_version' => 'Version',
        'view_col_languages' => 'Sprachen',
        'view_col_articles' => 'Artikel',
        'view_col_protected' => 'Geschützt',
        'view_protected_yes' => 'Ja',
        'view_protected_no' => 'Nein',
        'view_picker_label' => 'Vertrag ansehen:',
        'view_lang_label' => 'Sprache:',
        'view_not_found' => 'Dieser Vertrag konnte nicht gefunden werden.',
        'view_empty' => 'Es wurden noch keine Verträge erstellt.',
        'view_sample_note' => 'Die hervorgehobenen Werte unten (Firmennamen, Adressen, Daten, Rollen, …) sind Beispieldaten, auf dieselbe Weise eingefügt wie die Standardvorschau auf der Registerkarte „Neuer Vertrag“ — kein echter, unterschriebener Vertrag. Fahren Sie mit der Maus über einen hervorgehobenen Wert, um zu sehen, für welches {{TOKEN}} er steht.',
        'view_mode_label' => 'Anzeige:',
        'view_mode_filled' => 'Beispielwerte (z. B. „Gemeente Amsterdam“)',
        'view_mode_raw' => 'Rohe Platzhalter (z. B. „{{P1}}“)',
        'view_raw_note' => 'Unten werden die rohen {{TOKEN}}-Platzhalter angezeigt, genau wie in der Vertragsvorlage gespeichert — nicht mit Beispieldaten ausgefüllt.',
        'view_generate_title' => 'Jetzt generieren',
        'view_generate_sub' => 'Erzeugen Sie diesen Vertrag mit den oben gezeigten Beispieldaten und erstellen Sie eine herunterladbare Textdatei, JSON, MHTML und einen scanbaren QR-Code — mit demselben Mechanismus wie auf der Registerkarte „Neuer Vertrag“.',
        'view_generate_btn' => '⚡ Jetzt generieren',
        'view_generate_result_sub' => '(erzeugt aus den Beispieldaten auf dieser Seite)',
        'view_print_btn' => '🖨️ Drucken',
        'config_title' => 'Konfiguration von Verträgen',
        'config_sub' => 'Bearbeiten Sie den Quelltext von Verträgen, Artikel für Artikel, in jeder Sprache',
        'config_intro' => 'Der SCC-Vertrag wird in diesem Tool nicht mehr inline gespeichert. Er liegt als separate JSON-Datei vor (<code>contracts/safeguard_scc.json</code>) und kann unten nach Artikel und Sprache bearbeitet werden. Das Speichern ändert sofort den Inhalt, der auf der Registerkarte „Neuer Vertrag“ generiert wird – der Rest des Ablaufs (Payload, MD5, QR-Code, Signieren) bleibt unverändert.',
        'config_not_found' => 'contracts/safeguard_scc.json konnte nicht gefunden oder gelesen werden.',
        'config_current' => 'Aktuelle Datei',
        'config_version' => 'Version',
        'config_md5' => 'MD5 (= ZIP-Passwort)',
        'config_field_title' => 'Titel',
        'config_field_body' => 'Text',
        'config_save_btn' => '💾 Vertrag speichern',
        'config_saved_msg' => 'Vertrag gespeichert. Der neue Text wird sofort für neue Verträge verwendet.',
        'config_save_error' => 'Das Speichern der Vertragskonfiguration ist fehlgeschlagen.',
        'config_export_title' => 'Als ZIP mit Passwort exportieren',
        'config_export_body' => 'Packt die aktuelle <code>safeguard_scc.json</code> genau so, wie sie auf der Festplatte gespeichert ist, in eine AES-256-verschlüsselte ZIP-Datei. Das Passwort ist der MD5-Hash dieser JSON-Datei – oben angezeigt und bei jedem Speichern automatisch neu berechnet.',
        'config_export_btn' => '🔐 ZIP mit Passwort exportieren',
        'config_label_preamble' => 'Präambel',
        'config_label_article' => 'Artikel %s',
        'config_label_annex_a' => 'Anhang A.%s',
        'config_label_annex_common' => 'Anhang %s',
        'config_label_signatures' => 'Unterzeichnung',
        'config_add_article_btn' => '➕ Neuen Artikel hinzufügen',
        'config_new_article_key_label' => 'Schlüssel neuer Artikel',
        'config_new_article_key_placeholder' => 'z. B. 8, A.10, Custom',
        'config_duplicate_key_warning' => 'Dieser Schlüssel existiert bereits — beim Speichern wird dieser Artikel überschrieben.',
        'config_remove_article_btn' => '✕ Entfernen',
        'ph_vars_label' => 'Variablen — klicken zum Einfügen:',
        'ph_p1' => 'Name Partei 1',
        'ph_p2' => 'Name Partei 2',
        'ph_a1' => 'Adresse + Land Partei 1',
        'ph_a2' => 'Adresse + Land Partei 2',
        'ph_c1' => 'Land Partei 1',
        'ph_c2' => 'Land Partei 2',
        'ph_r1' => 'Rolle Partei 1',
        'ph_r2' => 'Rolle Partei 2',
        'ph_e1' => 'E-Mail Partei 1',
        'ph_e2' => 'E-Mail Partei 2',
        'ph_rep1' => 'Vertreter Partei 1',
        'ph_rep2' => 'Vertreter Partei 2',
        'ph_law' => 'Anwendbares Recht',
        'ph_forum' => 'Zuständiges Gericht',
        'ph_date' => 'Vertragsdatum',
        'ph_eff' => 'Datum des Inkrafttretens',
        'ph_module' => 'SCC-Modul (automatisch anhand der Rollen bestimmt)',
        'ph_subs' => 'Unterauftragsverarbeiter',
        'ph_purpose' => 'Zweck der Verarbeitung',
        'ph_cats' => 'Kategorien personenbezogener Daten',
        'ph_subj' => 'Kategorien betroffener Personen',
        'ph_dur' => 'Laufzeit',
        'ph_notice' => 'Kündigungsfrist',
        'ph_kvk1' => 'Handelsregisternummer Partei 1',
        'ph_kvk2' => 'Handelsregisternummer Partei 2',
        'ph_vat1' => 'USt-IdNr. Partei 1',
        'ph_vat2' => 'USt-IdNr. Partei 2',
        'ph_iban1' => 'IBAN Partei 1',
        'ph_iban2' => 'IBAN Partei 2',
        'ph_reptitle1' => 'Funktionsbezeichnung Vertreter Partei 1',
        'ph_reptitle2' => 'Funktionsbezeichnung Vertreter Partei 2',
        'ph_phone1' => 'Telefonnummer Partei 1',
        'ph_phone2' => 'Telefonnummer Partei 2',
        'ph_value' => 'Vertragswert',
        'ph_currency' => 'Währung',
        'ph_liability' => 'Haftungsobergrenze',
        'ph_payment' => 'Zahlungsbedingungen',
        'ph_penalty' => 'Vertragsstrafe',
        'ph_slauptime' => 'SLA-Verfügbarkeit',
        'ph_slaresponse' => 'SLA-Reaktionszeit',
        'ph_conf' => 'Geheimhaltungsdauer (Jahre)',
        'ph_insurance' => 'Versicherungspflicht',
        'ph_audit' => 'Prüfungsrechte',
        'ph_notes' => 'Zusätzliche Hinweise',
        'config_undo_remove_btn' => '↺ Rückgängig machen',
        'config_marked_for_removal' => 'Dieser Artikel wird beim Speichern entfernt.',
        'config_move_up_label' => 'Nach oben',
        'config_move_down_label' => 'Nach unten',
        'contract_default_label' => 'Standard-SCC-Vertrag',
        'config_protected_notice' => 'Dies ist der eingebaute Standardvertrag. Er ist schreibgeschützt — verwenden Sie unten "Neuen Vertrag anlegen", um eine Kopie davon anzupassen.',
        'config_protected_save_error' => 'Dieser Vertrag ist geschützt und kann nicht überschrieben werden. Legen Sie einen neuen Vertrag an, um ihn anzupassen.',
        'config_picker_label' => 'Vertrag:',
        'config_picker_protected_suffix' => '(Standard, schreibgeschützt)',
        'config_create_new_title' => 'Neuen Vertrag anlegen',
        'config_create_new_sub' => 'Beginnen Sie mit einem leeren Vertrag oder einer Kopie eines bestehenden Vertrags — vollständig bearbeit- und speicherbar.',
        'config_new_contract_key_label' => 'Schlüssel (wird als Dateiname verwendet)',
        'config_new_contract_key_placeholder' => 'z. B. meine_nda',
        'config_new_contract_title_label' => 'Anzeigename',
        'config_new_contract_title_placeholder' => 'z. B. Eigene NDA',
        'config_new_contract_clone_label' => 'Beginnen Sie mit einer Kopie von',
        'config_new_contract_clone_blank' => '(leerer Vertrag)',
        'config_new_contract_create_btn' => '+ Vertrag anlegen',
        'config_contract_created_msg' => 'Neuer Vertrag angelegt. Sie können ihn unten bearbeiten und speichern.',
        'config_contract_deleted_msg' => 'Vertrag gelöscht.',
        'config_new_contract_error_empty' => 'Geben Sie einen Schlüssel für den neuen Vertrag ein.',
        'config_new_contract_error_protected' => 'Dieser Schlüssel ist für den eingebauten Standardvertrag reserviert.',
        'config_new_contract_error_exists' => 'Ein Vertrag mit diesem Schlüssel existiert bereits.',
        'config_new_contract_error_generic' => 'Der neue Vertrag konnte nicht angelegt werden.',
        'config_delete_contract_btn' => '🗑 Diesen Vertrag löschen',
        'config_delete_contract_confirm_label' => 'Diesen Vertrag endgültig löschen?',
        'config_delete_contract_yes' => 'Ja, löschen',
        'config_delete_contract_cancel' => 'Abbrechen',
    ];
}

// Machinaal vertaald met DeepL vanuit de Engelse teksten hierboven, en
// vervolgens automatisch teruggeplaatst op dezelfde sleutels. Net als bij
// contractvertalingen (zie contract_translate.php) geldt: een machine-
// vertaling van de interface is geen gecontroleerde vertaling. Controleer
// de tekst bij twijfel, met name de juridische termen.
function lang_dict_es(): array {
    return [
        'title' => 'Contrato · Regeneración de MD5 · Firma digital',
        'subtitle' => 'Capítulo V del RGPD · autónomo',
        'sub' => 'RGPD · Capítulo V · Autónomo',
        'stripe_no_disk' => 'Sin disco · sin base de datos · sin sesión',
        'stripe_full' => 'Contrato completo + firmas dentro de la CARGA ÚTIL',
        'stripe_integrity' => 'Comprobación de integridad',
        'tab_generate' => '📄 Nuevo contrato + firmar',
        'tab_regen' => '🔄 Regenerar',
        'tab_about' => 'ℹ️ Cómo funciona',
        'section_new' => 'Nuevo contrato',
        'section_new_sub' => 'Rellenar · firmar · descargar .txt',
        'section_safeguard' => 'Plantilla de contrato',
        'section_company' => 'Datos de la empresa',
        'summary_heading' => 'RESUMEN DE LOS DATOS ENVIADOS',
        'summary_company_p1' => 'Parte 1',
        'summary_company_p2' => 'Parte 2',
        'summary_annex_included' => 'incluido',
        'summary_annex_removed' => 'eliminado',
        'summary_empty' => '— no facilitado —',
        'section_safeguard_sub' => 'Elige qué contrato generar',
        'section_processing' => 'Detalles del proceso',
        'section_commercial' => 'Condiciones comerciales',
        'section_annexes' => 'Editar anexos',
        'section_annexes_sub' => 'Marcar o desmarcar artículos, o editarlos',
        'annex_instance_note' => 'Estos cambios solo se aplican a este contrato específico. Para modificar la plantilla reutilizable para todos los contratos futuros, utilice la pestaña «Configuración del contrato».',
        'annex_include_label' => 'Incluir este artículo en este contrato',
        'annex_removed_badge' => 'Eliminado para este contrato',
        'annex_reset_btn' => '↺ Restablecer al texto estándar',
        'annex_reset_all_btn' => '↺ Restablecer todos los artículos',
        'annex_empty' => 'No se han encontrado artículos para el tipo de contrato seleccionado.',
        'section_sign' => 'Firma digital',
        'section_sign_sub' => 'Firmar con el ratón o con el dedo',
        'help_title' => '¿Cómo funciona?',
        'help_body' => 'Todos los campos y las firmas se empaquetan en formato JSON, se comprimen y se codifican en base64. Eso es la CARGA ÚTIL. El MD5 se calcula sobre esa carga útil. Ambos aparecen en el contrato .txt, y la CARGA ÚTIL también se muestra como código(s) QR para que puedas incluirlos en el contrato impreso y escanearlos más tarde en lugar de volver a escribirlos. No se almacena nada en el disco ni en una base de datos.',
        'quick_fill' => 'Rellenado rápido:',
        'btn_fill_sample' => '📋 Rellenar con texto de ejemplo',
        'btn_clear_all' => '🧹 Borrar todos los campos',
        'btn_clear_signatures' => '✍️ Borrar firmas',
        'load_json_title' => 'Cargar datos de la empresa desde JSON',
        'load_json_hint' => 'Sube un archivo .json por cada parte para rellenar sus campos automáticamente. Campos reconocidos: nombre, dirección, país, kvk, vat, iban, rep, rep_title, correo electrónico, teléfono, función (responsable del tratamiento/encargado del tratamiento/conjunto).',
        'btn_load_json_p1' => '📂 Cargar parte 1 (JSON)',
        'btn_load_json_p2' => '📂 Cargar parte 2 (JSON)',
        'btn_json_template_p1' => '⬇ Ejemplo de JSON',
        'btn_json_template_p2' => '⬇ Ejemplo de JSON',
        'load_json_ok' => 'Datos de la empresa %s cargados desde JSON.',
        'load_json_error' => 'No se ha podido leer este archivo JSON: %s',
        'load_json_empty' => 'Este archivo JSON no contenía ningún campo reconocido.',
        'wizard_title' => 'Asistente',
        'wizard_sub' => '¿Qué contrato necesito?',
        'wizard_info' => 'Responde a unas cuantas preguntas. El asistente te propone el mecanismo de garantía adecuado según el capítulo V del RGPD y rellena automáticamente el tipo de contrato y el módulo de las CCT correctos.',
        'w1_q' => '1. ¿Se transfieren datos personales fuera del Espacio Económico Europeo (EEE)?',
        'w2_q' => '2. ¿Cuenta el país de destino con una decisión de adecuación válida de la Comisión Europea?',
        'w3_q' => '3. ¿Cuál es la función de cada parte?',
        'w3_role_p1' => 'Función de la Parte 1 (exportador)',
        'w3_role_p2' => 'Función de la Parte 2 (importador)',
        'w4_q' => '4. ¿La transferencia es estructural u ocasional?',
        'w4_structural' => 'Estructural / continua',
        'w4_incidental' => 'Ocasional / puntual',
        'w5_q' => '5. ¿Existen ya garantías adicionales?',
        'w5_group' => 'Dentro de un grupo con normas corporativas vinculantes (BCR) aprobadas',
        'w5_certified' => 'Existe un mecanismo de certificación aprobado',
        'w5_code' => 'Se aplica un código de conducta aprobado',
        'yes' => 'Sí',
        'no' => 'No',
        'unknown' => 'No lo sé',
        'next' => 'Siguiente →',
        'prev' => '← Anterior',
        'wizard_finish' => 'Mostrar recomendación →',
        'wizard_advice' => 'Recomendación',
        'wizard_proposed' => 'Mecanismo propuesto:',
        'wizard_scc_module' => 'Módulo de las CCT recomendado:',
        'wizard_restart' => '↺ Reiniciar',
        'wizard_apply' => '✔ Aplicar al formulario',
        'role_controller' => 'Responsable del tratamiento',
        'role_processor' => 'Encargado del tratamiento',
        'role_joint' => 'Responsable conjunto del tratamiento',
        'p1_name' => 'Nombre de la parte 1',
        'p2_name' => 'Nombre de la parte 2',
        'p1_role' => 'Función de la parte 1',
        'p2_role' => 'Función de la parte 2',
        'p1_address' => 'Dirección de la parte 1',
        'p2_address' => 'Dirección de la parte 2',
        'p1_country' => 'País de la parte 1',
        'p2_country' => 'País de la parte 2',
        'p1_kvk' => 'N.º de registro de la parte 1',
        'p2_kvk' => 'N.º de registro de la parte 2',
        'p1_vat' => 'N.º de IVA de la parte 1',
        'p2_vat' => 'N.º de IVA de la Parte 2',
        'p1_iban' => 'IBAN de la Parte 1',
        'p2_iban' => 'IBAN de la Parte 2',
        'p1_rep' => 'Representante de la Parte 1',
        'p2_rep' => 'Representante de la Parte 2',
        'p1_rep_title' => 'Cargo de la Parte 1',
        'p2_rep_title' => 'Cargo de la Parte 2',
        'p1_email' => 'Correo electrónico de la Parte 1',
        'p2_email' => 'Correo electrónico de la Parte 2',
        'p1_phone' => 'Teléfono de la Parte 1',
        'p2_phone' => 'Teléfono de la Parte 2',
        'safeguard_label' => 'Contrato',
        'safeguard_note' => 'El contrato estándar de las Cláusulas Contractuales Tipo (SCC) está integrado y es de solo lectura. Los contratos personalizados que crees en <strong>Configuración del contrato</strong> también aparecen en esta lista.',
        'purpose' => 'Finalidad',
        'data_categories' => 'Categorías de datos personales',
        'data_subjects' => 'Categorías de interesados',
        'effective_date' => 'Fecha de entrada en vigor',
        'duration' => 'Duración',
        'notice_period' => 'Plazo de preaviso',
        'field_remove_title' => 'Eliminar este campo del contrato',
        'contract_value' => 'Importe del contrato',
        'currency' => 'Moneda',
        'liability_cap' => 'Límite de responsabilidad',
        'payment_terms' => 'Condiciones de pago',
        'penalty_clause' => 'Cláusula de penalización',
        'sla_uptime' => 'Tiempo de actividad según el SLA',
        'sla_response' => 'Tiempo de respuesta del SLA',
        'sub_processors' => 'Subencargados del tratamiento',
        'confidentiality' => 'Confidencialidad (años)',
        'governing_law' => 'Legislación aplicable',
        'jurisdiction' => 'Tribunal competente',
        'insurance' => 'Requisitos de seguro',
        'audit_rights' => 'Derechos de auditoría',
        'extra_notes' => 'Observaciones adicionales',
        'annex_a_title' => 'Anexo A — Fundamento jurídico',
        'annex_a_remove_all' => 'Eliminar por completo el anexo A',
        'annex_a_remove_all_sub' => 'todos los artículos siguientes',
        'annex_a_custom' => 'Texto sustitutivo o complementario del anexo A',
        'annex_c_title' => 'Anexos I, II y III — Partes, medidas, subencargados del tratamiento',
        'annex_c_remove_all' => 'Eliminar por completo los anexos I, II y III',
        'annex_c_remove_all_sub' => 'todos los artículos siguientes',
        'annex_c_custom' => 'Texto sustitutivo o complementario de los anexos I, II y III',
        'annex_custom_ph' => 'Déjelo en blanco para utilizar el texto estándar. Si introduce algo, se añadirá como texto sustitutivo.',
        'annex_grow_hint' => 'El área de texto se amplía automáticamente según su contenido.',
        'annex_info' => 'Los anexos se generan automáticamente en función del mecanismo de salvaguardia elegido. Aquí puedes <strong>marcar o desmarcar cada artículo</strong> y <strong>editar el texto</strong>. Si no modificas un artículo, se utilizará el texto estándar. Si cambias de mecanismo, los anexos que aparecen a continuación se sustituirán inmediatamente por los artículos del nuevo mecanismo.',
        'article_include' => 'Incluir el artículo %s',
        'article_edit_hint' => 'Editar el texto si es necesario',
        'article_remove_btn' => '🗑️ Eliminar',
        'article_text' => 'Texto',
        'article_removed' => '[El artículo %s ha sido eliminado por las partes.]',
        'annex_removed' => '[El anexo %s ha sido eliminado por las partes.]',
        'optional' => '(opcional)',
        'editable' => '(editable)',
        'sig_p1' => 'Firma de la Parte 1',
        'sig_p2' => 'Firma de la parte 2',
        'sig_rep' => 'Representante:',
        'sig_not_signed' => '— Aún sin firmar —',
        'status_signed' => 'Firmado',
        'unit_chars' => 'caracteres',
        'msg_parts_reset' => 'Restablecimiento de las partes escaneadas.',
        'msg_qr_scanned_filled' => 'Código QR escaneado y rellenado.',
        'sig_clear' => 'Borrar',
        'btn_generate' => '📄 Generar contrato + código QR',
        'result_title' => 'Resultado',
        'result_sub' => 'Imprime el código QR junto con el contrato',
        'result_note' => 'Los códigos QR contienen la CARGA ÚTIL completa. Imprímelos junto con el contrato; al volver a generarlo, nadie tendrá que volver a escribir este texto, solo habrá que escanearlo.',
        'qr_hint' => 'Escanear para volver a leer la CARGA ÚTIL',
        'qr_single' => 'Escanear para volver a leer la CARGA ÚTIL',
        'qr_multi' => 'Esta CARGA ÚTIL está dividida en varios códigos QR. Escanéalos uno por uno; se combinan automáticamente.',
        'meta_id' => 'ID del contrato',
        'meta_md5' => 'MD5 (de la CARGA ÚTIL)',
        'meta_len' => 'Longitud de la carga útil',
        'meta_payload' => 'CARGA ÚTIL',
        'btn_download' => '⬇ Descargar .txt',
        'btn_download_json' => '⬇ Descargar .json (campos)',
        'btn_pdf' => '📑 Descargar MHTML (contrato + QR)',
        'regen_title' => 'Regenerar a partir de MD5 + PAYLOAD',
        'regen_sub' => 'Reconstrucción 1 a 1 · MD5 idéntico',
        'regen_info' => '<strong>Pega el bloque de integridad</strong> o <strong>escanea el código o códigos QR</strong> del contrato impreso. El sistema reconstruye el contrato <strong>1 a 1</strong>, incluidas las firmas digitales. Si hay varios códigos QR: escanéalos uno por uno; se combinan automáticamente. El <strong>MD5 sigue siendo exactamente el mismo</strong> que el original, ya que la CARGA se reutiliza byte a byte. No se almacena nada.',
        'regen_label' => 'Bloque de integridad o CARGA',
        'regen_ph' => '=== INTEGRIDAD DEL CONTRATO ===
ID del contrato:  c3f8a9b2d1e4
MD5:          8f14e45fceea167a5a36dedd4bea2543
…',
        'regen_qr_hint' => 'Misma CARGA → mismo QR',
        'btn_regen' => '🔄 Regenerar contrato',
        'regen_result_sub' => 'Reconstrucción con bytes idénticos',
        'scan_start' => '📷 Escanea el código QR con la cámara',
        'scan_stop' => '⏹ Detén la cámara',
        'scan_upload' => '🖼️ Sube la(s) foto(s) del código QR',
        'scan_reset' => '🗑️ Restablecer las partes escaneadas',
        'scan_camera_on' => 'Cámara activa: apunta al código QR…',
        'scan_camera_err' => 'No se ha podido iniciar la cámara:',
        'scan_no_qr' => '⚠️ No se ha reconocido ningún código QR en la foto.',
        'scan_part' => 'Pieza',
        'scan_all_done' => '✅ Todas las piezas escaneadas y combinadas.',
        'about_title' => '¿Cómo funciona?',
        'about_sub' => 'Sin disco · sin base de datos',
        'about_body' => '<strong>Durante la generación:</strong><br>1. Todos los campos + firmas → JSON<br>2. gzcompress()<br>3. base64_encode() → PAYLOAD<br>4. MD5 = md5(PAYLOAD)<br>5. PAYLOAD + MD5 en el contrato .txt y como código(s) QR. <br><br><strong>Al volver a generarlo:</strong><br>1. Pega el bloque o escanea los códigos QR.<br>2. base64_decode() → gzuncompress() → JSON<br>3. Se comprueba que el MD5 coincida con el PAYLOAD.<br>4. Se reutiliza el PAYLOAD original, byte a byte.<br>5. El contrato y las firmas se reconstruyen de forma exacta (1 a 1).<br>6. El MD5 es exactamente el mismo que en el original.<br>7. El propio archivo es idéntico byte a byte: md5sum contract.txt devuelve el mismo valor.<br><br><strong>¿Por qué códigos QR (posiblemente varios)?</strong> La CARGA es una cadena larga en base64. Volver a escribirla a mano desde el papel no es fiable. Un código QR en el contrato impreso se puede escanear con un teléfono o una cámara web y rellena el campo de entrada automáticamente. Un solo código QR puede contener unos 2.900 caracteres; las cargas útiles más grandes se dividen automáticamente (cada código contiene PARTn/total:…). Al escanearlo, las partes se combinan automáticamente.<br><br><strong>Importante:</strong> conserva siempre el bloque de integridad completo (incluida la carga útil) o todos los códigos QR impresos. El MD5 por sí solo (32 caracteres hexadecimales) no es suficiente para reconstruir un contrato; eso es matemáticamente imposible con un hash unidireccional.<br><br><strong>No se almacena nada:</strong> ni en disco, ni en base de datos, ni en sesión.',
        'about_tip' => 'Consejo:',
        'about_tip_body' => 'Las firmas se reducen automáticamente (máximo 300×100 píxeles) y se guardan en formato PNG, que comprime los trazos de los dibujos lineales mucho mejor que un formato fotográfico, con el fin de que el tamaño de los datos sea lo suficientemente pequeño como para que quepan en el menor número posible de códigos QR.',
        'note_scc' => 'Anexo A: Decisión de ejecución (UE) 2021/914 — el módulo se deriva de la distribución de funciones. El texto se carga en tiempo real desde contracts/safeguard_scc.json; edítalo en la pestaña «Configuración del contrato».',
        'note_bcr' => 'Anexo A: Artículo 47 del RGPD — requiere un documento de BCR aprobado',
        'note_shield' => 'NOTA: no válido desde Schrems II (16-07-2020) — el anexo A documenta la transición',
        'note_adequacy' => 'Anexo A: Artículo 45 del RGPD — incluye una solución alternativa en caso de que se revoque la decisión',
        'note_consent' => 'Anexo A: Artículo 49, apartado 1, letra a), del RGPD — con texto modelo para la declaración',
        'note_model' => 'Anexo A: Artículo 46, apartado 2, letras c) y d), del RGPD: se requiere su adopción sin modificaciones',
        'note_cert' => 'Anexo A: Artículos 42 y 46, apartado 2, letra f), del RGPD: con control de la validez',
        'note_code' => 'Anexo A: Artículos 40 y 46, apartado 2, letra e), del RGPD: con declaración de compromiso',
        'note_dpia' => 'Anexo A: Artículo 35 del RGPD — no constituye una base de transferencia independiente',
        'note_tia' => 'Anexo A: Plan de seis pasos del CEPD 01/2020 — no constituye una base de transferencia independiente',
        'error_parties' => 'Ambas partes deben tener un nombre.',
        'error_empty_input' => 'Pega o escanea primero el bloque de integridad o la CARGA ÚTIL.',
        'error_decode' => 'No se ha podido descodificar la CARGA ÚTIL. Comprueba el escaneo o la entrada.',
        'error_md5' => 'El MD5 NO coincide con la CARGA ÚTIL. Esperado: %1$s, calculado: %2$s',
        'error_zip_ext' => 'La extensión «zip» de PHP (ext-zip) no está disponible en este servidor, por lo que no se puede crear un archivo ZIP protegido con contraseña.',
        'error_zip_md5' => 'MD5 no válido: no se ha podido establecer la contraseña del ZIP.',
        'error_zip_empty' => 'No se han recibido imágenes QR para comprimir.',
        'error_zip_tmp' => 'No se ha podido crear un archivo temporal para el ZIP.',
        'error_zip_open' => 'No se ha podido crear el archivo ZIP.',
        'error_zip_encrypt' => 'La extensión «zip» de este servidor no puede cifrar el archivo (falta compatibilidad con AES en libzip).',
        'btn_zip' => '🔐 Descargar códigos QR (.zip, protegidos con contraseña)',
        'zip_hint' => 'El archivo ZIP está cifrado (AES-256). Contraseña = el MD5 anterior, tal y como se muestra (32 caracteres hexadecimales en minúsculas).',
        'icons_switch_label' => 'Iconos',
        'icons_on' => 'ACTIVADO',
        'icons_off' => 'DESACTIVADO',
        'footer' => 'Registro de contratos · Regeneración de MD5 puro · Firma digital · Sin disco · Sin base de datos',
        'tab_config' => '⚙️ Configuración del contrato',
        'tab_presets' => '🧩 Ajustes predefinidos',
        'tab_contracts' => '📚 Contratos',
        'preset_none' => '— ninguno —',
        'presets_title' => 'ajuste predefinido',
        'presets_sub' => 'Bloques de texto reutilizables para los campos de detalles de tramitación y condiciones comerciales en «Nuevo contrato»',
        'presets_info' => 'Los ajustes predefinidos son globales: todos ellos están disponibles independientemente de la plantilla de contrato que se elija en la parte superior de «Nuevo contrato». Cada ajuste predefinido tiene su propio texto para cada idioma de la interfaz (EN/NL/DE/ES/FR); si el idioma actual está vacío, se utiliza la versión en inglés; en caso contrario, se utiliza el primer idioma que se haya introducido.',
        'presets_none' => 'Aún no hay ajustes predefinidos. Crea uno a continuación.',
        'presets_edit' => 'Editar',
        'presets_delete' => 'Eliminar',
        'presets_delete_confirm' => '¿Desea eliminar este preajuste? Esta acción no se puede deshacer.',
        'presets_edit_title' => 'Editar preajuste',
        'presets_new_title' => 'Nueva configuración predefinida',
        'presets_name' => 'Nombre de la configuración predefinida',
        'presets_cancel_edit' => 'Cancelar',
        'presets_save' => 'Guardar cambios',
        'presets_create' => 'Crear configuración predefinida',
        'presets_error' => 'No se ha podido guardar la configuración predefinida. Revisa el formulario e inténtalo de nuevo.',
        'presets_saved' => 'Configuración predefinida guardada.',
        'presets_deleted' => 'Configuración predefinida eliminada.',
        'presets_manage_hint' => 'Gestionar configuraciones predefinidas en',
        'pdf_extra_langs_title' => 'Traducciones adicionales para la exportación MHTML',
        'pdf_extra_langs_sub' => 'Opcional: añade uno o más idiomas adicionales después del texto del contrato anterior, a través de DeepL',
        'view_title' => 'Contratos',
        'view_sub' => 'Resumen de solo lectura de todos los contratos que se han creado',
        'view_intro' => 'Esta pestaña solo muestra lo que ya existe; aquí no se puede modificar nada. Para editar, traducir, clonar o eliminar un contrato, utiliza la pestaña «Configuración del contrato».',
        'view_list_title' => 'Todos los contratos',
        'view_col_key' => 'Clave',
        'view_col_title' => 'Título',
        'view_col_version' => 'Versión',
        'view_col_languages' => 'Idiomas',
        'view_col_articles' => 'Artículos',
        'view_col_protected' => 'Protegido',
        'view_protected_yes' => 'Sí',
        'view_protected_no' => 'No',
        'view_picker_label' => 'Consultar contrato:',
        'view_lang_label' => 'Idioma:',
        'view_not_found' => 'No se ha encontrado este contrato.',
        'view_empty' => 'Aún no se ha creado ningún contrato.',
        'view_sample_note' => 'Los valores resaltados a continuación (nombres de empresas, direcciones, fechas, cargos, etc.) son datos de ejemplo ilustrativos, rellenados de la misma forma que la vista previa predeterminada de la pestaña «Nuevo contrato»; no se trata de un contrato real firmado. Pasa el cursor por encima de un valor resaltado para ver a qué {{TOKEN}} corresponde.',
        'view_mode_label' => 'Visualización:',
        'view_mode_filled' => 'Valores de ejemplo (p. ej., «Gemeente Amsterdam»)',
        'view_mode_raw' => 'Marcadores de posición sin formato (p. ej., «{{P1}}»)',
        'view_raw_note' => 'A continuación se muestran los marcadores de posición {{TOKEN}} sin formato, tal y como están almacenados en la plantilla del contrato, sin rellenar con datos de ejemplo.',
        'view_generate_title' => 'Generar ahora',
        'view_generate_sub' => 'Genera este contrato con los datos de ejemplo mostrados anteriormente y crea un archivo de texto descargable, un archivo JSON, un MHTML y un código QR escaneable, utilizando el mismo mecanismo que en la pestaña «Nuevo contrato».',
        'view_generate_btn' => '⚡ Generar ahora',
        'view_generate_result_sub' => '(generado a partir de los datos de ejemplo de esta página)',
        'view_print_btn' => '🖨️ Imprimir',
        'config_title' => 'Configuración del contrato',
        'config_sub' => 'Edita los contratos originales, artículo por artículo, en todos los idiomas',
        'config_intro' => 'El contrato SCC ya no se almacena directamente en esta herramienta. Se encuentra en un archivo JSON independiente (<code>contracts/safeguard_scc.json</code>), que se puede editar por artículo y por idioma a continuación. Al guardar aquí, se modifica inmediatamente lo que se genera en la pestaña «Nuevo contrato»; el resto del proceso (carga útil, MD5, código QR, firma) permanece sin cambios.',
        'config_not_found' => 'No se ha podido encontrar o leer el archivo contracts/safeguard_scc.json.',
        'config_current' => 'Archivo actual',
        'config_version' => 'Versión',
        'config_md5' => 'MD5 (= contraseña del zip)',
        'config_field_title' => 'Título',
        'config_field_body' => 'Cuerpo',
        'config_save_btn' => '💾 Guardar contrato',
        'config_saved_msg' => 'Contrato guardado. El nuevo texto se utiliza inmediatamente para los nuevos contratos.',
        'config_save_error' => 'No se ha podido guardar la configuración del contrato.',
        'config_export_title' => 'Exportar como ZIP protegido con contraseña',
        'config_export_body' => 'Comprime el archivo actual <code>safeguard_scc.json</code> tal y como está guardado en el disco en un ZIP cifrado con AES-256. La contraseña es el hash MD5 de ese archivo JSON —que se muestra arriba— y se vuelve a calcular automáticamente cada vez que guardas.',
        'config_export_btn' => '🔐 Exportar ZIP con contraseña',
        'config_label_preamble' => 'Preámbulo',
        'config_label_article' => 'Artículo %s',
        'config_label_annex_a' => 'Anexo A.%s',
        'config_label_annex_common' => 'Anexo %s',
        'config_label_signatures' => 'Firmas',
        'config_add_article_btn' => '➕ Añadir nuevo artículo',
        'config_new_article_key_label' => 'Clave del nuevo artículo',
        'config_new_article_key_placeholder' => 'p. ej., 8, A.10, Personalizado',
        'config_duplicate_key_warning' => 'Esta clave ya existe: al guardar se sobrescribirá ese artículo.',
        'config_remove_article_btn' => '✕ Eliminar',
        'ph_vars_label' => 'Variables: haz clic para insertarlas:',
        'ph_p1' => 'Nombre de la Parte 1',
        'ph_p2' => 'Nombre de la Parte 2',
        'ph_a1' => 'Dirección de la parte 1 + país',
        'ph_a2' => 'Dirección de la parte 2 + país',
        'ph_c1' => 'País de la parte 1',
        'ph_c2' => 'País de la parte 2',
        'ph_r1' => 'Cargo de la parte 1',
        'ph_r2' => 'Función de la Parte 2',
        'ph_e1' => 'Correo electrónico de la Parte 1',
        'ph_e2' => 'Correo electrónico de la Parte 2',
        'ph_rep1' => 'Representante de la Parte 1',
        'ph_rep2' => 'Representante de la Parte 2',
        'ph_law' => 'Legislación aplicable',
        'ph_forum' => 'Jurisdicción',
        'ph_date' => 'Fecha del contrato',
        'ph_eff' => 'Fecha de entrada en vigor',
        'ph_module' => 'Módulo de las CCT (calculado automáticamente a partir de las funciones)',
        'ph_subs' => 'Subencargados del tratamiento',
        'ph_purpose' => 'Finalidad del tratamiento',
        'ph_cats' => 'Categorías de datos personales',
        'ph_subj' => 'Categorías de interesados',
        'ph_dur' => 'Duración',
        'ph_notice' => 'Plazo de preaviso',
        'ph_kvk1' => 'Número de la Cámara de Comercio de la Parte 1',
        'ph_kvk2' => 'Número de la Cámara de Comercio de la Parte 2',
        'ph_vat1' => 'Número de IVA de la Parte 1',
        'ph_vat2' => 'Número de IVA de la Parte 2',
        'ph_iban1' => 'IBAN de la Parte 1',
        'ph_iban2' => 'IBAN de la Parte 2',
        'ph_reptitle1' => 'Cargo del representante de la Parte 1',
        'ph_reptitle2' => 'Cargo del representante de la Parte 2',
        'ph_phone1' => 'Número de teléfono de la Parte 1',
        'ph_phone2' => 'Número de teléfono de la Parte 2',
        'ph_value' => 'Importe del contrato',
        'ph_currency' => 'Divisa',
        'ph_liability' => 'Límite de responsabilidad',
        'ph_payment' => 'Condiciones de pago',
        'ph_penalty' => 'Cláusula de penalización',
        'ph_slauptime' => 'Tiempo de actividad según el SLA',
        'ph_slaresponse' => 'Tiempo de respuesta según el SLA',
        'ph_conf' => 'Período de confidencialidad (años)',
        'ph_insurance' => 'Requisitos de seguro',
        'ph_audit' => 'Derechos de auditoría',
        'ph_notes' => 'Notas adicionales',
        'config_undo_remove_btn' => '↺ Deshacer',
        'config_marked_for_removal' => 'Este artículo se eliminará al guardar.',
        'config_move_up_label' => 'Subir',
        'config_move_down_label' => 'Bajar',
        'contract_default_label' => 'Contrato estándar de SCC',
        'config_protected_notice' => 'Este es el contrato estándar integrado. Es de solo lectura; utiliza «Crear nuevo contrato» más abajo para personalizar una copia del mismo.',
        'config_protected_save_error' => 'Este contrato está protegido y no se puede sobrescribir. Crea un nuevo contrato para personalizarlo.',
        'config_picker_label' => 'Contrato:',
        'config_picker_protected_suffix' => '(estándar, de solo lectura)',
        'config_create_new_title' => 'Crear nuevo contrato',
        'config_create_new_sub' => 'Empieza con un contrato en blanco o con una copia de uno ya existente: totalmente editable y guardable.',
        'config_new_contract_key_label' => 'Clave (utilizada como nombre de archivo)',
        'config_new_contract_key_placeholder' => 'p. ej., my_custom_nda',
        'config_new_contract_title_label' => 'Nombre para mostrar',
        'config_new_contract_title_placeholder' => 'p. ej., NDA personalizado',
        'config_new_contract_clone_label' => 'Empezar a partir de una copia de',
        'config_new_contract_clone_blank' => '(contrato en blanco)',
        'config_new_contract_create_btn' => '+ Crear contrato',
        'config_contract_created_msg' => 'Se ha creado un nuevo contrato. Puedes editarlo y guardarlo a continuación.',
        'config_contract_deleted_msg' => 'Contrato eliminado.',
        'config_new_contract_error_empty' => 'Introduce una clave para el nuevo contrato.',
        'config_new_contract_error_protected' => 'Esa clave está reservada para el contrato estándar integrado.',
        'config_new_contract_error_exists' => 'Ya existe un contrato con esa clave.',
        'config_new_contract_error_generic' => 'No se ha podido crear el nuevo contrato.',
        'config_delete_contract_btn' => '🗑 Eliminar este contrato',
        'config_delete_contract_confirm_label' => '¿Deseas eliminar este contrato de forma permanente?',
        'config_delete_contract_yes' => 'Sí, eliminar',
        'config_delete_contract_cancel' => 'Cancelar',
    ];
}

function lang_dict_fr(): array {
    return [
        'title' => 'Contrat · Régénération MD5 · Signature numérique',
        'subtitle' => 'Chapitre V du RGPD · autonome',
        'sub' => 'RGPD · Chapitre V · autonome',
        'stripe_no_disk' => 'Pas de disque · pas de base de données · pas de session',
        'stripe_full' => 'Contrat complet + signatures dans le PAYLOAD',
        'stripe_integrity' => 'Contrôle d\'intégrité',
        'tab_generate' => '📄 Nouveau contrat + signature',
        'tab_regen' => '🔄 Régénérer',
        'tab_about' => 'ℹ️ Comment ça marche',
        'section_new' => 'Nouveau contrat',
        'section_new_sub' => 'Remplir · signer · télécharger le fichier .txt',
        'section_safeguard' => 'Modèle de contrat',
        'section_company' => 'Coordonnées de l\'entreprise',
        'summary_heading' => 'APERÇU DES DONNÉES SOUMISES',
        'summary_company_p1' => 'Partie 1',
        'summary_company_p2' => 'Partie 2',
        'summary_annex_included' => 'inclus',
        'summary_annex_removed' => 'supprimé',
        'summary_empty' => '— non fourni —',
        'section_safeguard_sub' => 'Choisissez le contrat à générer',
        'section_processing' => 'Détails du traitement',
        'section_commercial' => 'Conditions commerciales',
        'section_annexes' => 'Modifier les annexes',
        'section_annexes_sub' => 'Cochez ou décochez les articles, ou modifiez-les',
        'annex_instance_note' => 'Ces modifications s’appliquent uniquement à ce contrat spécifique. Pour modifier le modèle réutilisable pour tous les futurs contrats, utilisez l’onglet « Configuration du contrat ».',
        'annex_include_label' => 'Inclure cet article dans ce contrat',
        'annex_removed_badge' => 'Supprimé pour ce contrat',
        'annex_reset_btn' => '↺ Rétablir le texte par défaut',
        'annex_reset_all_btn' => '↺ Réinitialiser tous les articles',
        'annex_empty' => 'Aucun article trouvé pour le type de contrat sélectionné.',
        'section_sign' => 'Signature numérique',
        'section_sign_sub' => 'Signer avec la souris ou le doigt',
        'help_title' => 'Comment cela fonctionne-t-il ?',
        'help_body' => 'Tous les champs et toutes les signatures sont regroupés au format JSON, compressés et encodés en base64. C\'est ce qu\'on appelle le PAYLOAD. La somme MD5 est calculée à partir de ce payload. Les deux apparaissent dans le contrat au format .txt, et le PAYLOAD est également affiché sous forme de code(s) QR afin que vous puissiez les ajouter au contrat imprimé et les scanner ultérieurement au lieu de les retaper. Aucune donnée n’est stockée sur le disque dur ni dans une base de données.',
        'quick_fill' => 'Remplissage rapide :',
        'btn_fill_sample' => '📋 Remplir avec un texte d’exemple',
        'btn_clear_all' => '🧹 Effacer tous les champs',
        'btn_clear_signatures' => '✍️ Effacer les signatures',
        'load_json_title' => 'Charger les données de l\'entreprise à partir d\'un fichier JSON',
        'load_json_hint' => 'Téléchargez un fichier .json par partie pour remplir automatiquement ses champs. Champs reconnus : nom, adresse, pays, kvk, n° de TVA, IBAN, rep, rep_title, e-mail, téléphone, rôle (responsable du traitement/sous-traitant/conjoint).',
        'btn_load_json_p1' => '📂 Charger la partie 1 (JSON)',
        'btn_load_json_p2' => '📂 Charger la partie 2 (JSON)',
        'btn_json_template_p1' => '⬇ Exemple de fichier JSON',
        'btn_json_template_p2' => '⬇ Exemple de fichier JSON',
        'load_json_ok' => 'Données de l\'entreprise %s chargées à partir du fichier JSON.',
        'load_json_error' => 'Impossible de lire ce fichier JSON : %s',
        'load_json_empty' => 'Ce fichier JSON ne contenait aucun champ reconnu.',
        'wizard_title' => 'Assistant',
        'wizard_sub' => 'De quel contrat ai-je besoin ?',
        'wizard_info' => 'Répondez à quelques questions. L\'assistant vous propose le mécanisme de protection adapté conformément au chapitre V du RGPD et sélectionne automatiquement le type de contrat et le module de clauses contractuelles types (SCC) appropriés.',
        'w1_q' => '1. Les données à caractère personnel sont-elles transférées en dehors de l\'Espace économique européen (EEE) ?',
        'w2_q' => '2. Le pays de destination bénéficie-t-il d\'une décision d\'adéquation valide de la Commission européenne ?',
        'w3_q' => '3. Quel est le rôle de chaque partie ?',
        'w3_role_p1' => 'Rôle de la partie 1 (exportateur)',
        'w3_role_p2' => 'Rôle de la partie 2 (importateur)',
        'w4_q' => '4. Le transfert est-il structurel ou occasionnel ?',
        'w4_structural' => 'Structurel / continu',
        'w4_incidental' => 'Occasionnel / ponctuel',
        'w5_q' => '5. Des garanties supplémentaires sont-elles déjà en place ?',
        'w5_group' => 'Au sein d\'un groupe disposant de BCR approuvées',
        'w5_certified' => 'Mécanisme de certification approuvé en place',
        'w5_code' => 'Code de conduite approuvé applicable',
        'yes' => 'Oui',
        'no' => 'Non',
        'unknown' => 'Je ne sais pas',
        'next' => 'Suivant →',
        'prev' => '← Précédent',
        'wizard_finish' => 'Afficher les conseils →',
        'wizard_advice' => 'Conseils',
        'wizard_proposed' => 'Mécanisme proposé :',
        'wizard_scc_module' => 'Module SCC recommandé :',
        'wizard_restart' => '↺ Recommencer',
        'wizard_apply' => '✔ Appliquer au formulaire',
        'role_controller' => 'Responsable du traitement',
        'role_processor' => 'Sous-traitant',
        'role_joint' => 'Responsable conjoint du traitement',
        'p1_name' => 'Nom de la partie 1',
        'p2_name' => 'Nom de la partie 2',
        'p1_role' => 'Rôle de la partie 1',
        'p2_role' => 'Rôle de la partie 2',
        'p1_address' => 'Adresse de la partie 1',
        'p2_address' => 'Adresse de la partie 2',
        'p1_country' => 'Pays de la partie 1',
        'p2_country' => 'Pays de la partie 2',
        'p1_kvk' => 'Numéro d\'enregistrement de la partie 1',
        'p2_kvk' => 'Numéro d\'enregistrement de la partie 2',
        'p1_vat' => 'Numéro de TVA de la partie 1',
        'p2_vat' => 'Numéro de TVA de la partie 2',
        'p1_iban' => 'IBAN de la partie 1',
        'p2_iban' => 'IBAN de la partie 2',
        'p1_rep' => 'Représentant de la partie 1',
        'p2_rep' => 'Représentant de la partie 2',
        'p1_rep_title' => 'Fonction de la partie 1',
        'p2_rep_title' => 'Fonction de la partie 2',
        'p1_email' => 'E-mail de la partie 1',
        'p2_email' => 'E-mail de la partie 2',
        'p1_phone' => 'Téléphone de la partie 1',
        'p2_phone' => 'Numéro de téléphone de la partie 2',
        'safeguard_label' => 'Contrat',
        'safeguard_note' => 'Le contrat SCC standard est intégré et en lecture seule. Les contrats personnalisés que vous créez sous <strong>Configuration du contrat</strong> apparaissent également dans cette liste.',
        'purpose' => 'Objet',
        'data_categories' => 'Catégories de données à caractère personnel',
        'data_subjects' => 'Catégories de personnes concernées',
        'effective_date' => 'Date d’entrée en vigueur',
        'duration' => 'Durée',
        'notice_period' => 'Délai de préavis',
        'field_remove_title' => 'Supprimer ce champ du contrat',
        'contract_value' => 'Valeur du contrat',
        'currency' => 'Devise',
        'liability_cap' => 'Plafond de responsabilité',
        'payment_terms' => 'Conditions de paiement',
        'penalty_clause' => 'Clause pénale',
        'sla_uptime' => 'Temps de disponibilité SLA',
        'sla_response' => 'Délai de réponse prévu par le SLA',
        'sub_processors' => 'Sous-traitants',
        'confidentiality' => 'Confidentialité (en années)',
        'governing_law' => 'Droit applicable',
        'jurisdiction' => 'Tribunal compétent',
        'insurance' => 'Exigence d’assurance',
        'audit_rights' => 'Droits d’audit',
        'extra_notes' => 'Remarques supplémentaires',
        'annex_a_title' => 'Annexe A — Base juridique',
        'annex_a_remove_all' => 'Supprimer entièrement l’annexe A',
        'annex_a_remove_all_sub' => 'tous les articles ci-dessous',
        'annex_a_custom' => 'Texte de remplacement / complémentaire de l’annexe A',
        'annex_c_title' => 'Annexes I, II et III — Parties, mesures, sous-traitants',
        'annex_c_remove_all' => 'Supprimer intégralement les annexes I, II et III',
        'annex_c_remove_all_sub' => 'tous les articles ci-dessous',
        'annex_c_custom' => 'Texte de remplacement / complémentaire pour les annexes I/II/III',
        'annex_custom_ph' => 'Laissez ce champ vide pour utiliser le texte standard. Si vous saisissez quelque chose, cela sera ajouté en tant que texte de remplacement.',
        'annex_grow_hint' => 'La zone de texte s\'agrandit automatiquement en fonction de son contenu.',
        'annex_info' => 'Les annexes sont générées automatiquement en fonction du mécanisme de sauvegarde choisi. Vous pouvez ici <strong>cocher ou décocher chaque article</strong> et <strong>modifier le texte</strong>. Si vous ne modifiez pas un article, le texte standard est utilisé. Si vous changez de mécanisme, les annexes ci-dessous sont immédiatement remplacées par les articles du nouveau mécanisme.',
        'article_include' => 'Inclure l’article %s',
        'article_edit_hint' => 'Modifier le texte si nécessaire',
        'article_remove_btn' => '🗑️ Supprimer',
        'article_text' => 'Texte',
        'article_removed' => '[L’article %s a été supprimé par les parties.]',
        'annex_removed' => '[L’annexe %s a été supprimée par les parties.]',
        'optional' => '(facultatif)',
        'editable' => '(modifiable)',
        'sig_p1' => 'Signature de la partie 1',
        'sig_p2' => 'Signature de la partie 2',
        'sig_rep' => 'Représentant :',
        'sig_not_signed' => '— Pas encore signé —',
        'status_signed' => 'Signé',
        'unit_chars' => 'caractères',
        'msg_parts_reset' => 'Réinitialisation des parties numérisées.',
        'msg_qr_scanned_filled' => 'Code QR scanné et renseigné.',
        'sig_clear' => 'Effacer',
        'btn_generate' => '📄 Générer le contrat + le code QR',
        'result_title' => 'Résultat',
        'result_sub' => 'Imprimer le QR avec le contrat',
        'result_note' => 'Le ou les codes QR contiennent l\'intégralité de la CHARGE UTILE. Imprimez-les avec le contrat — lors d\'une nouvelle génération, personne n\'aura à retaper ce texte, il suffira de le scanner.',
        'qr_hint' => 'Scannez pour relire la CHARGE UTILE',
        'qr_single' => 'Scannez pour relire la CHARGE UTILE',
        'qr_multi' => 'Cette CHARGE UTILE est répartie sur plusieurs codes QR. Scannez-les un par un — ils sont combinés automatiquement.',
        'meta_id' => 'ID du contrat',
        'meta_md5' => 'MD5 (de la charge utile)',
        'meta_len' => 'Longueur de la charge utile',
        'meta_payload' => 'Charge utile',
        'btn_download' => '⬇ Télécharger le fichier .txt',
        'btn_download_json' => '⬇ Télécharger le fichier .json (champs)',
        'btn_pdf' => '📑 Télécharger le MHTML (contrat + QR)',
        'regen_title' => 'Régénérer à partir du MD5 + PAYLOAD',
        'regen_sub' => 'Reconstruction 1 à 1 · MD5 identique',
        'regen_info' => '<strong>Collez le bloc d\'intégrité</strong> ou <strong>scannez le(s) code(s) QR</strong> figurant sur le contrat imprimé. Le système reconstitue le contrat <strong>à l\'identique</strong>, y compris les signatures numériques. En cas de codes QR multiples : scannez-les un par un — ils sont combinés automatiquement. Le <strong>MD5 reste exactement le même</strong> que celui de l’original, car la CHARGE UTILE est réutilisée à l’octet près. Rien n’est stocké.',
        'regen_label' => 'Bloc d’intégrité ou CHARGE UTILE',
        'regen_ph' => '=== INTÉGRITÉ DU CONTRAT ===
ID du contrat :  c3f8a9b2d1e4
MD5 :          8f14e45fceea167a5a36dedd4bea2543
…',
        'regen_qr_hint' => 'Même PAYLOAD → même QR',
        'btn_regen' => '🔄 Régénérer le contrat',
        'regen_result_sub' => 'Reconstruction identique à l\'octet près',
        'scan_start' => '📷 Scanner le QR avec l\'appareil photo',
        'scan_stop' => '⏹ Arrêter l\'appareil photo',
        'scan_upload' => '🖼️ Télécharger la ou les photos du QR',
        'scan_reset' => '🗑️ Réinitialiser les parties scannées',
        'scan_camera_on' => 'Appareil photo actif — visez le code QR…',
        'scan_camera_err' => 'Impossible de démarrer l’appareil photo :',
        'scan_no_qr' => '⚠️ Aucun code QR reconnu sur la photo.',
        'scan_part' => 'Pièce',
        'scan_all_done' => '✅ Toutes les pièces ont été scannées et combinées.',
        'about_title' => 'Comment ça marche ?',
        'about_sub' => 'Pas de disque · pas de base de données',
        'about_body' => '<strong>Lors de la génération :</strong><br>1. Tous les champs + signatures → JSON<br>2. gzcompress()<br>3. base64_encode() → PAYLOAD<br>4. MD5 = md5(PAYLOAD)<br>5. PAYLOAD + MD5 dans le contrat .txt, et sous forme de code(s) QR. <br><br><strong>Lors de la régénération :</strong><br>1. Collez le bloc ou scannez le(s) QR code(s).<br>2. base64_decode() → gzuncompress() → JSON<br>3. Le MD5 est vérifié par rapport au PAYLOAD.<br>4. Le PAYLOAD d’origine est réutilisé à l’octet près.<br>5. Le contrat et les signatures sont reconstitués à l’identique.<br>6. Le MD5 est exactement le même que dans l’original.<br>7. Le fichier lui-même est identique octet par octet — la commande md5sum contract.txt renvoie la même valeur.<br><br><strong>Pourquoi des codes QR (éventuellement plusieurs) ?</strong> La CHARGE UTILE est une longue chaîne en base64. La ressaisie à partir d’un document papier n’est pas fiable. Un code QR figurant sur le contrat imprimé peut être scanné à l’aide d’un téléphone ou d’une webcam et remplit automatiquement le champ de saisie. Un seul code QR peut contenir environ 2 900 caractères ; les charges utiles plus volumineuses sont automatiquement fractionnées (chaque code contient PARTn/total :…). Lors du scan, les parties sont automatiquement combinées.<br><br><strong>Important :</strong> conservez toujours le bloc d’intégrité complet (y compris la charge utile) ou tous les codes QR imprimés. Le MD5 seul (32 caractères hexadécimaux) ne suffit pas pour reconstituer un contrat — cela est mathématiquement impossible avec un hachage à sens unique.<br><br><strong>Rien n’est stocké :</strong> ni sur disque, ni dans une base de données, ni en session.',
        'about_tip' => 'Astuce :',
        'about_tip_body' => 'Les signatures sont automatiquement redimensionnées (max. 300 × 100 px) et enregistrées au format PNG, qui compresse bien mieux les traits de dessin au trait qu’un format photo, afin de maintenir la taille des données suffisamment petite pour tenir dans le moins de codes QR possible.',
        'note_scc' => 'Annexe A : Mise en œuvre de la décision (UE) 2021/914 — le module découle de la répartition des rôles. Le texte est chargé en temps réel à partir du fichier contracts/safeguard_scc.json — modifiez-le dans l’onglet « Configuration du contrat ».',
        'note_bcr' => 'Annexe A : article 47 du RGPD — nécessite un document BCR approuvé',
        'note_shield' => 'REMARQUE : non valide depuis l’arrêt Schrems II (16/07/2020) — l’annexe A documente la transition',
        'note_adequacy' => 'Annexe A : article 45 du RGPD — y compris une solution de repli en cas de retrait de la décision',
        'note_consent' => 'Annexe A : article 49, paragraphe 1, point a), du RGPD — avec un modèle de texte pour la déclaration',
        'note_model' => 'Annexe A : Article 46, paragraphe 2, points c) et d), du RGPD — adoption inchangée requise',
        'note_cert' => 'Annexe A : Articles 42 et 46, paragraphe 2, point f), du RGPD — avec contrôle de la validité',
        'note_code' => 'Annexe A : Articles 40 et 46, paragraphe 2, point e), du RGPD — avec déclaration d’engagement',
        'note_dpia' => 'Annexe A : Article 35 du RGPD — ne constitue pas une base de transfert autonome',
        'note_tia' => 'Annexe A : Plan en six étapes du CEPD 01/2020 — ne constitue pas une base de transfert autonome',
        'error_parties' => 'Les deux parties doivent avoir un nom.',
        'error_empty_input' => 'Collez ou numérisez d\'abord le bloc d\'intégrité ou le PAYLOAD.',
        'error_decode' => 'Impossible de décoder le PAYLOAD. Vérifiez la numérisation/la saisie.',
        'error_md5' => 'Le MD5 ne correspond PAS au PAYLOAD. Attendu : %1$s, calculé : %2$s',
        'error_zip_ext' => 'L\'extension PHP « zip » (ext-zip) n\'est pas disponible sur ce serveur ; il est donc impossible de créer un fichier ZIP protégé par mot de passe.',
        'error_zip_md5' => 'MD5 non valide — le mot de passe du fichier ZIP n\'a pas pu être défini.',
        'error_zip_empty' => 'Aucune image QR n\'a été reçue pour la compression.',
        'error_zip_tmp' => 'Impossible de créer un fichier temporaire pour le fichier ZIP.',
        'error_zip_open' => 'Impossible de créer l’archive ZIP.',
        'error_zip_encrypt' => 'L’extension zip de ce serveur ne peut pas chiffrer l’archive (prise en charge AES manquante dans libzip).',
        'btn_zip' => '🔐 Télécharger les codes QR (.zip, protégés par mot de passe)',
        'zip_hint' => 'Le fichier ZIP est chiffré (AES-256). Mot de passe = le MD5 ci-dessus, exactement tel qu’il est affiché (32 caractères hexadécimaux en minuscules).',
        'icons_switch_label' => 'Icônes',
        'icons_on' => 'ACTIVÉ',
        'icons_off' => 'DÉSACTIVÉ',
        'footer' => 'Registre des contrats · Régénération MD5 pure · Signature numérique · Pas de disque · Pas de base de données',
        'tab_config' => '⚙️ Configuration du contrat',
        'tab_presets' => '🧩 Préréglages',
        'tab_contracts' => '📚 Contrats',
        'preset_none' => '— aucun —',
        'presets_title' => 'préréglage',
        'presets_sub' => 'Blocs de texte réutilisables pour les champs « Détails du traitement » et « Conditions commerciales » dans « Nouveau contrat »',
        'presets_info' => 'Les préréglages sont globaux : chaque préréglage est disponible quel que soit le modèle de contrat sélectionné en haut de la page « Nouveau contrat ». Chaque préréglage dispose de son propre texte pour chaque langue de l\'interface (EN/NL/DE/ES/FR) ; si la langue actuelle n\'est pas renseignée, c\'est la version anglaise qui est utilisée, sinon c\'est la première langue renseignée.',
        'presets_none' => 'Aucun préréglage pour le moment. Créez-en un ci-dessous.',
        'presets_edit' => 'Modifier',
        'presets_delete' => 'Supprimer',
        'presets_delete_confirm' => 'Supprimer ce préréglage ? Cette action ne peut pas être annulée.',
        'presets_edit_title' => 'Modifier le préréglage',
        'presets_new_title' => 'Nouveau préréglage',
        'presets_name' => 'Nom du préréglage',
        'presets_cancel_edit' => 'Annuler',
        'presets_save' => 'Enregistrer les modifications',
        'presets_create' => 'Créer un préréglage',
        'presets_error' => 'Impossible d\'enregistrer le préréglage. Vérifiez le formulaire et réessayez.',
        'presets_saved' => 'Préréglage enregistré.',
        'presets_deleted' => 'Préréglage supprimé.',
        'presets_manage_hint' => 'Gérer les préréglages sous',
        'pdf_extra_langs_title' => 'Traductions supplémentaires pour l\'export MHTML',
        'pdf_extra_langs_sub' => 'Facultatif : ajoutez une ou plusieurs langues supplémentaires après le texte du contrat ci-dessus, via DeepL',
        'view_title' => 'Contrats',
        'view_sub' => 'Aperçu en lecture seule de tous les contrats qui ont été créés',
        'view_intro' => 'Cet onglet affiche uniquement ce qui existe déjà — rien ne peut être modifié ici. Pour modifier, traduire, cloner ou supprimer un contrat, utilisez l’onglet « Configuration du contrat ».',
        'view_list_title' => 'Tous les contrats',
        'view_col_key' => 'Clé',
        'view_col_title' => 'Titre',
        'view_col_version' => 'Version',
        'view_col_languages' => 'Langues',
        'view_col_articles' => 'Articles',
        'view_col_protected' => 'Protégé',
        'view_protected_yes' => 'Oui',
        'view_protected_no' => 'Non',
        'view_picker_label' => 'Consulter le contrat :',
        'view_lang_label' => 'Langue :',
        'view_not_found' => 'Ce contrat est introuvable.',
        'view_empty' => 'Aucun contrat n’a encore été créé.',
        'view_sample_note' => 'Les valeurs surlignées ci-dessous (noms d’entreprises, adresses, dates, fonctions, etc.) sont des exemples illustratifs, renseignés de la même manière que l’aperçu par défaut de l’onglet « Nouveau contrat » — il ne s’agit pas d’un véritable contrat signé. Passez la souris sur une valeur surlignée pour voir quel {{TOKEN}} elle représente.',
        'view_mode_label' => 'Affichage :',
        'view_mode_filled' => 'Exemples de valeurs (par ex. « Gemeente Amsterdam »)',
        'view_mode_raw' => 'Espaces réservés bruts (par ex. « {{P1}} »)',
        'view_raw_note' => 'Les espaces réservés bruts {{TOKEN}} sont présentés ci-dessous, exactement tels qu’ils sont stockés dans le modèle de contrat — sans être renseignés par des données d’exemple.',
        'view_generate_title' => 'Générer maintenant',
        'view_generate_sub' => 'Générez ce contrat à partir des exemples de données présentés ci-dessus et obtenez un fichier texte téléchargeable, un fichier JSON, un MHTML et un code QR scannable — en utilisant le même mécanisme que l’onglet « Nouveau contrat ».',
        'view_generate_btn' => '⚡ Générer maintenant',
        'view_generate_result_sub' => '(généré à partir des données d\'exemple de cette page)',
        'view_print_btn' => '🖨️ Imprimer',
        'config_title' => 'Configuration du contrat',
        'config_sub' => 'Modifier les contrats sources, article par article, dans toutes les langues',
        'config_intro' => 'Le contrat SCC n\'est plus stocké directement dans cet outil. Il se trouve désormais dans un fichier JSON distinct (<code>contracts/safeguard_scc.json</code>), modifiable par article et par langue ci-dessous. L\'enregistrement ici modifie immédiatement le contenu généré dans l\'onglet « Nouveau contrat » — le reste du processus (charge utile, MD5, QR, signature) reste inchangé.',
        'config_not_found' => 'Impossible de trouver ou de lire le fichier contracts/safeguard_scc.json.',
        'config_current' => 'Fichier actuel',
        'config_version' => 'Version',
        'config_md5' => 'MD5 (= mot de passe du fichier zip)',
        'config_field_title' => 'Titre',
        'config_field_body' => 'Corps',
        'config_save_btn' => '💾 Enregistrer le contrat',
        'config_saved_msg' => 'Contrat enregistré. Le nouveau texte est immédiatement utilisé pour les nouveaux contrats.',
        'config_save_error' => 'Impossible d’enregistrer la configuration du contrat.',
        'config_export_title' => 'Exporter sous forme de fichier ZIP protégé par mot de passe',
        'config_export_body' => 'Compresse le fichier <code>safeguard_scc.json</code> actuel exactement tel qu’il est enregistré sur le disque dans un fichier ZIP chiffré en AES-256. Le mot de passe correspond au hachage MD5 de ce fichier JSON — affiché ci-dessus — et est recalculé automatiquement à chaque enregistrement.',
        'config_export_btn' => '🔐 Exporter le fichier ZIP avec mot de passe',
        'config_label_preamble' => 'Préambule',
        'config_label_article' => 'Article %s',
        'config_label_annex_a' => 'Annexe A.%s',
        'config_label_annex_common' => 'Annexe %s',
        'config_label_signatures' => 'Signatures',
        'config_add_article_btn' => '➕ Ajouter un nouvel article',
        'config_new_article_key_label' => 'Clé du nouvel article',
        'config_new_article_key_placeholder' => 'par ex. 8, A.10, Personnalisé',
        'config_duplicate_key_warning' => 'Cette clé existe déjà — l\'enregistrement écrasera cet article.',
        'config_remove_article_btn' => '✕ Supprimer',
        'ph_vars_label' => 'Variables — cliquez pour insérer :',
        'ph_p1' => 'Nom de la partie 1',
        'ph_p2' => 'Nom de la partie 2',
        'ph_a1' => 'Adresse de la partie 1 + pays',
        'ph_a2' => 'Adresse de la partie 2 + pays',
        'ph_c1' => 'Pays de la partie 1',
        'ph_c2' => 'Pays de la partie 2',
        'ph_r1' => 'Rôle de la partie 1',
        'ph_r2' => 'Rôle de la partie 2',
        'ph_e1' => 'E-mail de la partie 1',
        'ph_e2' => 'E-mail de la partie 2',
        'ph_rep1' => 'Représentant de la partie 1',
        'ph_rep2' => 'Représentant de la partie 2',
        'ph_law' => 'Droit applicable',
        'ph_forum' => 'Juridiction compétente',
        'ph_date' => 'Date du contrat',
        'ph_eff' => 'Date d’entrée en vigueur',
        'ph_module' => 'Module SCC (calculé automatiquement à partir des rôles)',
        'ph_subs' => 'Sous-traitants',
        'ph_purpose' => 'Finalité du traitement',
        'ph_cats' => 'Catégories de données à caractère personnel',
        'ph_subj' => 'Catégories de personnes concernées',
        'ph_dur' => 'Durée',
        'ph_notice' => 'Délai de préavis',
        'ph_kvk1' => 'Numéro d\'enregistrement à la Chambre de commerce de la partie 1',
        'ph_kvk2' => 'Numéro d\'enregistrement à la Chambre de commerce de la partie 2',
        'ph_vat1' => 'Numéro de TVA de la partie 1',
        'ph_vat2' => 'Numéro de TVA de la partie 2',
        'ph_iban1' => 'IBAN de la partie 1',
        'ph_iban2' => 'IBAN de la partie 2',
        'ph_reptitle1' => 'Titre du représentant de la partie 1',
        'ph_reptitle2' => 'Titre du représentant de la partie 2',
        'ph_phone1' => 'Numéro de téléphone de la partie 1',
        'ph_phone2' => 'Numéro de téléphone de la partie 2',
        'ph_value' => 'Valeur du contrat',
        'ph_currency' => 'Devise',
        'ph_liability' => 'Plafond de responsabilité',
        'ph_payment' => 'Conditions de paiement',
        'ph_penalty' => 'Clause pénale',
        'ph_slauptime' => 'Disponibilité prévue par le SLA',
        'ph_slaresponse' => 'Délai de réponse prévu par le SLA',
        'ph_conf' => 'Durée de confidentialité (en années)',
        'ph_insurance' => 'Exigences en matière d\'assurance',
        'ph_audit' => 'Droits d\'audit',
        'ph_notes' => 'Remarques supplémentaires',
        'config_undo_remove_btn' => '↺ Annuler',
        'config_marked_for_removal' => 'Cet article sera supprimé lorsque vous enregistrerez.',
        'config_move_up_label' => 'Remonter',
        'config_move_down_label' => 'Déplacer vers le bas',
        'contract_default_label' => 'Contrat SCC standard',
        'config_protected_notice' => 'Il s\'agit du contrat standard intégré. Il est en lecture seule — utilisez « Créer un nouveau contrat » ci-dessous pour personnaliser une copie de celui-ci.',
        'config_protected_save_error' => 'Ce contrat est protégé et ne peut pas être écrasé. Créez un nouveau contrat pour le personnaliser.',
        'config_picker_label' => 'Contrat :',
        'config_picker_protected_suffix' => '(standard, en lecture seule)',
        'config_create_new_title' => 'Créer un nouveau contrat',
        'config_create_new_sub' => 'Commencez à partir d’un contrat vierge ou d’une copie d’un contrat existant — entièrement modifiable et enregistrable.',
        'config_new_contract_key_label' => 'Clé (utilisée comme nom de fichier)',
        'config_new_contract_key_placeholder' => 'par ex. my_custom_nda',
        'config_new_contract_title_label' => 'Nom d’affichage',
        'config_new_contract_title_placeholder' => 'par ex. Accord de confidentialité personnalisé',
        'config_new_contract_clone_label' => 'Partir d’une copie de',
        'config_new_contract_clone_blank' => '(contrat vierge)',
        'config_new_contract_create_btn' => '+ Créer un contrat',
        'config_contract_created_msg' => 'Nouveau contrat créé. Vous pouvez le modifier et l’enregistrer ci-dessous.',
        'config_contract_deleted_msg' => 'Contrat supprimé.',
        'config_new_contract_error_empty' => 'Saisissez une clé pour le nouveau contrat.',
        'config_new_contract_error_protected' => 'Cette clé est réservée au contrat standard intégré.',
        'config_new_contract_error_exists' => 'Un contrat portant cette clé existe déjà.',
        'config_new_contract_error_generic' => 'Impossible de créer le nouveau contrat.',
        'config_delete_contract_btn' => '🗑 Supprimer ce contrat',
        'config_delete_contract_confirm_label' => 'Supprimer définitivement ce contrat ?',
        'config_delete_contract_yes' => 'Oui, supprimer',
        'config_delete_contract_cancel' => 'Annuler',
    ];
}


// ===============================================================
// SAFEGUARD LABELS
// ===============================================================
function safeguard_labels(): array {
    if (current_lang() === 'nl') {
        return [
            'safeguard_scc'               => "Standaardcontractbepalingen (SCC's)",
            'safeguard_bcr'               => "Binding Corporate Rules (BCR's)",
            'safeguard_privacy_shield'    => 'Privacy Shield (niet meer geldig)',
            'safeguard_adequacy_decision' => 'Adequaatheidsbesluit Europese Commissie',
            'safeguard_consent'           => 'Specifieke toestemming van betrokkene',
            'safeguard_model_contracts'   => 'Modelcontracten',
            'safeguard_certification'     => 'Certificeringsmechanismen',
            'safeguard_codes_of_conduct'  => 'Gedragscodes',
            'safeguard_dpia'              => 'Data Protection Impact Assessment (DPIA)',
            'safeguard_tia'               => 'Internationale Data Transfer Impact Assessment (TIA)',
        ];
    }
    if (current_lang() === 'de') {
        return [
            'safeguard_scc'               => 'Standardvertragsklauseln (SCCs)',
            'safeguard_bcr'               => 'Binding Corporate Rules (BCRs)',
            'safeguard_privacy_shield'    => 'Privacy Shield (nicht mehr gültig)',
            'safeguard_adequacy_decision' => 'Angemessenheitsbeschluss der Europäischen Kommission',
            'safeguard_consent'           => 'Ausdrückliche Einwilligung der betroffenen Person',
            'safeguard_model_contracts'   => 'Musterverträge',
            'safeguard_certification'     => 'Zertifizierungsmechanismen',
            'safeguard_codes_of_conduct'  => 'Verhaltenskodizes',
            'safeguard_dpia'              => 'Datenschutz-Folgenabschätzung (DPIA)',
            'safeguard_tia'               => 'Internationale Transfer Impact Assessment (TIA)',
        ];
    }
    if (current_lang() === 'es') {
        return [
            'safeguard_scc'               => 'Cláusulas Contractuales Tipo (CCT)',
            'safeguard_bcr'               => 'Normas Corporativas Vinculantes (BCR)',
            'safeguard_privacy_shield'    => 'Privacy Shield (ya no es válido)',
            'safeguard_adequacy_decision' => 'Decisión de adecuación de la Comisión Europea',
            'safeguard_consent'           => 'Consentimiento específico del interesado',
            'safeguard_model_contracts'   => 'Contratos tipo',
            'safeguard_certification'     => 'Mecanismos de certificación',
            'safeguard_codes_of_conduct'  => 'Códigos de conducta',
            'safeguard_dpia'              => 'Evaluación de impacto relativa a la protección de datos (EIPD)',
            'safeguard_tia'               => 'Evaluación de impacto de transferencias internacionales de datos (TIA)',
        ];
    }
    if (current_lang() === 'fr') {
        return [
            'safeguard_scc'               => 'Clauses contractuelles types (CCT)',
            'safeguard_bcr'               => 'Règles d\'entreprise contraignantes (BCR)',
            'safeguard_privacy_shield'    => 'Privacy Shield (plus valide)',
            'safeguard_adequacy_decision' => 'Décision d\'adéquation de la Commission européenne',
            'safeguard_consent'           => 'Consentement spécifique de la personne concernée',
            'safeguard_model_contracts'   => 'Contrats types',
            'safeguard_certification'     => 'Mécanismes de certification',
            'safeguard_codes_of_conduct'  => 'Codes de conduite',
            'safeguard_dpia'              => 'Analyse d\'impact relative à la protection des données (AIPD)',
            'safeguard_tia'               => 'Analyse d\'impact des transferts internationaux de données (TIA)',
        ];
    }
    return [
        'safeguard_scc'               => "Standard Contractual Clauses (SCCs)",
        'safeguard_bcr'               => "Binding Corporate Rules (BCRs)",
        'safeguard_privacy_shield'    => 'Privacy Shield (no longer valid)',
        'safeguard_adequacy_decision' => 'Adequacy decision of the European Commission',
        'safeguard_consent'           => 'Specific consent of the data subject',
        'safeguard_model_contracts'   => 'Model contracts',
        'safeguard_certification'     => 'Certification mechanisms',
        'safeguard_codes_of_conduct'  => 'Codes of conduct',
        'safeguard_dpia'              => 'Data Protection Impact Assessment (DPIA)',
        'safeguard_tia'               => 'International Data Transfer Impact Assessment (TIA)',
    ];
}


// ===============================================================
// HELPERS
// ===============================================================
function e(?string $s): string { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function new_id(): string { return 'c' . bin2hex(random_bytes(6)); }

function recommend_scc_module(string $roleP1, string $roleP2): string {
    $p1 = $roleP1 === 'processor'; $p2 = $roleP2 === 'processor';
    if (!$p1 && !$p2) return 'Module 1 — Controller-to-Controller (C2C)';
    if (!$p1 &&  $p2) return 'Module 2 — Controller-to-Processor (C2P)';
    if ( $p1 &&  $p2) return 'Module 3 — Processor-to-Processor (P2P)';
    return 'Module 4 — Processor-to-Controller (P2C)';
}

// ===============================================================
// VOORBEELDWAARDEN — EN en NL
// ===============================================================
function sample_values_en(): array {
    return [
        'company1_name'      => 'Acme Netherlands B.V.',
        'company1_address'   => 'Keizersgracht 123',
        'company1_country'   => 'Netherlands',
        'company1_kvk'       => '12345678',
        'company1_vat'       => 'NL123456789B01',
        'company1_iban'      => 'NL91 ABNA 0417 1643 00',
        'company1_rep'       => 'John Smith',
        'company1_rep_title' => 'Chief Executive Officer',
        'company1_email'     => 'j.smith@acme.com',
        'company1_phone'     => '+31 20 123 45 67',
        'company1_role'      => 'verwerkingsverantwoordelijke',
        'company2_name'      => 'CloudData Solutions GmbH',
        'company2_address'   => 'Friedrichstraße 88',
        'company2_country'   => 'Germany',
        'company2_kvk'       => 'HRB 987654',
        'company2_vat'       => 'DE987654321',
        'company2_iban'      => 'DE89 3704 0044 0532 0130 00',
        'company2_rep'       => 'Anna Schmidt',
        'company2_rep_title' => 'Managing Director',
        'company2_email'     => 'a.schmidt@clouddata.de',
        'company2_phone'     => '+49 30 987 65 43',
        'company2_role'      => 'verwerker',
        'purpose'        => 'Hosting and managing customer data for the SaaS service, including storage, backup and technical administration.',
        'dataCategories' => 'Name, email address, telephone number, IP address, invoice details, usage statistics.',
        'dataSubjects'   => 'Customers, prospects, customer employees, website visitors.',
        'effectiveDate'  => date('d-m-Y'),
        'duration'       => '3 years, automatically renewed for successive periods of 1 year',
        'noticePeriod'   => '2 months',
        'contractValue'  => '125,000',
        'liabilityCap'   => 'Limited to the annual contract value, except in case of intent or gross negligence.',
        'paymentTerms'   => 'Payment within 30 days of invoice date, without deduction or set-off.',
        'penaltyClause'  => '€ 500 per day for non-performance, up to a maximum of 10% of the annual contract value.',
        'slaUptime'      => '99.9% monthly',
        'slaResponse'    => '4 hours during office hours for critical incidents, 8 hours for other incidents.',
        'subProcessors'  => "- Amazon Web Services EMEA SARL (Ireland)\n- Cloudflare Inc. (USA, under SCCs)\n- Stripe Payments Europe Ltd. (Ireland)",
        'confidentiality'=> '5',
        'governingLaw'   => 'Dutch law',
        'jurisdiction'   => 'Amsterdam District Court',
        'insurance'      => 'Professional liability insurance with cover of at least € 2,000,000 per event, plus cyber insurance.',
        'auditRights'    => 'Annual audit possible with at least 10 business days notice. Audits are performed by an independent third party.',
        'extraNotes'     => 'The Parties agree that changes to sub-processors must be notified in writing in advance. This agreement is supplementary to the general terms and conditions of Party 1.',
    ];
}

function sample_values_nl(): array {
    return [
        'company1_name'      => 'Acme Nederland B.V.',
        'company1_address'   => 'Keizersgracht 123',
        'company1_country'   => 'Nederland',
        'company1_kvk'       => '12345678',
        'company1_vat'       => 'NL123456789B01',
        'company1_iban'      => 'NL91 ABNA 0417 1643 00',
        'company1_rep'       => 'Jan de Vries',
        'company1_rep_title' => 'Algemeen Directeur',
        'company1_email'     => 'j.devries@acme.nl',
        'company1_phone'     => '+31 20 123 45 67',
        'company1_role'      => 'verwerkingsverantwoordelijke',
        'company2_name'      => 'CloudData Solutions GmbH',
        'company2_address'   => 'Friedrichstraße 88',
        'company2_country'   => 'Duitsland',
        'company2_kvk'       => 'HRB 987654',
        'company2_vat'       => 'DE987654321',
        'company2_iban'      => 'DE89 3704 0044 0532 0130 00',
        'company2_rep'       => 'Anna Schmidt',
        'company2_rep_title' => 'Managing Director',
        'company2_email'     => 'a.schmidt@clouddata.de',
        'company2_phone'     => '+49 30 987 65 43',
        'company2_role'      => 'verwerker',
        'purpose'        => 'Het hosten en beheren van klantgegevens ten behoeve van de SaaS-dienstverlening, waaronder opslag, back-up en technisch beheer.',
        'dataCategories' => 'Naam, e-mailadres, telefoonnummer, IP-adres, factuurgegevens, gebruiksstatistieken.',
        'dataSubjects'   => 'Klanten, prospects, medewerkers van klanten, websitebezoekers.',
        'effectiveDate'  => date('d-m-Y'),
        'duration'       => '3 jaar, met stilzwijgende verlenging van telkens 1 jaar',
        'noticePeriod'   => '2 maanden',
        'contractValue'  => '125.000',
        'liabilityCap'   => 'Beperkt tot de jaarlijkse contractwaarde, behoudens opzet of grove schuld.',
        'paymentTerms'   => 'Betaling binnen 30 dagen na factuurdatum, zonder aftrek of verrekening.',
        'penaltyClause'  => '€ 500 per dag bij tekortkoming, met een maximum van 10% van de jaarlijkse contractwaarde.',
        'slaUptime'      => '99,9% op maandbasis',
        'slaResponse'    => '4 uur tijdens kantooruren bij kritieke incidenten, 8 uur bij overige incidenten.',
        'subProcessors'  => "- Amazon Web Services EMEA SARL (Ierland)\n- Cloudflare Inc. (VS, onder SCC's)\n- Stripe Payments Europe Ltd. (Ierland)",
        'confidentiality'=> '5',
        'governingLaw'   => 'Nederlands recht',
        'jurisdiction'   => 'Rechtbank Amsterdam',
        'insurance'      => 'Beroepsaansprakelijkheidsverzekering met dekking van minimaal € 2.000.000 per gebeurtenis, plus cyberverzekering.',
        'auditRights'    => 'Jaarlijkse audit mogelijk met minimaal 10 werkdagen kennisgeving. Audits worden uitgevoerd door een onafhankelijke derde partij.',
        'extraNotes'     => 'Partijen komen overeen dat wijzigingen in sub-verwerkers vooraf schriftelijk gemeld dienen te worden. Deze overeenkomst is aanvullend op de algemene voorwaarden van Partij 1.',
    ];
}

function sample_values_de(): array {
    return [
        'company1_name'      => 'Acme Netherlands B.V.',
        'company1_address'   => 'Keizersgracht 123',
        'company1_country'   => 'Niederlande',
        'company1_kvk'       => '12345678',
        'company1_vat'       => 'NL123456789B01',
        'company1_iban'      => 'NL91 ABNA 0417 1643 00',
        'company1_rep'       => 'Jan de Vries',
        'company1_rep_title' => 'Geschäftsführer',
        'company1_email'     => 'j.devries@acme.nl',
        'company1_phone'     => '+31 20 123 45 67',
        'company1_role'      => 'Verantwortlicher',
        'company2_name'      => 'CloudData Solutions GmbH',
        'company2_address'   => 'Friedrichstraße 88',
        'company2_country'   => 'Deutschland',
        'company2_kvk'       => 'HRB 987654',
        'company2_vat'       => 'DE987654321',
        'company2_iban'      => 'DE89 3704 0044 0532 0130 00',
        'company2_rep'       => 'Anna Schmidt',
        'company2_rep_title' => 'Managing Director',
        'company2_email'     => 'a.schmidt@clouddata.de',
        'company2_phone'     => '+49 30 987 65 43',
        'company2_role'      => 'Auftragsverarbeiter',
        'purpose'        => 'Das Hosten und Verwalten von Kundendaten im Rahmen der SaaS-Dienstleistungen, einschließlich Speicherung, Datensicherung und technischer Verwaltung.',
        'dataCategories' => 'Name, E-Mail-Adresse, Telefonnummer, IP-Adresse, Rechnungsdaten, Nutzungsstatistiken.',
        'dataSubjects'   => 'Kunden, Interessenten, Mitarbeiter von Kunden, Website-Besucher.',
        'effectiveDate'  => date('d-m-Y'),
        'duration'       => '3 Jahre, mit stillschweigender Verlängerung jeweils um 1 Jahr',
        'noticePeriod'   => '2 Monate',
        'contractValue'  => '125.000',
        'liabilityCap'   => 'Begrenzt auf den jährlichen Vertragswert, außer bei Vorsatz oder grober Fahrlässigkeit.',
        'paymentTerms'   => 'Zahlung innerhalb von 30 Tagen nach Rechnungsdatum, ohne Abzug oder Aufrechnung.',
        'penaltyClause'  => '500 € pro Tag bei Vertragsverletzung, maximal 10 % des jährlichen Vertragswerts.',
        'slaUptime'      => '99,9 % im Monatsdurchschnitt',
        'slaResponse'    => '4 Stunden während der Bürozeiten bei kritischen Vorfällen, 8 Stunden bei sonstigen Vorfällen.',
        'subProcessors'  => "- Amazon Web Services EMEA SARL (Irland)\n- Cloudflare Inc. (USA, im Rahmen von SCCs)\n- Stripe Payments Europe Ltd. (Irland)",
        'confidentiality'=> '5',
        'governingLaw'   => 'Niederländisches Recht',
        'jurisdiction'   => 'Gerichtsstand Amsterdam',
        'insurance'      => 'Berufshaftpflichtversicherung mit einer Deckungssumme von mindestens 2.000.000 € pro Schadensfall sowie Cyberversicherung.',
        'auditRights'    => 'Jährliches Audit möglich mit einer Vorankündigung von mindestens 10 Werktagen. Audits werden von einem unabhängigen Dritten durchgeführt.',
        'extraNotes'     => 'Die Parteien vereinbaren, dass Änderungen bei Unterauftragsverarbeitern vorab schriftlich mitgeteilt werden müssen. Diese Vereinbarung ergänzt die Allgemeinen Geschäftsbedingungen von Partei 1.',
    ];
}

function sample_values_es(): array {
    return [
        'company1_name'      => 'Acme Netherlands B.V.',
        'company1_address'   => 'Keizersgracht 123',
        'company1_country'   => 'Países Bajos',
        'company1_kvk'       => '12345678',
        'company1_vat'       => 'NL123456789B01',
        'company1_iban'      => 'NL91 ABNA 0417 1643 00',
        'company1_rep'       => 'John Smith',
        'company1_rep_title' => 'Consejero delegado',
        'company1_email'     => 'j.smith@acme.com',
        'company1_phone'     => '+31 20 123 45 67',
        'company1_role'      => 'verwerkingsverantwoordelijke',
        'company2_name'      => 'CloudData Solutions GmbH',
        'company2_address'   => 'Friedrichstraße 88',
        'company2_country'   => 'Alemania',
        'company2_kvk'       => 'HRB 987654',
        'company2_vat'       => 'DE987654321',
        'company2_iban'      => 'DE89 3704 0044 0532 0130 00',
        'company2_rep'       => 'Anna Schmidt',
        'company2_rep_title' => 'Director general',
        'company2_email'     => 'a.schmidt@clouddata.de',
        'company2_phone'     => '+49 30 987 65 43',
        'company2_role'      => 'verwerker',
        'purpose'        => 'Alojamiento y gestión de los datos de los clientes para el servicio SaaS, incluyendo el almacenamiento, las copias de seguridad y la administración técnica.',
        'dataCategories' => 'Nombre, dirección de correo electrónico, número de teléfono, dirección IP, datos de facturación, estadísticas de uso.',
        'dataSubjects'   => 'Clientes, clientes potenciales, empleados de los clientes, visitantes del sitio web.',
        'effectiveDate'  => date('d-m-Y'),
        'duration'       => '3 años, renovables automáticamente por períodos sucesivos de 1 año',
        'noticePeriod'   => '2 meses',
        'contractValue'  => '125.000',
        'liabilityCap'   => 'Limitada al valor anual del contrato, salvo en caso de dolo o negligencia grave.',
        'paymentTerms'   => 'Pago en un plazo de 30 días a partir de la fecha de la factura, sin deducciones ni compensaciones.',
        'penaltyClause'  => '500 € al día por incumplimiento, hasta un máximo del 10 % del valor anual del contrato.',
        'slaUptime'      => '99,9 % mensual',
        'slaResponse'    => '4 horas en horario de oficina para incidencias críticas, 8 horas para el resto de incidencias.',
        'subProcessors'  => '- Amazon Web Services EMEA SARL (Irlanda)
- Cloudflare Inc. (EE. UU., bajo las Cláusulas Contractuales Tipo de la UE)
- Stripe Payments Europe Ltd. (Irlanda)',
        'confidentiality'=> '5',
        'governingLaw'   => 'Legislación neerlandesa',
        'jurisdiction'   => 'Tribunal de Distrito de Ámsterdam',
        'insurance'      => 'Seguro de responsabilidad civil profesional con una cobertura mínima de 2 000 000 € por siniestro, más un seguro cibernético.',
        'auditRights'    => 'Es posible realizar una auditoría anual con un preaviso de al menos 10 días hábiles. Las auditorías las lleva a cabo un tercero independiente.',
        'extraNotes'     => 'Las Partes acuerdan que los cambios en los subencargados del tratamiento deben notificarse por escrito con antelación. El presente acuerdo es complementario a los términos y condiciones generales de la Parte 1.',
    ];
}

function sample_values_fr(): array {
    return [
        'company1_name'      => 'Acme Netherlands B.V.',
        'company1_address'   => 'Keizersgracht 123',
        'company1_country'   => 'Pays-Bas',
        'company1_kvk'       => '12345678',
        'company1_vat'       => 'NL123456789B01',
        'company1_iban'      => 'NL91 ABNA 0417 1643 00',
        'company1_rep'       => 'John Smith',
        'company1_rep_title' => 'Président-directeur général',
        'company1_email'     => 'j.smith@acme.com',
        'company1_phone'     => '+31 20 123 45 67',
        'company1_role'      => 'verwerkingsverantwoordelijke',
        'company2_name'      => 'CloudData Solutions GmbH',
        'company2_address'   => 'Friedrichstraße 88',
        'company2_country'   => 'Allemagne',
        'company2_kvk'       => 'HRB 987654',
        'company2_vat'       => 'DE987654321',
        'company2_iban'      => 'DE89 3704 0044 0532 0130 00',
        'company2_rep'       => 'Anna Schmidt',
        'company2_rep_title' => 'Directeur général',
        'company2_email'     => 'a.schmidt@clouddata.de',
        'company2_phone'     => '+49 30 987 65 43',
        'company2_role'      => 'verwerker',
        'purpose'        => 'Hébergement et gestion des données clients pour le service SaaS, y compris le stockage, la sauvegarde et l\'administration technique.',
        'dataCategories' => 'Nom, adresse e-mail, numéro de téléphone, adresse IP, détails de facturation, statistiques d’utilisation.',
        'dataSubjects'   => 'Clients, prospects, employés des clients, visiteurs du site web.',
        'effectiveDate'  => date('d-m-Y'),
        'duration'       => '3 ans, renouvellement automatique pour des périodes successives d’un an',
        'noticePeriod'   => '2 mois',
        'contractValue'  => '125.000',
        'liabilityCap'   => 'Limité à la valeur annuelle du contrat, sauf en cas de faute intentionnelle ou de négligence grave.',
        'paymentTerms'   => 'Paiement dans les 30 jours suivant la date de facturation, sans déduction ni compensation.',
        'penaltyClause'  => '500 € par jour en cas d’inexécution, dans la limite de 10 % de la valeur annuelle du contrat.',
        'slaUptime'      => '99,9 % par mois',
        'slaResponse'    => '4 heures pendant les heures de bureau pour les incidents critiques, 8 heures pour les autres incidents.',
        'subProcessors'  => '- Amazon Web Services EMEA SARL (Irlande)
- Cloudflare Inc. (États-Unis, dans le cadre des clauses contractuelles types)
- Stripe Payments Europe Ltd. (Irlande)',
        'confidentiality'=> '5',
        'governingLaw'   => 'Droit néerlandais',
        'jurisdiction'   => 'Tribunal d’arrondissement d’Amsterdam',
        'insurance'      => 'Assurance responsabilité civile professionnelle avec une couverture d’au moins 2 000 000 € par sinistre, ainsi qu’une cyberassurance.',
        'auditRights'    => 'Audit annuel possible moyennant un préavis d’au moins 10 jours ouvrés. Les audits sont réalisés par un tiers indépendant.',
        'extraNotes'     => 'Les parties conviennent que tout changement concernant les sous-traitants doit être notifié par écrit à l’avance. Le présent accord vient compléter les conditions générales de la partie 1.',
    ];
}

function sample_values(): array {
    return match (current_lang()) {
        'nl' => sample_values_nl(),
        'de' => sample_values_de(),
        'es' => sample_values_es(),
        'fr' => sample_values_fr(),
        default => sample_values_en(),
    };
}

$SAMPLES = sample_values();

// ===============================================================
// PAYLOAD
// ===============================================================
function make_payload(array $record): string {
    $json = json_encode($record, JSON_UNESCAPED_UNICODE);
    if ($json === false) $json = '{}';
    $compressed = gzcompress($json, 9);
    if ($compressed === false) $compressed = $json;
    return base64_encode($compressed);
}

function read_payload(string $payload): ?array {
    $payload = preg_replace('/\s+/', '', trim($payload));
    $raw = base64_decode($payload, true);
    if ($raw === false) return null;
    $json = @gzuncompress($raw);
    if ($json === false) $json = $raw;
    $data = json_decode($json, true);
    return is_array($data) ? $data : null;
}

function payload_md5(string $payload): string { return md5($payload); }

// ===============================================================
// CONTRACT DEFINITIONS UIT JSON (bv. contracts/safeguard_scc.json)
// -----------------------------------------------------------------
// Contracten worden NIET meer inline (als PHP-heredoc) opgeslagen.
// Een contract zoals de SCC wordt beheerd als los JSON-bestand in de
// map /contracts, per artikel en per taal (en/nl/de), en is te
// bewerken via het tabblad "Configuratie contracten". Bij het
// genereren van een nieuw contract wordt dat JSON-bestand live
// ingeladen; de rest van de flow (payload, MD5, QR, ondertekenen)
// verandert niet.
// ===============================================================
define('CONTRACTS_DIR', __DIR__ . '/contracts');

function contract_safe_key(string $key): string {
    return preg_replace('/[^a-zA-Z0-9_\-]/', '', $key);
}

function contract_json_path(string $key): string {
    return CONTRACTS_DIR . '/' . contract_safe_key($key) . '.json';
}

function contract_json_raw(string $key): ?string {
    $safe = contract_safe_key($key);
    if ($safe === '') return null;
    $path = contract_json_path($safe);
    if (!is_file($path)) return null;
    $raw = @file_get_contents($path);
    return $raw === false ? null : $raw;
}

function load_contract_definition(string $key): ?array {
    static $cache = [];
    $safe = contract_safe_key($key);
    if ($safe === '') return null;
    if (array_key_exists($safe, $cache)) return $cache[$safe];
    $raw = contract_json_raw($safe);
    if ($raw === null) return $cache[$safe] = null;
    $data = json_decode($raw, true);
    if (!is_array($data) || empty($data['articles']) || !is_array($data['articles'])) {
        return $cache[$safe] = null;
    }
    if (empty($data['languages']) || !is_array($data['languages'])) {
        // Was ooit ['en'] (uit de tijd dat EN de brontaal was). Nederlands is
        // nu de brontaal, met Engels als vaste tweede standaardtaal; Duits,
        // Frans en Spaans (en elke andere DeepL-taal) worden niet meer
        // standaard aangenomen maar alleen nog on-demand via DeepL
        // toegevoegd (Extra vertalingen / Automatisch vertalen) — dus voor
        // een contract-json zonder eigen 'languages'-sleutel gaan we uit van
        // alleen nl + en.
        $data['languages'] = ['nl', 'en'];
    }
    return $cache[$safe] = $data;
}

function contract_definition_languages(string $key): array {
    $def = load_contract_definition($key);
    return $def['languages'] ?? [];
}

// Contracten die nooit via het configuratie-tabblad overschreven of
// verwijderd mogen worden. Het standaard SCC-contract blijft altijd
// volledig leesbaar/bruikbaar (om contracten te genereren en als basis
// voor een kloon), maar is niet-beschrijfbaar: opslaan/verwijderen wordt
// zowel hier (duidelijke foutmelding) als op bestandsniveau (chmod 0444,
// zie install/deploy) geweigerd.
function protected_contract_keys(): array {
    return ['safeguard_scc'];
}

function is_protected_contract(string $key): bool {
    return in_array(contract_safe_key($key), protected_contract_keys(), true);
}

// Alle beschikbare contract-JSON-bestanden in /contracts, als key => label.
// Wordt gebruikt voor de contractkiezer in "Nieuw contract" en voor de
// "kloon van"-lijst bij het aanmaken van een nieuw contract in de
// configurator.
function contract_display_label(string $key): string {
    $safe = contract_safe_key($key);
    $def = load_contract_definition($safe);
    if ($def !== null && !empty($def['title'])) return (string)$def['title'];
    return $safe === 'safeguard_scc' ? t('contract_default_label') : $safe;
}

function list_available_contracts(): array {
    $out = [];
    if (is_dir(CONTRACTS_DIR)) {
        $files = @scandir(CONTRACTS_DIR) ?: [];
        sort($files);
        foreach ($files as $f) {
            if (!str_ends_with($f, '.json')) continue;
            $key = contract_safe_key(substr($f, 0, -5));
            if ($key === '') continue;
            if (load_contract_definition($key) === null) continue;
            $out[$key] = contract_display_label($key);
        }
    }
    if (!isset($out['safeguard_scc']) && load_contract_definition('safeguard_scc') !== null) {
        $out = ['safeguard_scc' => contract_display_label('safeguard_scc')] + $out;
    }
    return $out;
}

// Korte vervangtekst voor het geval het JSON-bestand ontbreekt of
// niet gelezen kon worden — vervangt de vroegere, lange inline tekst.
function contract_missing_json_notice(string $lang): string {
    $en = "ANNEX A — STANDARD CONTRACTUAL CLAUSES (SCCs)\n>>> This text is managed via contracts/safeguard_scc.json (the \"Contract configuration\" tab). The file is missing or could not be read; restore it to display this annex correctly.";
    $static = match ($lang) {
        'nl' => "BIJLAGE A — STANDAARDCONTRACTBEPALINGEN (SCC's)\n>>> Deze tekst wordt beheerd via contracts/safeguard_scc.json (tabblad \"Configuratie contracten\"). Het bestand ontbreekt of kon niet worden gelezen; herstel het om deze bijlage correct te tonen.",
        'de' => "ANHANG A — STANDARDVERTRAGSKLAUSELN (SCCs)\n>>> Dieser Text wird über contracts/safeguard_scc.json verwaltet (Registerkarte \"Vertragskonfiguration\"). Die Datei fehlt oder konnte nicht gelesen werden; stellen Sie sie wieder her, um diesen Anhang korrekt anzuzeigen.",
        'es' => "ANEXO A — CLÁUSULAS CONTRACTUALES TIPO (SCC)\n>>> Este texto se gestiona mediante contracts/safeguard_scc.json (pestaña \"Configuración de contratos\"). El archivo falta o no se ha podido leer; restáuralo para mostrar este anexo correctamente.",
        'fr' => "ANNEXE A — CLAUSES CONTRACTUELLES TYPES (CCT)\n>>> Ce texte est géré via contracts/safeguard_scc.json (onglet \"Configuration des contrats\"). Le fichier est manquant ou n'a pas pu être lu ; restaurez-le pour afficher correctement cette annexe.",
        'en' => $en,
        default => null,
    };
    if ($static !== null) return $static;
    // Taal buiten UI_LANGS (bv. Arabisch, Russisch): vertaal de Engelse
    // melding lui via DeepL en cache per taal (label_translate.php).
    if (!function_exists('translate_doc_label')) return $en;
    return translate_doc_label('contract_missing_json_notice', $lang, $en);
}

// Rendert een volledig contract rechtstreeks uit een JSON-definitie
// (schema contractregister/contract/v1): elk artikel (Preamble, 1..7,
// A.1..A.9, C.I..C.III, Signatures) wordt na elkaar gezet, met dezelfde
// {{PLACEHOLDER}}-vervanging (ph()) en dezelfde per-instantie
// enable/override-mogelijkheid (render_article()) als de rest van de
// tool al gebruikt.
//
// Tussen de artikelen komen CONTRACT_ARTICLE_BLANK_LINES lege regels
// (standaard 2), zodat elk artikel in de .txt/MHTML/print duidelijk los staat.
// De witruimte aan het eind van elk artikel wordt eerst weggehaald, zodat het
// aantal lege regels altijd precies gelijk is, ongeacht de JSON-body.
//
// (Historisch:) er werd hier géén extra "\n\n" meer tussen artikelen gezet.
// De artikelen zelf bevatten hun eigen witruimte (via de JSON-body), en
// de vroege versie plakte daar onvoorwaardelijk een extra lege regel
// tussen — dat gaf in de praktijk te veel witruimte in de PDF/print en
// in de voorbeeldweergave. We joinen nu met een enkele "\n" en trimmen
// elke gerenderde bijdrage, zodat de opmaak exact volgt wat er in het
// JSON-bestand staat.
const CONTRACT_ARTICLE_BLANK_LINES = 2;

function render_contract_from_definition(array $def, array $d): string {
    $languages = $def['languages'] ?? ['en'];
    $lang = $d['lang'] ?? current_lang();
    if (!in_array($lang, $languages, true)) {
        $lang = $languages[0] ?? 'en';
    }

    $parts = [];
    foreach ($def['articles'] as $key => $byLang) {
        if (!is_array($byLang)) continue;
        $entry = $byLang[$lang] ?? $byLang['en'] ?? reset($byLang);
        if (!is_array($entry)) continue;
        $title = (string)($entry['title'] ?? '');
        $body  = (string)($entry['body']  ?? '');
        // De Preamble draagt zijn eigen opmaakkop al in de body (bv.
        // "DATA TRANSFER AGREEMENT..."); de titel is daar alleen een
        // kort label en hoeft niet nogmaals boven de tekst te komen.
        $defaultTpl = ($title !== '' && (string)$key !== 'Preamble') ? ($title . "\n" . $body) : $body;
        $rendered = rtrim(render_article($d, (string)$key, $defaultTpl), " \t\r\n");
        $rendered = ltrim($rendered, "\r\n");
        if ($rendered !== '') $parts[] = $rendered;
    }
    if ($parts === []) return '';
    $gap = str_repeat("\n", CONTRACT_ARTICLE_BLANK_LINES + 1);
    return implode($gap, $parts) . $gap;
}

// ===============================================================
// CONTRACT-OVERZICHT — Bedrijfsgegevens / Verwerkingsdetails /
// Commerciële voorwaarden / Bijlagen aanpassen, in deze volgorde,
// vooraan in het gegenereerde contract.
//
// De bedrijfsgegevens worden hier ALLEEN als waarde getoond (zonder
// label als "Naam Partij 1:"), zodat het overzicht direct de ingevulde
// variabelen toont. De commerciële en verwerkings-artikelen krijgen
// elk een extra lege regel zodat ze in de PDF/print duidelijk
// gescheiden zijn — dit is wat "extra new lines per artikel" doet.
// ===============================================================
function summary_line(string $label, $value): string {
    $val = is_string($value) ? trim($value) : (string)$value;
    if ($val === '') $val = t('summary_empty');
    // Meerregelige waarden (textareas) netjes laten inspringen.
    $val = str_replace("\n", "\n    ", $val);
    return '- ' . $label . ': ' . $val;
}

// Zelfde als summary_line, maar dan zonder label — puur de waarde.
// Wordt gebruikt voor de bedrijfsgegevens, waar de gebruiker alleen de
// variabele-inhoud wil zien (niet de labels "Naam Partij 1" e.d.).
function summary_value($value): string {
    $val = is_string($value) ? trim($value) : (string)$value;
    if ($val === '') $val = t('summary_empty');
    $val = str_replace("\n", "\n    ", $val);
    return '- ' . $val;
}

// Wrapper: rendert het overzicht met t() tijdelijk vastgezet op de taal van
// dit contract ($d['lang']), zie de toelichting bij render_lang() hierboven.
function contract_summary_section(array $d): string {
    $lang = (string)($d['lang'] ?? current_lang());
    return with_render_lang($lang, function () use ($d) {
        return contract_summary_section_body($d);
    });
}

function contract_summary_section_body(array $d): string {
    $lines = [];
    $lines[] = '=== ' . t('summary_heading') . ' ===';
    $lines[] = '';

    // 1) Bedrijfsgegevens — alleen de variabele-inhoud, geen labels.
    $lines[] = '## ' . t('section_company');
    $lines[] = t('summary_company_p1') . ':';
    $lines[] = summary_value($d['company1_name'] ?? '');
    $lines[] = summary_value($d['company1_role'] ?? '');
    $lines[] = summary_value($d['company1_address'] ?? '');
    $lines[] = summary_value($d['company1_country'] ?? '');
    $lines[] = summary_value($d['company1_kvk'] ?? '');
    $lines[] = summary_value($d['company1_vat'] ?? '');
    $lines[] = summary_value($d['company1_iban'] ?? '');
    $lines[] = summary_value($d['company1_rep'] ?? '');
    $lines[] = summary_value($d['company1_rep_title'] ?? '');
    $lines[] = summary_value($d['company1_email'] ?? '');
    $lines[] = summary_value($d['company1_phone'] ?? '');
    $lines[] = '';
    $lines[] = t('summary_company_p2') . ':';
    $lines[] = summary_value($d['company2_name'] ?? '');
    $lines[] = summary_value($d['company2_role'] ?? '');
    $lines[] = summary_value($d['company2_address'] ?? '');
    $lines[] = summary_value($d['company2_country'] ?? '');
    $lines[] = summary_value($d['company2_kvk'] ?? '');
    $lines[] = summary_value($d['company2_vat'] ?? '');
    $lines[] = summary_value($d['company2_iban'] ?? '');
    $lines[] = summary_value($d['company2_rep'] ?? '');
    $lines[] = summary_value($d['company2_rep_title'] ?? '');
    $lines[] = summary_value($d['company2_email'] ?? '');
    $lines[] = summary_value($d['company2_phone'] ?? '');
    $lines[] = '';

    // 2) Verwerkingsdetails — extra lege regel per artikel.
    $lines[] = '## ' . t('section_processing');
    $lines[] = '';
    $lines[] = summary_line(t('purpose'), $d['purpose'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('data_categories'), $d['dataCategories'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('data_subjects'), $d['dataSubjects'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('effective_date'), $d['effectiveDate'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('duration'), $d['duration'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('notice_period'), $d['noticePeriod'] ?? '');
    $lines[] = '';

    // 3) Commerciële voorwaarden — extra lege regel per artikel.
    $lines[] = '## ' . t('section_commercial');
    $lines[] = '';
    $lines[] = summary_line(t('contract_value'), $d['contractValue'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('currency'), $d['currency'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('liability_cap'), $d['liabilityCap'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('payment_terms'), $d['paymentTerms'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('penalty_clause'), $d['penaltyClause'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('sla_uptime'), $d['slaUptime'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('sla_response'), $d['slaResponse'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('sub_processors'), $d['subProcessors'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('confidentiality'), $d['confidentiality'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('governing_law'), $d['governingLaw'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('jurisdiction'), $d['jurisdiction'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('insurance'), $d['insurance'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('audit_rights'), $d['auditRights'] ?? '');
    $lines[] = '';
    $lines[] = summary_line(t('extra_notes'), $d['extraNotes'] ?? '');
    $lines[] = '';

    // 4) Bijlagen aanpassen — status per artikel van de gekozen sjabloon
    $lines[] = '## ' . t('section_annexes');
    $jsonDef = (function_exists('merged_contract_definition') ? merged_contract_definition($d) : null)
        ?? load_contract_definition((string)($d['safeguard'] ?? 'safeguard_scc'));
    if ($jsonDef !== null && !empty($jsonDef['articles']) && is_array($jsonDef['articles'])) {
        $lang = $d['lang'] ?? current_lang();
        foreach ($jsonDef['articles'] as $key => $byLang) {
            if (!is_array($byLang)) continue;
            $entry = $byLang[$lang] ?? $byLang['en'] ?? reset($byLang);
            $title = is_array($entry) ? (string)($entry['title'] ?? (string)$key) : (string)$key;
            $status = article_enabled($d, (string)$key) ? t('summary_annex_included') : t('summary_annex_removed');
            $lines[] = '- ' . $title . ' (' . $key . '): ' . $status;
        }
        // Artikelen die partijen bij de overeenkomst hebben weggelaten.
        foreach ((array)($d['mergedContract']['excluded'] ?? []) as $__x) {
            $lines[] = '- ' . $__x . ': ' . t('summary_annex_removed');
        }
    }
    $lines[] = '';
    $lines[] = str_repeat('=', 32);
    $lines[] = '';

    return implode("\n", $lines);
}

// ===============================================================
// CONTRACT TEXT — tweetalig
// ===============================================================
function generate_contract_body(array $d, array $types): string {
    // Overeenkomst uit twee contracten: de artikelen (en eventuele tweede
    // taal) komen uit de payload zelf, niet uit contracts/<key>.json.
    if (!empty($d['mergedContract']) && function_exists('merged_contract_body')) {
        $merged = merged_contract_body($d, 'contract_summary_section');
        if ($merged !== null) return $merged;
    }
    $summary = contract_summary_section($d);
    $jsonDef = load_contract_definition((string)($d['safeguard'] ?? 'safeguard_scc'));
    if ($jsonDef !== null) {
        return $summary . render_contract_from_definition($jsonDef, $d);
    }
    // Niet meer clemmen tot UI_LANGS: contract_missing_json_notice() vertaalt
    // en cachet zelf voor elke andere DeepL-taal (label_translate.php).
    $__lang = (string)($d['lang'] ?? current_lang());
    return $summary . contract_missing_json_notice($__lang);
}



// ===============================================================
// BIJLAGEN — placeholders
// ===============================================================
// Standaardteksten die ph() invult wanneer een veld leeg is, per
// contracttaal (niet de UI-taal — een contract kan in het Engels worden
// gegenereerd terwijl de interface op Nederlands staat). Voorheen stonden
// hier altijd de Nederlandse woorden, ook in een Engels/Duits contract.
function ph_defaults(string $lang): array {
    $static = match ($lang) {
        'en' => [
            'R1'    => 'controller',
            'R2'    => 'processor',
            'LAW'   => 'Dutch law',
            'FORUM' => 'the District Court of Amsterdam',
            'SUBS'  => '- None at this time -',
            'DUR'   => 'an indefinite period',
        ],
        'de' => [
            'R1'    => 'Verantwortlicher',
            'R2'    => 'Auftragsverarbeiter',
            'LAW'   => 'niederländisches Recht',
            'FORUM' => 'das Gericht Amsterdam',
            'SUBS'  => '- Derzeit keine -',
            'DUR'   => 'unbestimmte Zeit',
        ],
        'es' => [
            'R1'    => 'responsable del tratamiento',
            'R2'    => 'encargado del tratamiento',
            'LAW'   => 'la legislación neerlandesa',
            'FORUM' => 'el Tribunal de Distrito de Ámsterdam',
            'SUBS'  => '- Ninguno por el momento -',
            'DUR'   => 'un período indefinido',
        ],
        'fr' => [
            'R1'    => 'responsable du traitement',
            'R2'    => 'sous-traitant',
            'LAW'   => 'le droit néerlandais',
            'FORUM' => 'le tribunal de district d\'Amsterdam',
            'SUBS'  => '- Aucun pour le moment -',
            'DUR'   => 'une durée indéterminée',
        ],
        'nl' => [
            'R1'    => 'verwerkingsverantwoordelijke',
            'R2'    => 'verwerker',
            'LAW'   => 'Nederlands recht',
            'FORUM' => 'Rechtbank Amsterdam',
            'SUBS'  => '- Geen op dit moment -',
            'DUR'   => 'onbepaalde tijd',
        ],
        default => null,
    };
    if ($static !== null) return $static;

    // Taal buiten UI_LANGS (bv. Arabisch, Russisch — via de "Extra
    // vertalingen"-checkboxes bij "Nieuw contract"): de Engelse standaard-
    // waarden hierboven worden lui via DeepL vertaald en per taal gecached
    // (label_translate.php), i.p.v. stilzwijgend op Engels terug te vallen.
    $en = [
        'R1'    => 'controller',
        'R2'    => 'processor',
        'LAW'   => 'Dutch law',
        'FORUM' => 'the District Court of Amsterdam',
        'SUBS'  => '- None at this time -',
        'DUR'   => 'an indefinite period',
    ];
    if (!function_exists('translate_doc_label')) return $en;
    $out = [];
    foreach ($en as $k => $v) {
        $out[$k] = translate_doc_label('ph_default:' . $k, $lang, $v);
    }
    return $out;
}

// De rolkiezer in "Nieuw contract" stuurt altijd de Nederlandse waarde op
// (verwerkingsverantwoordelijke/verwerker/gezamenlijke ...), ongeacht de
// interfacetaal — scc_module() herkent de module aan die vaste Nederlandse
// tekst. Voor weergave in {{R1}}/{{R2}} vertalen we die vaste waarde hier
// naar de contracttaal; vrije tekst (een handmatig aangepaste rol) laten we
// ongewijzigd staan.
function ph_role_label(string $role, string $lang): string {
    $labels = [
        'verwerkingsverantwoordelijke' => ['nl' => 'verwerkingsverantwoordelijke', 'en' => 'controller', 'de' => 'Verantwortlicher', 'es' => 'responsable del tratamiento', 'fr' => 'responsable du traitement'],
        'verwerker' => ['nl' => 'verwerker', 'en' => 'processor', 'de' => 'Auftragsverarbeiter', 'es' => 'encargado del tratamiento', 'fr' => 'sous-traitant'],
        'gezamenlijke verwerkingsverantwoordelijke' => ['nl' => 'gezamenlijke verwerkingsverantwoordelijke', 'en' => 'joint controller', 'de' => 'gemeinsamer Verantwortlicher', 'es' => 'responsable conjunto del tratamiento', 'fr' => 'responsable conjoint du traitement'],
    ];
    $key = strtolower(trim($role));
    if (!isset($labels[$key])) return $role;
    if (isset($labels[$key][$lang])) return $labels[$key][$lang];
    $en = $labels[$key]['en'];
    // Taal buiten UI_LANGS (bv. Arabisch, Russisch): vertaal de Engelse
    // rolnaam lui via DeepL en cache per taal (label_translate.php), i.p.v.
    // stilzwijgend op Engels terug te vallen.
    if (!in_array($lang, UI_LANGS, true) && function_exists('translate_doc_label')) {
        return translate_doc_label('ph_role:' . $key, $lang, $en);
    }
    return $en;
}

function ph(string $tpl, array $d): string {
    // $__lang mag hier elke taal zijn die de contracttaalkiezer of de "Extra
    // vertalingen"-checkboxes opleveren — óók buiten UI_LANGS (bv. 'ar',
    // 'ru'). Wordt niet meer geclemd tot 'en': ph_defaults()/ph_role_label()
    // vertalen en cachen de vaste fallback-tekst zelf zodra dat nodig is.
    $__lang = (string)($d['lang'] ?? current_lang());
    $def = ph_defaults($__lang);

    return strtr($tpl, [
        '{{P1}}'     => ($d['company1_name']     ?? '') ?: '—',
        '{{P2}}'     => ($d['company2_name']     ?? '') ?: '—',
        '{{A1}}'     => trim((($d['company1_address'] ?? '') . ', ' . ($d['company1_country'] ?? '')), ', ') ?: '—',
        '{{A2}}'     => trim((($d['company2_address'] ?? '') . ', ' . ($d['company2_country'] ?? '')), ', ') ?: '—',
        '{{C1}}'     => ($d['company1_country']  ?? '') ?: '—',
        '{{C2}}'     => ($d['company2_country']  ?? '') ?: '—',
        '{{R1}}'     => ph_role_label((string)($d['company1_role'] ?? ''), $__lang) ?: $def['R1'],
        '{{R2}}'     => ph_role_label((string)($d['company2_role'] ?? ''), $__lang) ?: $def['R2'],
        '{{E1}}'     => ($d['company1_email']    ?? '') ?: '—',
        '{{E2}}'     => ($d['company2_email']    ?? '') ?: '—',
        '{{REP1}}'   => ($d['company1_rep']      ?? '') ?: '—',
        '{{REP2}}'   => ($d['company2_rep']      ?? '') ?: '—',
        '{{LAW}}'    => ($d['governingLaw']      ?? '') ?: $def['LAW'],
        '{{FORUM}}'  => ($d['jurisdiction']      ?? '') ?: $def['FORUM'],
        '{{DATE}}'   => ($d['effectiveDate']     ?? '') ?: ($d['createdDate'] ?? '—'),
        '{{EFF}}'    => ($d['effectiveDate']     ?? '') ?: ($d['createdDate'] ?? '—'),
        '{{MODULE}}' => scc_module($d),
        '{{SUBS}}'   => ($d['subProcessors']     ?? '') ?: $def['SUBS'],
        '{{PURPOSE}}'=> ($d['purpose']           ?? '') ?: '—',
        '{{CATS}}'   => ($d['dataCategories']    ?? '') ?: '—',
        '{{SUBJ}}'   => ($d['dataSubjects']      ?? '') ?: '—',
        '{{DUR}}'    => ($d['duration']          ?? '') ?: $def['DUR'],
        '{{NOTICE}}' => ($d['noticePeriod']      ?? '') ?: '—',
        '{{KVK1}}'   => ($d['company1_kvk']      ?? '') ?: '—',
        '{{KVK2}}'   => ($d['company2_kvk']      ?? '') ?: '—',
        '{{VAT1}}'   => ($d['company1_vat']      ?? '') ?: '—',
        '{{VAT2}}'   => ($d['company2_vat']      ?? '') ?: '—',
        '{{IBAN1}}'  => ($d['company1_iban']     ?? '') ?: '—',
        '{{IBAN2}}'  => ($d['company2_iban']     ?? '') ?: '—',
        '{{REPTITLE1}}' => ($d['company1_rep_title'] ?? '') ?: '—',
        '{{REPTITLE2}}' => ($d['company2_rep_title'] ?? '') ?: '—',
        '{{PHONE1}}' => ($d['company1_phone']    ?? '') ?: '—',
        '{{PHONE2}}' => ($d['company2_phone']    ?? '') ?: '—',
        '{{VALUE}}'      => ($d['contractValue']  ?? '') ?: '—',
        '{{CURRENCY}}'   => ($d['currency']       ?? '') ?: '—',
        '{{LIABILITY}}'  => ($d['liabilityCap']   ?? '') ?: '—',
        '{{PAYMENT}}'    => ($d['paymentTerms']   ?? '') ?: '—',
        '{{PENALTY}}'    => ($d['penaltyClause']  ?? '') ?: '—',
        '{{SLAUPTIME}}'  => ($d['slaUptime']      ?? '') ?: '—',
        '{{SLARESPONSE}}'=> ($d['slaResponse']    ?? '') ?: '—',
        '{{CONF}}'       => ($d['confidentiality']?? '') ?: '—',
        '{{INSURANCE}}'  => ($d['insurance']      ?? '') ?: '—',
        '{{AUDIT}}'      => ($d['auditRights']    ?? '') ?: '—',
        '{{NOTES}}'      => ($d['extraNotes']     ?? '') ?: '—',
    ]);
}

// Catalogus van alle {{PLACEHOLDER}}-tokens die ph() vervangt. Wordt gebruikt
// om in het tabblad "Configuratie contracten" een rij klikbare variabele-chips
// te tonen per artikel, zodat je ze in de titel/tekst kunt klikken zonder ze
// te hoeven onthouden of over te typen.
function placeholder_tokens(): array {
    return [
        ['token' => 'P1',     'descKey' => 'ph_p1'],
        ['token' => 'P2',     'descKey' => 'ph_p2'],
        ['token' => 'A1',     'descKey' => 'ph_a1'],
        ['token' => 'A2',     'descKey' => 'ph_a2'],
        ['token' => 'C1',     'descKey' => 'ph_c1'],
        ['token' => 'C2',     'descKey' => 'ph_c2'],
        ['token' => 'R1',     'descKey' => 'ph_r1'],
        ['token' => 'R2',     'descKey' => 'ph_r2'],
        ['token' => 'E1',     'descKey' => 'ph_e1'],
        ['token' => 'E2',     'descKey' => 'ph_e2'],
        ['token' => 'REP1',   'descKey' => 'ph_rep1'],
        ['token' => 'REP2',   'descKey' => 'ph_rep2'],
        ['token' => 'LAW',    'descKey' => 'ph_law'],
        ['token' => 'FORUM',  'descKey' => 'ph_forum'],
        ['token' => 'DATE',   'descKey' => 'ph_date'],
        ['token' => 'EFF',    'descKey' => 'ph_eff'],
        ['token' => 'MODULE', 'descKey' => 'ph_module'],
        ['token' => 'SUBS',   'descKey' => 'ph_subs'],
        ['token' => 'PURPOSE','descKey' => 'ph_purpose'],
        ['token' => 'CATS',   'descKey' => 'ph_cats'],
        ['token' => 'SUBJ',   'descKey' => 'ph_subj'],
        ['token' => 'DUR',    'descKey' => 'ph_dur'],
        ['token' => 'NOTICE',     'descKey' => 'ph_notice'],
        ['token' => 'KVK1',       'descKey' => 'ph_kvk1'],
        ['token' => 'KVK2',       'descKey' => 'ph_kvk2'],
        ['token' => 'VAT1',       'descKey' => 'ph_vat1'],
        ['token' => 'VAT2',       'descKey' => 'ph_vat2'],
        ['token' => 'IBAN1',      'descKey' => 'ph_iban1'],
        ['token' => 'IBAN2',      'descKey' => 'ph_iban2'],
        ['token' => 'REPTITLE1',  'descKey' => 'ph_reptitle1'],
        ['token' => 'REPTITLE2',  'descKey' => 'ph_reptitle2'],
        ['token' => 'PHONE1',     'descKey' => 'ph_phone1'],
        ['token' => 'PHONE2',     'descKey' => 'ph_phone2'],
        ['token' => 'VALUE',       'descKey' => 'ph_value'],
        ['token' => 'CURRENCY',    'descKey' => 'ph_currency'],
        ['token' => 'LIABILITY',   'descKey' => 'ph_liability'],
        ['token' => 'PAYMENT',     'descKey' => 'ph_payment'],
        ['token' => 'PENALTY',     'descKey' => 'ph_penalty'],
        ['token' => 'SLAUPTIME',   'descKey' => 'ph_slauptime'],
        ['token' => 'SLARESPONSE','descKey' => 'ph_slaresponse'],
        ['token' => 'CONF',        'descKey' => 'ph_conf'],
        ['token' => 'INSURANCE',   'descKey' => 'ph_insurance'],
        ['token' => 'AUDIT',       'descKey' => 'ph_audit'],
        ['token' => 'NOTES',       'descKey' => 'ph_notes'],
    ];
}

function scc_module(array $d): string {
    $r1 = strtolower((string)($d['company1_role'] ?? ''));
    $r2 = strtolower((string)($d['company2_role'] ?? ''));
    $p1 = str_contains($r1, 'verwerker') && !str_contains($r1, 'verantwoordelijke');
    $p2 = str_contains($r2, 'verwerker') && !str_contains($r2, 'verantwoordelijke');
    $lang = (string)($d['lang'] ?? current_lang());

    if ($lang === 'nl') {
        if (!$p1 && !$p2) return 'MODULE EEN — verwerkingsverantwoordelijke naar verwerkingsverantwoordelijke (C2C)';
        if (!$p1 &&  $p2) return 'MODULE TWEE — verwerkingsverantwoordelijke naar verwerker (C2P)';
        if ( $p1 &&  $p2) return 'MODULE DRIE — verwerker naar verwerker (P2P)';
        return 'MODULE VIER — verwerker naar verwerkingsverantwoordelijke (P2C)';
    }
    if ($lang === 'de') {
        if (!$p1 && !$p2) return 'MODUL EINS — Verantwortlicher zu Verantwortlicher (C2C)';
        if (!$p1 &&  $p2) return 'MODUL ZWEI — Verantwortlicher zu Auftragsverarbeiter (C2P)';
        if ( $p1 &&  $p2) return 'MODUL DREI — Auftragsverarbeiter zu Auftragsverarbeiter (P2P)';
        return 'MODUL VIER — Auftragsverarbeiter zu Verantwortlicher (P2C)';
    }
    if ($lang === 'es') {
        if (!$p1 && !$p2) return 'MÓDULO UNO — responsable a responsable (C2C)';
        if (!$p1 &&  $p2) return 'MÓDULO DOS — responsable a encargado (C2P)';
        if ( $p1 &&  $p2) return 'MÓDULO TRES — encargado a encargado (P2P)';
        return 'MÓDULO CUATRO — encargado a responsable (P2C)';
    }
    if ($lang === 'fr') {
        if (!$p1 && !$p2) return 'MODULE UN — responsable de traitement à responsable de traitement (C2C)';
        if (!$p1 &&  $p2) return 'MODULE DEUX — responsable de traitement à sous-traitant (C2P)';
        if ( $p1 &&  $p2) return 'MODULE TROIS — sous-traitant à sous-traitant (P2P)';
        return 'MODULE QUATRE — sous-traitant à responsable de traitement (P2C)';
    }
    $moduleKey = (!$p1 && !$p2) ? 'c2c' : ((!$p1 && $p2) ? 'c2p' : (($p1 && $p2) ? 'p2p' : 'p2c'));
    $en = match ($moduleKey) {
        'c2c' => 'MODULE ONE — Controller-to-Controller (C2C)',
        'c2p' => 'MODULE TWO — Controller-to-Processor (C2P)',
        'p2p' => 'MODULE THREE — Processor-to-Processor (P2P)',
        default => 'MODULE FOUR — Processor-to-Controller (P2C)',
    };
    // Taal buiten UI_LANGS (bv. Arabisch, Russisch): vertaal en cache de
    // Engelse moduletekst (label_translate.php) i.p.v. stilzwijgend Engels
    // te tonen.
    if ($lang !== 'en' && !in_array($lang, UI_LANGS, true) && function_exists('translate_doc_label')) {
        return translate_doc_label('scc_module:' . $moduleKey, $lang, $en);
    }
    return $en;
}

function article_enabled(array $d, string $key): bool {
    if (!array_key_exists('articleEnabled', $d) || !is_array($d['articleEnabled'])) return true;
    if (!array_key_exists($key, $d['articleEnabled'])) return true;
    return !empty($d['articleEnabled'][$key]);
}

function article_text(array $d, string $key, string $default): string {
    if (isset($d['articleText'][$key]) && is_string($d['articleText'][$key]) && $d['articleText'][$key] !== '') {
        return $d['articleText'][$key];
    }
    return $default;
}

function render_article(array $d, string $key, string $defaultTpl): string {
    $lang = $d['lang'] ?? current_lang();
    if (!article_enabled($d, $key)) {
        $label = match ($lang) {
            'nl' => '[Artikel ' . $key . ' is door partijen verwijderd.]',
            'de' => '[Artikel ' . $key . ' wurde von den Parteien entfernt.]',
            'es' => '[El artículo ' . $key . ' ha sido eliminado por las partes.]',
            'fr' => '[L\'article ' . $key . ' a été supprimé par les parties.]',
            default => '[Article ' . $key . ' has been removed by the parties.]',
        };
        return "\n" . $label . "\n";
    }
    return ph(article_text($d, $key, $defaultTpl), $d);
}


// ===============================================================
// FIELDS JSON
// ===============================================================
function fields_json(array $record, array $types, string $payload): string {
    $out = [
        'schema'      => 'contractregister/velden/v1',
        'lang'        => $record['lang'] ?? current_lang(),
        'id'          => $record['id'] ?? null,
        'md5'         => payload_md5($payload),
        'createdAt'   => $record['createdAt'] ?? null,
        'safeguard'   => [
            'key'   => $record['safeguard'] ?? null,
            'label' => $types[$record['safeguard'] ?? ''] ?? null,
            'sccModule' => scc_module($record),
        ],
        'partij1' => [
            'naam' => $record['company1_name'] ?? '', 'adres' => $record['company1_address'] ?? '',
            'land' => $record['company1_country'] ?? '', 'kvk' => $record['company1_kvk'] ?? '',
            'btw' => $record['company1_vat'] ?? '', 'iban' => $record['company1_iban'] ?? '',
            'vertegenwoordiger' => $record['company1_rep'] ?? '', 'functie' => $record['company1_rep_title'] ?? '',
            'email' => $record['company1_email'] ?? '', 'telefoon' => $record['company1_phone'] ?? '',
            'rol' => $record['company1_role'] ?? '',
        ],
        'partij2' => [
            'naam' => $record['company2_name'] ?? '', 'adres' => $record['company2_address'] ?? '',
            'land' => $record['company2_country'] ?? '', 'kvk' => $record['company2_kvk'] ?? '',
            'btw' => $record['company2_vat'] ?? '', 'iban' => $record['company2_iban'] ?? '',
            'vertegenwoordiger' => $record['company2_rep'] ?? '', 'functie' => $record['company2_rep_title'] ?? '',
            'email' => $record['company2_email'] ?? '', 'telefoon' => $record['company2_phone'] ?? '',
            'rol' => $record['company2_role'] ?? '',
        ],
        'verwerking' => [
            'doel' => $record['purpose'] ?? '', 'gegevenscategorieen' => $record['dataCategories'] ?? '',
            'betrokkenen' => $record['dataSubjects'] ?? '', 'ingangsdatum' => $record['effectiveDate'] ?? '',
            'duur' => $record['duration'] ?? '', 'opzegtermijn' => $record['noticePeriod'] ?? '',
            'subverwerkers' => $record['subProcessors'] ?? '',
        ],
        'commercieel' => [
            'contractwaarde' => $record['contractValue'] ?? '', 'valuta' => $record['currency'] ?? 'EUR',
            'betaling' => $record['paymentTerms'] ?? '', 'aansprakelijkheid' => $record['liabilityCap'] ?? '',
            'boetebeding' => $record['penaltyClause'] ?? '', 'slaBeschikbaarheid' => $record['slaUptime'] ?? '',
            'slaReactietijd' => $record['slaResponse'] ?? '', 'geheimhoudingJaren' => $record['confidentiality'] ?? '',
            'verzekering' => $record['insurance'] ?? '', 'auditrechten' => $record['auditRights'] ?? '',
        ],
        'juridisch' => [
            'toepasselijkRecht' => $record['governingLaw'] ?? '',
            'bevoegdeRechter' => $record['jurisdiction'] ?? '',
            'opmerkingen' => $record['extraNotes'] ?? '',
        ],
        'bijlagen' => [
            'annexA_aangepast' => !empty($record['annexA_custom']),
            'annexA_verwijderd' => !empty($record['annexA_remove']),
            'annexCommon_aangepast' => !empty($record['annex_common_custom']),
            'annexCommon_verwijderd' => !empty($record['annex_common_remove']),
            'articleEnabled' => $record['articleEnabled'] ?? [],
            'articleText' => $record['articleText'] ?? [],
        ],
        'overeenkomst' => function_exists('merged_contract_fields_summary') ? merged_contract_fields_summary($record) : null,
        'handtekeningen' => [
            'partij1' => [
                'aanwezig' => !empty($record['signature1']),
                'bytes' => strlen((string)($record['signature1'] ?? '')),
                'tijdstip' => $record['signedAt1'] ?? null,
            ],
            'partij2' => [
                'aanwezig' => !empty($record['signature2']),
                'bytes' => strlen((string)($record['signature2'] ?? '')),
                'tijdstip' => $record['signedAt2'] ?? null,
            ],
        ],
        'payload' => [
            'lengte' => strlen($payload),
            'opmerking' => 'De PAYLOAD zelf staat in het .txt-contract en in de QR-code(s).',
        ],
    ];
    return json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

// ===============================================================
// RENDER TXT
// ===============================================================
function render_txt(array $record, array $types, string $payload, array $extraLangs = []): string {
    // Schone lei voor de label-vertaalbreker (label_translate.php) bij elke
    // generatie, ook als build_multilang_body() hieronder niet wordt
    // aangeroepen (bv. geen extra talen gekozen) — anders zou een eerdere,
    // mislukte poging in hetzelfde PHP-proces onterecht blijven doorwerken.
    if (function_exists('label_translate_circuit_reset')) label_translate_circuit_reset();
    $md5  = payload_md5($payload);
    $body = ($extraLangs !== [] && function_exists('build_multilang_body'))
        ? build_multilang_body($record, $types, $extraLangs)
        : generate_contract_body($record, $types);
    $lang = ($record['lang'] ?? current_lang());
    if (!in_array($lang, UI_LANGS, true)) $lang = 'en';

    if ($lang === 'nl') {
        $header =
            "=== CONTRACT INTEGRITEIT ===\n" .
            "Contract-ID:  {$record['id']}\n" .
            "MD5:          {$md5}\n" .
            "Taal:         " . ($record['lang'] ?? 'nl') . "\n" .
            "Aangemaakt:   " . ($record['createdAt'] ?? '') . "\n" .
            "Ondertekend:  " . (!empty($record['signed']) ? 'JA' : 'NEE') . "\n" .
            "================================\n" .
            "PAYLOAD (bewaar dit om het contract later 1-op-1 te hergenereren):\n" .
            $payload . "\n" .
            "================================\n\n";
    } elseif ($lang === 'de') {
        $header =
            "=== VERTRAGSINTEGRITÄT ===\n" .
            "Vertrags-ID:  {$record['id']}\n" .
            "MD5:          {$md5}\n" .
            "Sprache:      " . ($record['lang'] ?? 'de') . "\n" .
            "Erstellt:     " . ($record['createdAt'] ?? '') . "\n" .
            "Unterzeichnet:" . (!empty($record['signed']) ? ' JA' : ' NEIN') . "\n" .
            "================================\n" .
            "PAYLOAD (bewahren Sie dies auf, um den Vertrag später 1:1 neu zu erzeugen):\n" .
            $payload . "\n" .
            "================================\n\n";
    } elseif ($lang === 'es') {
        $header =
            "=== INTEGRIDAD DEL CONTRATO ===\n" .
            "ID del contrato:  {$record['id']}\n" .
            "MD5:              {$md5}\n" .
            "Idioma:           " . ($record['lang'] ?? 'es') . "\n" .
            "Creado:           " . ($record['createdAt'] ?? '') . "\n" .
            "Firmado:          " . (!empty($record['signed']) ? 'SÍ' : 'NO') . "\n" .
            "================================\n" .
            "CARGA ÚTIL (consérvela para regenerar el contrato 1 a 1 más adelante):\n" .
            $payload . "\n" .
            "================================\n\n";
    } elseif ($lang === 'fr') {
        $header =
            "=== INTÉGRITÉ DU CONTRAT ===\n" .
            "ID du contrat :  {$record['id']}\n" .
            "MD5 :            {$md5}\n" .
            "Langue :         " . ($record['lang'] ?? 'fr') . "\n" .
            "Créé le :        " . ($record['createdAt'] ?? '') . "\n" .
            "Signé :          " . (!empty($record['signed']) ? 'OUI' : 'NON') . "\n" .
            "================================\n" .
            "PAYLOAD (conservez-le pour régénérer le contrat à l'identique plus tard) :\n" .
            $payload . "\n" .
            "================================\n\n";
    } else {
        $header =
            "=== CONTRACT INTEGRITY ===\n" .
            "Contract ID:  {$record['id']}\n" .
            "MD5:          {$md5}\n" .
            "Language:     " . ($record['lang'] ?? 'en') . "\n" .
            "Created:      " . ($record['createdAt'] ?? '') . "\n" .
            "Signed:       " . (!empty($record['signed']) ? 'YES' : 'NO') . "\n" .
            "================================\n" .
            "PAYLOAD (keep this to re-generate the contract 1-to-1 later):\n" .
            $payload . "\n" .
            "================================\n\n";
    }
    return $header . $body;
}

// ===============================================================
// REQUEST HANDLING
// ===============================================================
$errors  = [];
$txtOut  = null;
$txtName = null;
$isRegen = false;

function collect_articles_from_post(): array {
    $enabled = []; $texts = [];
    if (!empty($_POST['articleEnabled']) && is_array($_POST['articleEnabled'])) {
        foreach ($_POST['articleEnabled'] as $k => $v) {
            $key = preg_replace('/[^A-Za-z0-9._]/', '', (string)$k);
            if ($key === '') continue;
            $enabled[$key] = !empty($v);
        }
    }
    if (!empty($_POST['articleText']) && is_array($_POST['articleText'])) {
        foreach ($_POST['articleText'] as $k => $v) {
            $key = preg_replace('/[^A-Za-z0-9._]/', '', (string)$k);
            if ($key === '') continue;
            $texts[$key] = (string)$v;
        }
    }
    return ['articleEnabled' => $enabled, 'articleText' => $texts];
}

function selected_contract_key_from_post(): string {
    $requested = contract_safe_key((string)($_POST['safeguard'] ?? 'safeguard_scc'));
    $available = list_available_contracts();
    if ($requested !== '' && isset($available[$requested])) return $requested;
    return 'safeguard_scc';
}

function build_record_from_post(): array {
    $sign1 = trim($_POST['sig1'] ?? '');
    $sign2 = trim($_POST['sig2'] ?? '');
    $articles = collect_articles_from_post();
    $record = [
        'id'             => new_id(),
        // Taal van de contracttekst. Standaard de UI-taal, maar een contract kan
        // via DeepL meer talen hebben dan de interface (bv. FR/ES); dan bepaalt
        // de contracttaalkiezer welke versie wordt gegenereerd. De waarde gaat
        // mee in het record en dus in de payload, zodat de MD5 stabiel blijft.
        'lang'           => contract_output_lang(selected_contract_key_from_post()),
        'safeguard'      => selected_contract_key_from_post(),
        'company1_name'  => trim($_POST['company1_name'] ?? ''),
        'company1_address'=> trim($_POST['company1_address'] ?? ''),
        'company1_country'=> trim($_POST['company1_country'] ?? ''),
        'company1_kvk'   => trim($_POST['company1_kvk'] ?? ''),
        'company1_vat'   => trim($_POST['company1_vat'] ?? ''),
        'company1_iban'  => trim($_POST['company1_iban'] ?? ''),
        'company1_rep'   => trim($_POST['company1_rep'] ?? ''),
        'company1_rep_title' => trim($_POST['company1_rep_title'] ?? ''),
        'company1_email' => trim($_POST['company1_email'] ?? ''),
        'company1_phone' => trim($_POST['company1_phone'] ?? ''),
        'company1_role'  => trim($_POST['company1_role'] ?? 'verwerkingsverantwoordelijke'),
        'company2_name'  => trim($_POST['company2_name'] ?? ''),
        'company2_address'=> trim($_POST['company2_address'] ?? ''),
        'company2_country'=> trim($_POST['company2_country'] ?? ''),
        'company2_kvk'   => trim($_POST['company2_kvk'] ?? ''),
        'company2_vat'   => trim($_POST['company2_vat'] ?? ''),
        'company2_iban'  => trim($_POST['company2_iban'] ?? ''),
        'company2_rep'   => trim($_POST['company2_rep'] ?? ''),
        'company2_rep_title' => trim($_POST['company2_rep_title'] ?? ''),
        'company2_email' => trim($_POST['company2_email'] ?? ''),
        'company2_phone' => trim($_POST['company2_phone'] ?? ''),
        'company2_role'  => trim($_POST['company2_role'] ?? 'verwerker'),
        'purpose'        => trim($_POST['purpose'] ?? ''),
        'dataCategories' => trim($_POST['dataCategories'] ?? ''),
        'dataSubjects'   => trim($_POST['dataSubjects'] ?? ''),
        'effectiveDate'  => trim($_POST['effectiveDate'] ?? ''),
        'duration'       => trim($_POST['duration'] ?? ''),
        'noticePeriod'   => trim($_POST['noticePeriod'] ?? ''),
        'contractValue'  => trim($_POST['contractValue'] ?? ''),
        'currency'       => trim($_POST['currency'] ?? 'EUR'),
        'liabilityCap'   => trim($_POST['liabilityCap'] ?? ''),
        'paymentTerms'   => trim($_POST['paymentTerms'] ?? ''),
        'penaltyClause'  => trim($_POST['penaltyClause'] ?? ''),
        'slaUptime'      => trim($_POST['slaUptime'] ?? ''),
        'slaResponse'    => trim($_POST['slaResponse'] ?? ''),
        'subProcessors'  => trim($_POST['subProcessors'] ?? ''),
        'confidentiality'=> trim($_POST['confidentiality'] ?? ''),
        'governingLaw'   => trim($_POST['governingLaw'] ?? ''),
        'jurisdiction'   => trim($_POST['jurisdiction'] ?? ''),
        'insurance'      => trim($_POST['insurance'] ?? ''),
        'auditRights'    => trim($_POST['auditRights'] ?? ''),
        'extraNotes'     => trim($_POST['extraNotes'] ?? ''),
        'annexA_custom'  => trim($_POST['annexA_custom'] ?? ''),
        'annexA_remove'  => !empty($_POST['annexA_remove']),
        'annex_common_custom' => trim($_POST['annex_common_custom'] ?? ''),
        'annex_common_remove' => !empty($_POST['annex_common_remove']),
        'articleEnabled' => $articles['articleEnabled'],
        'articleText'    => $articles['articleText'],
        'signature1'     => $sign1, 'signature2' => $sign2,
        'signedAt1'      => $sign1 !== '' ? date('c') : null,
        'signedAt2'      => $sign2 !== '' ? date('c') : null,
        'signed'         => ($sign1 !== '' || $sign2 !== ''),
        'createdAt'      => date('c'),
        'createdDate'    => date('d-m-Y'),
        'parentMd5'      => null,
    ];
    // Werkwijze "overeenkomst uit twee contracten": artikelen + taal uit de
    // overeenkomst; bedrijfsgegevens/verwerking/commercieel blijven de
    // formuliervelden hierboven (worden nooit uit de contract-ZIP's geladen).
    if (function_exists('merged_contract_apply_to_record')) {
        $record = merged_contract_apply_to_record($record);
    }
    return $record;
}

// ===============================================================
// DEEPL — automatische vertaling van contractdefinities
// ---------------------------------------------------------------
// Aparte module: voegt action=translate_contract toe, plus het paneel
// "Automatisch vertalen" in het tabblad "Configuratie contracten" en de
// contracttaalkiezer bij "Nieuw contract". Hier ingeladen omdat CONTRACTS_DIR
// en de contract_*-functies nu beschikbaar zijn, en vóór de POST-afhandeling
// zodat de module zijn eigen actie kan oppakken.
// ===============================================================
require_once __DIR__ . '/contract_translate.php';

// ===============================================================
// LABEL-VERTALING — vaste contractlabels/placeholder-fallbacks in elke
// DeepL-taal (Arabisch, Russisch, ...), niet alleen UI_LANGS
// ---------------------------------------------------------------
// Ná contract_translate.php geladen: gebruikt deepl_enabled()/
// deepl_lang_known()/deepl_translate_block() daaruit. t()/ph()/
// ph_defaults()/ph_role_label()/contract_missing_json_notice() hierboven
// roepen translate_doc_label() zelf aan zodra de gevraagde taal buiten
// UI_LANGS valt — zie label_translate.php voor de cache/circuit breaker.
// ===============================================================
require_once __DIR__ . '/label_translate.php';

// ===============================================================
// PRESETS — Verwerkingsdetails / Commerciële voorwaarden
// ---------------------------------------------------------------
// Zelfde soort drop-in module als contract_translate.php hierboven. Voegt
// tabblad "Presets" toe plus het invulmechanisme voor de twee preset-
// dropdowns bovenaan "Nieuw contract". Hier ingeladen (vóór de POST-
// afhandeling) zodat de module zijn eigen acties (save_preset/delete_preset)
// kan oppakken, net als bij contract_translate.php.
// ===============================================================
require_once __DIR__ . '/presets.php';

// ===============================================================
// PDF-VERTALING — extra talen toevoegen aan de gegenereerde PDF
// ---------------------------------------------------------------
// Ná presets.php geladen: gebruikt zowel de deepl_*-functies uit
// contract_translate.php als index.php's eigen contract-renderfuncties
// (load_contract_definition, generate_contract_body, enz.), die op dit punt
// al gedefinieerd zijn.
// ===============================================================
require_once __DIR__ . '/pdf_translate.php';

// ===============================================================
// OVEREENKOMST — contract als QR-ZIP (wachtwoord = MD5) + samenvoegen van
// het contract van partij 1 en partij 2 (zie contract_merge.php).
// ===============================================================
require_once __DIR__ . '/contract_merge.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ===============================================================
    // CONFIGURATIE CONTRACTEN — opslaan (JSON, per artikel per taal)
    // ===============================================================
    if ($action === 'save_contract_config') {
        $key = contract_safe_key((string)($_POST['key'] ?? ''));
        $incoming = $_POST['articles'] ?? [];

        if (is_protected_contract($key)) {
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=protected');
            exit;
        }

        if ($key === '' || !is_array($incoming) || count($incoming) === 0) {
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=1');
            exit;
        }

        $existing = load_contract_definition($key) ?? [
            'schema' => 'contractregister/contract/v1',
            'key' => $key,
            'version' => 0,
            'languages' => ['nl', 'en'],
        ];

        // De talenlijst komt uit de definitie zelf, niet uit een vaste lijst:
        // talen die via DeepL zijn toegevoegd (de, fr, es, ...) mogen bij het
        // opslaan van het formulier niet stilzwijgend verdwijnen.
        $languages = $existing['languages'] ?? [];
        if (!is_array($languages) || $languages === []) $languages = ['nl', 'en'];
        $previousArticles = $existing['articles'] ?? [];

        $articles = [];
        foreach ($incoming as $artKey => $byLang) {
            $artKey = preg_replace('/[^A-Za-z0-9._]/', '', (string)$artKey);
            if ($artKey === '' || !is_array($byLang)) continue;
            foreach ($languages as $l) {
                $title = trim((string)($byLang[$l]['title'] ?? ''));
                $body  = (string)($byLang[$l]['body'] ?? '');
                $body  = str_replace("\r\n", "\n", $body);
                $entry = ['title' => $title, 'body' => $body];

                // Het _mt-stempel (machinevertaling) blijft alleen staan als de
                // tekst ongewijzigd is opgeslagen. Wie een vertaling met de hand
                // bijwerkt, maakt er een menselijke vertaling van: die wordt
                // daarna niet meer automatisch overschreven.
                $prev = $previousArticles[$artKey][$l] ?? null;
                if (is_array($prev) && isset($prev['_mt'])
                    && (string)($prev['title'] ?? '') === $title
                    && (string)($prev['body'] ?? '')  === $body) {
                    $entry['_mt'] = $prev['_mt'];
                }

                $articles[$artKey][$l] = $entry;
            }
        }

        if (count($articles) === 0) {
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=1');
            exit;
        }

        $existing['schema']    = $existing['schema'] ?? 'contractregister/contract/v1';
        $existing['key']       = $key;
        $existing['languages'] = $languages;
        $existing['articles']  = $articles;
        $existing['version']   = (int)($existing['version'] ?? 0) + 1;

        $encoded = json_encode($existing, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $writeOk = false;
        if ($encoded !== false) {
            if (!is_dir(CONTRACTS_DIR)) @mkdir(CONTRACTS_DIR, 0775, true);
            $writeOk = @file_put_contents(contract_json_path($key), $encoded) !== false;
        }

        header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&' . ($writeOk ? 'cfgsaved=1' : 'cfgerror=1'));
        exit;
    }

    // ===============================================================
    // CONFIGURATIE CONTRACTEN — nieuw contract aanmaken
    // Maakt een nieuw, volledig beschrijfbaar contracts/<key>.json aan,
    // optioneel als kloon van een bestaand contract (bv. het beschermde
    // standaard SCC-contract als startpunt). De nieuwe key mag nooit
    // gelijk zijn aan een beschermde key en nog niet bestaan.
    // ===============================================================
    if ($action === 'create_contract') {
        $newKey    = contract_safe_key((string)($_POST['new_key'] ?? ''));
        $cloneFrom = contract_safe_key((string)($_POST['clone_from'] ?? ''));
        $languages = ['nl', 'en'];

        $failRedirect = function (string $reason) {
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&newcontracterror=' . urlencode($reason));
            exit;
        };

        if ($newKey === '') $failRedirect('empty');
        if (is_protected_contract($newKey)) $failRedirect('protected');
        if (is_file(contract_json_path($newKey))) $failRedirect('exists');

        $cloneDef = $cloneFrom !== '' ? load_contract_definition($cloneFrom) : null;
        $newDef = [
            'schema'    => 'contractregister/contract/v1',
            'key'       => $newKey,
            'title'     => (string)($_POST['new_title'] ?? $newKey),
            'version'   => 1,
            'languages' => $languages,
            'articles'  => $cloneDef['articles'] ?? [
                'Preamble' => array_fill_keys($languages, ['title' => '', 'body' => '']),
            ],
        ];

        $encoded = json_encode($newDef, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($encoded === false) $failRedirect('encode');

        if (!is_dir(CONTRACTS_DIR)) @mkdir(CONTRACTS_DIR, 0775, true);
        $writeOk = @file_put_contents(contract_json_path($newKey), $encoded) !== false;
        if (!$writeOk) $failRedirect('write');

        header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($newKey) . '&contractcreated=1');
        exit;
    }

    // ===============================================================
    // CONFIGURATIE CONTRACTEN — heel contract verwijderen
    // Alleen voor zelf aangemaakte (niet-beschermde) contracten.
    // ===============================================================
    if ($action === 'delete_contract') {
        $key = contract_safe_key((string)($_POST['key'] ?? ''));
        if ($key === '' || is_protected_contract($key)) {
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=protected');
            exit;
        }
        $path = contract_json_path($key);
        if (is_file($path)) @unlink($path);
        header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=safeguard_scc&contractdeleted=1');
        exit;
    }

    // ===============================================================
    // CONFIGURATIE CONTRACTEN — export als wachtwoord-ZIP
    // Wachtwoord = MD5 van het JSON-bestand zoals het op schijf staat
    // (dezelfde byte-inhoud die ook wordt getoond/opgeslagen).
    // ===============================================================
    if ($action === 'export_contract_zip') {
        $key = contract_safe_key((string)($_POST['key'] ?? ''));
        $raw = $key !== '' ? contract_json_raw($key) : null;

        if ($raw === null) {
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=1');
            exit;
        }
        if (!class_exists('ZipArchive')) {
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=zip');
            exit;
        }

        $password = md5($raw);
        $tmpPath = tempnam(sys_get_temp_dir(), 'ctrcfgzip_');
        if ($tmpPath === false) {
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=1');
            exit;
        }
        @unlink($tmpPath);

        $zip = new ZipArchive();
        if ($zip->open($tmpPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            @unlink($tmpPath);
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=1');
            exit;
        }

        $entryName = $key . '.json';
        $zip->addFromString($entryName, $raw);
        $encryptOk = $zip->setEncryptionName($entryName, ZipArchive::EM_AES_256, $password);
        $zip->close();

        if (!$encryptOk) {
            @unlink($tmpPath);
            header('Location: ?tab=config&lang=' . urlencode(current_lang()) . '&key=' . urlencode($key) . '&cfgerror=zip');
            exit;
        }

        $zipData = file_get_contents($tmpPath);
        @unlink($tmpPath);

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $key . '.zip"');
        header('Content-Length: ' . strlen($zipData));
        header('X-Zip-Password-MD5: ' . $password);
        echo $zipData; exit;
    }

    if ($action === 'generate_json') {
        header('Content-Type: application/json; charset=utf-8');
        $record = build_record_from_post();
        if (function_exists('merged_contract_post_error') && ($__mergeErr = merged_contract_post_error()) !== null) {
            echo json_encode(['ok' => false, 'error' => $__mergeErr]); exit;
        }
        if ($record['company1_name'] === '' || $record['company2_name'] === '') {
            echo json_encode(['ok' => false, 'error' => t('error_parties')]); exit;
        }
        $payload    = make_payload($record);
        // Bij een overeenkomst regelt de overeenkomst zelf de (tweede) taal.
        $extraLangs = (empty($record['mergedContract']) && function_exists('extra_langs_from_post')) ? extra_langs_from_post() : [];
        $txt        = render_txt($record, safeguard_labels(), $payload, $extraLangs);
        $md5     = payload_md5($payload);
        echo json_encode([
            'ok' => true, 'id' => $record['id'], 'lang' => $record['lang'],
            'payload' => $payload, 'md5' => $md5, 'txt' => $txt,
            'filename' => 'contract_' . $record['id'] . '.txt',
            'json' => fields_json($record, safeguard_labels(), $payload),
            'jsonFilename' => 'contract_' . $record['id'] . '_velden.json',
            'payloadLength' => strlen($payload),
            'extraLangs' => $extraLangs,
            'signature1' => $record['signature1'] ?? '',
            'signature2' => $record['signature2'] ?? '',
        ]); exit;
    }

    if ($action === 'regen_json') {
        header('Content-Type: application/json; charset=utf-8');
        $rawInput = trim($_POST['regen_input'] ?? '');
        if ($rawInput === '') { echo json_encode(['ok' => false, 'error' => t('error_empty_input')]); exit; }
        $payload = ''; $expectedMd5 = '';
        if (preg_match('/MD5:\s*([a-f0-9]{32})/i', $rawInput, $m)) $expectedMd5 = strtolower($m[1]);
        if (preg_match('/PAYLOAD[^\n]*\n([A-Za-z0-9+\/=\s]+)/', $rawInput, $m)) {
            $payload = preg_replace('/\s+/', '', $m[1]);
        } else {
            $payload = preg_replace('/\s+/', '', $rawInput);
        }
        $record = read_payload($payload);
        if (!$record || !is_array($record)) { echo json_encode(['ok' => false, 'error' => t('error_decode')]); exit; }
        $actualMd5 = payload_md5($payload);
        if ($expectedMd5 !== '' && !hash_equals($expectedMd5, $actualMd5)) {
            echo json_encode(['ok' => false, 'error' => t('error_md5', [$expectedMd5, $actualMd5])]); exit;
        }
        $txt = render_txt($record, safeguard_labels(), $payload);
        echo json_encode([
            'ok' => true, 'id' => $record['id'] ?? 'onbekend', 'lang' => $record['lang'] ?? 'en',
            'payload' => $payload, 'md5' => $actualMd5, 'txt' => $txt,
            'filename' => 'contract_' . ($record['id'] ?? 'onbekend') . '.txt',
            'json' => fields_json($record, safeguard_labels(), $payload),
            'jsonFilename' => 'contract_' . ($record['id'] ?? 'onbekend') . '_velden.json',
            'payloadLength' => strlen($payload),
            'signature1' => $record['signature1'] ?? '',
            'signature2' => $record['signature2'] ?? '',
        ]); exit;
    }

    // ===============================================================
    // QR-CODES ALS WACHTWOORD-BEVEILIGDE ZIP
    // De browser rendert de QR-code(s) al (canvas/PNG) voor het printen/de MHTML-export;
    // hier worden diezelfde PNG's ingepakt in een ZIP en met AES-256 versleuteld.
    // Wachtwoord = de MD5 van het contract (dezelfde MD5 die al op het contract
    // en in de QR staat). Er wordt een tijdelijk bestand gebruikt om de ZIP op
    // te bouwen (ZipArchive kan niet puur in-memory schrijven); dat bestand
    // wordt direct na het uitlezen weer verwijderd — er blijft niets op disk.
    // ===============================================================
    if ($action === 'qrzip_json') {
        if (!class_exists('ZipArchive')) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => t('error_zip_ext')]); exit;
        }

        $md5 = strtolower(trim((string)($_POST['md5'] ?? '')));
        if (!preg_match('/^[a-f0-9]{32}$/', $md5)) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => t('error_zip_md5')]); exit;
        }

        $id = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)($_POST['id'] ?? 'contract'));
        if ($id === '') $id = 'contract';

        $images = $_POST['images'] ?? [];
        if (!is_array($images) || count($images) === 0) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => t('error_zip_empty')]); exit;
        }

        $tmpPath = tempnam(sys_get_temp_dir(), 'qrzip_');
        if ($tmpPath === false) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => t('error_zip_tmp')]); exit;
        }
        @unlink($tmpPath); // ZipArchive::CREATE bouwt het bestand zelf opnieuw op

        $zip = new ZipArchive();
        if ($zip->open($tmpPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            @unlink($tmpPath);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => t('error_zip_open')]); exit;
        }

        $total = count($images);
        $pad = strlen((string)$total);
        $added = 0;
        $encryptOk = true;
        foreach ($images as $i => $dataUrl) {
            if (!is_string($dataUrl) || $dataUrl === '') continue;
            $comma = strpos($dataUrl, ',');
            $b64 = $comma !== false ? substr($dataUrl, $comma + 1) : $dataUrl;
            $bin = base64_decode($b64, true);
            if ($bin === false || $bin === '') continue;
            $n = str_pad((string)($i + 1), $pad, '0', STR_PAD_LEFT);
            $name = "qr_{$n}_of_{$total}.png";
            $zip->addFromString($name, $bin);
            if (!$zip->setEncryptionName($name, ZipArchive::EM_AES_256, $md5)) {
                $encryptOk = false;
            }
            $added++;
        }
        $zip->close();

        if ($added === 0) {
            @unlink($tmpPath);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => t('error_zip_empty')]); exit;
        }
        if (!$encryptOk) {
            @unlink($tmpPath);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => t('error_zip_encrypt')]); exit;
        }

        $zipData = file_get_contents($tmpPath);
        @unlink($tmpPath);
        if ($zipData === false) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => t('error_zip_open')]); exit;
        }

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="contract_' . $id . '_qr.zip"');
        header('Content-Length: ' . strlen($zipData));
        echo $zipData; exit;
    }

    if ($action === 'generate') {
        $record = build_record_from_post();
        if (function_exists('merged_contract_post_error') && ($__mergeErr = merged_contract_post_error()) !== null) {
            $errors[] = $__mergeErr;
        } elseif ($record['company1_name'] === '' || $record['company2_name'] === '') {
            $errors[] = t('error_parties');
        } else {
            $payload = make_payload($record);
            $txtOut  = render_txt($record, safeguard_labels(), $payload);
            $txtName = 'contract_' . $record['id'] . '.txt';
        }
    }

    if ($action === 'regen') {
        $rawInput = trim($_POST['regen_input'] ?? '');
        if ($rawInput === '') { $errors[] = t('error_empty_input'); }
        else {
            $payload = ''; $expectedMd5 = '';
            if (preg_match('/MD5:\s*([a-f0-9]{32})/i', $rawInput, $m)) $expectedMd5 = strtolower($m[1]);
            if (preg_match('/PAYLOAD[^\n]*\n([A-Za-z0-9+\/=\s]+)/', $rawInput, $m)) {
                $payload = preg_replace('/\s+/', '', $m[1]);
            } else {
                $payload = preg_replace('/\s+/', '', $rawInput);
            }
            $record = read_payload($payload);
            if (!$record || !is_array($record)) { $errors[] = t('error_decode'); }
            else {
                $actualMd5 = payload_md5($payload);
                if ($expectedMd5 !== '' && !hash_equals($expectedMd5, $actualMd5)) {
                    $errors[] = t('error_md5', [$expectedMd5, $actualMd5]);
                } else {
                    $isRegen = true;
                    $txtOut  = render_txt($record, safeguard_labels(), $payload);
                    $txtName = 'contract_' . ($record['id'] ?? 'onbekend') . '.txt';
                }
            }
        }
    }
}

if ($txtOut !== null && $txtName !== null) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $txtName . '"');
    header('Content-Length: ' . strlen($txtOut));
    header('X-Contract-Regen: ' . ($isRegen ? '1' : '0'));
    header('X-Contract-File-MD5: ' . md5($txtOut));
    echo $txtOut; exit;
}

$tab  = $_GET['tab'] ?? 'generate';
$lang = current_lang();

// ===============================================================
// VERTAAL-API GEZONDHEIDSCHECK — vooraf bij het inladen van de pagina
// ---------------------------------------------------------------
// Doet, vóór de pagina wordt getoond, een ECHTE test-aanroep naar ELK van de
// vier vertaalengines (DeepL, translateapi.ai, Lingvanex, Microsoft
// Translator) om per stuk vast te stellen of hij ONLINE is (geconfigureerd
// én er is nog tegoed) of OFFLINE (geen sleutel, of tegoed op/sleutel
// ongeldig/onbereikbaar) — zie translate_engines_health_check() in
// contract_translate.php. Dit is bewust GEEN weergave van
// translate_error.log (dat toont alleen oude, toevallig al opgetreden
// fouten en zegt niets over de huidige status); een live API-test is de
// valide manier om dit vooraf te weten. translate_error_log_recent() haalt
// er wél de laatst bekende foutmelding per engine bij, puur als extra
// context naast de live status. Pas hier geplaatst (ná alle POST-acties en
// AJAX/downloadendpoints hierboven, die altijd zelf al exit() aanroepen)
// zodat alleen het daadwerkelijk tonen van de pagina de test (gecached, zie
// ENGINE_HEALTH_TTL) triggert — niet elke losse formulier-post of
// bestandsdownload.
// ===============================================================
$__engineHealth = translate_engines_health_check();
$__engineLog    = translate_error_log_recent();

// Leesbaar label per artikelsleutel (Preamble, 1..7, A.1..A.9, C.I..C.III,
// Signatures). Gebruikt door zowel het configuratie-tabblad (bewerken) als
// het contracten-overzicht (alleen-lezen), vandaar hier boven de
// tab-dispatch gedefinieerd i.p.v. binnen één van de tak-specifieke blokken.
function config_article_label(string $key): string {
    if ($key === 'Preamble') return t('config_label_preamble');
    if ($key === 'Signatures') return t('config_label_signatures');
    if (preg_match('/^A\.(\d+)$/', $key, $m)) return t('config_label_annex_a', [$m[1]]);
    if (preg_match('/^C\.(I{1,3})$/', $key, $m)) return t('config_label_annex_common', [$m[1]]);
    if (preg_match('/^\d+$/', $key)) return t('config_label_article', [$key]);
    return $key;
}

// Er is nu maar één contract: de SCC uit contracts/safeguard_scc.json.
$uiRecord = $SAMPLES + [
    'safeguard'     => 'safeguard_scc',
    'lang'          => $lang,
    'company1_role' => $SAMPLES['company1_role'] ?? 'verwerkingsverantwoordelijke',
    'company2_role' => $SAMPLES['company2_role'] ?? 'verwerker',
    'createdDate'   => date('d-m-Y'),
];

// Per-contracttype de artikelen (sleutel, label, titel/body per taal) voor de
// client-side artikel-editor in "Nieuw contract": daar kan de gebruiker per
// GEGENEREERD contract een artikel uitzetten ("verwijderen voor dit contract")
// of de tekst overschrijven, zonder de herbruikbare sjabloon in
// contracts/<key>.json aan te raken (dat blijft het tabblad "Configuratie
// contracten"). De backend ondersteunt dit al via articleEnabled/articleText
// in build_record_from_post(); dit is alleen de UI ervoor.
$articleDefsForJs = [];
foreach (list_available_contracts() as $__ak => $__alabel) {
    $__adef = load_contract_definition($__ak);
    if ($__adef === null || !is_array($__adef['articles'] ?? null)) continue;
    $__arts = [];
    foreach ($__adef['articles'] as $__artKey => $__byLang) {
        if (!is_array($__byLang)) continue;
        $__arts[] = [
            'key'    => (string)$__artKey,
            'label'  => config_article_label((string)$__artKey),
            'byLang' => $__byLang,
        ];
    }
    $articleDefsForJs[$__ak] = $__arts;
}
unset($__ak, $__alabel, $__adef, $__arts, $__artKey, $__byLang);
?>
<!DOCTYPE html>
<html lang="<?= e($lang) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e(t('title')) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700&amp;family=IBM+Plex+Mono:wght@400;500;600&amp;display=swap">
<script src="qrcode.js"></script>
<script>
/* jsQR v1.4.0 — vendored inline zodat QR-scannen/uploaden niet afhangt van een externe CDN. https://github.com/cozmo/jsQR */
!function(o,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==typeof define&&define.amd?define([],e):"object"==typeof exports?exports.jsQR=e():o.jsQR=e()}("undefined"!=typeof self?self:this,function(){return function(o){var e={};function r(t){if(e[t])return e[t].exports;var c=e[t]={i:t,l:!1,exports:{}};return o[t].call(c.exports,c,c.exports,r),c.l=!0,c.exports}return r.m=o,r.c=e,r.d=function(o,e,t){r.o(o,e)||Object.defineProperty(o,e,{configurable:!1,enumerable:!0,get:t})},r.n=function(o){var e=o&&o.__esModule?function(){return o.default}:function(){return o};return r.d(e,"a",e),e},r.o=function(o,e){return Object.prototype.hasOwnProperty.call(o,e)},r.p="",r(r.s=3)}([function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=function(){function o(o,e){this.width=e,this.height=o.length/e,this.data=o}return o.createEmpty=function(e,r){return new o(new Uint8ClampedArray(e*r),e)},o.prototype.get=function(o,e){return!(o<0||o>=this.width||e<0||e>=this.height)&&!!this.data[e*this.width+o]},o.prototype.set=function(o,e,r){this.data[e*this.width+o]=r?1:0},o.prototype.setRegion=function(o,e,r,t,c){for(var s=e;s<e+t;s++)for(var a=o;a<o+r;a++)this.set(a,s,!!c)},o}();e.BitMatrix=t},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=r(2);e.addOrSubtractGF=function(o,e){return o^e};var c=function(){function o(o,e,r){this.primitive=o,this.size=e,this.generatorBase=r,this.expTable=new Array(this.size),this.logTable=new Array(this.size);for(var c=1,s=0;s<this.size;s++)this.expTable[s]=c,(c*=2)>=this.size&&(c=(c^this.primitive)&this.size-1);for(s=0;s<this.size-1;s++)this.logTable[this.expTable[s]]=s;this.zero=new t.default(this,Uint8ClampedArray.from([0])),this.one=new t.default(this,Uint8ClampedArray.from([1]))}return o.prototype.multiply=function(o,e){return 0===o||0===e?0:this.expTable[(this.logTable[o]+this.logTable[e])%(this.size-1)]},o.prototype.inverse=function(o){if(0===o)throw new Error("Can't invert 0");return this.expTable[this.size-this.logTable[o]-1]},o.prototype.buildMonomial=function(o,e){if(o<0)throw new Error("Invalid monomial degree less than 0");if(0===e)return this.zero;var r=new Uint8ClampedArray(o+1);return r[0]=e,new t.default(this,r)},o.prototype.log=function(o){if(0===o)throw new Error("Can't take log(0)");return this.logTable[o]},o.prototype.exp=function(o){return this.expTable[o]},o}();e.default=c},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=r(1),c=function(){function o(o,e){if(0===e.length)throw new Error("No coefficients.");this.field=o;var r=e.length;if(r>1&&0===e[0]){for(var t=1;t<r&&0===e[t];)t++;if(t===r)this.coefficients=o.zero.coefficients;else{this.coefficients=new Uint8ClampedArray(r-t);for(var c=0;c<this.coefficients.length;c++)this.coefficients[c]=e[t+c]}}else this.coefficients=e}return o.prototype.degree=function(){return this.coefficients.length-1},o.prototype.isZero=function(){return 0===this.coefficients[0]},o.prototype.getCoefficient=function(o){return this.coefficients[this.coefficients.length-1-o]},o.prototype.addOrSubtract=function(e){var r;if(this.isZero())return e;if(e.isZero())return this;var c=this.coefficients,s=e.coefficients;c.length>s.length&&(c=(r=[s,c])[0],s=r[1]);for(var a=new Uint8ClampedArray(s.length),n=s.length-c.length,d=0;d<n;d++)a[d]=s[d];for(d=n;d<s.length;d++)a[d]=t.addOrSubtractGF(c[d-n],s[d]);return new o(this.field,a)},o.prototype.multiply=function(e){if(0===e)return this.field.zero;if(1===e)return this;for(var r=this.coefficients.length,t=new Uint8ClampedArray(r),c=0;c<r;c++)t[c]=this.field.multiply(this.coefficients[c],e);return new o(this.field,t)},o.prototype.multiplyPoly=function(e){if(this.isZero()||e.isZero())return this.field.zero;for(var r=this.coefficients,c=r.length,s=e.coefficients,a=s.length,n=new Uint8ClampedArray(c+a-1),d=0;d<c;d++)for(var l=r[d],i=0;i<a;i++)n[d+i]=t.addOrSubtractGF(n[d+i],this.field.multiply(l,s[i]));return new o(this.field,n)},o.prototype.multiplyByMonomial=function(e,r){if(e<0)throw new Error("Invalid degree less than 0");if(0===r)return this.field.zero;for(var t=this.coefficients.length,c=new Uint8ClampedArray(t+e),s=0;s<t;s++)c[s]=this.field.multiply(this.coefficients[s],r);return new o(this.field,c)},o.prototype.evaluateAt=function(o){var e=0;if(0===o)return this.getCoefficient(0);var r=this.coefficients.length;if(1===o)return this.coefficients.forEach(function(o){e=t.addOrSubtractGF(e,o)}),e;e=this.coefficients[0];for(var c=1;c<r;c++)e=t.addOrSubtractGF(this.field.multiply(o,e),this.coefficients[c]);return e},o}();e.default=c},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=r(4),c=r(5),s=r(11),a=r(12);function n(o){var e=a.locate(o);if(!e)return null;for(var r=0,t=e;r<t.length;r++){var n=t[r],d=s.extract(o,n),l=c.decode(d.matrix);if(l)return{binaryData:l.bytes,data:l.text,chunks:l.chunks,version:l.version,location:{topRightCorner:d.mappingFunction(n.dimension,0),topLeftCorner:d.mappingFunction(0,0),bottomRightCorner:d.mappingFunction(n.dimension,n.dimension),bottomLeftCorner:d.mappingFunction(0,n.dimension),topRightFinderPattern:n.topRight,topLeftFinderPattern:n.topLeft,bottomLeftFinderPattern:n.bottomLeft,bottomRightAlignmentPattern:n.alignmentPattern}}}return null}var d={inversionAttempts:"attemptBoth"};function l(o,e,r,c){void 0===c&&(c={});var s=d;Object.keys(s||{}).forEach(function(o){s[o]=c[o]||s[o]});var a="attemptBoth"===s.inversionAttempts||"invertFirst"===s.inversionAttempts,l="onlyInvert"===s.inversionAttempts||"invertFirst"===s.inversionAttempts,i=t.binarize(o,e,r,a),B=i.binarized,k=i.inverted,u=n(l?k:B);return u||"attemptBoth"!==s.inversionAttempts&&"invertFirst"!==s.inversionAttempts||(u=n(l?B:k)),u}l.default=l,e.default=l},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=r(0);function c(o,e,r){return o<e?e:o>r?r:o}var s=function(){function o(o,e){this.width=o,this.data=new Uint8ClampedArray(o*e)}return o.prototype.get=function(o,e){return this.data[e*this.width+o]},o.prototype.set=function(o,e,r){this.data[e*this.width+o]=r},o}();e.binarize=function(o,e,r,a){if(o.length!==e*r*4)throw new Error("Malformed data passed to binarizer.");for(var n=new s(e,r),d=0;d<e;d++)for(var l=0;l<r;l++){var i=o[4*(l*e+d)+0],B=o[4*(l*e+d)+1],k=o[4*(l*e+d)+2];n.set(d,l,.2126*i+.7152*B+.0722*k)}for(var u=Math.ceil(e/8),C=Math.ceil(r/8),m=new s(u,C),f=0;f<C;f++)for(var w=0;w<u;w++){var P=0,v=1/0,h=0;for(l=0;l<8;l++)for(d=0;d<8;d++){var y=n.get(8*w+d,8*f+l);P+=y,v=Math.min(v,y),h=Math.max(h,y)}var p=P/Math.pow(8,2);if(h-v<=24&&(p=v/2,f>0&&w>0)){var b=(m.get(w,f-1)+2*m.get(w-1,f)+m.get(w-1,f-1))/4;v<b&&(p=b)}m.set(w,f,p)}var g=t.BitMatrix.createEmpty(e,r),x=null;for(a&&(x=t.BitMatrix.createEmpty(e,r)),f=0;f<C;f++)for(w=0;w<u;w++){for(var M=c(w,2,u-3),L=c(f,2,C-3),N=(P=0,-2);N<=2;N++)for(var I=-2;I<=2;I++)P+=m.get(M+N,L+I);var O=P/25;for(N=0;N<8;N++)for(I=0;I<8;I++){d=8*w+N,l=8*f+I;var z=n.get(d,l);g.set(d,l,z<=O),a&&x.set(d,l,!(z<=O))}}return a?{binarized:g,inverted:x}:{binarized:g}}},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=r(0),c=r(6),s=r(9),a=r(10);function n(o,e){for(var r=o^e,t=0;r;)t++,r&=r-1;return t}function d(o,e){return e<<1|o}var l=[{bits:21522,formatInfo:{errorCorrectionLevel:1,dataMask:0}},{bits:20773,formatInfo:{errorCorrectionLevel:1,dataMask:1}},{bits:24188,formatInfo:{errorCorrectionLevel:1,dataMask:2}},{bits:23371,formatInfo:{errorCorrectionLevel:1,dataMask:3}},{bits:17913,formatInfo:{errorCorrectionLevel:1,dataMask:4}},{bits:16590,formatInfo:{errorCorrectionLevel:1,dataMask:5}},{bits:20375,formatInfo:{errorCorrectionLevel:1,dataMask:6}},{bits:19104,formatInfo:{errorCorrectionLevel:1,dataMask:7}},{bits:30660,formatInfo:{errorCorrectionLevel:0,dataMask:0}},{bits:29427,formatInfo:{errorCorrectionLevel:0,dataMask:1}},{bits:32170,formatInfo:{errorCorrectionLevel:0,dataMask:2}},{bits:30877,formatInfo:{errorCorrectionLevel:0,dataMask:3}},{bits:26159,formatInfo:{errorCorrectionLevel:0,dataMask:4}},{bits:25368,formatInfo:{errorCorrectionLevel:0,dataMask:5}},{bits:27713,formatInfo:{errorCorrectionLevel:0,dataMask:6}},{bits:26998,formatInfo:{errorCorrectionLevel:0,dataMask:7}},{bits:5769,formatInfo:{errorCorrectionLevel:3,dataMask:0}},{bits:5054,formatInfo:{errorCorrectionLevel:3,dataMask:1}},{bits:7399,formatInfo:{errorCorrectionLevel:3,dataMask:2}},{bits:6608,formatInfo:{errorCorrectionLevel:3,dataMask:3}},{bits:1890,formatInfo:{errorCorrectionLevel:3,dataMask:4}},{bits:597,formatInfo:{errorCorrectionLevel:3,dataMask:5}},{bits:3340,formatInfo:{errorCorrectionLevel:3,dataMask:6}},{bits:2107,formatInfo:{errorCorrectionLevel:3,dataMask:7}},{bits:13663,formatInfo:{errorCorrectionLevel:2,dataMask:0}},{bits:12392,formatInfo:{errorCorrectionLevel:2,dataMask:1}},{bits:16177,formatInfo:{errorCorrectionLevel:2,dataMask:2}},{bits:14854,formatInfo:{errorCorrectionLevel:2,dataMask:3}},{bits:9396,formatInfo:{errorCorrectionLevel:2,dataMask:4}},{bits:8579,formatInfo:{errorCorrectionLevel:2,dataMask:5}},{bits:11994,formatInfo:{errorCorrectionLevel:2,dataMask:6}},{bits:11245,formatInfo:{errorCorrectionLevel:2,dataMask:7}}],i=[function(o){return(o.y+o.x)%2==0},function(o){return o.y%2==0},function(o){return o.x%3==0},function(o){return(o.y+o.x)%3==0},function(o){return(Math.floor(o.y/2)+Math.floor(o.x/3))%2==0},function(o){return o.x*o.y%2+o.x*o.y%3==0},function(o){return(o.y*o.x%2+o.y*o.x%3)%2==0},function(o){return((o.y+o.x)%2+o.y*o.x%3)%2==0}];function B(o,e,r){for(var c=i[r.dataMask],s=o.height,a=function(o){var e=17+4*o.versionNumber,r=t.BitMatrix.createEmpty(e,e);r.setRegion(0,0,9,9,!0),r.setRegion(e-8,0,8,9,!0),r.setRegion(0,e-8,9,8,!0);for(var c=0,s=o.alignmentPatternCenters;c<s.length;c++)for(var a=s[c],n=0,d=o.alignmentPatternCenters;n<d.length;n++){var l=d[n];6===a&&6===l||6===a&&l===e-7||a===e-7&&6===l||r.setRegion(a-2,l-2,5,5,!0)}return r.setRegion(6,9,1,e-17,!0),r.setRegion(9,6,e-17,1,!0),o.versionNumber>6&&(r.setRegion(e-11,0,3,6,!0),r.setRegion(0,e-11,6,3,!0)),r}(e),n=[],l=0,B=0,k=!0,u=s-1;u>0;u-=2){6===u&&u--;for(var C=0;C<s;C++)for(var m=k?s-1-C:C,f=0;f<2;f++){var w=u-f;if(!a.get(w,m)){B++;var P=o.get(w,m);c({y:m,x:w})&&(P=!P),l=d(P,l),8===B&&(n.push(l),B=0,l=0)}}k=!k}return n}function k(o){var e=function(o){var e=o.height,r=Math.floor((e-17)/4);if(r<=6)return a.VERSIONS[r-1];for(var t=0,c=5;c>=0;c--)for(var s=e-9;s>=e-11;s--)t=d(o.get(s,c),t);var l=0;for(s=5;s>=0;s--)for(c=e-9;c>=e-11;c--)l=d(o.get(s,c),l);for(var i,B=1/0,k=0,u=a.VERSIONS;k<u.length;k++){var C=u[k];if(C.infoBits===t||C.infoBits===l)return C;var m=n(t,C.infoBits);m<B&&(i=C,B=m),(m=n(l,C.infoBits))<B&&(i=C,B=m)}return B<=3?i:void 0}(o);if(!e)return null;var r=function(o){for(var e=0,r=0;r<=8;r++)6!==r&&(e=d(o.get(r,8),e));for(var t=7;t>=0;t--)6!==t&&(e=d(o.get(8,t),e));var c=o.height,s=0;for(t=c-1;t>=c-7;t--)s=d(o.get(8,t),s);for(r=c-8;r<c;r++)s=d(o.get(r,8),s);for(var a=1/0,i=null,B=0,k=l;B<k.length;B++){var u=k[B],C=u.bits,m=u.formatInfo;if(C===e||C===s)return m;var f=n(e,C);f<a&&(i=m,a=f),e!==s&&(f=n(s,C))<a&&(i=m,a=f)}return a<=3?i:null}(o);if(!r)return null;var t=function(o,e,r){var t=e.errorCorrectionLevels[r],c=[],s=0;if(t.ecBlocks.forEach(function(o){for(var e=0;e<o.numBlocks;e++)c.push({numDataCodewords:o.dataCodewordsPerBlock,codewords:[]}),s+=o.dataCodewordsPerBlock+t.ecCodewordsPerBlock}),o.length<s)return null;o=o.slice(0,s);for(var a=t.ecBlocks[0].dataCodewordsPerBlock,n=0;n<a;n++)for(var d=0,l=c;d<l.length;d++)l[d].codewords.push(o.shift());if(t.ecBlocks.length>1){var i=t.ecBlocks[0].numBlocks,B=t.ecBlocks[1].numBlocks;for(n=0;n<B;n++)c[i+n].codewords.push(o.shift())}for(;o.length>0;)for(var k=0,u=c;k<u.length;k++)u[k].codewords.push(o.shift());return c}(B(o,e,r),e,r.errorCorrectionLevel);if(!t)return null;for(var i=t.reduce(function(o,e){return o+e.numDataCodewords},0),k=new Uint8ClampedArray(i),u=0,C=0,m=t;C<m.length;C++){var f=m[C],w=s.decode(f.codewords,f.codewords.length-f.numDataCodewords);if(!w)return null;for(var P=0;P<f.numDataCodewords;P++)k[u++]=w[P]}try{return c.decode(k,e.versionNumber)}catch(o){return null}}e.decode=function(o){if(null==o)return null;var e=k(o);if(e)return e;for(var r=0;r<o.width;r++)for(var t=r+1;t<o.height;t++)o.get(r,t)!==o.get(t,r)&&(o.set(r,t,!o.get(r,t)),o.set(t,r,!o.get(t,r)));return k(o)}},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t,c,s=r(7),a=r(8);function n(o,e){for(var r=[],t="",c=[10,12,14][e],s=o.readBits(c);s>=3;){if((l=o.readBits(10))>=1e3)throw new Error("Invalid numeric value above 999");var a=Math.floor(l/100),n=Math.floor(l/10)%10,d=l%10;r.push(48+a,48+n,48+d),t+=a.toString()+n.toString()+d.toString(),s-=3}if(2===s){if((l=o.readBits(7))>=100)throw new Error("Invalid numeric value above 99");a=Math.floor(l/10),n=l%10;r.push(48+a,48+n),t+=a.toString()+n.toString()}else if(1===s){var l;if((l=o.readBits(4))>=10)throw new Error("Invalid numeric value above 9");r.push(48+l),t+=l.toString()}return{bytes:r,text:t}}!function(o){o.Numeric="numeric",o.Alphanumeric="alphanumeric",o.Byte="byte",o.Kanji="kanji",o.ECI="eci"}(t=e.Mode||(e.Mode={})),function(o){o[o.Terminator=0]="Terminator",o[o.Numeric=1]="Numeric",o[o.Alphanumeric=2]="Alphanumeric",o[o.Byte=4]="Byte",o[o.Kanji=8]="Kanji",o[o.ECI=7]="ECI"}(c||(c={}));var d=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function l(o,e){for(var r=[],t="",c=[9,11,13][e],s=o.readBits(c);s>=2;){var a=o.readBits(11),n=Math.floor(a/45),l=a%45;r.push(d[n].charCodeAt(0),d[l].charCodeAt(0)),t+=d[n]+d[l],s-=2}if(1===s){n=o.readBits(6);r.push(d[n].charCodeAt(0)),t+=d[n]}return{bytes:r,text:t}}function i(o,e){for(var r=[],t="",c=[8,16,16][e],s=o.readBits(c),a=0;a<s;a++){var n=o.readBits(8);r.push(n)}try{t+=decodeURIComponent(r.map(function(o){return"%"+("0"+o.toString(16)).substr(-2)}).join(""))}catch(o){}return{bytes:r,text:t}}function B(o,e){for(var r=[],t="",c=[8,10,12][e],s=o.readBits(c),n=0;n<s;n++){var d=o.readBits(13),l=Math.floor(d/192)<<8|d%192;l+=l<7936?33088:49472,r.push(l>>8,255&l),t+=String.fromCharCode(a.shiftJISTable[l])}return{bytes:r,text:t}}e.decode=function(o,e){for(var r,a,d,k,u=new s.BitStream(o),C=e<=9?0:e<=26?1:2,m={text:"",bytes:[],chunks:[],version:e};u.available()>=4;){var f=u.readBits(4);if(f===c.Terminator)return m;if(f===c.ECI)0===u.readBits(1)?m.chunks.push({type:t.ECI,assignmentNumber:u.readBits(7)}):0===u.readBits(1)?m.chunks.push({type:t.ECI,assignmentNumber:u.readBits(14)}):0===u.readBits(1)?m.chunks.push({type:t.ECI,assignmentNumber:u.readBits(21)}):m.chunks.push({type:t.ECI,assignmentNumber:-1});else if(f===c.Numeric){var w=n(u,C);m.text+=w.text,(r=m.bytes).push.apply(r,w.bytes),m.chunks.push({type:t.Numeric,text:w.text})}else if(f===c.Alphanumeric){var P=l(u,C);m.text+=P.text,(a=m.bytes).push.apply(a,P.bytes),m.chunks.push({type:t.Alphanumeric,text:P.text})}else if(f===c.Byte){var v=i(u,C);m.text+=v.text,(d=m.bytes).push.apply(d,v.bytes),m.chunks.push({type:t.Byte,bytes:v.bytes,text:v.text})}else if(f===c.Kanji){var h=B(u,C);m.text+=h.text,(k=m.bytes).push.apply(k,h.bytes),m.chunks.push({type:t.Kanji,bytes:h.bytes,text:h.text})}}if(0===u.available()||0===u.readBits(u.available()))return m}},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=function(){function o(o){this.byteOffset=0,this.bitOffset=0,this.bytes=o}return o.prototype.readBits=function(o){if(o<1||o>32||o>this.available())throw new Error("Cannot read "+o.toString()+" bits");var e=0;if(this.bitOffset>0){var r=8-this.bitOffset,t=o<r?o:r,c=255>>8-t<<(s=r-t);e=(this.bytes[this.byteOffset]&c)>>s,o-=t,this.bitOffset+=t,8===this.bitOffset&&(this.bitOffset=0,this.byteOffset++)}if(o>0){for(;o>=8;)e=e<<8|255&this.bytes[this.byteOffset],this.byteOffset++,o-=8;if(o>0){var s;c=255>>(s=8-o)<<s;e=e<<o|(this.bytes[this.byteOffset]&c)>>s,this.bitOffset+=o}}return e},o.prototype.available=function(){return 8*(this.bytes.length-this.byteOffset)-this.bitOffset},o}();e.BitStream=t},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.shiftJISTable={32:32,33:33,34:34,35:35,36:36,37:37,38:38,39:39,40:40,41:41,42:42,43:43,44:44,45:45,46:46,47:47,48:48,49:49,50:50,51:51,52:52,53:53,54:54,55:55,56:56,57:57,58:58,59:59,60:60,61:61,62:62,63:63,64:64,65:65,66:66,67:67,68:68,69:69,70:70,71:71,72:72,73:73,74:74,75:75,76:76,77:77,78:78,79:79,80:80,81:81,82:82,83:83,84:84,85:85,86:86,87:87,88:88,89:89,90:90,91:91,92:165,93:93,94:94,95:95,96:96,97:97,98:98,99:99,100:100,101:101,102:102,103:103,104:104,105:105,106:106,107:107,108:108,109:109,110:110,111:111,112:112,113:113,114:114,115:115,116:116,117:117,118:118,119:119,120:120,121:121,122:122,123:123,124:124,125:125,126:8254,33088:12288,33089:12289,33090:12290,33091:65292,33092:65294,33093:12539,33094:65306,33095:65307,33096:65311,33097:65281,33098:12443,33099:12444,33100:180,33101:65344,33102:168,33103:65342,33104:65507,33105:65343,33106:12541,33107:12542,33108:12445,33109:12446,33110:12291,33111:20189,33112:12293,33113:12294,33114:12295,33115:12540,33116:8213,33117:8208,33118:65295,33119:92,33120:12316,33121:8214,33122:65372,33123:8230,33124:8229,33125:8216,33126:8217,33127:8220,33128:8221,33129:65288,33130:65289,33131:12308,33132:12309,33133:65339,33134:65341,33135:65371,33136:65373,33137:12296,33138:12297,33139:12298,33140:12299,33141:12300,33142:12301,33143:12302,33144:12303,33145:12304,33146:12305,33147:65291,33148:8722,33149:177,33150:215,33152:247,33153:65309,33154:8800,33155:65308,33156:65310,33157:8806,33158:8807,33159:8734,33160:8756,33161:9794,33162:9792,33163:176,33164:8242,33165:8243,33166:8451,33167:65509,33168:65284,33169:162,33170:163,33171:65285,33172:65283,33173:65286,33174:65290,33175:65312,33176:167,33177:9734,33178:9733,33179:9675,33180:9679,33181:9678,33182:9671,33183:9670,33184:9633,33185:9632,33186:9651,33187:9650,33188:9661,33189:9660,33190:8251,33191:12306,33192:8594,33193:8592,33194:8593,33195:8595,33196:12307,33208:8712,33209:8715,33210:8838,33211:8839,33212:8834,33213:8835,33214:8746,33215:8745,33224:8743,33225:8744,33226:172,33227:8658,33228:8660,33229:8704,33230:8707,33242:8736,33243:8869,33244:8978,33245:8706,33246:8711,33247:8801,33248:8786,33249:8810,33250:8811,33251:8730,33252:8765,33253:8733,33254:8757,33255:8747,33256:8748,33264:8491,33265:8240,33266:9839,33267:9837,33268:9834,33269:8224,33270:8225,33271:182,33276:9711,33359:65296,33360:65297,33361:65298,33362:65299,33363:65300,33364:65301,33365:65302,33366:65303,33367:65304,33368:65305,33376:65313,33377:65314,33378:65315,33379:65316,33380:65317,33381:65318,33382:65319,33383:65320,33384:65321,33385:65322,33386:65323,33387:65324,33388:65325,33389:65326,33390:65327,33391:65328,33392:65329,33393:65330,33394:65331,33395:65332,33396:65333,33397:65334,33398:65335,33399:65336,33400:65337,33401:65338,33409:65345,33410:65346,33411:65347,33412:65348,33413:65349,33414:65350,33415:65351,33416:65352,33417:65353,33418:65354,33419:65355,33420:65356,33421:65357,33422:65358,33423:65359,33424:65360,33425:65361,33426:65362,33427:65363,33428:65364,33429:65365,33430:65366,33431:65367,33432:65368,33433:65369,33434:65370,33439:12353,33440:12354,33441:12355,33442:12356,33443:12357,33444:12358,33445:12359,33446:12360,33447:12361,33448:12362,33449:12363,33450:12364,33451:12365,33452:12366,33453:12367,33454:12368,33455:12369,33456:12370,33457:12371,33458:12372,33459:12373,33460:12374,33461:12375,33462:12376,33463:12377,33464:12378,33465:12379,33466:12380,33467:12381,33468:12382,33469:12383,33470:12384,33471:12385,33472:12386,33473:12387,33474:12388,33475:12389,33476:12390,33477:12391,33478:12392,33479:12393,33480:12394,33481:12395,33482:12396,33483:12397,33484:12398,33485:12399,33486:12400,33487:12401,33488:12402,33489:12403,33490:12404,33491:12405,33492:12406,33493:12407,33494:12408,33495:12409,33496:12410,33497:12411,33498:12412,33499:12413,33500:12414,33501:12415,33502:12416,33503:12417,33504:12418,33505:12419,33506:12420,33507:12421,33508:12422,33509:12423,33510:12424,33511:12425,33512:12426,33513:12427,33514:12428,33515:12429,33516:12430,33517:12431,33518:12432,33519:12433,33520:12434,33521:12435,33600:12449,33601:12450,33602:12451,33603:12452,33604:12453,33605:12454,33606:12455,33607:12456,33608:12457,33609:12458,33610:12459,33611:12460,33612:12461,33613:12462,33614:12463,33615:12464,33616:12465,33617:12466,33618:12467,33619:12468,33620:12469,33621:12470,33622:12471,33623:12472,33624:12473,33625:12474,33626:12475,33627:12476,33628:12477,33629:12478,33630:12479,33631:12480,33632:12481,33633:12482,33634:12483,33635:12484,33636:12485,33637:12486,33638:12487,33639:12488,33640:12489,33641:12490,33642:12491,33643:12492,33644:12493,33645:12494,33646:12495,33647:12496,33648:12497,33649:12498,33650:12499,33651:12500,33652:12501,33653:12502,33654:12503,33655:12504,33656:12505,33657:12506,33658:12507,33659:12508,33660:12509,33661:12510,33662:12511,33664:12512,33665:12513,33666:12514,33667:12515,33668:12516,33669:12517,33670:12518,33671:12519,33672:12520,33673:12521,33674:12522,33675:12523,33676:12524,33677:12525,33678:12526,33679:12527,33680:12528,33681:12529,33682:12530,33683:12531,33684:12532,33685:12533,33686:12534,33695:913,33696:914,33697:915,33698:916,33699:917,33700:918,33701:919,33702:920,33703:921,33704:922,33705:923,33706:924,33707:925,33708:926,33709:927,33710:928,33711:929,33712:931,33713:932,33714:933,33715:934,33716:935,33717:936,33718:937,33727:945,33728:946,33729:947,33730:948,33731:949,33732:950,33733:951,33734:952,33735:953,33736:954,33737:955,33738:956,33739:957,33740:958,33741:959,33742:960,33743:961,33744:963,33745:964,33746:965,33747:966,33748:967,33749:968,33750:969,33856:1040,33857:1041,33858:1042,33859:1043,33860:1044,33861:1045,33862:1025,33863:1046,33864:1047,33865:1048,33866:1049,33867:1050,33868:1051,33869:1052,33870:1053,33871:1054,33872:1055,33873:1056,33874:1057,33875:1058,33876:1059,33877:1060,33878:1061,33879:1062,33880:1063,33881:1064,33882:1065,33883:1066,33884:1067,33885:1068,33886:1069,33887:1070,33888:1071,33904:1072,33905:1073,33906:1074,33907:1075,33908:1076,33909:1077,33910:1105,33911:1078,33912:1079,33913:1080,33914:1081,33915:1082,33916:1083,33917:1084,33918:1085,33920:1086,33921:1087,33922:1088,33923:1089,33924:1090,33925:1091,33926:1092,33927:1093,33928:1094,33929:1095,33930:1096,33931:1097,33932:1098,33933:1099,33934:1100,33935:1101,33936:1102,33937:1103,33951:9472,33952:9474,33953:9484,33954:9488,33955:9496,33956:9492,33957:9500,33958:9516,33959:9508,33960:9524,33961:9532,33962:9473,33963:9475,33964:9487,33965:9491,33966:9499,33967:9495,33968:9507,33969:9523,33970:9515,33971:9531,33972:9547,33973:9504,33974:9519,33975:9512,33976:9527,33977:9535,33978:9501,33979:9520,33980:9509,33981:9528,33982:9538,34975:20124,34976:21782,34977:23043,34978:38463,34979:21696,34980:24859,34981:25384,34982:23030,34983:36898,34984:33909,34985:33564,34986:31312,34987:24746,34988:25569,34989:28197,34990:26093,34991:33894,34992:33446,34993:39925,34994:26771,34995:22311,34996:26017,34997:25201,34998:23451,34999:22992,35e3:34427,35001:39156,35002:32098,35003:32190,35004:39822,35005:25110,35006:31903,35007:34999,35008:23433,35009:24245,35010:25353,35011:26263,35012:26696,35013:38343,35014:38797,35015:26447,35016:20197,35017:20234,35018:20301,35019:20381,35020:20553,35021:22258,35022:22839,35023:22996,35024:23041,35025:23561,35026:24799,35027:24847,35028:24944,35029:26131,35030:26885,35031:28858,35032:30031,35033:30064,35034:31227,35035:32173,35036:32239,35037:32963,35038:33806,35039:34915,35040:35586,35041:36949,35042:36986,35043:21307,35044:20117,35045:20133,35046:22495,35047:32946,35048:37057,35049:30959,35050:19968,35051:22769,35052:28322,35053:36920,35054:31282,35055:33576,35056:33419,35057:39983,35058:20801,35059:21360,35060:21693,35061:21729,35062:22240,35063:23035,35064:24341,35065:39154,35066:28139,35067:32996,35068:34093,35136:38498,35137:38512,35138:38560,35139:38907,35140:21515,35141:21491,35142:23431,35143:28879,35144:32701,35145:36802,35146:38632,35147:21359,35148:40284,35149:31418,35150:19985,35151:30867,35152:33276,35153:28198,35154:22040,35155:21764,35156:27421,35157:34074,35158:39995,35159:23013,35160:21417,35161:28006,35162:29916,35163:38287,35164:22082,35165:20113,35166:36939,35167:38642,35168:33615,35169:39180,35170:21473,35171:21942,35172:23344,35173:24433,35174:26144,35175:26355,35176:26628,35177:27704,35178:27891,35179:27945,35180:29787,35181:30408,35182:31310,35183:38964,35184:33521,35185:34907,35186:35424,35187:37613,35188:28082,35189:30123,35190:30410,35191:39365,35192:24742,35193:35585,35194:36234,35195:38322,35196:27022,35197:21421,35198:20870,35200:22290,35201:22576,35202:22852,35203:23476,35204:24310,35205:24616,35206:25513,35207:25588,35208:27839,35209:28436,35210:28814,35211:28948,35212:29017,35213:29141,35214:29503,35215:32257,35216:33398,35217:33489,35218:34199,35219:36960,35220:37467,35221:40219,35222:22633,35223:26044,35224:27738,35225:29989,35226:20985,35227:22830,35228:22885,35229:24448,35230:24540,35231:25276,35232:26106,35233:27178,35234:27431,35235:27572,35236:29579,35237:32705,35238:35158,35239:40236,35240:40206,35241:40644,35242:23713,35243:27798,35244:33659,35245:20740,35246:23627,35247:25014,35248:33222,35249:26742,35250:29281,35251:20057,35252:20474,35253:21368,35254:24681,35255:28201,35256:31311,35257:38899,35258:19979,35259:21270,35260:20206,35261:20309,35262:20285,35263:20385,35264:20339,35265:21152,35266:21487,35267:22025,35268:22799,35269:23233,35270:23478,35271:23521,35272:31185,35273:26247,35274:26524,35275:26550,35276:27468,35277:27827,35278:28779,35279:29634,35280:31117,35281:31166,35282:31292,35283:31623,35284:33457,35285:33499,35286:33540,35287:33655,35288:33775,35289:33747,35290:34662,35291:35506,35292:22057,35293:36008,35294:36838,35295:36942,35296:38686,35297:34442,35298:20420,35299:23784,35300:25105,35301:29273,35302:30011,35303:33253,35304:33469,35305:34558,35306:36032,35307:38597,35308:39187,35309:39381,35310:20171,35311:20250,35312:35299,35313:22238,35314:22602,35315:22730,35316:24315,35317:24555,35318:24618,35319:24724,35320:24674,35321:25040,35322:25106,35323:25296,35324:25913,35392:39745,35393:26214,35394:26800,35395:28023,35396:28784,35397:30028,35398:30342,35399:32117,35400:33445,35401:34809,35402:38283,35403:38542,35404:35997,35405:20977,35406:21182,35407:22806,35408:21683,35409:23475,35410:23830,35411:24936,35412:27010,35413:28079,35414:30861,35415:33995,35416:34903,35417:35442,35418:37799,35419:39608,35420:28012,35421:39336,35422:34521,35423:22435,35424:26623,35425:34510,35426:37390,35427:21123,35428:22151,35429:21508,35430:24275,35431:25313,35432:25785,35433:26684,35434:26680,35435:27579,35436:29554,35437:30906,35438:31339,35439:35226,35440:35282,35441:36203,35442:36611,35443:37101,35444:38307,35445:38548,35446:38761,35447:23398,35448:23731,35449:27005,35450:38989,35451:38990,35452:25499,35453:31520,35454:27179,35456:27263,35457:26806,35458:39949,35459:28511,35460:21106,35461:21917,35462:24688,35463:25324,35464:27963,35465:28167,35466:28369,35467:33883,35468:35088,35469:36676,35470:19988,35471:39993,35472:21494,35473:26907,35474:27194,35475:38788,35476:26666,35477:20828,35478:31427,35479:33970,35480:37340,35481:37772,35482:22107,35483:40232,35484:26658,35485:33541,35486:33841,35487:31909,35488:21e3,35489:33477,35490:29926,35491:20094,35492:20355,35493:20896,35494:23506,35495:21002,35496:21208,35497:21223,35498:24059,35499:21914,35500:22570,35501:23014,35502:23436,35503:23448,35504:23515,35505:24178,35506:24185,35507:24739,35508:24863,35509:24931,35510:25022,35511:25563,35512:25954,35513:26577,35514:26707,35515:26874,35516:27454,35517:27475,35518:27735,35519:28450,35520:28567,35521:28485,35522:29872,35523:29976,35524:30435,35525:30475,35526:31487,35527:31649,35528:31777,35529:32233,35530:32566,35531:32752,35532:32925,35533:33382,35534:33694,35535:35251,35536:35532,35537:36011,35538:36996,35539:37969,35540:38291,35541:38289,35542:38306,35543:38501,35544:38867,35545:39208,35546:33304,35547:20024,35548:21547,35549:23736,35550:24012,35551:29609,35552:30284,35553:30524,35554:23721,35555:32747,35556:36107,35557:38593,35558:38929,35559:38996,35560:39e3,35561:20225,35562:20238,35563:21361,35564:21916,35565:22120,35566:22522,35567:22855,35568:23305,35569:23492,35570:23696,35571:24076,35572:24190,35573:24524,35574:25582,35575:26426,35576:26071,35577:26082,35578:26399,35579:26827,35580:26820,35648:27231,35649:24112,35650:27589,35651:27671,35652:27773,35653:30079,35654:31048,35655:23395,35656:31232,35657:32e3,35658:24509,35659:35215,35660:35352,35661:36020,35662:36215,35663:36556,35664:36637,35665:39138,35666:39438,35667:39740,35668:20096,35669:20605,35670:20736,35671:22931,35672:23452,35673:25135,35674:25216,35675:25836,35676:27450,35677:29344,35678:30097,35679:31047,35680:32681,35681:34811,35682:35516,35683:35696,35684:25516,35685:33738,35686:38816,35687:21513,35688:21507,35689:21931,35690:26708,35691:27224,35692:35440,35693:30759,35694:26485,35695:40653,35696:21364,35697:23458,35698:33050,35699:34384,35700:36870,35701:19992,35702:20037,35703:20167,35704:20241,35705:21450,35706:21560,35707:23470,35708:24339,35709:24613,35710:25937,35712:26429,35713:27714,35714:27762,35715:27875,35716:28792,35717:29699,35718:31350,35719:31406,35720:31496,35721:32026,35722:31998,35723:32102,35724:26087,35725:29275,35726:21435,35727:23621,35728:24040,35729:25298,35730:25312,35731:25369,35732:28192,35733:34394,35734:35377,35735:36317,35736:37624,35737:28417,35738:31142,35739:39770,35740:20136,35741:20139,35742:20140,35743:20379,35744:20384,35745:20689,35746:20807,35747:31478,35748:20849,35749:20982,35750:21332,35751:21281,35752:21375,35753:21483,35754:21932,35755:22659,35756:23777,35757:24375,35758:24394,35759:24623,35760:24656,35761:24685,35762:25375,35763:25945,35764:27211,35765:27841,35766:29378,35767:29421,35768:30703,35769:33016,35770:33029,35771:33288,35772:34126,35773:37111,35774:37857,35775:38911,35776:39255,35777:39514,35778:20208,35779:20957,35780:23597,35781:26241,35782:26989,35783:23616,35784:26354,35785:26997,35786:29577,35787:26704,35788:31873,35789:20677,35790:21220,35791:22343,35792:24062,35793:37670,35794:26020,35795:27427,35796:27453,35797:29748,35798:31105,35799:31165,35800:31563,35801:32202,35802:33465,35803:33740,35804:34943,35805:35167,35806:35641,35807:36817,35808:37329,35809:21535,35810:37504,35811:20061,35812:20534,35813:21477,35814:21306,35815:29399,35816:29590,35817:30697,35818:33510,35819:36527,35820:39366,35821:39368,35822:39378,35823:20855,35824:24858,35825:34398,35826:21936,35827:31354,35828:20598,35829:23507,35830:36935,35831:38533,35832:20018,35833:27355,35834:37351,35835:23633,35836:23624,35904:25496,35905:31391,35906:27795,35907:38772,35908:36705,35909:31402,35910:29066,35911:38536,35912:31874,35913:26647,35914:32368,35915:26705,35916:37740,35917:21234,35918:21531,35919:34219,35920:35347,35921:32676,35922:36557,35923:37089,35924:21350,35925:34952,35926:31041,35927:20418,35928:20670,35929:21009,35930:20804,35931:21843,35932:22317,35933:29674,35934:22411,35935:22865,35936:24418,35937:24452,35938:24693,35939:24950,35940:24935,35941:25001,35942:25522,35943:25658,35944:25964,35945:26223,35946:26690,35947:28179,35948:30054,35949:31293,35950:31995,35951:32076,35952:32153,35953:32331,35954:32619,35955:33550,35956:33610,35957:34509,35958:35336,35959:35427,35960:35686,35961:36605,35962:38938,35963:40335,35964:33464,35965:36814,35966:39912,35968:21127,35969:25119,35970:25731,35971:28608,35972:38553,35973:26689,35974:20625,35975:27424,35976:27770,35977:28500,35978:31348,35979:32080,35980:34880,35981:35363,35982:26376,35983:20214,35984:20537,35985:20518,35986:20581,35987:20860,35988:21048,35989:21091,35990:21927,35991:22287,35992:22533,35993:23244,35994:24314,35995:25010,35996:25080,35997:25331,35998:25458,35999:26908,36e3:27177,36001:29309,36002:29356,36003:29486,36004:30740,36005:30831,36006:32121,36007:30476,36008:32937,36009:35211,36010:35609,36011:36066,36012:36562,36013:36963,36014:37749,36015:38522,36016:38997,36017:39443,36018:40568,36019:20803,36020:21407,36021:21427,36022:24187,36023:24358,36024:28187,36025:28304,36026:29572,36027:29694,36028:32067,36029:33335,36030:35328,36031:35578,36032:38480,36033:20046,36034:20491,36035:21476,36036:21628,36037:22266,36038:22993,36039:23396,36040:24049,36041:24235,36042:24359,36043:25144,36044:25925,36045:26543,36046:28246,36047:29392,36048:31946,36049:34996,36050:32929,36051:32993,36052:33776,36053:34382,36054:35463,36055:36328,36056:37431,36057:38599,36058:39015,36059:40723,36060:20116,36061:20114,36062:20237,36063:21320,36064:21577,36065:21566,36066:23087,36067:24460,36068:24481,36069:24735,36070:26791,36071:27278,36072:29786,36073:30849,36074:35486,36075:35492,36076:35703,36077:37264,36078:20062,36079:39881,36080:20132,36081:20348,36082:20399,36083:20505,36084:20502,36085:20809,36086:20844,36087:21151,36088:21177,36089:21246,36090:21402,36091:21475,36092:21521,36160:21518,36161:21897,36162:22353,36163:22434,36164:22909,36165:23380,36166:23389,36167:23439,36168:24037,36169:24039,36170:24055,36171:24184,36172:24195,36173:24218,36174:24247,36175:24344,36176:24658,36177:24908,36178:25239,36179:25304,36180:25511,36181:25915,36182:26114,36183:26179,36184:26356,36185:26477,36186:26657,36187:26775,36188:27083,36189:27743,36190:27946,36191:28009,36192:28207,36193:28317,36194:30002,36195:30343,36196:30828,36197:31295,36198:31968,36199:32005,36200:32024,36201:32094,36202:32177,36203:32789,36204:32771,36205:32943,36206:32945,36207:33108,36208:33167,36209:33322,36210:33618,36211:34892,36212:34913,36213:35611,36214:36002,36215:36092,36216:37066,36217:37237,36218:37489,36219:30783,36220:37628,36221:38308,36222:38477,36224:38917,36225:39321,36226:39640,36227:40251,36228:21083,36229:21163,36230:21495,36231:21512,36232:22741,36233:25335,36234:28640,36235:35946,36236:36703,36237:40633,36238:20811,36239:21051,36240:21578,36241:22269,36242:31296,36243:37239,36244:40288,36245:40658,36246:29508,36247:28425,36248:33136,36249:29969,36250:24573,36251:24794,36252:39592,36253:29403,36254:36796,36255:27492,36256:38915,36257:20170,36258:22256,36259:22372,36260:22718,36261:23130,36262:24680,36263:25031,36264:26127,36265:26118,36266:26681,36267:26801,36268:28151,36269:30165,36270:32058,36271:33390,36272:39746,36273:20123,36274:20304,36275:21449,36276:21766,36277:23919,36278:24038,36279:24046,36280:26619,36281:27801,36282:29811,36283:30722,36284:35408,36285:37782,36286:35039,36287:22352,36288:24231,36289:25387,36290:20661,36291:20652,36292:20877,36293:26368,36294:21705,36295:22622,36296:22971,36297:23472,36298:24425,36299:25165,36300:25505,36301:26685,36302:27507,36303:28168,36304:28797,36305:37319,36306:29312,36307:30741,36308:30758,36309:31085,36310:25998,36311:32048,36312:33756,36313:35009,36314:36617,36315:38555,36316:21092,36317:22312,36318:26448,36319:32618,36320:36001,36321:20916,36322:22338,36323:38442,36324:22586,36325:27018,36326:32948,36327:21682,36328:23822,36329:22524,36330:30869,36331:40442,36332:20316,36333:21066,36334:21643,36335:25662,36336:26152,36337:26388,36338:26613,36339:31364,36340:31574,36341:32034,36342:37679,36343:26716,36344:39853,36345:31545,36346:21273,36347:20874,36348:21047,36416:23519,36417:25334,36418:25774,36419:25830,36420:26413,36421:27578,36422:34217,36423:38609,36424:30352,36425:39894,36426:25420,36427:37638,36428:39851,36429:30399,36430:26194,36431:19977,36432:20632,36433:21442,36434:23665,36435:24808,36436:25746,36437:25955,36438:26719,36439:29158,36440:29642,36441:29987,36442:31639,36443:32386,36444:34453,36445:35715,36446:36059,36447:37240,36448:39184,36449:26028,36450:26283,36451:27531,36452:20181,36453:20180,36454:20282,36455:20351,36456:21050,36457:21496,36458:21490,36459:21987,36460:22235,36461:22763,36462:22987,36463:22985,36464:23039,36465:23376,36466:23629,36467:24066,36468:24107,36469:24535,36470:24605,36471:25351,36472:25903,36473:23388,36474:26031,36475:26045,36476:26088,36477:26525,36478:27490,36480:27515,36481:27663,36482:29509,36483:31049,36484:31169,36485:31992,36486:32025,36487:32043,36488:32930,36489:33026,36490:33267,36491:35222,36492:35422,36493:35433,36494:35430,36495:35468,36496:35566,36497:36039,36498:36060,36499:38604,36500:39164,36501:27503,36502:20107,36503:20284,36504:20365,36505:20816,36506:23383,36507:23546,36508:24904,36509:25345,36510:26178,36511:27425,36512:28363,36513:27835,36514:29246,36515:29885,36516:30164,36517:30913,36518:31034,36519:32780,36520:32819,36521:33258,36522:33940,36523:36766,36524:27728,36525:40575,36526:24335,36527:35672,36528:40235,36529:31482,36530:36600,36531:23437,36532:38635,36533:19971,36534:21489,36535:22519,36536:22833,36537:23241,36538:23460,36539:24713,36540:28287,36541:28422,36542:30142,36543:36074,36544:23455,36545:34048,36546:31712,36547:20594,36548:26612,36549:33437,36550:23649,36551:34122,36552:32286,36553:33294,36554:20889,36555:23556,36556:25448,36557:36198,36558:26012,36559:29038,36560:31038,36561:32023,36562:32773,36563:35613,36564:36554,36565:36974,36566:34503,36567:37034,36568:20511,36569:21242,36570:23610,36571:26451,36572:28796,36573:29237,36574:37196,36575:37320,36576:37675,36577:33509,36578:23490,36579:24369,36580:24825,36581:20027,36582:21462,36583:23432,36584:25163,36585:26417,36586:27530,36587:29417,36588:29664,36589:31278,36590:33131,36591:36259,36592:37202,36593:39318,36594:20754,36595:21463,36596:21610,36597:23551,36598:25480,36599:27193,36600:32172,36601:38656,36602:22234,36603:21454,36604:21608,36672:23447,36673:23601,36674:24030,36675:20462,36676:24833,36677:25342,36678:27954,36679:31168,36680:31179,36681:32066,36682:32333,36683:32722,36684:33261,36685:33311,36686:33936,36687:34886,36688:35186,36689:35728,36690:36468,36691:36655,36692:36913,36693:37195,36694:37228,36695:38598,36696:37276,36697:20160,36698:20303,36699:20805,36700:21313,36701:24467,36702:25102,36703:26580,36704:27713,36705:28171,36706:29539,36707:32294,36708:37325,36709:37507,36710:21460,36711:22809,36712:23487,36713:28113,36714:31069,36715:32302,36716:31899,36717:22654,36718:29087,36719:20986,36720:34899,36721:36848,36722:20426,36723:23803,36724:26149,36725:30636,36726:31459,36727:33308,36728:39423,36729:20934,36730:24490,36731:26092,36732:26991,36733:27529,36734:28147,36736:28310,36737:28516,36738:30462,36739:32020,36740:24033,36741:36981,36742:37255,36743:38918,36744:20966,36745:21021,36746:25152,36747:26257,36748:26329,36749:28186,36750:24246,36751:32210,36752:32626,36753:26360,36754:34223,36755:34295,36756:35576,36757:21161,36758:21465,36759:22899,36760:24207,36761:24464,36762:24661,36763:37604,36764:38500,36765:20663,36766:20767,36767:21213,36768:21280,36769:21319,36770:21484,36771:21736,36772:21830,36773:21809,36774:22039,36775:22888,36776:22974,36777:23100,36778:23477,36779:23558,36780:23567,36781:23569,36782:23578,36783:24196,36784:24202,36785:24288,36786:24432,36787:25215,36788:25220,36789:25307,36790:25484,36791:25463,36792:26119,36793:26124,36794:26157,36795:26230,36796:26494,36797:26786,36798:27167,36799:27189,36800:27836,36801:28040,36802:28169,36803:28248,36804:28988,36805:28966,36806:29031,36807:30151,36808:30465,36809:30813,36810:30977,36811:31077,36812:31216,36813:31456,36814:31505,36815:31911,36816:32057,36817:32918,36818:33750,36819:33931,36820:34121,36821:34909,36822:35059,36823:35359,36824:35388,36825:35412,36826:35443,36827:35937,36828:36062,36829:37284,36830:37478,36831:37758,36832:37912,36833:38556,36834:38808,36835:19978,36836:19976,36837:19998,36838:20055,36839:20887,36840:21104,36841:22478,36842:22580,36843:22732,36844:23330,36845:24120,36846:24773,36847:25854,36848:26465,36849:26454,36850:27972,36851:29366,36852:30067,36853:31331,36854:33976,36855:35698,36856:37304,36857:37664,36858:22065,36859:22516,36860:39166,36928:25325,36929:26893,36930:27542,36931:29165,36932:32340,36933:32887,36934:33394,36935:35302,36936:39135,36937:34645,36938:36785,36939:23611,36940:20280,36941:20449,36942:20405,36943:21767,36944:23072,36945:23517,36946:23529,36947:24515,36948:24910,36949:25391,36950:26032,36951:26187,36952:26862,36953:27035,36954:28024,36955:28145,36956:30003,36957:30137,36958:30495,36959:31070,36960:31206,36961:32051,36962:33251,36963:33455,36964:34218,36965:35242,36966:35386,36967:36523,36968:36763,36969:36914,36970:37341,36971:38663,36972:20154,36973:20161,36974:20995,36975:22645,36976:22764,36977:23563,36978:29978,36979:23613,36980:33102,36981:35338,36982:36805,36983:38499,36984:38765,36985:31525,36986:35535,36987:38920,36988:37218,36989:22259,36990:21416,36992:36887,36993:21561,36994:22402,36995:24101,36996:25512,36997:27700,36998:28810,36999:30561,37e3:31883,37001:32736,37002:34928,37003:36930,37004:37204,37005:37648,37006:37656,37007:38543,37008:29790,37009:39620,37010:23815,37011:23913,37012:25968,37013:26530,37014:36264,37015:38619,37016:25454,37017:26441,37018:26905,37019:33733,37020:38935,37021:38592,37022:35070,37023:28548,37024:25722,37025:23544,37026:19990,37027:28716,37028:30045,37029:26159,37030:20932,37031:21046,37032:21218,37033:22995,37034:24449,37035:24615,37036:25104,37037:25919,37038:25972,37039:26143,37040:26228,37041:26866,37042:26646,37043:27491,37044:28165,37045:29298,37046:29983,37047:30427,37048:31934,37049:32854,37050:22768,37051:35069,37052:35199,37053:35488,37054:35475,37055:35531,37056:36893,37057:37266,37058:38738,37059:38745,37060:25993,37061:31246,37062:33030,37063:38587,37064:24109,37065:24796,37066:25114,37067:26021,37068:26132,37069:26512,37070:30707,37071:31309,37072:31821,37073:32318,37074:33034,37075:36012,37076:36196,37077:36321,37078:36447,37079:30889,37080:20999,37081:25305,37082:25509,37083:25666,37084:25240,37085:35373,37086:31363,37087:31680,37088:35500,37089:38634,37090:32118,37091:33292,37092:34633,37093:20185,37094:20808,37095:21315,37096:21344,37097:23459,37098:23554,37099:23574,37100:24029,37101:25126,37102:25159,37103:25776,37104:26643,37105:26676,37106:27849,37107:27973,37108:27927,37109:26579,37110:28508,37111:29006,37112:29053,37113:26059,37114:31359,37115:31661,37116:32218,37184:32330,37185:32680,37186:33146,37187:33307,37188:33337,37189:34214,37190:35438,37191:36046,37192:36341,37193:36984,37194:36983,37195:37549,37196:37521,37197:38275,37198:39854,37199:21069,37200:21892,37201:28472,37202:28982,37203:20840,37204:31109,37205:32341,37206:33203,37207:31950,37208:22092,37209:22609,37210:23720,37211:25514,37212:26366,37213:26365,37214:26970,37215:29401,37216:30095,37217:30094,37218:30990,37219:31062,37220:31199,37221:31895,37222:32032,37223:32068,37224:34311,37225:35380,37226:38459,37227:36961,37228:40736,37229:20711,37230:21109,37231:21452,37232:21474,37233:20489,37234:21930,37235:22766,37236:22863,37237:29245,37238:23435,37239:23652,37240:21277,37241:24803,37242:24819,37243:25436,37244:25475,37245:25407,37246:25531,37248:25805,37249:26089,37250:26361,37251:24035,37252:27085,37253:27133,37254:28437,37255:29157,37256:20105,37257:30185,37258:30456,37259:31379,37260:31967,37261:32207,37262:32156,37263:32865,37264:33609,37265:33624,37266:33900,37267:33980,37268:34299,37269:35013,37270:36208,37271:36865,37272:36973,37273:37783,37274:38684,37275:39442,37276:20687,37277:22679,37278:24974,37279:33235,37280:34101,37281:36104,37282:36896,37283:20419,37284:20596,37285:21063,37286:21363,37287:24687,37288:25417,37289:26463,37290:28204,37291:36275,37292:36895,37293:20439,37294:23646,37295:36042,37296:26063,37297:32154,37298:21330,37299:34966,37300:20854,37301:25539,37302:23384,37303:23403,37304:23562,37305:25613,37306:26449,37307:36956,37308:20182,37309:22810,37310:22826,37311:27760,37312:35409,37313:21822,37314:22549,37315:22949,37316:24816,37317:25171,37318:26561,37319:33333,37320:26965,37321:38464,37322:39364,37323:39464,37324:20307,37325:22534,37326:23550,37327:32784,37328:23729,37329:24111,37330:24453,37331:24608,37332:24907,37333:25140,37334:26367,37335:27888,37336:28382,37337:32974,37338:33151,37339:33492,37340:34955,37341:36024,37342:36864,37343:36910,37344:38538,37345:40667,37346:39899,37347:20195,37348:21488,37349:22823,37350:31532,37351:37261,37352:38988,37353:40441,37354:28381,37355:28711,37356:21331,37357:21828,37358:23429,37359:25176,37360:25246,37361:25299,37362:27810,37363:28655,37364:29730,37365:35351,37366:37944,37367:28609,37368:35582,37369:33592,37370:20967,37371:34552,37372:21482,37440:21481,37441:20294,37442:36948,37443:36784,37444:22890,37445:33073,37446:24061,37447:31466,37448:36799,37449:26842,37450:35895,37451:29432,37452:40008,37453:27197,37454:35504,37455:20025,37456:21336,37457:22022,37458:22374,37459:25285,37460:25506,37461:26086,37462:27470,37463:28129,37464:28251,37465:28845,37466:30701,37467:31471,37468:31658,37469:32187,37470:32829,37471:32966,37472:34507,37473:35477,37474:37723,37475:22243,37476:22727,37477:24382,37478:26029,37479:26262,37480:27264,37481:27573,37482:30007,37483:35527,37484:20516,37485:30693,37486:22320,37487:24347,37488:24677,37489:26234,37490:27744,37491:30196,37492:31258,37493:32622,37494:33268,37495:34584,37496:36933,37497:39347,37498:31689,37499:30044,37500:31481,37501:31569,37502:33988,37504:36880,37505:31209,37506:31378,37507:33590,37508:23265,37509:30528,37510:20013,37511:20210,37512:23449,37513:24544,37514:25277,37515:26172,37516:26609,37517:27880,37518:34411,37519:34935,37520:35387,37521:37198,37522:37619,37523:39376,37524:27159,37525:28710,37526:29482,37527:33511,37528:33879,37529:36015,37530:19969,37531:20806,37532:20939,37533:21899,37534:23541,37535:24086,37536:24115,37537:24193,37538:24340,37539:24373,37540:24427,37541:24500,37542:25074,37543:25361,37544:26274,37545:26397,37546:28526,37547:29266,37548:30010,37549:30522,37550:32884,37551:33081,37552:33144,37553:34678,37554:35519,37555:35548,37556:36229,37557:36339,37558:37530,37559:38263,37560:38914,37561:40165,37562:21189,37563:25431,37564:30452,37565:26389,37566:27784,37567:29645,37568:36035,37569:37806,37570:38515,37571:27941,37572:22684,37573:26894,37574:27084,37575:36861,37576:37786,37577:30171,37578:36890,37579:22618,37580:26626,37581:25524,37582:27131,37583:20291,37584:28460,37585:26584,37586:36795,37587:34086,37588:32180,37589:37716,37590:26943,37591:28528,37592:22378,37593:22775,37594:23340,37595:32044,37596:29226,37597:21514,37598:37347,37599:40372,37600:20141,37601:20302,37602:20572,37603:20597,37604:21059,37605:35998,37606:21576,37607:22564,37608:23450,37609:24093,37610:24213,37611:24237,37612:24311,37613:24351,37614:24716,37615:25269,37616:25402,37617:25552,37618:26799,37619:27712,37620:30855,37621:31118,37622:31243,37623:32224,37624:33351,37625:35330,37626:35558,37627:36420,37628:36883,37696:37048,37697:37165,37698:37336,37699:40718,37700:27877,37701:25688,37702:25826,37703:25973,37704:28404,37705:30340,37706:31515,37707:36969,37708:37841,37709:28346,37710:21746,37711:24505,37712:25764,37713:36685,37714:36845,37715:37444,37716:20856,37717:22635,37718:22825,37719:23637,37720:24215,37721:28155,37722:32399,37723:29980,37724:36028,37725:36578,37726:39003,37727:28857,37728:20253,37729:27583,37730:28593,37731:3e4,37732:38651,37733:20814,37734:21520,37735:22581,37736:22615,37737:22956,37738:23648,37739:24466,37740:26007,37741:26460,37742:28193,37743:30331,37744:33759,37745:36077,37746:36884,37747:37117,37748:37709,37749:30757,37750:30778,37751:21162,37752:24230,37753:22303,37754:22900,37755:24594,37756:20498,37757:20826,37758:20908,37760:20941,37761:20992,37762:21776,37763:22612,37764:22616,37765:22871,37766:23445,37767:23798,37768:23947,37769:24764,37770:25237,37771:25645,37772:26481,37773:26691,37774:26812,37775:26847,37776:30423,37777:28120,37778:28271,37779:28059,37780:28783,37781:29128,37782:24403,37783:30168,37784:31095,37785:31561,37786:31572,37787:31570,37788:31958,37789:32113,37790:21040,37791:33891,37792:34153,37793:34276,37794:35342,37795:35588,37796:35910,37797:36367,37798:36867,37799:36879,37800:37913,37801:38518,37802:38957,37803:39472,37804:38360,37805:20685,37806:21205,37807:21516,37808:22530,37809:23566,37810:24999,37811:25758,37812:27934,37813:30643,37814:31461,37815:33012,37816:33796,37817:36947,37818:37509,37819:23776,37820:40199,37821:21311,37822:24471,37823:24499,37824:28060,37825:29305,37826:30563,37827:31167,37828:31716,37829:27602,37830:29420,37831:35501,37832:26627,37833:27233,37834:20984,37835:31361,37836:26932,37837:23626,37838:40182,37839:33515,37840:23493,37841:37193,37842:28702,37843:22136,37844:23663,37845:24775,37846:25958,37847:27788,37848:35930,37849:36929,37850:38931,37851:21585,37852:26311,37853:37389,37854:22856,37855:37027,37856:20869,37857:20045,37858:20970,37859:34201,37860:35598,37861:28760,37862:25466,37863:37707,37864:26978,37865:39348,37866:32260,37867:30071,37868:21335,37869:26976,37870:36575,37871:38627,37872:27741,37873:20108,37874:23612,37875:24336,37876:36841,37877:21250,37878:36049,37879:32905,37880:34425,37881:24319,37882:26085,37883:20083,37884:20837,37952:22914,37953:23615,37954:38894,37955:20219,37956:22922,37957:24525,37958:35469,37959:28641,37960:31152,37961:31074,37962:23527,37963:33905,37964:29483,37965:29105,37966:24180,37967:24565,37968:25467,37969:25754,37970:29123,37971:31896,37972:20035,37973:24316,37974:20043,37975:22492,37976:22178,37977:24745,37978:28611,37979:32013,37980:33021,37981:33075,37982:33215,37983:36786,37984:35223,37985:34468,37986:24052,37987:25226,37988:25773,37989:35207,37990:26487,37991:27874,37992:27966,37993:29750,37994:30772,37995:23110,37996:32629,37997:33453,37998:39340,37999:20467,38e3:24259,38001:25309,38002:25490,38003:25943,38004:26479,38005:30403,38006:29260,38007:32972,38008:32954,38009:36649,38010:37197,38011:20493,38012:22521,38013:23186,38014:26757,38016:26995,38017:29028,38018:29437,38019:36023,38020:22770,38021:36064,38022:38506,38023:36889,38024:34687,38025:31204,38026:30695,38027:33833,38028:20271,38029:21093,38030:21338,38031:25293,38032:26575,38033:27850,38034:30333,38035:31636,38036:31893,38037:33334,38038:34180,38039:36843,38040:26333,38041:28448,38042:29190,38043:32283,38044:33707,38045:39361,38046:40614,38047:20989,38048:31665,38049:30834,38050:31672,38051:32903,38052:31560,38053:27368,38054:24161,38055:32908,38056:30033,38057:30048,38058:20843,38059:37474,38060:28300,38061:30330,38062:37271,38063:39658,38064:20240,38065:32624,38066:25244,38067:31567,38068:38309,38069:40169,38070:22138,38071:22617,38072:34532,38073:38588,38074:20276,38075:21028,38076:21322,38077:21453,38078:21467,38079:24070,38080:25644,38081:26001,38082:26495,38083:27710,38084:27726,38085:29256,38086:29359,38087:29677,38088:30036,38089:32321,38090:33324,38091:34281,38092:36009,38093:31684,38094:37318,38095:29033,38096:38930,38097:39151,38098:25405,38099:26217,38100:30058,38101:30436,38102:30928,38103:34115,38104:34542,38105:21290,38106:21329,38107:21542,38108:22915,38109:24199,38110:24444,38111:24754,38112:25161,38113:25209,38114:25259,38115:26e3,38116:27604,38117:27852,38118:30130,38119:30382,38120:30865,38121:31192,38122:32203,38123:32631,38124:32933,38125:34987,38126:35513,38127:36027,38128:36991,38129:38750,38130:39131,38131:27147,38132:31800,38133:20633,38134:23614,38135:24494,38136:26503,38137:27608,38138:29749,38139:30473,38140:32654,38208:40763,38209:26570,38210:31255,38211:21305,38212:30091,38213:39661,38214:24422,38215:33181,38216:33777,38217:32920,38218:24380,38219:24517,38220:30050,38221:31558,38222:36924,38223:26727,38224:23019,38225:23195,38226:32016,38227:30334,38228:35628,38229:20469,38230:24426,38231:27161,38232:27703,38233:28418,38234:29922,38235:31080,38236:34920,38237:35413,38238:35961,38239:24287,38240:25551,38241:30149,38242:31186,38243:33495,38244:37672,38245:37618,38246:33948,38247:34541,38248:39981,38249:21697,38250:24428,38251:25996,38252:27996,38253:28693,38254:36007,38255:36051,38256:38971,38257:25935,38258:29942,38259:19981,38260:20184,38261:22496,38262:22827,38263:23142,38264:23500,38265:20904,38266:24067,38267:24220,38268:24598,38269:25206,38270:25975,38272:26023,38273:26222,38274:28014,38275:29238,38276:31526,38277:33104,38278:33178,38279:33433,38280:35676,38281:36e3,38282:36070,38283:36212,38284:38428,38285:38468,38286:20398,38287:25771,38288:27494,38289:33310,38290:33889,38291:34154,38292:37096,38293:23553,38294:26963,38295:39080,38296:33914,38297:34135,38298:20239,38299:21103,38300:24489,38301:24133,38302:26381,38303:31119,38304:33145,38305:35079,38306:35206,38307:28149,38308:24343,38309:25173,38310:27832,38311:20175,38312:29289,38313:39826,38314:20998,38315:21563,38316:22132,38317:22707,38318:24996,38319:25198,38320:28954,38321:22894,38322:31881,38323:31966,38324:32027,38325:38640,38326:25991,38327:32862,38328:19993,38329:20341,38330:20853,38331:22592,38332:24163,38333:24179,38334:24330,38335:26564,38336:20006,38337:34109,38338:38281,38339:38491,38340:31859,38341:38913,38342:20731,38343:22721,38344:30294,38345:30887,38346:21029,38347:30629,38348:34065,38349:31622,38350:20559,38351:22793,38352:29255,38353:31687,38354:32232,38355:36794,38356:36820,38357:36941,38358:20415,38359:21193,38360:23081,38361:24321,38362:38829,38363:20445,38364:33303,38365:37610,38366:22275,38367:25429,38368:27497,38369:29995,38370:35036,38371:36628,38372:31298,38373:21215,38374:22675,38375:24917,38376:25098,38377:26286,38378:27597,38379:31807,38380:33769,38381:20515,38382:20472,38383:21253,38384:21574,38385:22577,38386:22857,38387:23453,38388:23792,38389:23791,38390:23849,38391:24214,38392:25265,38393:25447,38394:25918,38395:26041,38396:26379,38464:27861,38465:27873,38466:28921,38467:30770,38468:32299,38469:32990,38470:33459,38471:33804,38472:34028,38473:34562,38474:35090,38475:35370,38476:35914,38477:37030,38478:37586,38479:39165,38480:40179,38481:40300,38482:20047,38483:20129,38484:20621,38485:21078,38486:22346,38487:22952,38488:24125,38489:24536,38490:24537,38491:25151,38492:26292,38493:26395,38494:26576,38495:26834,38496:20882,38497:32033,38498:32938,38499:33192,38500:35584,38501:35980,38502:36031,38503:37502,38504:38450,38505:21536,38506:38956,38507:21271,38508:20693,38509:21340,38510:22696,38511:25778,38512:26420,38513:29287,38514:30566,38515:31302,38516:37350,38517:21187,38518:27809,38519:27526,38520:22528,38521:24140,38522:22868,38523:26412,38524:32763,38525:20961,38526:30406,38528:25705,38529:30952,38530:39764,38531:40635,38532:22475,38533:22969,38534:26151,38535:26522,38536:27598,38537:21737,38538:27097,38539:24149,38540:33180,38541:26517,38542:39850,38543:26622,38544:40018,38545:26717,38546:20134,38547:20451,38548:21448,38549:25273,38550:26411,38551:27819,38552:36804,38553:20397,38554:32365,38555:40639,38556:19975,38557:24930,38558:28288,38559:28459,38560:34067,38561:21619,38562:26410,38563:39749,38564:24051,38565:31637,38566:23724,38567:23494,38568:34588,38569:28234,38570:34001,38571:31252,38572:33032,38573:22937,38574:31885,38575:27665,38576:30496,38577:21209,38578:22818,38579:28961,38580:29279,38581:30683,38582:38695,38583:40289,38584:26891,38585:23167,38586:23064,38587:20901,38588:21517,38589:21629,38590:26126,38591:30431,38592:36855,38593:37528,38594:40180,38595:23018,38596:29277,38597:28357,38598:20813,38599:26825,38600:32191,38601:32236,38602:38754,38603:40634,38604:25720,38605:27169,38606:33538,38607:22916,38608:23391,38609:27611,38610:29467,38611:30450,38612:32178,38613:32791,38614:33945,38615:20786,38616:26408,38617:40665,38618:30446,38619:26466,38620:21247,38621:39173,38622:23588,38623:25147,38624:31870,38625:36016,38626:21839,38627:24758,38628:32011,38629:38272,38630:21249,38631:20063,38632:20918,38633:22812,38634:29242,38635:32822,38636:37326,38637:24357,38638:30690,38639:21380,38640:24441,38641:32004,38642:34220,38643:35379,38644:36493,38645:38742,38646:26611,38647:34222,38648:37971,38649:24841,38650:24840,38651:27833,38652:30290,38720:35565,38721:36664,38722:21807,38723:20305,38724:20778,38725:21191,38726:21451,38727:23461,38728:24189,38729:24736,38730:24962,38731:25558,38732:26377,38733:26586,38734:28263,38735:28044,38736:29494,38737:29495,38738:30001,38739:31056,38740:35029,38741:35480,38742:36938,38743:37009,38744:37109,38745:38596,38746:34701,38747:22805,38748:20104,38749:20313,38750:19982,38751:35465,38752:36671,38753:38928,38754:20653,38755:24188,38756:22934,38757:23481,38758:24248,38759:25562,38760:25594,38761:25793,38762:26332,38763:26954,38764:27096,38765:27915,38766:28342,38767:29076,38768:29992,38769:31407,38770:32650,38771:32768,38772:33865,38773:33993,38774:35201,38775:35617,38776:36362,38777:36965,38778:38525,38779:39178,38780:24958,38781:25233,38782:27442,38784:27779,38785:28020,38786:32716,38787:32764,38788:28096,38789:32645,38790:34746,38791:35064,38792:26469,38793:33713,38794:38972,38795:38647,38796:27931,38797:32097,38798:33853,38799:37226,38800:20081,38801:21365,38802:23888,38803:27396,38804:28651,38805:34253,38806:34349,38807:35239,38808:21033,38809:21519,38810:23653,38811:26446,38812:26792,38813:29702,38814:29827,38815:30178,38816:35023,38817:35041,38818:37324,38819:38626,38820:38520,38821:24459,38822:29575,38823:31435,38824:33870,38825:25504,38826:30053,38827:21129,38828:27969,38829:28316,38830:29705,38831:30041,38832:30827,38833:31890,38834:38534,38835:31452,38836:40845,38837:20406,38838:24942,38839:26053,38840:34396,38841:20102,38842:20142,38843:20698,38844:20001,38845:20940,38846:23534,38847:26009,38848:26753,38849:28092,38850:29471,38851:30274,38852:30637,38853:31260,38854:31975,38855:33391,38856:35538,38857:36988,38858:37327,38859:38517,38860:38936,38861:21147,38862:32209,38863:20523,38864:21400,38865:26519,38866:28107,38867:29136,38868:29747,38869:33256,38870:36650,38871:38563,38872:40023,38873:40607,38874:29792,38875:22593,38876:28057,38877:32047,38878:39006,38879:20196,38880:20278,38881:20363,38882:20919,38883:21169,38884:23994,38885:24604,38886:29618,38887:31036,38888:33491,38889:37428,38890:38583,38891:38646,38892:38666,38893:40599,38894:40802,38895:26278,38896:27508,38897:21015,38898:21155,38899:28872,38900:35010,38901:24265,38902:24651,38903:24976,38904:28451,38905:29001,38906:31806,38907:32244,38908:32879,38976:34030,38977:36899,38978:37676,38979:21570,38980:39791,38981:27347,38982:28809,38983:36034,38984:36335,38985:38706,38986:21172,38987:23105,38988:24266,38989:24324,38990:26391,38991:27004,38992:27028,38993:28010,38994:28431,38995:29282,38996:29436,38997:31725,38998:32769,38999:32894,39e3:34635,39001:37070,39002:20845,39003:40595,39004:31108,39005:32907,39006:37682,39007:35542,39008:20525,39009:21644,39010:35441,39011:27498,39012:36036,39013:33031,39014:24785,39015:26528,39016:40434,39017:20121,39018:20120,39019:39952,39020:35435,39021:34241,39022:34152,39023:26880,39024:28286,39025:30871,39026:33109,39071:24332,39072:19984,39073:19989,39074:20010,39075:20017,39076:20022,39077:20028,39078:20031,39079:20034,39080:20054,39081:20056,39082:20098,39083:20101,39084:35947,39085:20106,39086:33298,39087:24333,39088:20110,39089:20126,39090:20127,39091:20128,39092:20130,39093:20144,39094:20147,39095:20150,39096:20174,39097:20173,39098:20164,39099:20166,39100:20162,39101:20183,39102:20190,39103:20205,39104:20191,39105:20215,39106:20233,39107:20314,39108:20272,39109:20315,39110:20317,39111:20311,39112:20295,39113:20342,39114:20360,39115:20367,39116:20376,39117:20347,39118:20329,39119:20336,39120:20369,39121:20335,39122:20358,39123:20374,39124:20760,39125:20436,39126:20447,39127:20430,39128:20440,39129:20443,39130:20433,39131:20442,39132:20432,39133:20452,39134:20453,39135:20506,39136:20520,39137:20500,39138:20522,39139:20517,39140:20485,39141:20252,39142:20470,39143:20513,39144:20521,39145:20524,39146:20478,39147:20463,39148:20497,39149:20486,39150:20547,39151:20551,39152:26371,39153:20565,39154:20560,39155:20552,39156:20570,39157:20566,39158:20588,39159:20600,39160:20608,39161:20634,39162:20613,39163:20660,39164:20658,39232:20681,39233:20682,39234:20659,39235:20674,39236:20694,39237:20702,39238:20709,39239:20717,39240:20707,39241:20718,39242:20729,39243:20725,39244:20745,39245:20737,39246:20738,39247:20758,39248:20757,39249:20756,39250:20762,39251:20769,39252:20794,39253:20791,39254:20796,39255:20795,39256:20799,39257:20800,39258:20818,39259:20812,39260:20820,39261:20834,39262:31480,39263:20841,39264:20842,39265:20846,39266:20864,39267:20866,39268:22232,39269:20876,39270:20873,39271:20879,39272:20881,39273:20883,39274:20885,39275:20886,39276:20900,39277:20902,39278:20898,39279:20905,39280:20906,39281:20907,39282:20915,39283:20913,39284:20914,39285:20912,39286:20917,39287:20925,39288:20933,39289:20937,39290:20955,39291:20960,39292:34389,39293:20969,39294:20973,39296:20976,39297:20981,39298:20990,39299:20996,39300:21003,39301:21012,39302:21006,39303:21031,39304:21034,39305:21038,39306:21043,39307:21049,39308:21071,39309:21060,39310:21067,39311:21068,39312:21086,39313:21076,39314:21098,39315:21108,39316:21097,39317:21107,39318:21119,39319:21117,39320:21133,39321:21140,39322:21138,39323:21105,39324:21128,39325:21137,39326:36776,39327:36775,39328:21164,39329:21165,39330:21180,39331:21173,39332:21185,39333:21197,39334:21207,39335:21214,39336:21219,39337:21222,39338:39149,39339:21216,39340:21235,39341:21237,39342:21240,39343:21241,39344:21254,39345:21256,39346:30008,39347:21261,39348:21264,39349:21263,39350:21269,39351:21274,39352:21283,39353:21295,39354:21297,39355:21299,39356:21304,39357:21312,39358:21318,39359:21317,39360:19991,39361:21321,39362:21325,39363:20950,39364:21342,39365:21353,39366:21358,39367:22808,39368:21371,39369:21367,39370:21378,39371:21398,39372:21408,39373:21414,39374:21413,39375:21422,39376:21424,39377:21430,39378:21443,39379:31762,39380:38617,39381:21471,39382:26364,39383:29166,39384:21486,39385:21480,39386:21485,39387:21498,39388:21505,39389:21565,39390:21568,39391:21548,39392:21549,39393:21564,39394:21550,39395:21558,39396:21545,39397:21533,39398:21582,39399:21647,39400:21621,39401:21646,39402:21599,39403:21617,39404:21623,39405:21616,39406:21650,39407:21627,39408:21632,39409:21622,39410:21636,39411:21648,39412:21638,39413:21703,39414:21666,39415:21688,39416:21669,39417:21676,39418:21700,39419:21704,39420:21672,39488:21675,39489:21698,39490:21668,39491:21694,39492:21692,39493:21720,39494:21733,39495:21734,39496:21775,39497:21780,39498:21757,39499:21742,39500:21741,39501:21754,39502:21730,39503:21817,39504:21824,39505:21859,39506:21836,39507:21806,39508:21852,39509:21829,39510:21846,39511:21847,39512:21816,39513:21811,39514:21853,39515:21913,39516:21888,39517:21679,39518:21898,39519:21919,39520:21883,39521:21886,39522:21912,39523:21918,39524:21934,39525:21884,39526:21891,39527:21929,39528:21895,39529:21928,39530:21978,39531:21957,39532:21983,39533:21956,39534:21980,39535:21988,39536:21972,39537:22036,39538:22007,39539:22038,39540:22014,39541:22013,39542:22043,39543:22009,39544:22094,39545:22096,39546:29151,39547:22068,39548:22070,39549:22066,39550:22072,39552:22123,39553:22116,39554:22063,39555:22124,39556:22122,39557:22150,39558:22144,39559:22154,39560:22176,39561:22164,39562:22159,39563:22181,39564:22190,39565:22198,39566:22196,39567:22210,39568:22204,39569:22209,39570:22211,39571:22208,39572:22216,39573:22222,39574:22225,39575:22227,39576:22231,39577:22254,39578:22265,39579:22272,39580:22271,39581:22276,39582:22281,39583:22280,39584:22283,39585:22285,39586:22291,39587:22296,39588:22294,39589:21959,39590:22300,39591:22310,39592:22327,39593:22328,39594:22350,39595:22331,39596:22336,39597:22351,39598:22377,39599:22464,39600:22408,39601:22369,39602:22399,39603:22409,39604:22419,39605:22432,39606:22451,39607:22436,39608:22442,39609:22448,39610:22467,39611:22470,39612:22484,39613:22482,39614:22483,39615:22538,39616:22486,39617:22499,39618:22539,39619:22553,39620:22557,39621:22642,39622:22561,39623:22626,39624:22603,39625:22640,39626:27584,39627:22610,39628:22589,39629:22649,39630:22661,39631:22713,39632:22687,39633:22699,39634:22714,39635:22750,39636:22715,39637:22712,39638:22702,39639:22725,39640:22739,39641:22737,39642:22743,39643:22745,39644:22744,39645:22757,39646:22748,39647:22756,39648:22751,39649:22767,39650:22778,39651:22777,39652:22779,39653:22780,39654:22781,39655:22786,39656:22794,39657:22800,39658:22811,39659:26790,39660:22821,39661:22828,39662:22829,39663:22834,39664:22840,39665:22846,39666:31442,39667:22869,39668:22864,39669:22862,39670:22874,39671:22872,39672:22882,39673:22880,39674:22887,39675:22892,39676:22889,39744:22904,39745:22913,39746:22941,39747:20318,39748:20395,39749:22947,39750:22962,39751:22982,39752:23016,39753:23004,39754:22925,39755:23001,39756:23002,39757:23077,39758:23071,39759:23057,39760:23068,39761:23049,39762:23066,39763:23104,39764:23148,39765:23113,39766:23093,39767:23094,39768:23138,39769:23146,39770:23194,39771:23228,39772:23230,39773:23243,39774:23234,39775:23229,39776:23267,39777:23255,39778:23270,39779:23273,39780:23254,39781:23290,39782:23291,39783:23308,39784:23307,39785:23318,39786:23346,39787:23248,39788:23338,39789:23350,39790:23358,39791:23363,39792:23365,39793:23360,39794:23377,39795:23381,39796:23386,39797:23387,39798:23397,39799:23401,39800:23408,39801:23411,39802:23413,39803:23416,39804:25992,39805:23418,39806:23424,39808:23427,39809:23462,39810:23480,39811:23491,39812:23495,39813:23497,39814:23508,39815:23504,39816:23524,39817:23526,39818:23522,39819:23518,39820:23525,39821:23531,39822:23536,39823:23542,39824:23539,39825:23557,39826:23559,39827:23560,39828:23565,39829:23571,39830:23584,39831:23586,39832:23592,39833:23608,39834:23609,39835:23617,39836:23622,39837:23630,39838:23635,39839:23632,39840:23631,39841:23409,39842:23660,39843:23662,39844:20066,39845:23670,39846:23673,39847:23692,39848:23697,39849:23700,39850:22939,39851:23723,39852:23739,39853:23734,39854:23740,39855:23735,39856:23749,39857:23742,39858:23751,39859:23769,39860:23785,39861:23805,39862:23802,39863:23789,39864:23948,39865:23786,39866:23819,39867:23829,39868:23831,39869:23900,39870:23839,39871:23835,39872:23825,39873:23828,39874:23842,39875:23834,39876:23833,39877:23832,39878:23884,39879:23890,39880:23886,39881:23883,39882:23916,39883:23923,39884:23926,39885:23943,39886:23940,39887:23938,39888:23970,39889:23965,39890:23980,39891:23982,39892:23997,39893:23952,39894:23991,39895:23996,39896:24009,39897:24013,39898:24019,39899:24018,39900:24022,39901:24027,39902:24043,39903:24050,39904:24053,39905:24075,39906:24090,39907:24089,39908:24081,39909:24091,39910:24118,39911:24119,39912:24132,39913:24131,39914:24128,39915:24142,39916:24151,39917:24148,39918:24159,39919:24162,39920:24164,39921:24135,39922:24181,39923:24182,39924:24186,39925:40636,39926:24191,39927:24224,39928:24257,39929:24258,39930:24264,39931:24272,39932:24271,4e4:24278,40001:24291,40002:24285,40003:24282,40004:24283,40005:24290,40006:24289,40007:24296,40008:24297,40009:24300,40010:24305,40011:24307,40012:24304,40013:24308,40014:24312,40015:24318,40016:24323,40017:24329,40018:24413,40019:24412,40020:24331,40021:24337,40022:24342,40023:24361,40024:24365,40025:24376,40026:24385,40027:24392,40028:24396,40029:24398,40030:24367,40031:24401,40032:24406,40033:24407,40034:24409,40035:24417,40036:24429,40037:24435,40038:24439,40039:24451,40040:24450,40041:24447,40042:24458,40043:24456,40044:24465,40045:24455,40046:24478,40047:24473,40048:24472,40049:24480,40050:24488,40051:24493,40052:24508,40053:24534,40054:24571,40055:24548,40056:24568,40057:24561,40058:24541,40059:24755,40060:24575,40061:24609,40062:24672,40064:24601,40065:24592,40066:24617,40067:24590,40068:24625,40069:24603,40070:24597,40071:24619,40072:24614,40073:24591,40074:24634,40075:24666,40076:24641,40077:24682,40078:24695,40079:24671,40080:24650,40081:24646,40082:24653,40083:24675,40084:24643,40085:24676,40086:24642,40087:24684,40088:24683,40089:24665,40090:24705,40091:24717,40092:24807,40093:24707,40094:24730,40095:24708,40096:24731,40097:24726,40098:24727,40099:24722,40100:24743,40101:24715,40102:24801,40103:24760,40104:24800,40105:24787,40106:24756,40107:24560,40108:24765,40109:24774,40110:24757,40111:24792,40112:24909,40113:24853,40114:24838,40115:24822,40116:24823,40117:24832,40118:24820,40119:24826,40120:24835,40121:24865,40122:24827,40123:24817,40124:24845,40125:24846,40126:24903,40127:24894,40128:24872,40129:24871,40130:24906,40131:24895,40132:24892,40133:24876,40134:24884,40135:24893,40136:24898,40137:24900,40138:24947,40139:24951,40140:24920,40141:24921,40142:24922,40143:24939,40144:24948,40145:24943,40146:24933,40147:24945,40148:24927,40149:24925,40150:24915,40151:24949,40152:24985,40153:24982,40154:24967,40155:25004,40156:24980,40157:24986,40158:24970,40159:24977,40160:25003,40161:25006,40162:25036,40163:25034,40164:25033,40165:25079,40166:25032,40167:25027,40168:25030,40169:25018,40170:25035,40171:32633,40172:25037,40173:25062,40174:25059,40175:25078,40176:25082,40177:25076,40178:25087,40179:25085,40180:25084,40181:25086,40182:25088,40183:25096,40184:25097,40185:25101,40186:25100,40187:25108,40188:25115,40256:25118,40257:25121,40258:25130,40259:25134,40260:25136,40261:25138,40262:25139,40263:25153,40264:25166,40265:25182,40266:25187,40267:25179,40268:25184,40269:25192,40270:25212,40271:25218,40272:25225,40273:25214,40274:25234,40275:25235,40276:25238,40277:25300,40278:25219,40279:25236,40280:25303,40281:25297,40282:25275,40283:25295,40284:25343,40285:25286,40286:25812,40287:25288,40288:25308,40289:25292,40290:25290,40291:25282,40292:25287,40293:25243,40294:25289,40295:25356,40296:25326,40297:25329,40298:25383,40299:25346,40300:25352,40301:25327,40302:25333,40303:25424,40304:25406,40305:25421,40306:25628,40307:25423,40308:25494,40309:25486,40310:25472,40311:25515,40312:25462,40313:25507,40314:25487,40315:25481,40316:25503,40317:25525,40318:25451,40320:25449,40321:25534,40322:25577,40323:25536,40324:25542,40325:25571,40326:25545,40327:25554,40328:25590,40329:25540,40330:25622,40331:25652,40332:25606,40333:25619,40334:25638,40335:25654,40336:25885,40337:25623,40338:25640,40339:25615,40340:25703,40341:25711,40342:25718,40343:25678,40344:25898,40345:25749,40346:25747,40347:25765,40348:25769,40349:25736,40350:25788,40351:25818,40352:25810,40353:25797,40354:25799,40355:25787,40356:25816,40357:25794,40358:25841,40359:25831,40360:33289,40361:25824,40362:25825,40363:25260,40364:25827,40365:25839,40366:25900,40367:25846,40368:25844,40369:25842,40370:25850,40371:25856,40372:25853,40373:25880,40374:25884,40375:25861,40376:25892,40377:25891,40378:25899,40379:25908,40380:25909,40381:25911,40382:25910,40383:25912,40384:30027,40385:25928,40386:25942,40387:25941,40388:25933,40389:25944,40390:25950,40391:25949,40392:25970,40393:25976,40394:25986,40395:25987,40396:35722,40397:26011,40398:26015,40399:26027,40400:26039,40401:26051,40402:26054,40403:26049,40404:26052,40405:26060,40406:26066,40407:26075,40408:26073,40409:26080,40410:26081,40411:26097,40412:26482,40413:26122,40414:26115,40415:26107,40416:26483,40417:26165,40418:26166,40419:26164,40420:26140,40421:26191,40422:26180,40423:26185,40424:26177,40425:26206,40426:26205,40427:26212,40428:26215,40429:26216,40430:26207,40431:26210,40432:26224,40433:26243,40434:26248,40435:26254,40436:26249,40437:26244,40438:26264,40439:26269,40440:26305,40441:26297,40442:26313,40443:26302,40444:26300,40512:26308,40513:26296,40514:26326,40515:26330,40516:26336,40517:26175,40518:26342,40519:26345,40520:26352,40521:26357,40522:26359,40523:26383,40524:26390,40525:26398,40526:26406,40527:26407,40528:38712,40529:26414,40530:26431,40531:26422,40532:26433,40533:26424,40534:26423,40535:26438,40536:26462,40537:26464,40538:26457,40539:26467,40540:26468,40541:26505,40542:26480,40543:26537,40544:26492,40545:26474,40546:26508,40547:26507,40548:26534,40549:26529,40550:26501,40551:26551,40552:26607,40553:26548,40554:26604,40555:26547,40556:26601,40557:26552,40558:26596,40559:26590,40560:26589,40561:26594,40562:26606,40563:26553,40564:26574,40565:26566,40566:26599,40567:27292,40568:26654,40569:26694,40570:26665,40571:26688,40572:26701,40573:26674,40574:26702,40576:26803,40577:26667,40578:26713,40579:26723,40580:26743,40581:26751,40582:26783,40583:26767,40584:26797,40585:26772,40586:26781,40587:26779,40588:26755,40589:27310,40590:26809,40591:26740,40592:26805,40593:26784,40594:26810,40595:26895,40596:26765,40597:26750,40598:26881,40599:26826,40600:26888,40601:26840,40602:26914,40603:26918,40604:26849,40605:26892,40606:26829,40607:26836,40608:26855,40609:26837,40610:26934,40611:26898,40612:26884,40613:26839,40614:26851,40615:26917,40616:26873,40617:26848,40618:26863,40619:26920,40620:26922,40621:26906,40622:26915,40623:26913,40624:26822,40625:27001,40626:26999,40627:26972,40628:27e3,40629:26987,40630:26964,40631:27006,40632:26990,40633:26937,40634:26996,40635:26941,40636:26969,40637:26928,40638:26977,40639:26974,40640:26973,40641:27009,40642:26986,40643:27058,40644:27054,40645:27088,40646:27071,40647:27073,40648:27091,40649:27070,40650:27086,40651:23528,40652:27082,40653:27101,40654:27067,40655:27075,40656:27047,40657:27182,40658:27025,40659:27040,40660:27036,40661:27029,40662:27060,40663:27102,40664:27112,40665:27138,40666:27163,40667:27135,40668:27402,40669:27129,40670:27122,40671:27111,40672:27141,40673:27057,40674:27166,40675:27117,40676:27156,40677:27115,40678:27146,40679:27154,40680:27329,40681:27171,40682:27155,40683:27204,40684:27148,40685:27250,40686:27190,40687:27256,40688:27207,40689:27234,40690:27225,40691:27238,40692:27208,40693:27192,40694:27170,40695:27280,40696:27277,40697:27296,40698:27268,40699:27298,40700:27299,40768:27287,40769:34327,40770:27323,40771:27331,40772:27330,40773:27320,40774:27315,40775:27308,40776:27358,40777:27345,40778:27359,40779:27306,40780:27354,40781:27370,40782:27387,40783:27397,40784:34326,40785:27386,40786:27410,40787:27414,40788:39729,40789:27423,40790:27448,40791:27447,40792:30428,40793:27449,40794:39150,40795:27463,40796:27459,40797:27465,40798:27472,40799:27481,40800:27476,40801:27483,40802:27487,40803:27489,40804:27512,40805:27513,40806:27519,40807:27520,40808:27524,40809:27523,40810:27533,40811:27544,40812:27541,40813:27550,40814:27556,40815:27562,40816:27563,40817:27567,40818:27570,40819:27569,40820:27571,40821:27575,40822:27580,40823:27590,40824:27595,40825:27603,40826:27615,40827:27628,40828:27627,40829:27635,40830:27631,40832:40638,40833:27656,40834:27667,40835:27668,40836:27675,40837:27684,40838:27683,40839:27742,40840:27733,40841:27746,40842:27754,40843:27778,40844:27789,40845:27802,40846:27777,40847:27803,40848:27774,40849:27752,40850:27763,40851:27794,40852:27792,40853:27844,40854:27889,40855:27859,40856:27837,40857:27863,40858:27845,40859:27869,40860:27822,40861:27825,40862:27838,40863:27834,40864:27867,40865:27887,40866:27865,40867:27882,40868:27935,40869:34893,40870:27958,40871:27947,40872:27965,40873:27960,40874:27929,40875:27957,40876:27955,40877:27922,40878:27916,40879:28003,40880:28051,40881:28004,40882:27994,40883:28025,40884:27993,40885:28046,40886:28053,40887:28644,40888:28037,40889:28153,40890:28181,40891:28170,40892:28085,40893:28103,40894:28134,40895:28088,40896:28102,40897:28140,40898:28126,40899:28108,40900:28136,40901:28114,40902:28101,40903:28154,40904:28121,40905:28132,40906:28117,40907:28138,40908:28142,40909:28205,40910:28270,40911:28206,40912:28185,40913:28274,40914:28255,40915:28222,40916:28195,40917:28267,40918:28203,40919:28278,40920:28237,40921:28191,40922:28227,40923:28218,40924:28238,40925:28196,40926:28415,40927:28189,40928:28216,40929:28290,40930:28330,40931:28312,40932:28361,40933:28343,40934:28371,40935:28349,40936:28335,40937:28356,40938:28338,40939:28372,40940:28373,40941:28303,40942:28325,40943:28354,40944:28319,40945:28481,40946:28433,40947:28748,40948:28396,40949:28408,40950:28414,40951:28479,40952:28402,40953:28465,40954:28399,40955:28466,40956:28364,161:65377,162:65378,163:65379,164:65380,165:65381,166:65382,167:65383,168:65384,169:65385,170:65386,171:65387,172:65388,173:65389,174:65390,175:65391,176:65392,177:65393,178:65394,179:65395,180:65396,181:65397,182:65398,183:65399,184:65400,185:65401,186:65402,187:65403,188:65404,189:65405,190:65406,191:65407,192:65408,193:65409,194:65410,195:65411,196:65412,197:65413,198:65414,199:65415,200:65416,201:65417,202:65418,203:65419,204:65420,205:65421,206:65422,207:65423,208:65424,209:65425,210:65426,211:65427,212:65428,213:65429,214:65430,215:65431,216:65432,217:65433,218:65434,219:65435,220:65436,221:65437,222:65438,223:65439,57408:28478,57409:28435,57410:28407,57411:28550,57412:28538,57413:28536,57414:28545,57415:28544,57416:28527,57417:28507,57418:28659,57419:28525,57420:28546,57421:28540,57422:28504,57423:28558,57424:28561,57425:28610,57426:28518,57427:28595,57428:28579,57429:28577,57430:28580,57431:28601,57432:28614,57433:28586,57434:28639,57435:28629,57436:28652,57437:28628,57438:28632,57439:28657,57440:28654,57441:28635,57442:28681,57443:28683,57444:28666,57445:28689,57446:28673,57447:28687,57448:28670,57449:28699,57450:28698,57451:28532,57452:28701,57453:28696,57454:28703,57455:28720,57456:28734,57457:28722,57458:28753,57459:28771,57460:28825,57461:28818,57462:28847,57463:28913,57464:28844,57465:28856,57466:28851,57467:28846,57468:28895,57469:28875,57470:28893,57472:28889,57473:28937,57474:28925,57475:28956,57476:28953,57477:29029,57478:29013,57479:29064,57480:29030,57481:29026,57482:29004,57483:29014,57484:29036,57485:29071,57486:29179,57487:29060,57488:29077,57489:29096,57490:29100,57491:29143,57492:29113,57493:29118,57494:29138,57495:29129,57496:29140,57497:29134,57498:29152,57499:29164,57500:29159,57501:29173,57502:29180,57503:29177,57504:29183,57505:29197,57506:29200,57507:29211,57508:29224,57509:29229,57510:29228,57511:29232,57512:29234,57513:29243,57514:29244,57515:29247,57516:29248,57517:29254,57518:29259,57519:29272,57520:29300,57521:29310,57522:29314,57523:29313,57524:29319,57525:29330,57526:29334,57527:29346,57528:29351,57529:29369,57530:29362,57531:29379,57532:29382,57533:29380,57534:29390,57535:29394,57536:29410,57537:29408,57538:29409,57539:29433,57540:29431,57541:20495,57542:29463,57543:29450,57544:29468,57545:29462,57546:29469,57547:29492,57548:29487,57549:29481,57550:29477,57551:29502,57552:29518,57553:29519,57554:40664,57555:29527,57556:29546,57557:29544,57558:29552,57559:29560,57560:29557,57561:29563,57562:29562,57563:29640,57564:29619,57565:29646,57566:29627,57567:29632,57568:29669,57569:29678,57570:29662,57571:29858,57572:29701,57573:29807,57574:29733,57575:29688,57576:29746,57577:29754,57578:29781,57579:29759,57580:29791,57581:29785,57582:29761,57583:29788,57584:29801,57585:29808,57586:29795,57587:29802,57588:29814,57589:29822,57590:29835,57591:29854,57592:29863,57593:29898,57594:29903,57595:29908,57596:29681,57664:29920,57665:29923,57666:29927,57667:29929,57668:29934,57669:29938,57670:29936,57671:29937,57672:29944,57673:29943,57674:29956,57675:29955,57676:29957,57677:29964,57678:29966,57679:29965,57680:29973,57681:29971,57682:29982,57683:29990,57684:29996,57685:30012,57686:30020,57687:30029,57688:30026,57689:30025,57690:30043,57691:30022,57692:30042,57693:30057,57694:30052,57695:30055,57696:30059,57697:30061,57698:30072,57699:30070,57700:30086,57701:30087,57702:30068,57703:30090,57704:30089,57705:30082,57706:30100,57707:30106,57708:30109,57709:30117,57710:30115,57711:30146,57712:30131,57713:30147,57714:30133,57715:30141,57716:30136,57717:30140,57718:30129,57719:30157,57720:30154,57721:30162,57722:30169,57723:30179,57724:30174,57725:30206,57726:30207,57728:30204,57729:30209,57730:30192,57731:30202,57732:30194,57733:30195,57734:30219,57735:30221,57736:30217,57737:30239,57738:30247,57739:30240,57740:30241,57741:30242,57742:30244,57743:30260,57744:30256,57745:30267,57746:30279,57747:30280,57748:30278,57749:30300,57750:30296,57751:30305,57752:30306,57753:30312,57754:30313,57755:30314,57756:30311,57757:30316,57758:30320,57759:30322,57760:30326,57761:30328,57762:30332,57763:30336,57764:30339,57765:30344,57766:30347,57767:30350,57768:30358,57769:30355,57770:30361,57771:30362,57772:30384,57773:30388,57774:30392,57775:30393,57776:30394,57777:30402,57778:30413,57779:30422,57780:30418,57781:30430,57782:30433,57783:30437,57784:30439,57785:30442,57786:34351,57787:30459,57788:30472,57789:30471,57790:30468,57791:30505,57792:30500,57793:30494,57794:30501,57795:30502,57796:30491,57797:30519,57798:30520,57799:30535,57800:30554,57801:30568,57802:30571,57803:30555,57804:30565,57805:30591,57806:30590,57807:30585,57808:30606,57809:30603,57810:30609,57811:30624,57812:30622,57813:30640,57814:30646,57815:30649,57816:30655,57817:30652,57818:30653,57819:30651,57820:30663,57821:30669,57822:30679,57823:30682,57824:30684,57825:30691,57826:30702,57827:30716,57828:30732,57829:30738,57830:31014,57831:30752,57832:31018,57833:30789,57834:30862,57835:30836,57836:30854,57837:30844,57838:30874,57839:30860,57840:30883,57841:30901,57842:30890,57843:30895,57844:30929,57845:30918,57846:30923,57847:30932,57848:30910,57849:30908,57850:30917,57851:30922,57852:30956,57920:30951,57921:30938,57922:30973,57923:30964,57924:30983,57925:30994,57926:30993,57927:31001,57928:31020,57929:31019,57930:31040,57931:31072,57932:31063,57933:31071,57934:31066,57935:31061,57936:31059,57937:31098,57938:31103,57939:31114,57940:31133,57941:31143,57942:40779,57943:31146,57944:31150,57945:31155,57946:31161,57947:31162,57948:31177,57949:31189,57950:31207,57951:31212,57952:31201,57953:31203,57954:31240,57955:31245,57956:31256,57957:31257,57958:31264,57959:31263,57960:31104,57961:31281,57962:31291,57963:31294,57964:31287,57965:31299,57966:31319,57967:31305,57968:31329,57969:31330,57970:31337,57971:40861,57972:31344,57973:31353,57974:31357,57975:31368,57976:31383,57977:31381,57978:31384,57979:31382,57980:31401,57981:31432,57982:31408,57984:31414,57985:31429,57986:31428,57987:31423,57988:36995,57989:31431,57990:31434,57991:31437,57992:31439,57993:31445,57994:31443,57995:31449,57996:31450,57997:31453,57998:31457,57999:31458,58e3:31462,58001:31469,58002:31472,58003:31490,58004:31503,58005:31498,58006:31494,58007:31539,58008:31512,58009:31513,58010:31518,58011:31541,58012:31528,58013:31542,58014:31568,58015:31610,58016:31492,58017:31565,58018:31499,58019:31564,58020:31557,58021:31605,58022:31589,58023:31604,58024:31591,58025:31600,58026:31601,58027:31596,58028:31598,58029:31645,58030:31640,58031:31647,58032:31629,58033:31644,58034:31642,58035:31627,58036:31634,58037:31631,58038:31581,58039:31641,58040:31691,58041:31681,58042:31692,58043:31695,58044:31668,58045:31686,58046:31709,58047:31721,58048:31761,58049:31764,58050:31718,58051:31717,58052:31840,58053:31744,58054:31751,58055:31763,58056:31731,58057:31735,58058:31767,58059:31757,58060:31734,58061:31779,58062:31783,58063:31786,58064:31775,58065:31799,58066:31787,58067:31805,58068:31820,58069:31811,58070:31828,58071:31823,58072:31808,58073:31824,58074:31832,58075:31839,58076:31844,58077:31830,58078:31845,58079:31852,58080:31861,58081:31875,58082:31888,58083:31908,58084:31917,58085:31906,58086:31915,58087:31905,58088:31912,58089:31923,58090:31922,58091:31921,58092:31918,58093:31929,58094:31933,58095:31936,58096:31941,58097:31938,58098:31960,58099:31954,58100:31964,58101:31970,58102:39739,58103:31983,58104:31986,58105:31988,58106:31990,58107:31994,58108:32006,58176:32002,58177:32028,58178:32021,58179:32010,58180:32069,58181:32075,58182:32046,58183:32050,58184:32063,58185:32053,58186:32070,58187:32115,58188:32086,58189:32078,58190:32114,58191:32104,58192:32110,58193:32079,58194:32099,58195:32147,58196:32137,58197:32091,58198:32143,58199:32125,58200:32155,58201:32186,58202:32174,58203:32163,58204:32181,58205:32199,58206:32189,58207:32171,58208:32317,58209:32162,58210:32175,58211:32220,58212:32184,58213:32159,58214:32176,58215:32216,58216:32221,58217:32228,58218:32222,58219:32251,58220:32242,58221:32225,58222:32261,58223:32266,58224:32291,58225:32289,58226:32274,58227:32305,58228:32287,58229:32265,58230:32267,58231:32290,58232:32326,58233:32358,58234:32315,58235:32309,58236:32313,58237:32323,58238:32311,58240:32306,58241:32314,58242:32359,58243:32349,58244:32342,58245:32350,58246:32345,58247:32346,58248:32377,58249:32362,58250:32361,58251:32380,58252:32379,58253:32387,58254:32213,58255:32381,58256:36782,58257:32383,58258:32392,58259:32393,58260:32396,58261:32402,58262:32400,58263:32403,58264:32404,58265:32406,58266:32398,58267:32411,58268:32412,58269:32568,58270:32570,58271:32581,58272:32588,58273:32589,58274:32590,58275:32592,58276:32593,58277:32597,58278:32596,58279:32600,58280:32607,58281:32608,58282:32616,58283:32617,58284:32615,58285:32632,58286:32642,58287:32646,58288:32643,58289:32648,58290:32647,58291:32652,58292:32660,58293:32670,58294:32669,58295:32666,58296:32675,58297:32687,58298:32690,58299:32697,58300:32686,58301:32694,58302:32696,58303:35697,58304:32709,58305:32710,58306:32714,58307:32725,58308:32724,58309:32737,58310:32742,58311:32745,58312:32755,58313:32761,58314:39132,58315:32774,58316:32772,58317:32779,58318:32786,58319:32792,58320:32793,58321:32796,58322:32801,58323:32808,58324:32831,58325:32827,58326:32842,58327:32838,58328:32850,58329:32856,58330:32858,58331:32863,58332:32866,58333:32872,58334:32883,58335:32882,58336:32880,58337:32886,58338:32889,58339:32893,58340:32895,58341:32900,58342:32902,58343:32901,58344:32923,58345:32915,58346:32922,58347:32941,58348:20880,58349:32940,58350:32987,58351:32997,58352:32985,58353:32989,58354:32964,58355:32986,58356:32982,58357:33033,58358:33007,58359:33009,58360:33051,58361:33065,58362:33059,58363:33071,58364:33099,58432:38539,58433:33094,58434:33086,58435:33107,58436:33105,58437:33020,58438:33137,58439:33134,58440:33125,58441:33126,58442:33140,58443:33155,58444:33160,58445:33162,58446:33152,58447:33154,58448:33184,58449:33173,58450:33188,58451:33187,58452:33119,58453:33171,58454:33193,58455:33200,58456:33205,58457:33214,58458:33208,58459:33213,58460:33216,58461:33218,58462:33210,58463:33225,58464:33229,58465:33233,58466:33241,58467:33240,58468:33224,58469:33242,58470:33247,58471:33248,58472:33255,58473:33274,58474:33275,58475:33278,58476:33281,58477:33282,58478:33285,58479:33287,58480:33290,58481:33293,58482:33296,58483:33302,58484:33321,58485:33323,58486:33336,58487:33331,58488:33344,58489:33369,58490:33368,58491:33373,58492:33370,58493:33375,58494:33380,58496:33378,58497:33384,58498:33386,58499:33387,58500:33326,58501:33393,58502:33399,58503:33400,58504:33406,58505:33421,58506:33426,58507:33451,58508:33439,58509:33467,58510:33452,58511:33505,58512:33507,58513:33503,58514:33490,58515:33524,58516:33523,58517:33530,58518:33683,58519:33539,58520:33531,58521:33529,58522:33502,58523:33542,58524:33500,58525:33545,58526:33497,58527:33589,58528:33588,58529:33558,58530:33586,58531:33585,58532:33600,58533:33593,58534:33616,58535:33605,58536:33583,58537:33579,58538:33559,58539:33560,58540:33669,58541:33690,58542:33706,58543:33695,58544:33698,58545:33686,58546:33571,58547:33678,58548:33671,58549:33674,58550:33660,58551:33717,58552:33651,58553:33653,58554:33696,58555:33673,58556:33704,58557:33780,58558:33811,58559:33771,58560:33742,58561:33789,58562:33795,58563:33752,58564:33803,58565:33729,58566:33783,58567:33799,58568:33760,58569:33778,58570:33805,58571:33826,58572:33824,58573:33725,58574:33848,58575:34054,58576:33787,58577:33901,58578:33834,58579:33852,58580:34138,58581:33924,58582:33911,58583:33899,58584:33965,58585:33902,58586:33922,58587:33897,58588:33862,58589:33836,58590:33903,58591:33913,58592:33845,58593:33994,58594:33890,58595:33977,58596:33983,58597:33951,58598:34009,58599:33997,58600:33979,58601:34010,58602:34e3,58603:33985,58604:33990,58605:34006,58606:33953,58607:34081,58608:34047,58609:34036,58610:34071,58611:34072,58612:34092,58613:34079,58614:34069,58615:34068,58616:34044,58617:34112,58618:34147,58619:34136,58620:34120,58688:34113,58689:34306,58690:34123,58691:34133,58692:34176,58693:34212,58694:34184,58695:34193,58696:34186,58697:34216,58698:34157,58699:34196,58700:34203,58701:34282,58702:34183,58703:34204,58704:34167,58705:34174,58706:34192,58707:34249,58708:34234,58709:34255,58710:34233,58711:34256,58712:34261,58713:34269,58714:34277,58715:34268,58716:34297,58717:34314,58718:34323,58719:34315,58720:34302,58721:34298,58722:34310,58723:34338,58724:34330,58725:34352,58726:34367,58727:34381,58728:20053,58729:34388,58730:34399,58731:34407,58732:34417,58733:34451,58734:34467,58735:34473,58736:34474,58737:34443,58738:34444,58739:34486,58740:34479,58741:34500,58742:34502,58743:34480,58744:34505,58745:34851,58746:34475,58747:34516,58748:34526,58749:34537,58750:34540,58752:34527,58753:34523,58754:34543,58755:34578,58756:34566,58757:34568,58758:34560,58759:34563,58760:34555,58761:34577,58762:34569,58763:34573,58764:34553,58765:34570,58766:34612,58767:34623,58768:34615,58769:34619,58770:34597,58771:34601,58772:34586,58773:34656,58774:34655,58775:34680,58776:34636,58777:34638,58778:34676,58779:34647,58780:34664,58781:34670,58782:34649,58783:34643,58784:34659,58785:34666,58786:34821,58787:34722,58788:34719,58789:34690,58790:34735,58791:34763,58792:34749,58793:34752,58794:34768,58795:38614,58796:34731,58797:34756,58798:34739,58799:34759,58800:34758,58801:34747,58802:34799,58803:34802,58804:34784,58805:34831,58806:34829,58807:34814,58808:34806,58809:34807,58810:34830,58811:34770,58812:34833,58813:34838,58814:34837,58815:34850,58816:34849,58817:34865,58818:34870,58819:34873,58820:34855,58821:34875,58822:34884,58823:34882,58824:34898,58825:34905,58826:34910,58827:34914,58828:34923,58829:34945,58830:34942,58831:34974,58832:34933,58833:34941,58834:34997,58835:34930,58836:34946,58837:34967,58838:34962,58839:34990,58840:34969,58841:34978,58842:34957,58843:34980,58844:34992,58845:35007,58846:34993,58847:35011,58848:35012,58849:35028,58850:35032,58851:35033,58852:35037,58853:35065,58854:35074,58855:35068,58856:35060,58857:35048,58858:35058,58859:35076,58860:35084,58861:35082,58862:35091,58863:35139,58864:35102,58865:35109,58866:35114,58867:35115,58868:35137,58869:35140,58870:35131,58871:35126,58872:35128,58873:35148,58874:35101,58875:35168,58876:35166,58944:35174,58945:35172,58946:35181,58947:35178,58948:35183,58949:35188,58950:35191,58951:35198,58952:35203,58953:35208,58954:35210,58955:35219,58956:35224,58957:35233,58958:35241,58959:35238,58960:35244,58961:35247,58962:35250,58963:35258,58964:35261,58965:35263,58966:35264,58967:35290,58968:35292,58969:35293,58970:35303,58971:35316,58972:35320,58973:35331,58974:35350,58975:35344,58976:35340,58977:35355,58978:35357,58979:35365,58980:35382,58981:35393,58982:35419,58983:35410,58984:35398,58985:35400,58986:35452,58987:35437,58988:35436,58989:35426,58990:35461,58991:35458,58992:35460,58993:35496,58994:35489,58995:35473,58996:35493,58997:35494,58998:35482,58999:35491,59e3:35524,59001:35533,59002:35522,59003:35546,59004:35563,59005:35571,59006:35559,59008:35556,59009:35569,59010:35604,59011:35552,59012:35554,59013:35575,59014:35550,59015:35547,59016:35596,59017:35591,59018:35610,59019:35553,59020:35606,59021:35600,59022:35607,59023:35616,59024:35635,59025:38827,59026:35622,59027:35627,59028:35646,59029:35624,59030:35649,59031:35660,59032:35663,59033:35662,59034:35657,59035:35670,59036:35675,59037:35674,59038:35691,59039:35679,59040:35692,59041:35695,59042:35700,59043:35709,59044:35712,59045:35724,59046:35726,59047:35730,59048:35731,59049:35734,59050:35737,59051:35738,59052:35898,59053:35905,59054:35903,59055:35912,59056:35916,59057:35918,59058:35920,59059:35925,59060:35938,59061:35948,59062:35960,59063:35962,59064:35970,59065:35977,59066:35973,59067:35978,59068:35981,59069:35982,59070:35988,59071:35964,59072:35992,59073:25117,59074:36013,59075:36010,59076:36029,59077:36018,59078:36019,59079:36014,59080:36022,59081:36040,59082:36033,59083:36068,59084:36067,59085:36058,59086:36093,59087:36090,59088:36091,59089:36100,59090:36101,59091:36106,59092:36103,59093:36111,59094:36109,59095:36112,59096:40782,59097:36115,59098:36045,59099:36116,59100:36118,59101:36199,59102:36205,59103:36209,59104:36211,59105:36225,59106:36249,59107:36290,59108:36286,59109:36282,59110:36303,59111:36314,59112:36310,59113:36300,59114:36315,59115:36299,59116:36330,59117:36331,59118:36319,59119:36323,59120:36348,59121:36360,59122:36361,59123:36351,59124:36381,59125:36382,59126:36368,59127:36383,59128:36418,59129:36405,59130:36400,59131:36404,59132:36426,59200:36423,59201:36425,59202:36428,59203:36432,59204:36424,59205:36441,59206:36452,59207:36448,59208:36394,59209:36451,59210:36437,59211:36470,59212:36466,59213:36476,59214:36481,59215:36487,59216:36485,59217:36484,59218:36491,59219:36490,59220:36499,59221:36497,59222:36500,59223:36505,59224:36522,59225:36513,59226:36524,59227:36528,59228:36550,59229:36529,59230:36542,59231:36549,59232:36552,59233:36555,59234:36571,59235:36579,59236:36604,59237:36603,59238:36587,59239:36606,59240:36618,59241:36613,59242:36629,59243:36626,59244:36633,59245:36627,59246:36636,59247:36639,59248:36635,59249:36620,59250:36646,59251:36659,59252:36667,59253:36665,59254:36677,59255:36674,59256:36670,59257:36684,59258:36681,59259:36678,59260:36686,59261:36695,59262:36700,59264:36706,59265:36707,59266:36708,59267:36764,59268:36767,59269:36771,59270:36781,59271:36783,59272:36791,59273:36826,59274:36837,59275:36834,59276:36842,59277:36847,59278:36999,59279:36852,59280:36869,59281:36857,59282:36858,59283:36881,59284:36885,59285:36897,59286:36877,59287:36894,59288:36886,59289:36875,59290:36903,59291:36918,59292:36917,59293:36921,59294:36856,59295:36943,59296:36944,59297:36945,59298:36946,59299:36878,59300:36937,59301:36926,59302:36950,59303:36952,59304:36958,59305:36968,59306:36975,59307:36982,59308:38568,59309:36978,59310:36994,59311:36989,59312:36993,59313:36992,59314:37002,59315:37001,59316:37007,59317:37032,59318:37039,59319:37041,59320:37045,59321:37090,59322:37092,59323:25160,59324:37083,59325:37122,59326:37138,59327:37145,59328:37170,59329:37168,59330:37194,59331:37206,59332:37208,59333:37219,59334:37221,59335:37225,59336:37235,59337:37234,59338:37259,59339:37257,59340:37250,59341:37282,59342:37291,59343:37295,59344:37290,59345:37301,59346:37300,59347:37306,59348:37312,59349:37313,59350:37321,59351:37323,59352:37328,59353:37334,59354:37343,59355:37345,59356:37339,59357:37372,59358:37365,59359:37366,59360:37406,59361:37375,59362:37396,59363:37420,59364:37397,59365:37393,59366:37470,59367:37463,59368:37445,59369:37449,59370:37476,59371:37448,59372:37525,59373:37439,59374:37451,59375:37456,59376:37532,59377:37526,59378:37523,59379:37531,59380:37466,59381:37583,59382:37561,59383:37559,59384:37609,59385:37647,59386:37626,59387:37700,59388:37678,59456:37657,59457:37666,59458:37658,59459:37667,59460:37690,59461:37685,59462:37691,59463:37724,59464:37728,59465:37756,59466:37742,59467:37718,59468:37808,59469:37804,59470:37805,59471:37780,59472:37817,59473:37846,59474:37847,59475:37864,59476:37861,59477:37848,59478:37827,59479:37853,59480:37840,59481:37832,59482:37860,59483:37914,59484:37908,59485:37907,59486:37891,59487:37895,59488:37904,59489:37942,59490:37931,59491:37941,59492:37921,59493:37946,59494:37953,59495:37970,59496:37956,59497:37979,59498:37984,59499:37986,59500:37982,59501:37994,59502:37417,59503:38e3,59504:38005,59505:38007,59506:38013,59507:37978,59508:38012,59509:38014,59510:38017,59511:38015,59512:38274,59513:38279,59514:38282,59515:38292,59516:38294,59517:38296,59518:38297,59520:38304,59521:38312,59522:38311,59523:38317,59524:38332,59525:38331,59526:38329,59527:38334,59528:38346,59529:28662,59530:38339,59531:38349,59532:38348,59533:38357,59534:38356,59535:38358,59536:38364,59537:38369,59538:38373,59539:38370,59540:38433,59541:38440,59542:38446,59543:38447,59544:38466,59545:38476,59546:38479,59547:38475,59548:38519,59549:38492,59550:38494,59551:38493,59552:38495,59553:38502,59554:38514,59555:38508,59556:38541,59557:38552,59558:38549,59559:38551,59560:38570,59561:38567,59562:38577,59563:38578,59564:38576,59565:38580,59566:38582,59567:38584,59568:38585,59569:38606,59570:38603,59571:38601,59572:38605,59573:35149,59574:38620,59575:38669,59576:38613,59577:38649,59578:38660,59579:38662,59580:38664,59581:38675,59582:38670,59583:38673,59584:38671,59585:38678,59586:38681,59587:38692,59588:38698,59589:38704,59590:38713,59591:38717,59592:38718,59593:38724,59594:38726,59595:38728,59596:38722,59597:38729,59598:38748,59599:38752,59600:38756,59601:38758,59602:38760,59603:21202,59604:38763,59605:38769,59606:38777,59607:38789,59608:38780,59609:38785,59610:38778,59611:38790,59612:38795,59613:38799,59614:38800,59615:38812,59616:38824,59617:38822,59618:38819,59619:38835,59620:38836,59621:38851,59622:38854,59623:38856,59624:38859,59625:38876,59626:38893,59627:40783,59628:38898,59629:31455,59630:38902,59631:38901,59632:38927,59633:38924,59634:38968,59635:38948,59636:38945,59637:38967,59638:38973,59639:38982,59640:38991,59641:38987,59642:39019,59643:39023,59644:39024,59712:39025,59713:39028,59714:39027,59715:39082,59716:39087,59717:39089,59718:39094,59719:39108,59720:39107,59721:39110,59722:39145,59723:39147,59724:39171,59725:39177,59726:39186,59727:39188,59728:39192,59729:39201,59730:39197,59731:39198,59732:39204,59733:39200,59734:39212,59735:39214,59736:39229,59737:39230,59738:39234,59739:39241,59740:39237,59741:39248,59742:39243,59743:39249,59744:39250,59745:39244,59746:39253,59747:39319,59748:39320,59749:39333,59750:39341,59751:39342,59752:39356,59753:39391,59754:39387,59755:39389,59756:39384,59757:39377,59758:39405,59759:39406,59760:39409,59761:39410,59762:39419,59763:39416,59764:39425,59765:39439,59766:39429,59767:39394,59768:39449,59769:39467,59770:39479,59771:39493,59772:39490,59773:39488,59774:39491,59776:39486,59777:39509,59778:39501,59779:39515,59780:39511,59781:39519,59782:39522,59783:39525,59784:39524,59785:39529,59786:39531,59787:39530,59788:39597,59789:39600,59790:39612,59791:39616,59792:39631,59793:39633,59794:39635,59795:39636,59796:39646,59797:39647,59798:39650,59799:39651,59800:39654,59801:39663,59802:39659,59803:39662,59804:39668,59805:39665,59806:39671,59807:39675,59808:39686,59809:39704,59810:39706,59811:39711,59812:39714,59813:39715,59814:39717,59815:39719,59816:39720,59817:39721,59818:39722,59819:39726,59820:39727,59821:39730,59822:39748,59823:39747,59824:39759,59825:39757,59826:39758,59827:39761,59828:39768,59829:39796,59830:39827,59831:39811,59832:39825,59833:39830,59834:39831,59835:39839,59836:39840,59837:39848,59838:39860,59839:39872,59840:39882,59841:39865,59842:39878,59843:39887,59844:39889,59845:39890,59846:39907,59847:39906,59848:39908,59849:39892,59850:39905,59851:39994,59852:39922,59853:39921,59854:39920,59855:39957,59856:39956,59857:39945,59858:39955,59859:39948,59860:39942,59861:39944,59862:39954,59863:39946,59864:39940,59865:39982,59866:39963,59867:39973,59868:39972,59869:39969,59870:39984,59871:40007,59872:39986,59873:40006,59874:39998,59875:40026,59876:40032,59877:40039,59878:40054,59879:40056,59880:40167,59881:40172,59882:40176,59883:40201,59884:40200,59885:40171,59886:40195,59887:40198,59888:40234,59889:40230,59890:40367,59891:40227,59892:40223,59893:40260,59894:40213,59895:40210,59896:40257,59897:40255,59898:40254,59899:40262,59900:40264,59968:40285,59969:40286,59970:40292,59971:40273,59972:40272,59973:40281,59974:40306,59975:40329,59976:40327,59977:40363,59978:40303,59979:40314,59980:40346,59981:40356,59982:40361,59983:40370,59984:40388,59985:40385,59986:40379,59987:40376,59988:40378,59989:40390,59990:40399,59991:40386,59992:40409,59993:40403,59994:40440,59995:40422,59996:40429,59997:40431,59998:40445,59999:40474,6e4:40475,60001:40478,60002:40565,60003:40569,60004:40573,60005:40577,60006:40584,60007:40587,60008:40588,60009:40594,60010:40597,60011:40593,60012:40605,60013:40613,60014:40617,60015:40632,60016:40618,60017:40621,60018:38753,60019:40652,60020:40654,60021:40655,60022:40656,60023:40660,60024:40668,60025:40670,60026:40669,60027:40672,60028:40677,60029:40680,60030:40687,60032:40692,60033:40694,60034:40695,60035:40697,60036:40699,60037:40700,60038:40701,60039:40711,60040:40712,60041:30391,60042:40725,60043:40737,60044:40748,60045:40766,60046:40778,60047:40786,60048:40788,60049:40803,60050:40799,60051:40800,60052:40801,60053:40806,60054:40807,60055:40812,60056:40810,60057:40823,60058:40818,60059:40822,60060:40853,60061:40860,60062:40864,60063:22575,60064:27079,60065:36953,60066:29796,60067:20956,60068:29081}},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=r(1),c=r(2);e.decode=function(o,e){var r=new Uint8ClampedArray(o.length);r.set(o);for(var s=new t.default(285,256,0),a=new c.default(s,r),n=new Uint8ClampedArray(e),d=!1,l=0;l<e;l++){var i=a.evaluateAt(s.exp(l+s.generatorBase));n[n.length-1-l]=i,0!==i&&(d=!0)}if(!d)return r;var B=new c.default(s,n),k=function(o,e,r,t){var c;e.degree()<r.degree()&&(e=(c=[r,e])[0],r=c[1]);for(var s=e,a=r,n=o.zero,d=o.one;a.degree()>=t/2;){var l=s,i=n;if(n=d,(s=a).isZero())return null;a=l;for(var B=o.zero,k=s.getCoefficient(s.degree()),u=o.inverse(k);a.degree()>=s.degree()&&!a.isZero();){var C=a.degree()-s.degree(),m=o.multiply(a.getCoefficient(a.degree()),u);B=B.addOrSubtract(o.buildMonomial(C,m)),a=a.addOrSubtract(s.multiplyByMonomial(C,m))}if(d=B.multiplyPoly(n).addOrSubtract(i),a.degree()>=s.degree())return null}var f=d.getCoefficient(0);if(0===f)return null;var w=o.inverse(f);return[d.multiply(w),a.multiply(w)]}(s,s.buildMonomial(e,1),B,e);if(null===k)return null;var u=function(o,e){var r=e.degree();if(1===r)return[e.getCoefficient(1)];for(var t=new Array(r),c=0,s=1;s<o.size&&c<r;s++)0===e.evaluateAt(s)&&(t[c]=o.inverse(s),c++);return c!==r?null:t}(s,k[0]);if(null==u)return null;for(var C=function(o,e,r){for(var c=r.length,s=new Array(c),a=0;a<c;a++){for(var n=o.inverse(r[a]),d=1,l=0;l<c;l++)a!==l&&(d=o.multiply(d,t.addOrSubtractGF(1,o.multiply(r[l],n))));s[a]=o.multiply(e.evaluateAt(n),o.inverse(d)),0!==o.generatorBase&&(s[a]=o.multiply(s[a],n))}return s}(s,k[1],u),m=0;m<u.length;m++){var f=r.length-1-s.log(u[m]);if(f<0)return null;r[f]=t.addOrSubtractGF(r[f],C[m])}return r}},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.VERSIONS=[{infoBits:null,versionNumber:1,alignmentPatternCenters:[],errorCorrectionLevels:[{ecCodewordsPerBlock:7,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:19}]},{ecCodewordsPerBlock:10,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:16}]},{ecCodewordsPerBlock:13,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:13}]},{ecCodewordsPerBlock:17,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:9}]}]},{infoBits:null,versionNumber:2,alignmentPatternCenters:[6,18],errorCorrectionLevels:[{ecCodewordsPerBlock:10,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:34}]},{ecCodewordsPerBlock:16,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:28}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:22}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:16}]}]},{infoBits:null,versionNumber:3,alignmentPatternCenters:[6,22],errorCorrectionLevels:[{ecCodewordsPerBlock:15,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:55}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:44}]},{ecCodewordsPerBlock:18,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:17}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:13}]}]},{infoBits:null,versionNumber:4,alignmentPatternCenters:[6,26],errorCorrectionLevels:[{ecCodewordsPerBlock:20,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:80}]},{ecCodewordsPerBlock:18,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:32}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:24}]},{ecCodewordsPerBlock:16,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:9}]}]},{infoBits:null,versionNumber:5,alignmentPatternCenters:[6,30],errorCorrectionLevels:[{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:108}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:43}]},{ecCodewordsPerBlock:18,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:15},{numBlocks:2,dataCodewordsPerBlock:16}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:11},{numBlocks:2,dataCodewordsPerBlock:12}]}]},{infoBits:null,versionNumber:6,alignmentPatternCenters:[6,34],errorCorrectionLevels:[{ecCodewordsPerBlock:18,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:68}]},{ecCodewordsPerBlock:16,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:27}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:19}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:15}]}]},{infoBits:31892,versionNumber:7,alignmentPatternCenters:[6,22,38],errorCorrectionLevels:[{ecCodewordsPerBlock:20,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:78}]},{ecCodewordsPerBlock:18,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:31}]},{ecCodewordsPerBlock:18,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:14},{numBlocks:4,dataCodewordsPerBlock:15}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:13},{numBlocks:1,dataCodewordsPerBlock:14}]}]},{infoBits:34236,versionNumber:8,alignmentPatternCenters:[6,24,42],errorCorrectionLevels:[{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:97}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:38},{numBlocks:2,dataCodewordsPerBlock:39}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:18},{numBlocks:2,dataCodewordsPerBlock:19}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:14},{numBlocks:2,dataCodewordsPerBlock:15}]}]},{infoBits:39577,versionNumber:9,alignmentPatternCenters:[6,26,46],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:116}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:36},{numBlocks:2,dataCodewordsPerBlock:37}]},{ecCodewordsPerBlock:20,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:16},{numBlocks:4,dataCodewordsPerBlock:17}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:12},{numBlocks:4,dataCodewordsPerBlock:13}]}]},{infoBits:42195,versionNumber:10,alignmentPatternCenters:[6,28,50],errorCorrectionLevels:[{ecCodewordsPerBlock:18,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:68},{numBlocks:2,dataCodewordsPerBlock:69}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:43},{numBlocks:1,dataCodewordsPerBlock:44}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:6,dataCodewordsPerBlock:19},{numBlocks:2,dataCodewordsPerBlock:20}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:6,dataCodewordsPerBlock:15},{numBlocks:2,dataCodewordsPerBlock:16}]}]},{infoBits:48118,versionNumber:11,alignmentPatternCenters:[6,30,54],errorCorrectionLevels:[{ecCodewordsPerBlock:20,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:81}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:50},{numBlocks:4,dataCodewordsPerBlock:51}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:22},{numBlocks:4,dataCodewordsPerBlock:23}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:12},{numBlocks:8,dataCodewordsPerBlock:13}]}]},{infoBits:51042,versionNumber:12,alignmentPatternCenters:[6,32,58],errorCorrectionLevels:[{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:92},{numBlocks:2,dataCodewordsPerBlock:93}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:6,dataCodewordsPerBlock:36},{numBlocks:2,dataCodewordsPerBlock:37}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:20},{numBlocks:6,dataCodewordsPerBlock:21}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:7,dataCodewordsPerBlock:14},{numBlocks:4,dataCodewordsPerBlock:15}]}]},{infoBits:55367,versionNumber:13,alignmentPatternCenters:[6,34,62],errorCorrectionLevels:[{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:107}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:8,dataCodewordsPerBlock:37},{numBlocks:1,dataCodewordsPerBlock:38}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:8,dataCodewordsPerBlock:20},{numBlocks:4,dataCodewordsPerBlock:21}]},{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:12,dataCodewordsPerBlock:11},{numBlocks:4,dataCodewordsPerBlock:12}]}]},{infoBits:58893,versionNumber:14,alignmentPatternCenters:[6,26,46,66],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:115},{numBlocks:1,dataCodewordsPerBlock:116}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:40},{numBlocks:5,dataCodewordsPerBlock:41}]},{ecCodewordsPerBlock:20,ecBlocks:[{numBlocks:11,dataCodewordsPerBlock:16},{numBlocks:5,dataCodewordsPerBlock:17}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:11,dataCodewordsPerBlock:12},{numBlocks:5,dataCodewordsPerBlock:13}]}]},{infoBits:63784,versionNumber:15,alignmentPatternCenters:[6,26,48,70],errorCorrectionLevels:[{ecCodewordsPerBlock:22,ecBlocks:[{numBlocks:5,dataCodewordsPerBlock:87},{numBlocks:1,dataCodewordsPerBlock:88}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:5,dataCodewordsPerBlock:41},{numBlocks:5,dataCodewordsPerBlock:42}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:5,dataCodewordsPerBlock:24},{numBlocks:7,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:11,dataCodewordsPerBlock:12},{numBlocks:7,dataCodewordsPerBlock:13}]}]},{infoBits:68472,versionNumber:16,alignmentPatternCenters:[6,26,50,74],errorCorrectionLevels:[{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:5,dataCodewordsPerBlock:98},{numBlocks:1,dataCodewordsPerBlock:99}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:7,dataCodewordsPerBlock:45},{numBlocks:3,dataCodewordsPerBlock:46}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:15,dataCodewordsPerBlock:19},{numBlocks:2,dataCodewordsPerBlock:20}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:15},{numBlocks:13,dataCodewordsPerBlock:16}]}]},{infoBits:70749,versionNumber:17,alignmentPatternCenters:[6,30,54,78],errorCorrectionLevels:[{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:107},{numBlocks:5,dataCodewordsPerBlock:108}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:10,dataCodewordsPerBlock:46},{numBlocks:1,dataCodewordsPerBlock:47}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:22},{numBlocks:15,dataCodewordsPerBlock:23}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:14},{numBlocks:17,dataCodewordsPerBlock:15}]}]},{infoBits:76311,versionNumber:18,alignmentPatternCenters:[6,30,56,82],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:5,dataCodewordsPerBlock:120},{numBlocks:1,dataCodewordsPerBlock:121}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:9,dataCodewordsPerBlock:43},{numBlocks:4,dataCodewordsPerBlock:44}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:17,dataCodewordsPerBlock:22},{numBlocks:1,dataCodewordsPerBlock:23}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:14},{numBlocks:19,dataCodewordsPerBlock:15}]}]},{infoBits:79154,versionNumber:19,alignmentPatternCenters:[6,30,58,86],errorCorrectionLevels:[{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:113},{numBlocks:4,dataCodewordsPerBlock:114}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:44},{numBlocks:11,dataCodewordsPerBlock:45}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:17,dataCodewordsPerBlock:21},{numBlocks:4,dataCodewordsPerBlock:22}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:9,dataCodewordsPerBlock:13},{numBlocks:16,dataCodewordsPerBlock:14}]}]},{infoBits:84390,versionNumber:20,alignmentPatternCenters:[6,34,62,90],errorCorrectionLevels:[{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:107},{numBlocks:5,dataCodewordsPerBlock:108}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:41},{numBlocks:13,dataCodewordsPerBlock:42}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:15,dataCodewordsPerBlock:24},{numBlocks:5,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:15,dataCodewordsPerBlock:15},{numBlocks:10,dataCodewordsPerBlock:16}]}]},{infoBits:87683,versionNumber:21,alignmentPatternCenters:[6,28,50,72,94],errorCorrectionLevels:[{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:116},{numBlocks:4,dataCodewordsPerBlock:117}]},{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:17,dataCodewordsPerBlock:42}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:17,dataCodewordsPerBlock:22},{numBlocks:6,dataCodewordsPerBlock:23}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:19,dataCodewordsPerBlock:16},{numBlocks:6,dataCodewordsPerBlock:17}]}]},{infoBits:92361,versionNumber:22,alignmentPatternCenters:[6,26,50,74,98],errorCorrectionLevels:[{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:111},{numBlocks:7,dataCodewordsPerBlock:112}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:17,dataCodewordsPerBlock:46}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:7,dataCodewordsPerBlock:24},{numBlocks:16,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:24,ecBlocks:[{numBlocks:34,dataCodewordsPerBlock:13}]}]},{infoBits:96236,versionNumber:23,alignmentPatternCenters:[6,30,54,74,102],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:121},{numBlocks:5,dataCodewordsPerBlock:122}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:47},{numBlocks:14,dataCodewordsPerBlock:48}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:11,dataCodewordsPerBlock:24},{numBlocks:14,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:16,dataCodewordsPerBlock:15},{numBlocks:14,dataCodewordsPerBlock:16}]}]},{infoBits:102084,versionNumber:24,alignmentPatternCenters:[6,28,54,80,106],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:6,dataCodewordsPerBlock:117},{numBlocks:4,dataCodewordsPerBlock:118}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:6,dataCodewordsPerBlock:45},{numBlocks:14,dataCodewordsPerBlock:46}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:11,dataCodewordsPerBlock:24},{numBlocks:16,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:30,dataCodewordsPerBlock:16},{numBlocks:2,dataCodewordsPerBlock:17}]}]},{infoBits:102881,versionNumber:25,alignmentPatternCenters:[6,32,58,84,110],errorCorrectionLevels:[{ecCodewordsPerBlock:26,ecBlocks:[{numBlocks:8,dataCodewordsPerBlock:106},{numBlocks:4,dataCodewordsPerBlock:107}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:8,dataCodewordsPerBlock:47},{numBlocks:13,dataCodewordsPerBlock:48}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:7,dataCodewordsPerBlock:24},{numBlocks:22,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:22,dataCodewordsPerBlock:15},{numBlocks:13,dataCodewordsPerBlock:16}]}]},{infoBits:110507,versionNumber:26,alignmentPatternCenters:[6,30,58,86,114],errorCorrectionLevels:[{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:10,dataCodewordsPerBlock:114},{numBlocks:2,dataCodewordsPerBlock:115}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:19,dataCodewordsPerBlock:46},{numBlocks:4,dataCodewordsPerBlock:47}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:28,dataCodewordsPerBlock:22},{numBlocks:6,dataCodewordsPerBlock:23}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:33,dataCodewordsPerBlock:16},{numBlocks:4,dataCodewordsPerBlock:17}]}]},{infoBits:110734,versionNumber:27,alignmentPatternCenters:[6,34,62,90,118],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:8,dataCodewordsPerBlock:122},{numBlocks:4,dataCodewordsPerBlock:123}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:22,dataCodewordsPerBlock:45},{numBlocks:3,dataCodewordsPerBlock:46}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:8,dataCodewordsPerBlock:23},{numBlocks:26,dataCodewordsPerBlock:24}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:12,dataCodewordsPerBlock:15},{numBlocks:28,dataCodewordsPerBlock:16}]}]},{infoBits:117786,versionNumber:28,alignmentPatternCenters:[6,26,50,74,98,122],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:117},{numBlocks:10,dataCodewordsPerBlock:118}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:3,dataCodewordsPerBlock:45},{numBlocks:23,dataCodewordsPerBlock:46}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:24},{numBlocks:31,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:11,dataCodewordsPerBlock:15},{numBlocks:31,dataCodewordsPerBlock:16}]}]},{infoBits:119615,versionNumber:29,alignmentPatternCenters:[6,30,54,78,102,126],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:7,dataCodewordsPerBlock:116},{numBlocks:7,dataCodewordsPerBlock:117}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:21,dataCodewordsPerBlock:45},{numBlocks:7,dataCodewordsPerBlock:46}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:1,dataCodewordsPerBlock:23},{numBlocks:37,dataCodewordsPerBlock:24}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:19,dataCodewordsPerBlock:15},{numBlocks:26,dataCodewordsPerBlock:16}]}]},{infoBits:126325,versionNumber:30,alignmentPatternCenters:[6,26,52,78,104,130],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:5,dataCodewordsPerBlock:115},{numBlocks:10,dataCodewordsPerBlock:116}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:19,dataCodewordsPerBlock:47},{numBlocks:10,dataCodewordsPerBlock:48}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:15,dataCodewordsPerBlock:24},{numBlocks:25,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:23,dataCodewordsPerBlock:15},{numBlocks:25,dataCodewordsPerBlock:16}]}]},{infoBits:127568,versionNumber:31,alignmentPatternCenters:[6,30,56,82,108,134],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:13,dataCodewordsPerBlock:115},{numBlocks:3,dataCodewordsPerBlock:116}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:46},{numBlocks:29,dataCodewordsPerBlock:47}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:42,dataCodewordsPerBlock:24},{numBlocks:1,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:23,dataCodewordsPerBlock:15},{numBlocks:28,dataCodewordsPerBlock:16}]}]},{infoBits:133589,versionNumber:32,alignmentPatternCenters:[6,34,60,86,112,138],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:17,dataCodewordsPerBlock:115}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:10,dataCodewordsPerBlock:46},{numBlocks:23,dataCodewordsPerBlock:47}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:10,dataCodewordsPerBlock:24},{numBlocks:35,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:19,dataCodewordsPerBlock:15},{numBlocks:35,dataCodewordsPerBlock:16}]}]},{infoBits:136944,versionNumber:33,alignmentPatternCenters:[6,30,58,86,114,142],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:17,dataCodewordsPerBlock:115},{numBlocks:1,dataCodewordsPerBlock:116}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:14,dataCodewordsPerBlock:46},{numBlocks:21,dataCodewordsPerBlock:47}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:29,dataCodewordsPerBlock:24},{numBlocks:19,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:11,dataCodewordsPerBlock:15},{numBlocks:46,dataCodewordsPerBlock:16}]}]},{infoBits:141498,versionNumber:34,alignmentPatternCenters:[6,34,62,90,118,146],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:13,dataCodewordsPerBlock:115},{numBlocks:6,dataCodewordsPerBlock:116}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:14,dataCodewordsPerBlock:46},{numBlocks:23,dataCodewordsPerBlock:47}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:44,dataCodewordsPerBlock:24},{numBlocks:7,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:59,dataCodewordsPerBlock:16},{numBlocks:1,dataCodewordsPerBlock:17}]}]},{infoBits:145311,versionNumber:35,alignmentPatternCenters:[6,30,54,78,102,126,150],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:12,dataCodewordsPerBlock:121},{numBlocks:7,dataCodewordsPerBlock:122}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:12,dataCodewordsPerBlock:47},{numBlocks:26,dataCodewordsPerBlock:48}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:39,dataCodewordsPerBlock:24},{numBlocks:14,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:22,dataCodewordsPerBlock:15},{numBlocks:41,dataCodewordsPerBlock:16}]}]},{infoBits:150283,versionNumber:36,alignmentPatternCenters:[6,24,50,76,102,128,154],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:6,dataCodewordsPerBlock:121},{numBlocks:14,dataCodewordsPerBlock:122}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:6,dataCodewordsPerBlock:47},{numBlocks:34,dataCodewordsPerBlock:48}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:46,dataCodewordsPerBlock:24},{numBlocks:10,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:2,dataCodewordsPerBlock:15},{numBlocks:64,dataCodewordsPerBlock:16}]}]},{infoBits:152622,versionNumber:37,alignmentPatternCenters:[6,28,54,80,106,132,158],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:17,dataCodewordsPerBlock:122},{numBlocks:4,dataCodewordsPerBlock:123}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:29,dataCodewordsPerBlock:46},{numBlocks:14,dataCodewordsPerBlock:47}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:49,dataCodewordsPerBlock:24},{numBlocks:10,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:24,dataCodewordsPerBlock:15},{numBlocks:46,dataCodewordsPerBlock:16}]}]},{infoBits:158308,versionNumber:38,alignmentPatternCenters:[6,32,58,84,110,136,162],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:4,dataCodewordsPerBlock:122},{numBlocks:18,dataCodewordsPerBlock:123}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:13,dataCodewordsPerBlock:46},{numBlocks:32,dataCodewordsPerBlock:47}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:48,dataCodewordsPerBlock:24},{numBlocks:14,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:42,dataCodewordsPerBlock:15},{numBlocks:32,dataCodewordsPerBlock:16}]}]},{infoBits:161089,versionNumber:39,alignmentPatternCenters:[6,26,54,82,110,138,166],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:20,dataCodewordsPerBlock:117},{numBlocks:4,dataCodewordsPerBlock:118}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:40,dataCodewordsPerBlock:47},{numBlocks:7,dataCodewordsPerBlock:48}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:43,dataCodewordsPerBlock:24},{numBlocks:22,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:10,dataCodewordsPerBlock:15},{numBlocks:67,dataCodewordsPerBlock:16}]}]},{infoBits:167017,versionNumber:40,alignmentPatternCenters:[6,30,58,86,114,142,170],errorCorrectionLevels:[{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:19,dataCodewordsPerBlock:118},{numBlocks:6,dataCodewordsPerBlock:119}]},{ecCodewordsPerBlock:28,ecBlocks:[{numBlocks:18,dataCodewordsPerBlock:47},{numBlocks:31,dataCodewordsPerBlock:48}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:34,dataCodewordsPerBlock:24},{numBlocks:34,dataCodewordsPerBlock:25}]},{ecCodewordsPerBlock:30,ecBlocks:[{numBlocks:20,dataCodewordsPerBlock:15},{numBlocks:61,dataCodewordsPerBlock:16}]}]}]},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=r(0);function c(o,e,r,t){var c=o.x-e.x+r.x-t.x,s=o.y-e.y+r.y-t.y;if(0===c&&0===s)return{a11:e.x-o.x,a12:e.y-o.y,a13:0,a21:r.x-e.x,a22:r.y-e.y,a23:0,a31:o.x,a32:o.y,a33:1};var a=e.x-r.x,n=t.x-r.x,d=e.y-r.y,l=t.y-r.y,i=a*l-n*d,B=(c*l-n*s)/i,k=(a*s-c*d)/i;return{a11:e.x-o.x+B*e.x,a12:e.y-o.y+B*e.y,a13:B,a21:t.x-o.x+k*t.x,a22:t.y-o.y+k*t.y,a23:k,a31:o.x,a32:o.y,a33:1}}e.extract=function(o,e){for(var r,s,a=function(o,e,r,t){var s=c(o,e,r,t);return{a11:s.a22*s.a33-s.a23*s.a32,a12:s.a13*s.a32-s.a12*s.a33,a13:s.a12*s.a23-s.a13*s.a22,a21:s.a23*s.a31-s.a21*s.a33,a22:s.a11*s.a33-s.a13*s.a31,a23:s.a13*s.a21-s.a11*s.a23,a31:s.a21*s.a32-s.a22*s.a31,a32:s.a12*s.a31-s.a11*s.a32,a33:s.a11*s.a22-s.a12*s.a21}}({x:3.5,y:3.5},{x:e.dimension-3.5,y:3.5},{x:e.dimension-6.5,y:e.dimension-6.5},{x:3.5,y:e.dimension-3.5}),n=c(e.topLeft,e.topRight,e.alignmentPattern,e.bottomLeft),d=(s=a,{a11:(r=n).a11*s.a11+r.a21*s.a12+r.a31*s.a13,a12:r.a12*s.a11+r.a22*s.a12+r.a32*s.a13,a13:r.a13*s.a11+r.a23*s.a12+r.a33*s.a13,a21:r.a11*s.a21+r.a21*s.a22+r.a31*s.a23,a22:r.a12*s.a21+r.a22*s.a22+r.a32*s.a23,a23:r.a13*s.a21+r.a23*s.a22+r.a33*s.a23,a31:r.a11*s.a31+r.a21*s.a32+r.a31*s.a33,a32:r.a12*s.a31+r.a22*s.a32+r.a32*s.a33,a33:r.a13*s.a31+r.a23*s.a32+r.a33*s.a33}),l=t.BitMatrix.createEmpty(e.dimension,e.dimension),i=function(o,e){var r=d.a13*o+d.a23*e+d.a33;return{x:(d.a11*o+d.a21*e+d.a31)/r,y:(d.a12*o+d.a22*e+d.a32)/r}},B=0;B<e.dimension;B++)for(var k=0;k<e.dimension;k++){var u=i(k+.5,B+.5);l.set(k,B,o.get(Math.floor(u.x),Math.floor(u.y)))}return{matrix:l,mappingFunction:i}}},function(o,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var t=function(o,e){return Math.sqrt(Math.pow(e.x-o.x,2)+Math.pow(e.y-o.y,2))};function c(o){return o.reduce(function(o,e){return o+e})}function s(o,e,r,c){var s,a,n,d,l=[{x:Math.floor(o.x),y:Math.floor(o.y)}],i=Math.abs(e.y-o.y)>Math.abs(e.x-o.x);i?(s=Math.floor(o.y),a=Math.floor(o.x),n=Math.floor(e.y),d=Math.floor(e.x)):(s=Math.floor(o.x),a=Math.floor(o.y),n=Math.floor(e.x),d=Math.floor(e.y));for(var B=Math.abs(n-s),k=Math.abs(d-a),u=Math.floor(-B/2),C=s<n?1:-1,m=a<d?1:-1,f=!0,w=s,P=a;w!==n+C;w+=C){var v=i?P:w,h=i?w:P;if(r.get(v,h)!==f&&(f=!f,l.push({x:v,y:h}),l.length===c+1))break;if((u+=k)>0){if(P===d)break;P+=m,u-=B}}for(var y=[],p=0;p<c;p++)l[p]&&l[p+1]?y.push(t(l[p],l[p+1])):y.push(0);return y}function a(o,e,r,t){var c,a=e.y-o.y,n=e.x-o.x,d=s(o,e,r,Math.ceil(t/2)),l=s(o,{x:o.x-n,y:o.y-a},r,Math.ceil(t/2)),i=d.shift()+l.shift()-1;return(c=l.concat(i)).concat.apply(c,d)}function n(o,e){var r=c(o)/c(e),t=0;return e.forEach(function(e,c){t+=Math.pow(o[c]-e*r,2)}),{averageSize:r,error:t}}function d(o,e,r){try{var t=a(o,{x:-1,y:o.y},r,e.length),c=a(o,{x:o.x,y:-1},r,e.length),s=a(o,{x:Math.max(0,o.x-o.y)-1,y:Math.max(0,o.y-o.x)-1},r,e.length),d=a(o,{x:Math.min(r.width,o.x+o.y)+1,y:Math.min(r.height,o.y+o.x)+1},r,e.length),l=n(t,e),i=n(c,e),B=n(s,e),k=n(d,e),u=Math.sqrt(l.error*l.error+i.error*i.error+B.error*B.error+k.error*k.error),C=(l.averageSize+i.averageSize+B.averageSize+k.averageSize)/4;return u+(Math.pow(l.averageSize-C,2)+Math.pow(i.averageSize-C,2)+Math.pow(B.averageSize-C,2)+Math.pow(k.averageSize-C,2))/C}catch(o){return 1/0}}function l(o,e){for(var r=Math.round(e.x);o.get(r,Math.round(e.y));)r--;for(var t=Math.round(e.x);o.get(t,Math.round(e.y));)t++;for(var c=(r+t)/2,s=Math.round(e.y);o.get(Math.round(c),s);)s--;for(var a=Math.round(e.y);o.get(Math.round(c),a);)a++;return{x:c,y:(s+a)/2}}function i(o,e,r,s,n){var l,i,B;try{l=function(o,e,r,s){var n=(c(a(o,r,s,5))/7+c(a(o,e,s,5))/7+c(a(r,o,s,5))/7+c(a(e,o,s,5))/7)/4;if(n<1)throw new Error("Invalid module size");var d=Math.round(t(o,e)/n),l=Math.round(t(o,r)/n),i=Math.floor((d+l)/2)+7;switch(i%4){case 0:i++;break;case 2:i--}return{dimension:i,moduleSize:n}}(s,r,n,o),i=l.dimension,B=l.moduleSize}catch(o){return null}var k=r.x-s.x+n.x,u=r.y-s.y+n.y,C=(t(s,n)+t(s,r))/2/B,m=1-3/C,f={x:s.x+m*(k-s.x),y:s.y+m*(u-s.y)},w=e.map(function(e){var r=(e.top.startX+e.top.endX+e.bottom.startX+e.bottom.endX)/4,s=(e.top.y+e.bottom.y+1)/2;if(o.get(Math.floor(r),Math.floor(s))){var a=[e.top.endX-e.top.startX,e.bottom.endX-e.bottom.startX,e.bottom.y-e.top.y+1];c(a);return{x:r,y:s,score:d({x:Math.floor(r),y:Math.floor(s)},[1,1,1],o)+t({x:r,y:s},f)}}}).filter(function(o){return!!o}).sort(function(o,e){return o.score-e.score});return{alignmentPattern:C>=15&&w.length?w[0]:f,dimension:i}}e.locate=function(o){for(var e=[],r=[],s=[],a=[],n=function(t){for(var n=0,d=!1,l=[0,0,0,0,0],i=function(e){var s=o.get(e,t);if(s===d)n++;else{l=[l[1],l[2],l[3],l[4],n],n=1,d=s;var i=c(l)/7,B=Math.abs(l[0]-i)<i&&Math.abs(l[1]-i)<i&&Math.abs(l[2]-3*i)<3*i&&Math.abs(l[3]-i)<i&&Math.abs(l[4]-i)<i&&!s,k=c(l.slice(-3))/3,u=Math.abs(l[2]-k)<k&&Math.abs(l[3]-k)<k&&Math.abs(l[4]-k)<k&&s;if(B){var C=e-l[3]-l[4],m=C-l[2],f={startX:m,endX:C,y:t};(w=r.filter(function(o){return m>=o.bottom.startX&&m<=o.bottom.endX||C>=o.bottom.startX&&m<=o.bottom.endX||m<=o.bottom.startX&&C>=o.bottom.endX&&l[2]/(o.bottom.endX-o.bottom.startX)<1.5&&l[2]/(o.bottom.endX-o.bottom.startX)>.5})).length>0?w[0].bottom=f:r.push({top:f,bottom:f})}if(u){var w,P=e-l[4],v=P-l[3];f={startX:v,y:t,endX:P};(w=a.filter(function(o){return v>=o.bottom.startX&&v<=o.bottom.endX||P>=o.bottom.startX&&v<=o.bottom.endX||v<=o.bottom.startX&&P>=o.bottom.endX&&l[2]/(o.bottom.endX-o.bottom.startX)<1.5&&l[2]/(o.bottom.endX-o.bottom.startX)>.5})).length>0?w[0].bottom=f:a.push({top:f,bottom:f})}}},B=-1;B<=o.width;B++)i(B);e.push.apply(e,r.filter(function(o){return o.bottom.y!==t&&o.bottom.y-o.top.y>=2})),r=r.filter(function(o){return o.bottom.y===t}),s.push.apply(s,a.filter(function(o){return o.bottom.y!==t})),a=a.filter(function(o){return o.bottom.y===t})},B=0;B<=o.height;B++)n(B);e.push.apply(e,r.filter(function(o){return o.bottom.y-o.top.y>=2})),s.push.apply(s,a);var k=e.filter(function(o){return o.bottom.y-o.top.y>=2}).map(function(e){var r=(e.top.startX+e.top.endX+e.bottom.startX+e.bottom.endX)/4,t=(e.top.y+e.bottom.y+1)/2;if(o.get(Math.round(r),Math.round(t))){var s=[e.top.endX-e.top.startX,e.bottom.endX-e.bottom.startX,e.bottom.y-e.top.y+1],a=c(s)/s.length;return{score:d({x:Math.round(r),y:Math.round(t)},[1,1,3,1,1],o),x:r,y:t,size:a}}}).filter(function(o){return!!o}).sort(function(o,e){return o.score-e.score}).map(function(o,e,r){if(e>4)return null;var t=r.filter(function(o,r){return e!==r}).map(function(e){return{x:e.x,y:e.y,score:e.score+Math.pow(e.size-o.size,2)/o.size,size:e.size}}).sort(function(o,e){return o.score-e.score});if(t.length<2)return null;var c=o.score+t[0].score+t[1].score;return{points:[o].concat(t.slice(0,2)),score:c}}).filter(function(o){return!!o}).sort(function(o,e){return o.score-e.score});if(0===k.length)return null;var u=function(o,e,r){var c,s,a,n,d,l,i,B=t(o,e),k=t(e,r),u=t(o,r);return k>=B&&k>=u?(d=(c=[e,o,r])[0],l=c[1],i=c[2]):u>=k&&u>=B?(d=(s=[o,e,r])[0],l=s[1],i=s[2]):(d=(a=[o,r,e])[0],l=a[1],i=a[2]),(i.x-l.x)*(d.y-l.y)-(i.y-l.y)*(d.x-l.x)<0&&(d=(n=[i,d])[0],i=n[1]),{bottomLeft:d,topLeft:l,topRight:i}}(k[0].points[0],k[0].points[1],k[0].points[2]),C=u.topRight,m=u.topLeft,f=u.bottomLeft,w=i(o,s,C,m,f),P=[];w&&P.push({alignmentPattern:{x:w.alignmentPattern.x,y:w.alignmentPattern.y},bottomLeft:{x:f.x,y:f.y},dimension:w.dimension,topLeft:{x:m.x,y:m.y},topRight:{x:C.x,y:C.y}});var v=l(o,C),h=l(o,m),y=l(o,f),p=i(o,s,v,h,y);return p&&P.push({alignmentPattern:{x:p.alignmentPattern.x,y:p.alignmentPattern.y},bottomLeft:{x:y.x,y:y.y},topLeft:{x:h.x,y:h.y},topRight:{x:v.x,y:v.y},dimension:p.dimension}),0===P.length?null:P}}]).default});
</script>
<style>
  :root{--ink:#000;--ink-2:#333;--ink-3:#6e6e6e;--ink-4:#9a9a9a;--paper:#fff;--paper-2:#f6f6f6;--paper-3:#ededed;--desk:#e4e4e4;--rule-soft:#d2d2d2;--rule-hair:#e4e4e4;--guilloche:repeating-linear-gradient(45deg,rgba(0,0,0,.055) 0 1px,transparent 1px 7px);--sans:'Archivo',ui-sans-serif,system-ui,-apple-system,'Segoe UI',Helvetica,Arial,sans-serif;--mono:'IBM Plex Mono',ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
  *,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
  body{font-family:var(--sans);font-size:14.5px;line-height:1.55;color:var(--ink);background-color:var(--desk);background-image:var(--guilloche);padding:26px 20px;min-height:100vh;-webkit-font-smoothing:antialiased}
  ::selection{background:var(--ink);color:var(--paper)}
  .app-container{max-width:1180px;margin:0 auto;background:var(--paper);border:1px solid var(--ink);padding:0 32px 32px;box-shadow:0 2px 0 rgba(0,0,0,.18),0 24px 48px -28px rgba(0,0,0,.55)}
  .header{margin:0 -32px 0;padding:30px 32px 22px;background-image:var(--guilloche);border-bottom:4px double var(--ink);display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px}
  .header h1{font-size:30px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;line-height:1.1}
  .header h1 small{display:block;margin-top:9px;font-size:12.5px;font-weight:400;letter-spacing:.04em;text-transform:none;color:var(--ink-3)}
  .header-right{display:flex;flex-direction:column;align-items:flex-end;gap:10px}
  .lang-switch{display:inline-flex;align-items:stretch;border:1px solid var(--ink);background:var(--paper);font-family:var(--mono);font-size:11px;font-weight:600;letter-spacing:.1em;text-transform:uppercase}
  .lang-switch .lang-opt{padding:5px 11px;color:var(--ink-3);text-decoration:none;transition:background .12s,color .12s}
  .lang-switch .lang-opt + .lang-opt{border-left:1px solid var(--ink)}
  .lang-switch .lang-opt:hover{background:var(--paper-3);color:var(--ink)}
  .lang-switch .lang-opt.active{background:var(--ink);color:var(--paper)}
  .header .sub{font-family:var(--mono);font-size:11px;font-weight:500;letter-spacing:.08em;text-transform:uppercase;background:var(--paper);border:1px solid var(--ink);padding:5px 11px}
  .bank-stripe{display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px 28px;margin:0 -32px 26px;padding:11px 32px;background:var(--ink);color:var(--paper);font-family:var(--mono);font-size:11px;letter-spacing:.07em;text-transform:uppercase}
  .tabs{display:flex;gap:0;flex-wrap:wrap;margin-bottom:28px;border-bottom:1px solid var(--ink)}
  .tabs .tab{display:inline-flex;align-items:center;gap:8px;padding:11px 22px;margin-bottom:-1px;font-size:13px;font-weight:500;color:var(--ink-3);text-decoration:none;white-space:nowrap;background:var(--paper-2);border:1px solid var(--rule-soft);border-bottom-color:var(--ink);transition:color .12s,background .12s}
  .tabs .tab + .tab{border-left:none}
  .tabs .tab:hover{background:var(--paper-3);color:var(--ink)}
  .tabs .tab.active{background:var(--ink);border-color:var(--ink);color:var(--paper);font-weight:600}
  .section-title{display:flex;align-items:baseline;flex-wrap:wrap;gap:3px 14px;font-size:15px;font-weight:700;letter-spacing:.13em;text-transform:uppercase;margin:34px 0 16px;padding-bottom:9px;border-bottom:1px solid var(--ink)}
  .section-title small{font-size:12.5px;font-weight:400;letter-spacing:0;text-transform:none;color:var(--ink-3)}
  .tabs + .section-title,.message + .section-title{margin-top:0}
  .panel{background:var(--paper);border:1px solid var(--rule-soft);border-top:2px solid var(--ink);padding:24px 26px;margin-bottom:28px}
  .info-box{background:var(--paper-2);border:1px solid var(--rule-soft);padding:17px 20px;margin-bottom:24px;max-width:82ch;font-size:13.5px;line-height:1.7;color:var(--ink-2)}
  .info-box strong{color:var(--ink);font-weight:600}
  .message{max-width:82ch;background:var(--paper);border:1px solid var(--rule-soft);border-left:4px solid var(--ink);padding:12px 16px;margin-bottom:18px;font-size:13.5px;color:var(--ink-2)}
  .message.danger{background:var(--paper-3);border-left-width:7px;color:var(--ink);font-weight:500}
  .message.info{border-left-color:var(--ink-4)}
  .message.success{border-left-style:double;border-left-width:7px}
  .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:0 24px}
  .grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:0 18px}
  .form-group{margin-bottom:17px}
  .form-group label{display:block;margin-bottom:5px;font-size:10.5px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3)}
  .form-group input,.form-group select,.form-group textarea{width:100%;font-family:inherit;font-size:14px;line-height:1.5;font-variant-numeric:tabular-nums;color:var(--ink);background:var(--paper);border:1px solid var(--ink-4);border-radius:0;padding:9px 11px;transition:border-color .12s,box-shadow .12s}
  .form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:var(--ink);box-shadow:inset 0 -2px 0 var(--ink)}
  .form-group select{appearance:none;-webkit-appearance:none;padding-right:34px;background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' fill='none'%3E%3Cpath d='M1 1.5 6 6.5l5-5' stroke='%23000000' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center}
  .form-group textarea{resize:vertical;min-height:64px}
  .form-group textarea.mono{font-family:var(--mono);font-size:12.5px;line-height:1.65;min-height:190px}
  .form-group .hint{margin-top:4px;font-size:11.5px;color:var(--ink-4)}
  .form-group.field-removable{position:relative;padding-right:30px}
  .form-group.field-removable .field-remove-btn{position:absolute;top:0;right:0;width:22px;height:22px;line-height:20px;text-align:center;padding:0;border:1px solid var(--ink-4);background:var(--paper);color:var(--ink-3);font-size:15px;cursor:pointer;border-radius:0;transition:background .12s,color .12s,border-color .12s}
  .form-group.field-removable .field-remove-btn:hover{background:var(--ink);color:var(--paper);border-color:var(--ink)}
  .form-group.field-removed{display:none}
  .config-article-header .annex-remove-btn{position:absolute;top:0;right:0;width:22px;height:22px;line-height:20px;text-align:center;padding:0;border:1px solid var(--ink-4);background:var(--paper);color:var(--ink-3);font-size:15px;cursor:pointer;border-radius:0;transition:background .12s,color .12s,border-color .12s}
  .config-article-header .annex-remove-btn:hover{background:var(--ink);color:var(--paper);border-color:var(--ink)}
  .choice-block{background:var(--paper-2);border:2px solid var(--ink);padding:20px 22px;margin-bottom:24px}
  .choice-block .form-group{margin-bottom:0}
  .choice-block select{border-color:var(--ink);font-weight:600}
  .choice-note{margin-top:14px;padding-top:14px;border-top:1px solid var(--rule-soft);font-size:12.5px;color:var(--ink-2)}
  .btn{display:inline-flex;align-items:center;gap:7px;padding:9px 17px;font-family:inherit;font-size:12.5px;font-weight:600;letter-spacing:.04em;line-height:1.2;color:var(--ink);background:var(--paper);border:1px solid var(--ink);border-radius:0;cursor:pointer;text-decoration:none;white-space:nowrap;transition:background .12s,color .12s,box-shadow .12s}
  .btn:hover{background:var(--paper-3)}
  .btn-primary{background:var(--ink);border-color:var(--ink);color:var(--paper)}
  .btn-primary:hover{background:var(--ink-2);border-color:var(--ink-2)}
  .btn-gold{padding:12px 24px;font-size:13px;letter-spacing:.1em;text-transform:uppercase;color:var(--paper);background:var(--ink);border-color:var(--ink);box-shadow:3px 3px 0 var(--ink)}
  .btn-gold:hover{background:var(--ink-2);box-shadow:1px 1px 0 var(--ink)}
  .btn-outline{background:var(--paper);border-color:var(--rule-soft);color:var(--ink-2);font-weight:500}
  .btn-outline:hover{background:var(--paper-2);border-color:var(--ink);color:var(--ink)}
  .btn-sm{padding:6px 12px;font-size:11.5px;gap:6px;letter-spacing:.03em}
  .btn[disabled]{opacity:.4;cursor:not-allowed;box-shadow:none}
  .form-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;background:var(--paper-2);border:1px solid var(--rule-soft);padding:12px 14px;margin-bottom:22px}
  .form-actions .label{margin-right:6px;font-size:10.5px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3)}
  .signature-area{display:grid;grid-template-columns:1fr 1fr;gap:26px;margin-top:26px;padding-top:26px;border-top:4px double var(--ink)}
  .signature-box{background:var(--paper);border:1px solid var(--rule-soft);padding:18px}
  .signature-box h4{font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase}
  .signature-box p{margin:6px 0 14px;font-size:12.5px;color:var(--ink-3)}
  .signature-canvas{display:block;width:100%;height:150px;border:1px solid var(--ink-4);cursor:crosshair;touch-action:none;user-select:none;-webkit-user-select:none;background:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='11' height='11'%3E%3Cpath d='M1 1l9 9M10 1l-9 9' stroke='%23000000' stroke-width='1.4'/%3E%3C/svg%3E") no-repeat 7% 72%,linear-gradient(var(--ink),var(--ink)) no-repeat 13% 78% / 79% 1px,var(--paper)}
  .signature-status{margin:12px 0;min-height:18px;font-family:var(--mono);font-size:11px;font-weight:500;letter-spacing:.07em;text-transform:uppercase;color:var(--ink-3)}
  .annex-group{margin-bottom:22px}
  .annex-group-title{font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:8px 0;margin-bottom:12px;border-bottom:1px solid var(--rule-soft)}
  .annex-editor{background:var(--paper-2);border:1px solid var(--rule-soft);border-left:3px solid var(--ink);padding:16px 18px;margin-bottom:18px}
  .annex-editor[hidden]{display:none}
  .annex-head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px 16px;margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--rule-hair)}
  .annex-toggle{display:inline-flex;align-items:center;gap:8px;font-size:12.5px;font-weight:600;cursor:pointer;user-select:none}
  .annex-toggle input[type="checkbox"]{appearance:none;-webkit-appearance:none;width:16px;height:16px;margin:0;border:1.5px solid var(--ink);background:var(--paper);cursor:pointer;position:relative;flex:0 0 auto}
  .annex-toggle input[type="checkbox"]:checked{background:var(--ink)}
  .annex-toggle input[type="checkbox"]:checked::after{content:'';position:absolute;left:4px;top:1px;width:5px;height:9px;border:solid var(--paper);border-width:0 2px 2px 0;transform:rotate(45deg)}
  .annex-name{font-size:11px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;color:var(--ink-3)}
  .annex-editor .optional{font-weight:400;text-transform:none;letter-spacing:0;color:var(--ink-4)}
  .btn-remove-article{margin-left:auto;font-size:11px;font-weight:600;color:#a33;background:transparent;border:1px solid #a33;border-radius:3px;padding:4px 10px;cursor:pointer}
  .btn-remove-article:hover{background:#a33;color:#fff}
  .var-toolbar{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-bottom:14px;padding-bottom:12px;border-bottom:1px dashed var(--rule-soft)}
  .var-toolbar-label{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--ink-3);margin-right:4px;font-weight:600}
  .var-chip{font-family:var(--mono);font-size:11px;padding:3px 9px;border:1px solid var(--ink-4);background:var(--paper);cursor:pointer;border-radius:3px;color:var(--ink-2);transition:background .12s,color .12s,border-color .12s}
  .var-chip:hover,.var-chip:focus{background:var(--ink);color:var(--paper);border-color:var(--ink);outline:none}
  .ph-fill{background:#fff3c4;border-bottom:1px dotted var(--ink-3);padding:0 1px;cursor:help}
  .config-article-header{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
  .config-article-controls{display:flex;gap:6px;align-items:center}
  .btn-move{font-family:var(--mono);font-size:12px;line-height:1;padding:5px 9px;border:1px solid var(--ink-4);background:var(--paper);cursor:pointer;border-radius:3px;color:var(--ink-2)}
  .btn-move:hover:not(:disabled){background:var(--ink);color:var(--paper);border-color:var(--ink)}
  .btn-move:disabled{opacity:.3;cursor:not-allowed}
  .panel.marked-for-removal{opacity:.55;border-left-color:var(--ink-4)}
  .panel.marked-for-removal .article-fields{display:none}
  .marked-for-removal-notice{margin-bottom:0}
  .annex-textarea{min-height:120px;max-height:none;overflow-y:hidden;resize:vertical;font-family:var(--mono);font-size:12.5px;line-height:1.6;width:100%;padding:9px 11px;color:var(--ink);background:var(--paper);border:1px solid var(--ink-4);border-radius:0}
  .annex-textarea:focus{outline:none;border-color:var(--ink);box-shadow:inset 0 -2px 0 var(--ink)}
  .annex-editor.removed{opacity:.55;border-left-color:var(--ink-4)}
  .annex-editor.removed .annex-textarea{background:var(--paper-3);color:var(--ink-3)}
  .annex-group.removed{opacity:.55}
  .wizard{background:var(--paper-2);border:2px solid var(--ink);padding:20px 22px;margin-bottom:24px}
  .wizard-step[hidden],.wizard-result[hidden]{display:none}
  .wizard-q{font-size:14px;font-weight:600;margin-bottom:14px;line-height:1.5}
  .wizard-options,.wizard-checks{display:flex;flex-direction:column;gap:8px;margin-bottom:16px}
  .wizard-opt{display:inline-flex;align-items:center;gap:10px;padding:10px 14px;background:var(--paper);border:1px solid var(--ink-4);font-size:13.5px;cursor:pointer}
  .wizard-opt input[type="radio"],.wizard-opt input[type="checkbox"]{appearance:none;-webkit-appearance:none;width:16px;height:16px;margin:0;border:1.5px solid var(--ink);background:var(--paper);cursor:pointer;position:relative;flex:0 0 auto}
  .wizard-opt input[type="radio"]{border-radius:50%}
  .wizard-opt input[type="radio"]:checked,.wizard-opt input[type="checkbox"]:checked{background:var(--ink)}
  .wizard-opt input[type="radio"]:checked::after{content:'';position:absolute;inset:3px;border-radius:50%;background:var(--paper)}
  .wizard-opt input[type="checkbox"]:checked::after{content:'';position:absolute;left:4px;top:1px;width:5px;height:9px;border:solid var(--paper);border-width:0 2px 2px 0;transform:rotate(45deg)}
  .wizard-nav{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;margin-top:8px}
  .wizard-result{border-top:2px solid var(--ink);padding-top:16px}
  .wizard-result-head{font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ink-3);margin-bottom:10px}
  .wizard-result-body p{font-size:13.5px;line-height:1.65;color:var(--ink-2);margin-bottom:12px}
  .qr-result{display:none}
  .qr-result.show{display:block;margin-top:30px;background:var(--paper);border:2px solid var(--ink);box-shadow:0 0 0 1px var(--paper) inset,0 0 0 3px var(--ink) inset}
  .qr-result .section-title{margin:0;padding:13px 22px;background:var(--ink);color:var(--paper);border-bottom:none;font-size:12px;letter-spacing:.16em}
  .qr-result .section-title small{color:rgba(255,255,255,.68)}
  .qr-result .qr-grid{padding:24px}
  .qr-grid{display:grid;grid-template-columns:1fr;gap:24px;align-items:start}
  .qr-box{background:var(--paper);border:1px solid var(--ink);padding:16px;text-align:center}
  .qr-box canvas,.qr-box img{display:block;margin:0 auto;max-width:100%;height:auto}
  .qr-box p{margin-top:12px;font-size:11.5px;color:var(--ink-3)}
  .qr-parts{display:flex;flex-wrap:wrap;gap:14px;justify-content:center}
  .qr-part{padding:8px;background:var(--paper);border:1px solid var(--rule-soft);text-align:center}
  .qr-part .lbl{margin-top:7px;font-family:var(--mono);font-size:10.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--ink-3)}
  .qr-meta{font-size:13px}
  .qr-meta .row{padding-bottom:12px;margin-bottom:12px;border-bottom:1px solid var(--rule-hair)}
  .qr-meta .label{display:block;margin-bottom:6px;font-size:10.5px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--ink-3)}
  .qr-meta code{display:block;max-height:132px;overflow:auto;font-family:var(--mono);font-size:11.5px;line-height:1.65;word-break:break-all;color:var(--ink);background:var(--paper-2);border:1px solid var(--rule-soft);padding:9px 11px}
  .qr-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}
  .scan-panel{margin-top:18px;padding:18px;background:var(--paper-2);border:1px solid var(--rule-soft)}
  .scan-buttons{display:flex;gap:8px;flex-wrap:wrap}
  .scan-video-wrap{position:relative;max-width:380px;margin-top:14px}
  #scanVideo{display:none;width:100%;background:#000;border:2px solid var(--ink)}
  .scan-status{margin-top:12px;font-family:var(--mono);font-size:11.5px;color:var(--ink-2)}
  .footer{margin-top:40px;padding-top:18px;border-top:4px double var(--ink);text-align:center;font-family:var(--mono);font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-3)}
  @media (max-width:900px){.grid-3{grid-template-columns:1fr 1fr}}
  @media (max-width:768px){body{padding:12px 10px}.app-container{padding:0 16px 24px}.header{margin:0 -16px;padding:22px 16px 18px}.header h1{font-size:20px;letter-spacing:.12em}.header-right{align-items:flex-start}.bank-stripe{margin:0 -16px 22px;padding:10px 16px;gap:5px}.panel{padding:18px 16px}.grid-2,.grid-3,.signature-area{grid-template-columns:1fr}.tabs{border-bottom:none}.tabs .tab{flex:1 1 100%;margin-bottom:0}.tabs .tab + .tab{border-left:1px solid var(--rule-soft);border-top:none}.qr-result .qr-grid{padding:16px}.btn-gold{width:100%;justify-content:center;box-shadow:none}.form-group input,.form-group select,.form-group textarea{font-size:16px}}
  @media (min-width:960px){.qr-grid{grid-template-columns:minmax(240px,300px) 1fr}}
  @media print{body{background:#fff;background-image:none;padding:0}.app-container{max-width:none;padding:0;border:none;box-shadow:none}.header{margin:0;padding:0 0 14px;background-image:none}.bank-stripe{margin:0 0 18px;padding:8px 0}.tabs,.form-actions,.scan-panel,.btn,.footer{display:none!important}.qr-result.show{border:1px solid #000;box-shadow:none}.qr-meta code{max-height:none;overflow:visible}}
</style>
</head>
<body>
<div class="app-container">
  <div class="header">
    <h1><?= e(t('title')) ?> <small><?= e(t('subtitle')) ?></small></h1>
    <div class="header-right">
      <div class="lang-switch" role="group" aria-label="<?= e(t('icons_switch_label')) ?>" title="<?= e(t('icons_switch_label')) ?>">
        <a class="lang-opt <?= icons_enabled() ? 'active' : '' ?>" href="?<?= e(http_build_query(array_merge($_GET, ['icons' => 'on']))) ?>"><?= e(t('icons_on')) ?></a>
        <a class="lang-opt <?= !icons_enabled() ? 'active' : '' ?>" href="?<?= e(http_build_query(array_merge($_GET, ['icons' => 'off']))) ?>"><?= e(t('icons_off')) ?></a>
      </div>
      <span class="sub"><?= e(t('sub')) ?></span>
      <a class="lang-opt" href="?logout=1" title="Uitloggen"><?= icons_enabled() ? '🚪 ' : '' ?>Uitloggen</a>
    </div>
  </div>

  <div class="bank-stripe">
    <span><?= icons_enabled() ? '🔒 ' : '' ?><?= e(t('stripe_no_disk')) ?></span>
    <span><?= e(t('stripe_full')) ?></span>
    <span>MD5 = <?= e(t('stripe_integrity')) ?></span>
  </div>

  <div class="tabs">
    <a class="tab <?= $tab === 'generate' ? 'active' : '' ?>" href="?tab=generate&amp;lang=<?= e($lang) ?>"><?= e(t('tab_generate')) ?></a>
    <a class="tab <?= $tab === 'regen' ? 'active' : '' ?>" href="?tab=regen&amp;lang=<?= e($lang) ?>"><?= e(t('tab_regen')) ?></a>
    <a class="tab <?= $tab === 'about' ? 'active' : '' ?>" href="?tab=about&amp;lang=<?= e($lang) ?>"><?= e(t('tab_about')) ?></a>
    <a class="tab <?= $tab === 'config' ? 'active' : '' ?>" href="?tab=config&amp;lang=<?= e($lang) ?>"><?= e(t('tab_config')) ?></a>
    <a class="tab <?= $tab === 'presets' ? 'active' : '' ?>" href="?tab=presets&amp;lang=<?= e($lang) ?>"><?= e(t('tab_presets')) ?></a>
    <a class="tab <?= $tab === 'contracts' ? 'active' : '' ?>" href="?tab=contracts&amp;lang=<?= e($lang) ?>"><?= e(t('tab_contracts')) ?></a>
  </div>

  <?php
  // ===============================================================
  // VERTAAL-API STATUSSTRIP — altijd zichtbaar, alle vier de engines, live
  // getest bij het inladen van deze pagina (zie $__engineHealth hierboven).
  // Online = geconfigureerd + tegoed beschikbaar. Offline = geen sleutel, of
  // tegoed op / sleutel ongeldig / niet bereikbaar. De balk krijgt alleen de
  // "danger"-kleur zodra minstens één GECONFIGUREERDE engine offline is
  // (translate_engines_have_problem()); een engine die bewust geen sleutel
  // heeft (bv. Microsoft) kleurt neutraal grijs, geen rode waarschuwing.
  // ===============================================================
  $__hasProblem = translate_engines_have_problem($__engineHealth);
  ?>
  <div class="message<?= $__hasProblem ? ' danger' : '' ?>" style="line-height:1.5;">
    <div style="font-weight:600;margin-bottom:4px;">
      <?= $__hasProblem ? (icons_enabled() ? '&#9888;&#65039; ' : '') : (icons_enabled() ? '&#128225; ' : '') ?>Vertaal-API's — status bij het laden van deze pagina
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:14px;">
      <?php foreach ($__engineHealth as $__eng => $__st): $__online = !empty($__st['online']); $__log = $__engineLog[$__eng] ?? null; ?>
        <div style="min-width:200px;">
          <span style="font-weight:600;color:<?= $__online ? '#2a7a4d' : '#c0392b' ?>;">&#9679; <?= e(tr_engine_label((string)$__eng)) ?>: <?= $__online ? 'Online' : 'Offline' ?></span>
          <div style="font-size:11.5px;opacity:.85;"><?= e((string)($__st['message'] ?? '')) ?></div>
          <?php if ($__log !== null): ?>
            <div style="font-size:11px;opacity:.7;">Laatste fout uit log (<?= e((string)$__log['ts']) ?>): <?= e((string)$__log['message']) ?></div>
          <?php endif; ?>
        </div>
      <?php endforeach; unset($__eng, $__st, $__online, $__log); ?>
    </div>
    <div style="margin-top:6px;font-size:11px;opacity:.75;">Online/offline is zojuist live getest (niet afgeleid uit translate_error.log); de regel "laatste fout uit log" eronder is alleen ter info. Zie tabblad "<?= e(t('tab_config')) ?>" voor details per contract.</div>
  </div>
  <?php unset($__hasProblem); ?>

  <?php if ($errors): ?>
    <div class="message danger"><?php foreach ($errors as $err) echo '<div>' . e($err) . '</div>'; ?></div>
  <?php endif; ?>

  <?php if ($tab === 'generate'): ?>
    <div class="section-title"><?= e(t('section_new')) ?> <small><?= e(t('section_new_sub')) ?></small></div>
    <div class="info-box"><strong><?= e(t('help_title')) ?></strong> <?= t('help_body') ?></div>

    <form method="post" id="contractForm" onsubmit="return false;">
      <input type="hidden" name="action" value="generate_json">
      <input type="hidden" name="sig1" id="sig1_input">
      <input type="hidden" name="sig2" id="sig2_input">

      <?= function_exists('render_merge_generate_section') ? render_merge_generate_section() : '' ?>

      <div id="templatePickerSection">
      <div class="form-group">
        <label><?= e(t('safeguard_label')) ?></label>
        <select name="safeguard" id="safeguardSelect">
          <?php foreach (list_available_contracts() as $k => $label): ?>
            <option value="<?= e($k) ?>" <?= $k === ($SAMPLES['safeguard'] ?? 'safeguard_scc') ? 'selected' : '' ?>>
              <?= e($label) ?><?= is_protected_contract($k) ? ' ' . e(t('config_picker_protected_suffix')) : '' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="section-title" style="font-size:15px;"><?= e(t('section_safeguard')) ?> <small><?= e(t('section_safeguard_sub')) ?></small></div>
      <?= render_contract_lang_selector() ?>
      </div>

    <div class="panel">
      <div class="form-actions">
        <span class="label"><?= e(t('quick_fill')) ?></span>
        <button type="button" class="btn btn-sm btn-outline" id="fillSampleBtn"><?= e(t('btn_fill_sample')) ?></button>
        <button type="button" class="btn btn-sm btn-outline" id="clearAllBtn"><?= e(t('btn_clear_all')) ?></button>
        <button type="button" class="btn btn-sm btn-outline" id="clearSignaturesBtn"><?= e(t('btn_clear_signatures')) ?></button>
      </div>

      <div class="form-actions" style="margin-top:8px;">
        <span class="label"><?= e(t('load_json_title')) ?>:</span>
        <button type="button" class="btn btn-sm btn-outline" id="loadJsonP1Btn"><?= e(t('btn_load_json_p1')) ?></button>
        <button type="button" class="btn btn-sm btn-outline" id="templateJsonP1Btn"><?= e(t('btn_json_template_p1')) ?></button>
        <button type="button" class="btn btn-sm btn-outline" id="loadJsonP2Btn"><?= e(t('btn_load_json_p2')) ?></button>
        <button type="button" class="btn btn-sm btn-outline" id="templateJsonP2Btn"><?= e(t('btn_json_template_p2')) ?></button>
        <input type="file" id="loadJsonP1Input" accept=".json,application/json" style="display:none;">
        <input type="file" id="loadJsonP2Input" accept=".json,application/json" style="display:none;">
      </div>
      <p style="margin:6px 0 0;font-size:11.5px;color:var(--ink-4);"><?= e(t('load_json_hint')) ?></p>
      <div id="loadJsonMsg" class="message" style="display:none;margin-top:10px;"></div>

        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_name')) ?> *</label><input type="text" name="company1_name" required value="<?= e($SAMPLES['company1_name']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_name')) ?> *</label><input type="text" name="company2_name" required value="<?= e($SAMPLES['company2_name']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_role')) ?></label>
            <select name="company1_role">
              <option value="verwerkingsverantwoordelijke"><?= e(t('role_controller')) ?></option>
              <option value="verwerker"><?= e(t('role_processor')) ?></option>
              <option value="gezamenlijke verwerkingsverantwoordelijke"><?= e(t('role_joint')) ?></option>
            </select>
          </div>
          <div class="form-group"><label><?= e(t('p2_role')) ?></label>
            <select name="company2_role">
              <option value="verwerker"><?= e(t('role_processor')) ?></option>
              <option value="verwerkingsverantwoordelijke"><?= e(t('role_controller')) ?></option>
              <option value="gezamenlijke verwerkingsverantwoordelijke"><?= e(t('role_joint')) ?></option>
            </select>
          </div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_address')) ?></label><input type="text" name="company1_address" value="<?= e($SAMPLES['company1_address']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_address')) ?></label><input type="text" name="company2_address" value="<?= e($SAMPLES['company2_address']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_country')) ?></label><input type="text" name="company1_country" value="<?= e($SAMPLES['company1_country']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_country')) ?></label><input type="text" name="company2_country" value="<?= e($SAMPLES['company2_country']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_kvk')) ?></label><input type="text" name="company1_kvk" value="<?= e($SAMPLES['company1_kvk']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_kvk')) ?></label><input type="text" name="company2_kvk" value="<?= e($SAMPLES['company2_kvk']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_vat')) ?></label><input type="text" name="company1_vat" value="<?= e($SAMPLES['company1_vat']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_vat')) ?></label><input type="text" name="company2_vat" value="<?= e($SAMPLES['company2_vat']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_iban')) ?></label><input type="text" name="company1_iban" value="<?= e($SAMPLES['company1_iban']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_iban')) ?></label><input type="text" name="company2_iban" value="<?= e($SAMPLES['company2_iban']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_rep')) ?></label><input type="text" name="company1_rep" value="<?= e($SAMPLES['company1_rep']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_rep')) ?></label><input type="text" name="company2_rep" value="<?= e($SAMPLES['company2_rep']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_rep_title')) ?></label><input type="text" name="company1_rep_title" value="<?= e($SAMPLES['company1_rep_title']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_rep_title')) ?></label><input type="text" name="company2_rep_title" value="<?= e($SAMPLES['company2_rep_title']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_email')) ?></label><input type="email" name="company1_email" value="<?= e($SAMPLES['company1_email']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_email')) ?></label><input type="email" name="company2_email" value="<?= e($SAMPLES['company2_email']) ?>"></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('p1_phone')) ?></label><input type="text" name="company1_phone" value="<?= e($SAMPLES['company1_phone']) ?>"></div>
          <div class="form-group"><label><?= e(t('p2_phone')) ?></label><input type="text" name="company2_phone" value="<?= e($SAMPLES['company2_phone']) ?>"></div>
        </div>

        <div class="section-title" style="font-size:15px;"><?= e(t('section_processing')) ?></div>
        <?= function_exists('render_preset_lang_picker') ? render_preset_lang_picker('processing', 'processingPresetLang') : '' ?>
        <div class="form-group">
          <label><?= e(t('presets_title')) ?></label>
          <select id="processingPresetSelect">
            <option value=""><?= e(t('preset_none')) ?></option>
            <?= render_preset_options('processing') ?>
          </select>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('purpose')) ?></label><?= render_preset_field_input('purpose', 'purpose', (string)$SAMPLES['purpose'], 'purpose_field') ?></div>
          <div class="form-group"><label><?= e(t('data_categories')) ?></label><?= render_preset_field_input('dataCategories', 'dataCategories', (string)$SAMPLES['dataCategories'], 'dataCategories_field') ?></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('data_subjects')) ?></label><?= render_preset_field_input('dataSubjects', 'dataSubjects', (string)$SAMPLES['dataSubjects'], 'dataSubjects_field') ?></div>
          <div class="form-group"><label><?= e(t('effective_date')) ?></label><?= render_preset_field_input('effectiveDate', 'effectiveDate', (string)$SAMPLES['effectiveDate'], 'effectiveDate_field') ?></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('duration')) ?></label><?= render_preset_field_input('duration', 'duration', (string)$SAMPLES['duration'], 'duration_field') ?></div>
          <div class="form-group"><label><?= e(t('notice_period')) ?></label><?= render_preset_field_input('noticePeriod', 'noticePeriod', (string)$SAMPLES['noticePeriod'], 'noticePeriod_field') ?></div>
        </div>
        <p style="margin:4px 0 18px;font-size:11.5px;color:var(--ink-4);"><?= e(t('presets_manage_hint')) ?> <a href="?tab=presets&amp;lang=<?= e($lang) ?>"><?= e(t('tab_presets')) ?> &rarr;</a></p>

        <div class="section-title" style="font-size:15px;"><?= e(t('section_commercial')) ?></div>
        <?= function_exists('render_preset_lang_picker') ? render_preset_lang_picker('commercial', 'commercialPresetLang') : '' ?>
        <div class="form-group">
          <label><?= e(t('presets_title')) ?></label>
          <select id="commercialPresetSelect">
            <option value=""><?= e(t('preset_none')) ?></option>
            <?= render_preset_options('commercial') ?>
          </select>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('contract_value')) ?></label><?= render_preset_field_input('contractValue', 'contractValue', (string)$SAMPLES['contractValue'], 'contractValue_field') ?></div>
          <div class="form-group"><label><?= e(t('currency')) ?></label><?= render_preset_field_input('currency', 'currency', 'EUR', 'currency_field') ?></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('liability_cap')) ?></label><?= render_preset_field_input('liabilityCap', 'liabilityCap', (string)$SAMPLES['liabilityCap'], 'liabilityCap_field') ?></div>
          <div class="form-group"><label><?= e(t('payment_terms')) ?></label><?= render_preset_field_input('paymentTerms', 'paymentTerms', (string)$SAMPLES['paymentTerms'], 'paymentTerms_field') ?></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('penalty_clause')) ?></label><?= render_preset_field_input('penaltyClause', 'penaltyClause', (string)$SAMPLES['penaltyClause'], 'penaltyClause_field') ?></div>
          <div class="form-group"><label><?= e(t('sla_uptime')) ?></label><?= render_preset_field_input('slaUptime', 'slaUptime', (string)$SAMPLES['slaUptime'], 'slaUptime_field') ?></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('sla_response')) ?></label><?= render_preset_field_input('slaResponse', 'slaResponse', (string)$SAMPLES['slaResponse'], 'slaResponse_field') ?></div>
          <div class="form-group"><label><?= e(t('sub_processors')) ?></label><?= render_preset_field_input('subProcessors', 'subProcessors', (string)$SAMPLES['subProcessors'], 'subProcessors_field') ?></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('confidentiality')) ?></label><?= render_preset_field_input('confidentiality', 'confidentiality', (string)$SAMPLES['confidentiality'], 'confidentiality_field') ?></div>
          <div class="form-group"><label><?= e(t('governing_law')) ?></label><?= render_preset_field_input('governingLaw', 'governingLaw', (string)$SAMPLES['governingLaw'], 'governingLaw_field') ?></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('jurisdiction')) ?></label><?= render_preset_field_input('jurisdiction', 'jurisdiction', (string)$SAMPLES['jurisdiction'], 'jurisdiction_field') ?></div>
          <div class="form-group"><label><?= e(t('insurance')) ?></label><?= render_preset_field_input('insurance', 'insurance', (string)$SAMPLES['insurance'], 'insurance_field') ?></div>
        </div>
        <div class="grid-2">
          <div class="form-group"><label><?= e(t('audit_rights')) ?></label><?= render_preset_field_input('auditRights', 'auditRights', (string)$SAMPLES['auditRights'], 'auditRights_field') ?></div>
          <div class="form-group"><label><?= e(t('extra_notes')) ?></label><?= render_preset_field_input('extraNotes', 'extraNotes', (string)$SAMPLES['extraNotes'], 'extraNotes_field') ?></div>
        </div>
        <p style="margin:4px 0 0;font-size:11.5px;color:var(--ink-4);"><?= e(t('presets_manage_hint')) ?> <a href="?tab=presets&amp;lang=<?= e($lang) ?>"><?= e(t('tab_presets')) ?> &rarr;</a></p>

        <div id="annexEditorSection">
        <div class="section-title" style="font-size:15px;"><?= e(t('section_annexes')) ?> <small><?= e(t('section_annexes_sub')) ?></small></div>
        <div class="message info">
          <?= e(t('annex_instance_note')) ?>
          &nbsp;<a href="?tab=config&amp;lang=<?= e($lang) ?>"><?= e(t('tab_config')) ?> &rarr;</a>
        </div>
        <div style="text-align:right;margin:10px 0;">
          <button type="button" class="btn btn-sm btn-outline" id="resetArticlesBtn"><?= e(t('annex_reset_all_btn')) ?></button>
        </div>
        <div id="articleEditorList"></div>
        </div>

        <div class="info-box" style="margin-bottom:20px;"><?= t('safeguard_note') ?></div>

        <?= render_preset_js() ?>

        <div id="extraLangsSection">
        <div class="section-title" style="font-size:15px;"><?= e(t('pdf_extra_langs_title')) ?> <small><?= e(t('pdf_extra_langs_sub')) ?></small></div>
        <?php if (deepl_enabled()): ?>
          <div class="message info" style="margin-bottom:10px;"><?= e(tr_t('legal')) ?></div>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:6px;margin-bottom:10px;">
            <?php foreach (deepl_languages_sorted() as $__code => $__meta): ?>
              <label style="font-weight:400;display:flex;align-items:center;gap:6px;">
                <input type="checkbox" name="extra_langs[]" value="<?= e($__code) ?>">
                <span><?= e(strtoupper($__code)) ?> — <?= e($__meta['label']) ?></span>
              </label>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="message"><?= e(tr_t('nokey')) ?></div>
        <?php endif; ?>
        </div>

        <div class="section-title" style="font-size:15px;"><?= e(t('section_sign')) ?> <small><?= e(t('section_sign_sub')) ?></small></div>
        <div class="signature-area">
          <div class="signature-box">
            <h4><?= e(t('sig_p1')) ?></h4>
            <p><?= e(t('sig_rep')) ?> <span id="rep1_display">—</span></p>
            <canvas class="signature-canvas" id="sigCanvas1" width="400" height="140"></canvas>
            <div class="signature-status" id="sigStatus1"><?= e(t('sig_not_signed')) ?></div>
            <button type="button" class="btn btn-sm btn-outline" data-clear="1" style="margin-top:6px;"><?= e(t('sig_clear')) ?></button>
          </div>
          <div class="signature-box">
            <h4><?= e(t('sig_p2')) ?></h4>
            <p><?= e(t('sig_rep')) ?> <span id="rep2_display">—</span></p>
            <canvas class="signature-canvas" id="sigCanvas2" width="400" height="140"></canvas>
            <div class="signature-status" id="sigStatus2"><?= e(t('sig_not_signed')) ?></div>
            <button type="button" class="btn btn-sm btn-outline" data-clear="2" style="margin-top:6px;"><?= e(t('sig_clear')) ?></button>
          </div>
        </div>

        <div style="text-align:right;margin-top:20px;">
          <button type="button" id="generateBtn" class="btn btn-gold"><?= e(t('btn_generate')) ?></button>
        </div>

        <div id="genError" class="message danger" style="display:none;margin-top:16px;"></div>

        <div class="qr-result" id="qrResult">
          <div class="section-title" style="font-size:15px;"><?= e(t('result_title')) ?> <small><?= e(t('result_sub')) ?></small></div>
          <div class="qr-grid">
            <div class="qr-box"><div id="qrCanvas"></div><p id="qrHint"><?= e(t('qr_hint')) ?></p></div>
            <div class="qr-meta">
              <div class="row"><span class="label"><?= e(t('meta_id')) ?></span><code id="metaId"></code></div>
              <div class="row"><span class="label"><?= e(t('meta_md5')) ?></span><code id="metaMd5"></code></div>
              <div class="row"><span class="label"><?= e(t('meta_len')) ?></span><code id="metaPayloadLen"></code></div>
              <div class="row"><span class="label"><?= e(t('meta_payload')) ?></span><code id="metaPayload"></code></div>
              <div class="qr-actions">
                <button type="button" class="btn btn-primary" id="downloadTxtBtn"><?= e(t('btn_download')) ?></button>
                <button type="button" class="btn btn-outline" id="downloadJsonBtn"><?= e(t('btn_download_json')) ?></button>
                <button type="button" class="btn btn-outline" id="printBtn"><?= e(t('btn_pdf')) ?></button>
                <button type="button" class="btn btn-outline" id="zipBtn"><?= e(t('btn_zip')) ?></button>
              </div>
              <div class="message success" style="margin-top:14px;"><?= e(t('result_note')) ?></div>
              <div class="message info" style="margin-top:10px;"><?= e(t('zip_hint')) ?></div>
            </div>
          </div>
        </div>
      </form>
    </div>

  <?php elseif ($tab === 'regen'): ?>
    <div class="section-title"><?= e(t('regen_title')) ?> <small><?= e(t('regen_sub')) ?></small></div>
    <div class="info-box"><?= t('regen_info') ?></div>

    <div class="panel">
      <form id="regenForm" onsubmit="return false;">
        <div class="form-group">
          <label><?= e(t('regen_label')) ?> *</label>
          <textarea name="regen_input" id="regenInput" class="mono" placeholder="<?= e(t('regen_ph')) ?>"></textarea>
        </div>
        <div class="scan-panel">
          <div class="scan-buttons">
            <button type="button" class="btn btn-outline btn-sm" id="startCameraBtn"><?= e(t('scan_start')) ?></button>
            <button type="button" class="btn btn-outline btn-sm" id="stopCameraBtn" style="display:none;"><?= e(t('scan_stop')) ?></button>
            <label class="btn btn-outline btn-sm" style="cursor:pointer;">
              <?= e(t('scan_upload')) ?>
              <input type="file" accept="image/*" id="scanFileInput" multiple style="display:none;">
            </label>
            <button type="button" class="btn btn-outline btn-sm" id="resetPartsBtn" style="display:none;"><?= e(t('scan_reset')) ?></button>
          </div>
          <div class="scan-video-wrap"><video id="scanVideo" playsinline muted></video></div>
          <canvas id="scanCanvasHidden" style="display:none;"></canvas>
          <div class="scan-status" id="scanStatus"></div>
        </div>
        <div style="text-align:right;margin-top:20px;">
          <button type="button" id="regenBtn" class="btn btn-gold"><?= e(t('btn_regen')) ?></button>
        </div>
        <div id="regenError" class="message danger" style="display:none;margin-top:16px;"></div>
        <div class="qr-result" id="qrResultRegen">
          <div class="section-title" style="font-size:15px;"><?= e(t('result_title')) ?> <small><?= e(t('regen_result_sub')) ?></small></div>
          <div class="qr-grid">
            <div class="qr-box"><div id="qrCanvasRegen"></div><p id="qrHintRegen"><?= e(t('regen_qr_hint')) ?></p></div>
            <div class="qr-meta">
              <div class="row"><span class="label"><?= e(t('meta_id')) ?></span><code id="metaIdRegen"></code></div>
              <div class="row"><span class="label"><?= e(t('meta_md5')) ?></span><code id="metaMd5Regen"></code></div>
              <div class="row"><span class="label"><?= e(t('meta_len')) ?></span><code id="metaPayloadLenRegen"></code></div>
              <div class="qr-actions">
                <button type="button" class="btn btn-primary" id="downloadTxtBtnRegen"><?= e(t('btn_download')) ?></button>
                <button type="button" class="btn btn-outline" id="downloadJsonBtnRegen"><?= e(t('btn_download_json')) ?></button>
                <button type="button" class="btn btn-outline" id="printBtnRegen"><?= e(t('btn_pdf')) ?></button>
                <button type="button" class="btn btn-outline" id="zipBtnRegen"><?= e(t('btn_zip')) ?></button>
              </div>
              <div class="message info" style="margin-top:10px;"><?= e(t('zip_hint')) ?></div>
            </div>
          </div>
        </div>
      </form>
    </div>

  <?php elseif ($tab === 'about'): ?>
    <div class="section-title"><?= e(t('about_title')) ?> <small><?= e(t('about_sub')) ?></small></div>
    <div class="info-box"><?= t('about_body') ?></div>
    <div class="message info"><strong><?= e(t('about_tip')) ?></strong> <?= e(t('about_tip_body')) ?></div>

  <?php elseif ($tab === 'config'):
    $configKey = contract_safe_key((string)($_GET['key'] ?? 'safeguard_scc'));
    if ($configKey === '') $configKey = 'safeguard_scc';
    $configDef = load_contract_definition($configKey);
    $configRaw = contract_json_raw($configKey);
    $configLangs = $configDef['languages'] ?? ['nl', 'en'];
    $configIsProtected = is_protected_contract($configKey);
    $configAvailable = list_available_contracts();

    function new_contract_error_key(string $reason): string {
        return match ($reason) {
            'protected' => 'config_new_contract_error_protected',
            'exists'    => 'config_new_contract_error_exists',
            'empty'     => 'config_new_contract_error_empty',
            default     => 'config_new_contract_error_generic',
        };
    }

    // Rij klikbare {{TOKEN}}-chips die per artikelpaneel wordt getoond; een
    // klik voegt het token in op de cursorpositie van het laatst-gefocuste
    // titel/tekstveld binnen datzelfde paneel (zie script onderaan).
    function render_var_toolbar(): string {
        $html = '<div class="var-toolbar"><span class="var-toolbar-label">' . e(t('ph_vars_label')) . '</span>';
        foreach (placeholder_tokens() as $pt) {
            $token = e($pt['token']);
            $desc  = e(t($pt['descKey']));
            $html .= '<button type="button" class="var-chip" data-token="{{' . $token . '}}" title="' . $desc . '">{{' . $token . '}}</button>';
        }
        $html .= '</div>';
        return $html;
    }
  ?>
    <div class="section-title"><?= e(t('config_title')) ?> <small><?= e(t('config_sub')) ?></small></div>
    <div class="info-box"><?= t('config_intro') ?></div>

    <div class="panel">
      <form method="get" class="contract-picker-form">
        <input type="hidden" name="tab" value="config">
        <div class="form-group" style="margin-bottom:0;">
          <label><?= e(t('config_picker_label')) ?></label>
          <select name="key" onchange="this.form.submit()">
            <?php foreach ($configAvailable as $k => $label): ?>
              <option value="<?= e($k) ?>" <?= $k === $configKey ? 'selected' : '' ?>>
                <?= e($label) ?><?= is_protected_contract($k) ? ' ' . e(t('config_picker_protected_suffix')) : '' ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </form>
    </div>

    <?php if (!empty($_GET['cfgsaved'])): ?>
      <div class="message success"><?= e(t('config_saved_msg')) ?></div>
    <?php elseif (!empty($_GET['contractcreated'])): ?>
      <div class="message success"><?= e(t('config_contract_created_msg')) ?></div>
    <?php elseif (!empty($_GET['contractdeleted'])): ?>
      <div class="message success"><?= e(t('config_contract_deleted_msg')) ?></div>
    <?php elseif (($_GET['cfgerror'] ?? '') === 'protected'): ?>
      <div class="message danger"><?= e(t('config_protected_save_error')) ?></div>
    <?php elseif (!empty($_GET['cfgerror'])): ?>
      <div class="message danger"><?= e(t('config_save_error')) ?></div>
    <?php elseif (!empty($_GET['newcontracterror'])): ?>
      <div class="message danger"><?= e(t(new_contract_error_key((string)$_GET['newcontracterror']))) ?></div>
    <?php endif; ?>

    <?php if ($configIsProtected): ?>
      <div class="message"><?= e(t('config_protected_notice')) ?></div>
    <?php endif; ?>

    <?php if ($configDef === null || $configRaw === null): ?>
      <div class="message danger"><?= e(t('config_not_found')) ?></div>
    <?php else: ?>
      <div class="panel">
        <div class="row"><span class="label"><?= e(t('config_current')) ?></span><code>contracts/<?= e($configKey) ?>.json</code></div>
        <div class="row"><span class="label"><?= e(t('config_version')) ?></span><code><?= e((string)($configDef['version'] ?? 1)) ?></code></div>
        <div class="row"><span class="label"><?= e(t('config_md5')) ?></span><code><?= e(md5($configRaw)) ?></code></div>
      </div>

      <div class="panel">
        <div class="section-title" style="font-size:15px;margin-top:0;"><?= e(t('config_export_title')) ?></div>
        <p style="margin-bottom:14px;"><?= t('config_export_body') ?></p>
        <form method="post">
          <input type="hidden" name="action" value="export_contract_zip">
          <input type="hidden" name="key" value="<?= e($configKey) ?>">
          <button type="submit" class="btn btn-outline"><?= e(t('config_export_btn')) ?></button>
        </form>
      </div>

      <?= function_exists('render_merge_config_panel') ? render_merge_config_panel($configKey, $configDef) : '' ?>

      <?= render_contract_translate_panel($configKey, $configDef, $configIsProtected) ?>

      <?php if (!$configIsProtected): ?>
      <div class="panel">
        <button type="button" id="deleteContractBtn" class="btn btn-outline" style="color:#a33;border-color:#a33;"><?= e(t('config_delete_contract_btn')) ?></button>
        <div id="deleteContractConfirm" style="display:none;margin-top:12px;">
          <div class="message danger" style="margin-bottom:10px;"><?= e(t('config_delete_contract_confirm_label')) ?></div>
          <form method="post" style="display:inline;">
            <input type="hidden" name="action" value="delete_contract">
            <input type="hidden" name="key" value="<?= e($configKey) ?>">
            <button type="submit" class="btn btn-gold" style="background:#a33;border-color:#a33;"><?= e(t('config_delete_contract_yes')) ?></button>
          </form>
          <button type="button" id="deleteContractCancel" class="btn btn-outline"><?= e(t('config_delete_contract_cancel')) ?></button>
        </div>
      </div>
      <script>
      (function() {
        'use strict';
        var btn = document.getElementById('deleteContractBtn');
        var confirmBox = document.getElementById('deleteContractConfirm');
        var cancelBtn = document.getElementById('deleteContractCancel');
        if (!btn || !confirmBox || !cancelBtn) return;
        btn.addEventListener('click', function() { btn.style.display = 'none'; confirmBox.style.display = 'block'; });
        cancelBtn.addEventListener('click', function() { confirmBox.style.display = 'none'; btn.style.display = ''; });
      })();
      </script>
      <?php endif; ?>

      <div class="panel">
        <div class="section-title" style="font-size:15px;margin-top:0;"><?= e(t('config_create_new_title')) ?></div>
        <p style="margin-bottom:14px;"><?= e(t('config_create_new_sub')) ?></p>
        <form method="post">
          <input type="hidden" name="action" value="create_contract">
          <div class="grid-3">
            <div class="form-group">
              <label><?= e(t('config_new_contract_key_label')) ?></label>
              <input type="text" class="mono" name="new_key" placeholder="<?= e(t('config_new_contract_key_placeholder')) ?>" required>
            </div>
            <div class="form-group">
              <label><?= e(t('config_new_contract_title_label')) ?></label>
              <input type="text" name="new_title" placeholder="<?= e(t('config_new_contract_title_placeholder')) ?>">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label><?= e(t('config_new_contract_clone_label')) ?></label>
              <select name="clone_from">
                <option value=""><?= e(t('config_new_contract_clone_blank')) ?></option>
                <?php foreach ($configAvailable as $k => $label): ?>
                  <option value="<?= e($k) ?>" <?= $k === $configKey ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div style="text-align:right;margin-top:8px;">
            <button type="submit" class="btn btn-gold"><?= e(t('config_new_contract_create_btn')) ?></button>
          </div>
        </form>
      </div>

      <form method="post" id="contractConfigForm">
        <input type="hidden" name="action" value="save_contract_config">
        <input type="hidden" name="key" value="<?= e($configKey) ?>">

        <div id="existingArticlesContainer">
        <?php foreach ($configDef['articles'] as $artKey => $byLang): ?>
          <div class="panel" data-existing-article-panel>
            <div class="section-title config-article-header" style="font-size:13px;margin-top:0;margin-bottom:14px;">
              <span class="config-article-title"><?= e(config_article_label((string)$artKey)) ?> <small><?= e((string)$artKey) ?></small></span>
              <?php if (!$configIsProtected): ?>
              <span class="config-article-controls">
                <button type="button" class="btn-move btn-move-up" title="<?= e(t('config_move_up_label')) ?>">▲</button>
                <button type="button" class="btn-move btn-move-down" title="<?= e(t('config_move_down_label')) ?>">▼</button>
                <button type="button" class="btn-remove-article btn-remove-existing"><?= e(t('config_remove_article_btn')) ?></button>
              </span>
              <?php endif; ?>
            </div>
            <?php if (!$configIsProtected): ?>
            <div class="marked-for-removal-notice message danger" style="display:none;">
              <?= e(t('config_marked_for_removal')) ?>
              <button type="button" class="btn btn-outline btn-undo-remove" style="margin-left:10px;"><?= e(t('config_undo_remove_btn')) ?></button>
            </div>
            <?php endif; ?>
            <div class="article-fields">
              <?php if (!$configIsProtected): ?><?= render_var_toolbar() ?><?php endif; ?>
              <div class="grid-3">
                <?php foreach ($configLangs as $l): $entry = $byLang[$l] ?? ['title' => '', 'body' => '']; ?>
                  <div class="form-group">
                    <label><?= e(strtoupper($l)) ?> — <?= e(t('config_field_title')) ?></label>
                    <input type="text" name="articles[<?= e((string)$artKey) ?>][<?= e($l) ?>][title]" value="<?= e($entry['title'] ?? '') ?>" <?= $configIsProtected ? 'readonly' : '' ?>>
                  </div>
                <?php endforeach; ?>
              </div>
              <div class="grid-3">
                <?php foreach ($configLangs as $l): $entry = $byLang[$l] ?? ['title' => '', 'body' => '']; ?>
                  <div class="form-group" style="margin-bottom:0;">
                    <label><?= e(strtoupper($l)) ?> — <?= e(t('config_field_body')) ?></label>
                    <textarea name="articles[<?= e((string)$artKey) ?>][<?= e($l) ?>][body]" class="mono annex-textarea" <?= $configIsProtected ? 'readonly' : '' ?>><?= e($entry['body'] ?? '') ?></textarea>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        </div>

        <?php if (!$configIsProtected): ?>
        <div id="newArticlesContainer"></div>

        <div style="text-align:left;margin-top:8px;margin-bottom:8px;">
          <button type="button" id="addArticleBtn" class="btn btn-outline"><?= e(t('config_add_article_btn')) ?></button>
        </div>

        <div style="text-align:right;margin-top:8px;">
          <button type="submit" class="btn btn-gold"><?= e(t('config_save_btn')) ?></button>
        </div>
        <?php endif; ?>
      </form>

      <?php if (!$configIsProtected): ?>
      <template id="newArticleTemplate">
        <div class="panel" data-new-article-panel>
          <div class="section-title" style="font-size:13px;margin-top:0;margin-bottom:14px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
            <label style="font-weight:600;" for=""><?= e(t('config_new_article_key_label')) ?></label>
            <input type="text" class="mono new-article-key-input" placeholder="<?= e(t('config_new_article_key_placeholder')) ?>" style="max-width:220px;">
            <button type="button" class="btn btn-outline btn-remove-article" style="margin-left:auto;"><?= e(t('config_remove_article_btn')) ?></button>
          </div>
          <div class="new-article-dup-warning message danger" style="display:none;margin-bottom:12px;"><?= e(t('config_duplicate_key_warning')) ?></div>
          <?= render_var_toolbar() ?>
          <div class="grid-3">
            <?php foreach ($configLangs as $l): ?>
              <div class="form-group">
                <label><?= e(strtoupper($l)) ?> — <?= e(t('config_field_title')) ?></label>
                <input type="text" data-lang="<?= e($l) ?>" data-field="title">
              </div>
            <?php endforeach; ?>
          </div>
          <div class="grid-3">
            <?php foreach ($configLangs as $l): ?>
              <div class="form-group" style="margin-bottom:0;">
                <label><?= e(strtoupper($l)) ?> — <?= e(t('config_field_body')) ?></label>
                <textarea data-lang="<?= e($l) ?>" data-field="body" class="mono annex-textarea"></textarea>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </template>

      <script>
      (function() {
        'use strict';
        var existingKeys = <?= json_encode(array_map('strval', array_keys($configDef['articles']))) ?>;
        var container = document.getElementById('newArticlesContainer');
        var addBtn = document.getElementById('addArticleBtn');
        var tpl = document.getElementById('newArticleTemplate');
        if (!container || !addBtn || !tpl) return;

        function sanitizeKey(raw) {
          return (raw || '').replace(/[^A-Za-z0-9._]/g, '');
        }

        function updateNames(panel) {
          var input = panel.querySelector('.new-article-key-input');
          var key = sanitizeKey(input.value);
          var warning = panel.querySelector('.new-article-dup-warning');
          panel.querySelectorAll('[data-lang]').forEach(function(el) {
            if (key === '') {
              el.removeAttribute('name');
            } else {
              el.setAttribute('name', 'articles[' + key + '][' + el.getAttribute('data-lang') + '][' + el.getAttribute('data-field') + ']');
            }
          });
          if (warning) warning.style.display = (key !== '' && existingKeys.indexOf(key) !== -1) ? 'block' : 'none';
        }

        addBtn.addEventListener('click', function() {
          var node = tpl.content.cloneNode(true);
          var panel = node.querySelector('[data-new-article-panel]');
          var keyInput = panel.querySelector('.new-article-key-input');
          keyInput.addEventListener('input', function() { updateNames(panel); });
          panel.querySelector('.btn-remove-article').addEventListener('click', function() { panel.remove(); });
          container.appendChild(node);
          keyInput.focus();
        });

        // Variabele-chips ({{P1}}, {{A1}}, …): een klik voegt het token in op
        // de cursorpositie van het laatst-gefocuste titel/tekstveld binnen
        // hetzelfde artikelpaneel. Werkt via event delegation op het formulier
        // zelf, zodat het ook meteen werkt voor panelen die pas na het laden
        // van de pagina worden toegevoegd (nieuw artikel).
        var configForm = document.getElementById('contractConfigForm');
        if (configForm) {
          configForm.addEventListener('focusin', function(e) {
            if (!(e.target.matches('input[type="text"], textarea'))) return;
            if (e.target.classList.contains('new-article-key-input')) return;
            var panel = e.target.closest('.panel');
            if (panel) panel.__lastVarField = e.target;
          });

          configForm.addEventListener('click', function(e) {
            var chip = e.target.closest('.var-chip');
            if (!chip) return;
            e.preventDefault();
            var panel = chip.closest('.panel');
            if (!panel) return;
            var field = panel.__lastVarField || panel.querySelector('.grid-3 textarea, .grid-3 input[type="text"]');
            if (!field) return;
            var token = chip.getAttribute('data-token') || '';
            var start = (field.selectionStart != null) ? field.selectionStart : field.value.length;
            var end = (field.selectionEnd != null) ? field.selectionEnd : field.value.length;
            field.value = field.value.slice(0, start) + token + field.value.slice(end);
            var newPos = start + token.length;
            field.focus();
            if (field.setSelectionRange) field.setSelectionRange(newPos, newPos);
            panel.__lastVarField = field;
            // Programmatic value changes don't fire native input events, but
            // the page's autoGrow-on-input listener (for .annex-textarea)
            // needs one to resize the box — dispatch it explicitly.
            field.dispatchEvent(new Event('input', { bubbles: true }));
          });
        }

        // Bestaande artikelen: verplaats omhoog/omlaag (verandert simpelweg
        // de DOM-volgorde van de panelen — bij opslaan worden de velden in
        // die volgorde geserialiseerd, dus geen backend-wijziging nodig) en
        // verwijderen/ongedaan maken (velden worden niet meegestuurd zolang
        // een paneel als "te verwijderen" is gemarkeerd; pas na opslaan is
        // het echt weg uit contracts/safeguard_scc.json).
        var existingContainer = document.getElementById('existingArticlesContainer');
        if (existingContainer) {
          var getExistingPanels = function() {
            return Array.prototype.slice.call(existingContainer.querySelectorAll(':scope > [data-existing-article-panel]'));
          };

          var updateMoveButtons = function() {
            var panels = getExistingPanels();
            panels.forEach(function(p, i) {
              var up = p.querySelector('.btn-move-up');
              var down = p.querySelector('.btn-move-down');
              if (up) up.disabled = (i === 0);
              if (down) down.disabled = (i === panels.length - 1);
            });
          };

          var setRemoved = function(panel, removed) {
            panel.classList.toggle('marked-for-removal', removed);
            if (removed) {
              panel.querySelectorAll('input[name], textarea[name]').forEach(function(el) {
                el.setAttribute('data-orig-name', el.getAttribute('name'));
                el.removeAttribute('name');
              });
            } else {
              panel.querySelectorAll('[data-orig-name]').forEach(function(el) {
                el.setAttribute('name', el.getAttribute('data-orig-name'));
                el.removeAttribute('data-orig-name');
              });
            }
            var notice = panel.querySelector('.marked-for-removal-notice');
            if (notice) notice.style.display = removed ? 'block' : 'none';
          };

          existingContainer.addEventListener('click', function(e) {
            var panel = e.target.closest('[data-existing-article-panel]');
            if (!panel) return;

            if (e.target.closest('.btn-move-up')) {
              var prev = panel.previousElementSibling;
              if (prev && prev.hasAttribute('data-existing-article-panel')) {
                existingContainer.insertBefore(panel, prev);
                updateMoveButtons();
                panel.scrollIntoView({ block: 'nearest' });
              }
              return;
            }
            if (e.target.closest('.btn-move-down')) {
              var next = panel.nextElementSibling;
              if (next && next.hasAttribute('data-existing-article-panel')) {
                existingContainer.insertBefore(next, panel);
                updateMoveButtons();
                panel.scrollIntoView({ block: 'nearest' });
              }
              return;
            }
            if (e.target.closest('.btn-remove-existing')) {
              setRemoved(panel, true);
              return;
            }
            if (e.target.closest('.btn-undo-remove')) {
              setRemoved(panel, false);
              return;
            }
          });

          updateMoveButtons();
        }
      })();
      </script>
      <?php endif; ?>
    <?php endif; ?>

  <?php elseif ($tab === 'contracts'):
    // Alleen-lezen overzicht: geen enkele actie hier schrijft naar disk.
    // Bewerken/vertalen/klonen/verwijderen blijft voorbehouden aan het
    // tabblad "Configuratie contracten" (action=..._contract*, translate_contract).
    $viewAvailable = list_available_contracts();
    $viewKey = contract_safe_key((string)($_GET['key'] ?? ''));
    if ($viewKey === '' || !isset($viewAvailable[$viewKey])) {
        $viewKey = (string)(array_key_first($viewAvailable) ?? '');
    }
    $viewDef   = $viewKey !== '' ? load_contract_definition($viewKey) : null;
    $viewRaw   = $viewKey !== '' ? contract_json_raw($viewKey) : null;
    $viewLangs = is_array($viewDef['languages'] ?? null) ? $viewDef['languages'] : [];
    $viewLang  = (string)($_GET['viewlang'] ?? '');
    if ($viewLang === '' || !in_array($viewLang, $viewLangs, true)) {
        $viewLang = (string)($viewLangs[0] ?? '');
    }
    $viewMode = ((string)($_GET['viewmode'] ?? 'filled')) === 'raw' ? 'raw' : 'filled';

    // Voor de leesweergave vullen we {{TOKEN}}-placeholders in met dezelfde
    // voorbeeldgegevens (bedrijfsnaam, adres, vertegenwoordiger, ...) die ook
    // als standaardinvulling in het tabblad "Nieuw contract" staan ($uiRecord,
    // gebaseerd op $SAMPLES). Zo lees je meteen "Acme Nederland B.V." in
    // plaats van de kale code {{P1}}. Dit zijn illustratieve voorbeeldwaarden,
    // geen echt ondertekend contract — vandaar de duidelijke melding eronder
    // en de gele markering per ingevulde waarde (hover toont het token).
    $viewSampleRecord = $uiRecord;
    $viewSampleRecord['lang'] = in_array($viewLang, UI_LANGS, true) ? $viewLang : $lang;

    function render_readonly_placeholder_text(string $text, array $sampleRecord): string {
        $escaped = e($text);
        return (string)preg_replace_callback('/\{\{([A-Za-z0-9_]+)\}\}/', function (array $m) use ($sampleRecord): string {
            $raw    = '{{' . $m[1] . '}}';
            $filled = ph($raw, $sampleRecord);
            if ($filled === $raw) return e($raw); // onbekend token: ongewijzigd tonen
            return '<span class="ph-fill" title="' . e($raw) . '">' . e($filled) . '</span>';
        }, $escaped);
    }
  ?>
    <div class="section-title"><?= e(t('view_title')) ?> <small><?= e(t('view_sub')) ?></small></div>
    <div class="info-box"><?= e(t('view_intro')) ?></div>

    <div class="panel">
      <div class="section-title" style="font-size:15px;margin-top:0;"><?= e(t('view_list_title')) ?></div>
      <?php if ($viewAvailable === []): ?>
        <p><?= e(t('view_empty')) ?></p>
      <?php else: ?>
      <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead>
            <tr>
              <?php foreach (['view_col_key', 'view_col_title', 'view_col_version', 'view_col_languages', 'view_col_articles', 'view_col_protected'] as $colKey): ?>
                <th style="text-align:left;padding:8px 10px;border-bottom:2px solid var(--ink);font-size:10.5px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-3);"><?= e(t($colKey)) ?></th>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($viewAvailable as $k => $label): $d = load_contract_definition($k); ?>
              <tr style="<?= $k === $viewKey ? 'background:var(--paper-2);' : '' ?>">
                <td style="padding:8px 10px;border-bottom:1px solid var(--rule-hair);font-family:var(--mono);">
                  <a href="?tab=contracts&amp;lang=<?= e($lang) ?>&amp;key=<?= e($k) ?>"><?= e($k) ?></a>
                </td>
                <td style="padding:8px 10px;border-bottom:1px solid var(--rule-hair);"><?= e($label) ?></td>
                <td style="padding:8px 10px;border-bottom:1px solid var(--rule-hair);font-family:var(--mono);"><?= e((string)($d['version'] ?? 1)) ?></td>
                <td style="padding:8px 10px;border-bottom:1px solid var(--rule-hair);font-family:var(--mono);"><?= e(strtoupper(implode(', ', is_array($d['languages'] ?? null) ? $d['languages'] : []))) ?></td>
                <td style="padding:8px 10px;border-bottom:1px solid var(--rule-hair);font-family:var(--mono);"><?= e((string)count(is_array($d['articles'] ?? null) ? $d['articles'] : [])) ?></td>
                <td style="padding:8px 10px;border-bottom:1px solid var(--rule-hair);"><?= is_protected_contract($k) ? e(t('view_protected_yes')) : e(t('view_protected_no')) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

    <?php if ($viewKey === '' || $viewDef === null || $viewRaw === null): ?>
      <?php if ($viewAvailable !== []): ?>
        <div class="message danger"><?= e(t('view_not_found')) ?></div>
      <?php endif; ?>
    <?php else: ?>

      <div class="panel">
        <form method="get" class="contract-picker-form">
          <input type="hidden" name="tab" value="contracts">
          <input type="hidden" name="lang" value="<?= e($lang) ?>">
          <div class="form-group" style="margin-bottom:0;">
            <label><?= e(t('view_picker_label')) ?></label>
            <select name="key" onchange="this.form.submit()">
              <?php foreach ($viewAvailable as $k => $label): ?>
                <option value="<?= e($k) ?>" <?= $k === $viewKey ? 'selected' : '' ?>>
                  <?= e($label) ?><?= is_protected_contract($k) ? ' ' . e(t('config_picker_protected_suffix')) : '' ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </form>
      </div>

      <div class="panel">
        <div class="row"><span class="label"><?= e(t('config_current')) ?></span><code>contracts/<?= e($viewKey) ?>.json</code></div>
        <div class="row"><span class="label"><?= e(t('config_version')) ?></span><code><?= e((string)($viewDef['version'] ?? 1)) ?></code></div>
        <div class="row"><span class="label"><?= e(t('config_md5')) ?></span><code><?= e(md5($viewRaw)) ?></code></div>
      </div>

      <?= render_translation_status_table($viewDef) ?>

      <?php if ($viewLangs !== []): ?>
      <div class="panel">
        <form method="get" class="contract-picker-form">
          <input type="hidden" name="tab" value="contracts">
          <input type="hidden" name="lang" value="<?= e($lang) ?>">
          <input type="hidden" name="key" value="<?= e($viewKey) ?>">
          <div class="grid-2">
            <div class="form-group" style="margin-bottom:0;">
              <label><?= e(t('view_lang_label')) ?></label>
              <select name="viewlang" onchange="this.form.submit()">
                <?php
                // Alfabetisch op (Nederlandse) taalnaam, net als de andere
                // taallijsten in de interface, i.p.v. de opslagvolgorde uit
                // het JSON-bestand.
                $__viewLangsSorted = $viewLangs;
                usort($__viewLangsSorted, function ($a, $b): int {
                    return strnatcasecmp(deepl_lang_label((string)$a), deepl_lang_label((string)$b));
                });
                foreach ($__viewLangsSorted as $l): if (!deepl_lang_known($l)) continue; ?>
                  <option value="<?= e($l) ?>" <?= $l === $viewLang ? 'selected' : '' ?>><?= e(strtoupper($l) . ' — ' . deepl_lang_label($l)) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label><?= e(t('view_mode_label')) ?></label>
              <select name="viewmode" onchange="this.form.submit()">
                <option value="filled" <?= $viewMode === 'filled' ? 'selected' : '' ?>><?= e(t('view_mode_filled')) ?></option>
                <option value="raw" <?= $viewMode === 'raw' ? 'selected' : '' ?>><?= e(t('view_mode_raw')) ?></option>
              </select>
            </div>
          </div>
        </form>
      </div>

      <div class="message"><?= e($viewMode === 'raw' ? t('view_raw_note') : t('view_sample_note')) ?></div>

      <div class="panel">
        <div class="section-title" style="font-size:15px;margin-top:0;"><?= e(t('view_generate_title')) ?></div>
        <p style="margin-bottom:14px;"><?= e(t('view_generate_sub')) ?></p>
        <div style="text-align:right;">
          <button type="button" id="generateContractsBtn" class="btn btn-gold" data-key="<?= e($viewKey) ?>" data-lang="<?= e($viewLang) ?>"><?= e(t('view_generate_btn')) ?></button>
        </div>
        <div id="genErrorContracts" class="message danger" style="display:none;margin-top:16px;"></div>
        <div class="qr-result" id="qrResultContracts">
          <div class="section-title" style="font-size:15px;"><?= e(t('result_title')) ?> <small><?= e(t('view_generate_result_sub')) ?></small></div>
          <div class="qr-grid">
            <div class="qr-box"><div id="qrCanvasContracts"></div><p id="qrHintContracts"><?= e(t('qr_hint')) ?></p></div>
            <div class="qr-meta">
              <div class="row"><span class="label"><?= e(t('meta_id')) ?></span><code id="metaIdContracts"></code></div>
              <div class="row"><span class="label"><?= e(t('meta_md5')) ?></span><code id="metaMd5Contracts"></code></div>
              <div class="row"><span class="label"><?= e(t('meta_len')) ?></span><code id="metaPayloadLenContracts"></code></div>
              <div class="qr-actions">
                <button type="button" class="btn btn-primary" id="downloadTxtBtnContracts"><?= e(t('btn_download')) ?></button>
                <button type="button" class="btn btn-outline" id="downloadJsonBtnContracts"><?= e(t('btn_download_json')) ?></button>
                <button type="button" class="btn btn-outline" id="printBtnContracts"><?= e(t('btn_pdf')) ?></button>
                <button type="button" class="btn btn-outline" id="zipBtnContracts"><?= e(t('btn_zip')) ?></button>
              </div>
              <div class="message info" style="margin-top:10px;"><?= e(t('zip_hint')) ?></div>
            </div>
          </div>
        </div>
      </div>

      <?php foreach ($viewDef['articles'] as $artKey => $byLang):
          if (!is_array($byLang)) continue;
          $entry = $byLang[$viewLang] ?? null;
          if (!is_array($entry)) continue;
      ?>
        <div class="panel">
          <div class="section-title" style="font-size:13px;margin-top:0;margin-bottom:14px;">
            <?= e(config_article_label((string)$artKey)) ?> <small><?= e((string)$artKey) ?></small>
          </div>
          <?php if (trim((string)($entry['title'] ?? '')) !== ''): ?>
            <div style="font-weight:600;font-size:15px;margin-bottom:10px;"><?= $viewMode === 'raw' ? e($entry['title']) : render_readonly_placeholder_text($entry['title'], $viewSampleRecord) ?></div>
          <?php endif; ?>
          <div style="white-space:pre-wrap;font-family:var(--mono);font-size:13px;line-height:1.7;color:var(--ink-2);"><?= $viewMode === 'raw' ? e($entry['body'] ?? '') : render_readonly_placeholder_text($entry['body'] ?? '', $viewSampleRecord) ?></div>
        </div>
      <?php endforeach; ?>
      <?php endif; ?>
    <?php endif; ?>
  <?php elseif ($tab === 'presets'): ?>
    <?= render_presets_tab() ?>
  <?php endif; ?>

  <div class="footer"><?= e(t('footer')) ?></div>
</div>

<script>
window.__LANG__ = <?= json_encode([
    'lang'             => $lang,
    'scc_module'       => t('wizard_scc_module'),
    'removed'          => t('article_removed'),
    'removed_annex'    => t('annex_removed'),
    'scan_part'        => t('scan_part'),
    'scan_all_done'    => t('scan_all_done'),
    'scan_no_qr'       => t('scan_no_qr'),
    'scan_camera_err'  => t('scan_camera_err'),
    'scan_camera_on'   => t('scan_camera_on'),
    'qr_single'        => t('qr_single'),
    'qr_multi'         => t('qr_multi'),
    'yes'              => t('yes'),
    'no'               => t('no'),
    'status_signed'    => t('status_signed'),
    'sig_not_signed'   => t('sig_not_signed'),
    'unit_chars'       => t('unit_chars'),
    'error_zip_empty'  => t('error_zip_empty'),
    'error_empty_input'=> t('error_empty_input'),
    'msg_parts_reset'  => t('msg_parts_reset'),
    'msg_qr_scanned_filled' => t('msg_qr_scanned_filled'),
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
window.__ICONS_ON__ = <?= icons_enabled() ? 'true' : 'false' ?>;
function withIcon(icon, text) { return (window.__ICONS_ON__ ? icon + ' ' : '') + text; }
// Small multilingual helper for ad-hoc UI strings that aren't backed by a t()
// dictionary key. Picks the branch matching the active UI language
// (en/nl/de/es/fr), defaulting to English when a branch is omitted.
function L3(en, nl, de, es, fr) {
  const l = (window.__LANG__ && window.__LANG__.lang) || 'en';
  if (l === 'nl') return nl;
  if (l === 'de') return de;
  if (l === 'es') return es || en;
  if (l === 'fr') return fr || en;
  return en;
}

(function() {
  'use strict';

  const pads = {};
  function initPad(n) {
    const canvas = document.getElementById('sigCanvas' + n);
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    canvas.height = Math.max(1, Math.floor(rect.height * dpr));
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#000';
    let drawing = false, lastX = 0, lastY = 0, hasContent = false;
    function getPos(e) {
      const r = canvas.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      return { x: clientX - r.left, y: clientY - r.top };
    }
    function start(e) { e.preventDefault(); drawing = true; const p = getPos(e); lastX = p.x; lastY = p.y; ctx.beginPath(); ctx.arc(lastX, lastY, ctx.lineWidth / 2, 0, Math.PI * 2); ctx.fillStyle = '#000'; ctx.fill(); hasContent = true; updateStatus(n, true); }
    function move(e) { if (!drawing) return; e.preventDefault(); const p = getPos(e); ctx.beginPath(); ctx.moveTo(lastX, lastY); ctx.lineTo(p.x, p.y); ctx.stroke(); lastX = p.x; lastY = p.y; }
    function end(e) { if (e) e.preventDefault(); drawing = false; }
    canvas.addEventListener('mousedown', start); canvas.addEventListener('mousemove', move);
    canvas.addEventListener('mouseup', end); canvas.addEventListener('mouseleave', end);
    canvas.addEventListener('touchstart', start, { passive: false });
    canvas.addEventListener('touchmove', move, { passive: false });
    canvas.addEventListener('touchend', end); canvas.addEventListener('touchcancel', end);
    pads[n] = { canvas, ctx, get hasContent() { return hasContent; }, reset() { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.restore(); hasContent = false; updateStatus(n, false); } };
  }
  function updateStatus(n, signed) {
    const el = document.getElementById('sigStatus' + n); if (!el) return;
    el.textContent = signed
      ? withIcon('✅', (window.__LANG__ && window.__LANG__.status_signed) || 'Signed')
      : ((window.__LANG__ && window.__LANG__.sig_not_signed) || '— Not signed yet —');
    el.style.color = signed ? '#000' : '#6e6e6e';
  }
  document.querySelectorAll('[data-clear]').forEach(btn => {
    btn.addEventListener('click', function() { const n = this.getAttribute('data-clear'); if (pads[n]) pads[n].reset(); });
  });
  document.querySelector('input[name="company1_rep"]')?.addEventListener('input', function() { document.getElementById('rep1_display').textContent = this.value || '—'; });
  document.querySelector('input[name="company2_rep"]')?.addEventListener('input', function() { document.getElementById('rep2_display').textContent = this.value || '—'; });
  window.addEventListener('DOMContentLoaded', function() {
    const r1 = document.querySelector('input[name="company1_rep"]');
    const r2 = document.querySelector('input[name="company2_rep"]');
    if (r1) document.getElementById('rep1_display').textContent = r1.value || '—';
    if (r2) document.getElementById('rep2_display').textContent = r2.value || '—';
  });
  // Rendert de handtekening op een wit canvas van de gevraagde afmeting en
  // drukt elke pixel plat naar zuiver zwart of wit (1-bit drempel). Een
  // handtekening heeft geen grijstinten nodig; dit haalt alle
  // anti-aliasing-grijswaarden weg zodat PNG's lossless compressie veel
  // grotere, volkomen egale vlakken ziet dan bij een gewone (grijswaarden-)
  // PNG of, erger nog, een JPEG.
  function renderThresholdedSignature(src, maxW, maxH, threshold) {
    const tmp = document.createElement('canvas');
    const scale = Math.min(maxW / src.width, maxH / src.height, 1);
    tmp.width = Math.max(1, Math.round(src.width * scale));
    tmp.height = Math.max(1, Math.round(src.height * scale));
    const ctx = tmp.getContext('2d');
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, tmp.width, tmp.height);
    ctx.drawImage(src, 0, 0, tmp.width, tmp.height);
    try {
      const imgData = ctx.getImageData(0, 0, tmp.width, tmp.height);
      const d = imgData.data;
      for (let i = 0; i < d.length; i += 4) {
        const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
        const v = gray < threshold ? 0 : 255;
        d[i] = v; d[i + 1] = v; d[i + 2] = v; d[i + 3] = 255;
      }
      ctx.putImageData(imgData, 0, 0);
    } catch (e) { /* getImageData kan falen bij een canvas met tainted origin; dan gewoon ongethresholded doorgaan */ }
    return tmp.toDataURL('image/png');
  }

  function collectSignatures() {
    // PNG in plaats van JPEG: een handtekening is in essentie dunne zwarte
    // lijnen op een vrijwel egale witte ondergrond, en dat is precies het
    // soort beeld waar JPEG's blokgebaseerde compressie slecht op scoort
    // (DCT-artefacten + overhead, zelfs op lege vlakken) terwijl PNG's
    // lossless compressie zulke grote egale vlakken bijna gratis wegwerkt.
    // Bovenop de 1-bit drempel (zie renderThresholdedSignature) proberen we
    // hieronder ook nog een paar kleinere formaten als een handtekening
    // ondanks dat alles nog te groot blijft (een zeer drukke/volle
    // handtekening met veel elkaar overlappende lijnen): zo blijft ook het
    // slechtste geval ruim binnen 1-2 QR-codes in plaats van de 20+
    // QR-codes die nodig waren met de oude JPEG-encoding.
    const SIG_BUDGET = 1400; // richtwaarde per handtekening (base64-tekens)
    const SIZE_STEPS = [[300, 100], [220, 73], [150, 50]];
    ['1', '2'].forEach(n => {
      const pad = pads[n]; const input = document.getElementById('sig' + n + '_input');
      if (!pad || !input) return;
      if (!pad.hasContent) { input.value = ''; return; }
      const src = pad.canvas;
      let dataUrl = '';
      for (let i = 0; i < SIZE_STEPS.length; i++) {
        const [w, h] = SIZE_STEPS[i];
        dataUrl = renderThresholdedSignature(src, w, h, 180);
        if (dataUrl.length <= SIG_BUDGET || i === SIZE_STEPS.length - 1) break;
      }
      input.value = dataUrl;
    });
  }
  initPad('1'); initPad('2');
  let resizeTimer;
  window.addEventListener('resize', function() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
      ['1', '2'].forEach(n => {
        const pad = pads[n];
        if (pad && !pad.hasContent) {
          const canvas = document.getElementById('sigCanvas' + n);
          if (canvas) { const fresh = canvas.cloneNode(false); canvas.parentNode.replaceChild(fresh, canvas); }
          initPad(n);
        }
      });
    }, 250);
  });

  function autoGrow(el) { if (!el || el.tagName !== 'TEXTAREA') return; el.style.height = 'auto'; el.style.height = (el.scrollHeight + 2) + 'px'; }
  document.querySelectorAll('.annex-textarea').forEach(ta => { autoGrow(ta); ta.addEventListener('input', function() { autoGrow(this); }); ta.addEventListener('change', function() { autoGrow(this); }); });

  document.getElementById('fillSampleBtn')?.addEventListener('click', () => { setTimeout(() => document.querySelectorAll('.annex-textarea').forEach(autoGrow), 0); });
  document.getElementById('clearAllBtn')?.addEventListener('click', () => { setTimeout(() => document.querySelectorAll('.annex-textarea').forEach(autoGrow), 0); });

  const SAMPLES = <?= json_encode($SAMPLES, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  const ARTICLE_DEFS = <?= json_encode($articleDefsForJs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

  // --- Bedrijfsgegevens laden uit JSON (Partij 1 / Partij 2) ---------------
  // Los bestand per partij, herkent een kleine set generieke velden en zet ze
  // om naar de company1_*/company2_*-formuliervelden. Rol-synoniemen (EN/NL/DE)
  // worden vertaald naar de vaste interne NL-waarde die scc_module() verwacht.
  const COMPANY_JSON_FIELDS = ['name', 'address', 'country', 'kvk', 'vat', 'iban', 'rep', 'rep_title', 'email', 'phone', 'role'];
  const COMPANY_JSON_ALIASES = {
    company_name: 'name', naam: 'name', bedrijfsnaam: 'name', firma: 'name', firmenname: 'name',
    adres: 'address', straat: 'address', anschrift: 'address',
    land: 'country', country_name: 'country',
    kvk_number: 'kvk', kvknummer: 'kvk', chamber_of_commerce: 'kvk', registration_no: 'kvk', handelsregister: 'kvk',
    vat_number: 'vat', btw: 'vat', btwnummer: 'vat', ust_id: 'vat', ustidnr: 'vat',
    iban_number: 'iban', bankrekening: 'iban', bank_account: 'iban',
    representative: 'rep', contactpersoon: 'rep', vertegenwoordiger: 'rep', ansprechpartner: 'rep',
    representative_title: 'rep_title', functie: 'rep_title', title: 'rep_title', funktion: 'rep_title', job_title: 'rep_title',
    'e-mail': 'email', mail: 'email', emailaddress: 'email', e_mail: 'email',
    telephone: 'phone', telefoon: 'phone', tel: 'phone', telefon: 'phone',
    rol: 'role', rolle: 'role',
  };
  const COMPANY_ROLE_MAP = {
    controller: 'verwerkingsverantwoordelijke', verwerkingsverantwoordelijke: 'verwerkingsverantwoordelijke', verantwortlicher: 'verwerkingsverantwoordelijke',
    processor: 'verwerker', verwerker: 'verwerker', auftragsverarbeiter: 'verwerker',
    joint: 'gezamenlijke verwerkingsverantwoordelijke', joint_controller: 'gezamenlijke verwerkingsverantwoordelijke',
    'gezamenlijke verwerkingsverantwoordelijke': 'gezamenlijke verwerkingsverantwoordelijke',
    'gemeinsamer verantwortlicher': 'gezamenlijke verwerkingsverantwoordelijke',
  };
  function normalizeCompanyJson(raw) {
    const out = {};
    if (!raw || typeof raw !== 'object') return out;
    Object.keys(raw).forEach(function(k) {
      const norm = String(k).trim().toLowerCase().replace(/[\s-]+/g, '_');
      const field = COMPANY_JSON_FIELDS.indexOf(norm) !== -1 ? norm : COMPANY_JSON_ALIASES[norm];
      if (!field) return;
      let val = raw[k];
      if (val === null || val === undefined) return;
      if (field === 'role' && typeof val === 'string') {
        val = COMPANY_ROLE_MAP[val.trim().toLowerCase()] || val;
      }
      out[field] = String(val);
    });
    return out;
  }
  function applyCompanyJson(prefix, data) {
    const form = document.getElementById('contractForm'); if (!form) return 0;
    let applied = 0;
    Object.keys(data).forEach(function(field) {
      const el = form.elements[prefix + '_' + field]; if (!el) return;
      if (el.tagName === 'SELECT') {
        const opt = Array.from(el.options).find(function(o) { return o.value === data[field]; });
        if (opt) { el.value = data[field]; applied++; }
      } else {
        el.value = data[field]; applied++;
      }
    });
    const rep = form.elements[prefix + '_rep'];
    const dispEl = document.getElementById(prefix === 'company1' ? 'rep1_display' : 'rep2_display');
    if (rep && dispEl) dispEl.textContent = rep.value || '—';
    return applied;
  }
  function showLoadJsonMessage(text, isError) {
    const box = document.getElementById('loadJsonMsg'); if (!box) return;
    box.textContent = text;
    box.className = 'message' + (isError ? ' danger' : ' success');
    box.style.display = 'block';
  }
  function wireCompanyJsonLoader(prefix, btnId, inputId, label) {
    const btn = document.getElementById(btnId); const input = document.getElementById(inputId);
    if (!btn || !input) return;
    btn.addEventListener('click', function() { input.click(); });
    input.addEventListener('change', function() {
      const file = input.files && input.files[0]; input.value = '';
      if (!file) return;
      const reader = new FileReader();
      reader.onload = function() {
        let parsed;
        try { parsed = JSON.parse(String(reader.result)); }
        catch (e) {
          showLoadJsonMessage(L3('Could not read this JSON file: ', 'Kon dit JSON-bestand niet lezen: ', 'Diese JSON-Datei konnte nicht gelesen werden: ', 'No se ha podido leer este archivo JSON: ', 'Impossible de lire ce fichier JSON : ') + e.message, true);
          return;
        }
        const data = normalizeCompanyJson(parsed);
        if (Object.keys(data).length === 0) {
          showLoadJsonMessage(L3('This JSON file did not contain any recognised fields.', 'Dit JSON-bestand bevatte geen herkende velden.', 'Diese JSON-Datei enthielt keine erkannten Felder.', 'Este archivo JSON no contenía ningún campo reconocido.', 'Ce fichier JSON ne contenait aucun champ reconnu.'), true);
          return;
        }
        applyCompanyJson(prefix, data);
        showLoadJsonMessage(L3('Company data for ', 'Bedrijfsgegevens voor ', 'Firmendaten für ', 'Datos de la empresa para ', 'Données de l\'entreprise pour ') + label + L3(' loaded from JSON.', ' geladen uit JSON.', ' aus JSON geladen.', ' cargados desde JSON.', ' chargées depuis le JSON.'), false);
      };
      reader.onerror = function() {
        showLoadJsonMessage(L3('Could not read this JSON file: ', 'Kon dit JSON-bestand niet lezen: ', 'Diese JSON-Datei konnte nicht gelesen werden: ', 'No se ha podido leer este archivo JSON: ', 'Impossible de lire ce fichier JSON : ') + L3('read error', 'leesfout', 'Lesefehler', 'error de lectura', 'erreur de lecture'), true);
      };
      reader.readAsText(file);
    });
  }
  wireCompanyJsonLoader('company1', 'loadJsonP1Btn', 'loadJsonP1Input', L3('Party 1', 'Partij 1', 'Partei 1', 'Parte 1', 'Partie 1'));
  wireCompanyJsonLoader('company2', 'loadJsonP2Btn', 'loadJsonP2Input', L3('Party 2', 'Partij 2', 'Partei 2', 'Parte 2', 'Partie 2'));

  function companyJsonTemplate(prefix) {
    const tpl = {};
    COMPANY_JSON_FIELDS.forEach(function(field) {
      const key = prefix + '_' + field;
      tpl[field] = SAMPLES[key] !== undefined ? SAMPLES[key] : '';
    });
    return tpl;
  }
  document.getElementById('templateJsonP1Btn')?.addEventListener('click', function() { downloadText(JSON.stringify(companyJsonTemplate('company1'), null, 2), 'bedrijf_partij1_voorbeeld.json', 'application/json'); });
  document.getElementById('templateJsonP2Btn')?.addEventListener('click', function() { downloadText(JSON.stringify(companyJsonTemplate('company2'), null, 2), 'bedrijf_partij2_voorbeeld.json', 'application/json'); });

  // --- Artikelen van dit specifieke contract bewerken/verwijderen ----------
  // Alleen voor déze generatie (articleEnabled/articleText in de payload);
  // de herbruikbare sjabloon in contracts/<key>.json blijft ongemoeid — dat
  // gebeurt in het tabblad "Configuratie contracten".
  function currentSafeguardKey() {
    const el = document.querySelector('select[name="safeguard"]');
    return el ? el.value : '';
  }
  function currentContractLang() {
    const el = document.getElementById('contractLangSelect');
    if (el && el.value) return el.value;
    return (window.__LANG__ && window.__LANG__.lang) || 'en';
  }
  function articleDefaultText(entry, key) {
    const title = (entry && entry.title) || '';
    const body = (entry && entry.body) || '';
    return (title && key !== 'Preamble') ? (title + '\n' + body) : body;
  }
  function buildArticlePanel(art, lang) {
    const byLang = art.byLang || {};
    const entry = byLang[lang] || byLang.en || byLang[Object.keys(byLang)[0]] || {};
    const defaultText = articleDefaultText(entry, art.key);

    const panel = document.createElement('div');
    panel.className = 'annex-editor';
    panel.dataset.articleKey = art.key;

    const header = document.createElement('div');
    header.className = 'section-title config-article-header';
    header.style.cssText = 'font-size:13px;margin-top:0;margin-bottom:10px;position:relative;padding-right:28px;';
    const titleSpan = document.createElement('span');
    titleSpan.className = 'config-article-title';
    titleSpan.appendChild(document.createTextNode(art.label + ' '));
    const small = document.createElement('small'); small.textContent = art.key;
    titleSpan.appendChild(small);
    header.appendChild(titleSpan);
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'field-remove-btn annex-remove-btn';
    removeBtn.title = L3('Remove this article from the contract', 'Dit artikel uit het contract verwijderen', 'Diesen Artikel aus dem Vertrag entfernen', 'Eliminar este artículo del contrato', 'Supprimer cet article du contrat');
    removeBtn.setAttribute('aria-label', removeBtn.title);
    removeBtn.textContent = '\u00d7';
    header.appendChild(removeBtn);
    panel.appendChild(header);

    const includeLabel = document.createElement('label');
    includeLabel.style.cssText = 'font-weight:400;display:flex;align-items:center;gap:6px;margin-bottom:8px;';
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox'; checkbox.checked = true; checkbox.className = 'annex-enabled-checkbox';
    const includeText = document.createElement('span');
    includeText.textContent = L3('Include this article in this contract', 'Dit artikel opnemen in dit contract', 'Diesen Artikel in diesen Vertrag aufnehmen', 'Incluir este artículo en este contrato', 'Inclure cet article dans ce contrat');
    includeLabel.appendChild(checkbox); includeLabel.appendChild(includeText);
    panel.appendChild(includeLabel);

    const removedBadge = document.createElement('div');
    removedBadge.className = 'message danger';
    removedBadge.style.cssText = 'display:none;margin:0 0 8px;font-size:11.5px;padding:6px 10px;';
    removedBadge.textContent = L3('Removed for this contract', 'Verwijderd voor dit contract', 'Für diesen Vertrag entfernt', 'Eliminado para este contrato', 'Supprimé pour ce contrat');
    panel.appendChild(removedBadge);

    const hidden = document.createElement('input');
    hidden.type = 'hidden'; hidden.name = 'articleEnabled[' + art.key + ']'; hidden.value = '1';
    panel.appendChild(hidden);

    const textarea = document.createElement('textarea');
    textarea.name = 'articleText[' + art.key + ']';
    textarea.className = 'mono annex-textarea';
    textarea.value = defaultText;
    textarea.dataset.defaultText = defaultText;
    panel.appendChild(textarea);

    const resetWrap = document.createElement('div');
    resetWrap.style.cssText = 'text-align:right;margin-top:8px;';
    const resetBtn = document.createElement('button');
    resetBtn.type = 'button'; resetBtn.className = 'btn btn-sm btn-outline annex-reset-btn';
    resetBtn.textContent = L3('↺ Reset to standard text', '↺ Terug naar standaardtekst', '↺ Auf Standardtext zurücksetzen', '↺ Restablecer al texto estándar', '↺ Rétablir le texte standard');
    resetWrap.appendChild(resetBtn);
    panel.appendChild(resetWrap);

    checkbox.addEventListener('change', function() {
      hidden.value = checkbox.checked ? '1' : '0';
      panel.classList.toggle('removed', !checkbox.checked);
      removedBadge.style.display = checkbox.checked ? 'none' : 'block';
      textarea.disabled = !checkbox.checked;
    });
    removeBtn.addEventListener('click', function() {
      checkbox.checked = false;
      checkbox.dispatchEvent(new Event('change'));
    });
    resetBtn.addEventListener('click', function() { textarea.value = textarea.dataset.defaultText; autoGrow(textarea); });
    textarea.addEventListener('input', function() { autoGrow(textarea); });
    textarea.addEventListener('change', function() { autoGrow(textarea); });

    return panel;
  }
  function renderArticleEditor() {
    const container = document.getElementById('articleEditorList');
    if (!container) return;
    const key = currentSafeguardKey();
    const lang = currentContractLang();
    const arts = (ARTICLE_DEFS && ARTICLE_DEFS[key]) || [];
    container.innerHTML = '';
    if (!arts.length) {
      const msg = document.createElement('div'); msg.className = 'message';
      msg.textContent = L3('No articles found for the selected contract type.', 'Geen artikelen gevonden voor het gekozen contracttype.', 'Keine Artikel für den gewählten Vertragstyp gefunden.', 'No se han encontrado artículos para el tipo de contrato seleccionado.', 'Aucun article trouvé pour le type de contrat sélectionné.');
      container.appendChild(msg);
      return;
    }
    arts.forEach(function(art) {
      const panel = buildArticlePanel(art, lang);
      container.appendChild(panel);
      autoGrow(panel.querySelector('.annex-textarea'));
    });
  }
  document.querySelector('select[name="safeguard"]')?.addEventListener('change', renderArticleEditor);
  document.getElementById('contractLangSelect')?.addEventListener('change', renderArticleEditor);
  // Verwerkingsdetails — veld helemaal verwijderen uit het formulier
  document.querySelectorAll('[data-field-remove]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const row = btn.closest('.form-group');
      if (!row) return;
      row.querySelectorAll('input, textarea, select').forEach(function(f) { f.disabled = true; });
      row.classList.add('field-removed');
    });
  });

  document.getElementById('resetArticlesBtn')?.addEventListener('click', renderArticleEditor);
  document.getElementById('clearAllBtn')?.addEventListener('click', renderArticleEditor);
  renderArticleEditor();

  document.getElementById('fillSampleBtn')?.addEventListener('click', function() {
    const form = document.getElementById('contractForm'); if (!form) return;
    Object.keys(SAMPLES).forEach(key => {
      const el = form.elements[key]; if (!el) return;
      if (el.tagName === 'SELECT') { const opt = Array.from(el.options).find(o => o.value === SAMPLES[key]); if (opt) el.value = SAMPLES[key]; }
      else el.value = SAMPLES[key];
    });
    const r1 = form.elements['company1_rep']; const r2 = form.elements['company2_rep'];
    if (r1) document.getElementById('rep1_display').textContent = r1.value || '—';
    if (r2) document.getElementById('rep2_display').textContent = r2.value || '—';
  });
  document.getElementById('clearAllBtn')?.addEventListener('click', function() {
    const form = document.getElementById('contractForm'); if (!form) return;
    Array.from(form.elements).forEach(el => {
      if (el.type === 'hidden' || el.type === 'submit' || el.type === 'button') return;
      if (el.tagName === 'SELECT') el.selectedIndex = 0; else el.value = '';
    });
    document.getElementById('rep1_display').textContent = '—';
    document.getElementById('rep2_display').textContent = '—';
  });
  document.getElementById('clearSignaturesBtn')?.addEventListener('click', function() { ['1', '2'].forEach(n => { if (pads[n]) pads[n].reset(); }); });

  const generateBtn = document.getElementById('generateBtn');
  let lastGenerated = null;
  if (generateBtn) {
    generateBtn.addEventListener('click', async function() {
      collectSignatures();
      const form = document.getElementById('contractForm');
      const errBox = document.getElementById('genError'); errBox.style.display = 'none';
      generateBtn.disabled = true; const orig = generateBtn.textContent; generateBtn.textContent = withIcon('⏳', '…');
      try {
        const fd = new FormData(form);
        const res = await fetch(window.location.pathname + '?tab=generate&lang=' + ((window.__LANG__ && window.__LANG__.lang) || 'en'), { method: 'POST', body: fd });
        const data = await res.json();
        if (!data.ok) { errBox.textContent = data.error || 'Error'; errBox.style.display = 'block'; return; }
        lastGenerated = data;
        renderQrMulti('qrCanvas', data.payload, 'qrHint');
        document.getElementById('metaId').textContent = data.id;
        document.getElementById('metaMd5').textContent = data.md5;
        document.getElementById('metaPayloadLen').textContent = data.payloadLength + ' ' + ((window.__LANG__ && window.__LANG__.unit_chars) || 'chars');
        document.getElementById('metaPayload').textContent = data.payload;
        document.getElementById('qrResult').classList.add('show');
        document.getElementById('qrResult').scrollIntoView({ behavior: 'smooth', block: 'start' });
      } catch (err) { errBox.textContent = 'Network error: ' + err.message; errBox.style.display = 'block'; }
      finally { generateBtn.disabled = false; generateBtn.textContent = orig; }
    });
  }
  document.getElementById('downloadTxtBtn')?.addEventListener('click', function() { if (!lastGenerated) return; downloadText(lastGenerated.txt, lastGenerated.filename); });
  document.getElementById('downloadJsonBtn')?.addEventListener('click', function() { if (!lastGenerated || !lastGenerated.json) return; downloadText(lastGenerated.json, lastGenerated.jsonFilename || 'contract_velden.json', 'application/json'); });
  document.getElementById('printBtn')?.addEventListener('click', async function() { if (!lastGenerated) return; const btn = this; const original = btn.textContent; btn.disabled = true; btn.textContent = withIcon('⏳', 'MHTML…'); try { await exportContractAsMhtml(lastGenerated); } finally { btn.disabled = false; btn.textContent = original; } });
  document.getElementById('zipBtn')?.addEventListener('click', async function() { if (!lastGenerated) return; const btn = this; const original = btn.textContent; btn.disabled = true; btn.textContent = withIcon('⏳', 'ZIP…'); try { await downloadQrZip(lastGenerated); } finally { btn.disabled = false; btn.textContent = original; } });

  // Tabblad "Contracten" — "Genereer nu": zelfde generate_json-mechanisme als
  // het tabblad "Nieuw contract", maar dan gevoed met de voorbeeldgegevens
  // (SAMPLES) van deze pagina in plaats van een handmatig ingevuld formulier.
  // De QR-code(s) bevatten dezelfde volledige PAYLOAD als bij "Nieuw contract",
  // dus dit contract kan later 1-op-1 worden teruggezet via "Her-genereren".
  const generateContractsBtn = document.getElementById('generateContractsBtn');
  let lastGeneratedContracts = null;
  if (generateContractsBtn) {
    generateContractsBtn.addEventListener('click', async function() {
      const errBox = document.getElementById('genErrorContracts'); errBox.style.display = 'none';
      generateContractsBtn.disabled = true; const orig = generateContractsBtn.textContent; generateContractsBtn.textContent = withIcon('⏳', '…');
      try {
        const key = generateContractsBtn.getAttribute('data-key') || '';
        const viewLang = generateContractsBtn.getAttribute('data-lang') || '';
        const fd = new FormData();
        fd.append('action', 'generate_json');
        fd.append('safeguard', key);
        fd.append('contract_lang', viewLang);
        Object.keys(SAMPLES).forEach(k => fd.append(k, SAMPLES[k]));
        const res = await fetch(window.location.pathname + '?tab=contracts&lang=' + ((window.__LANG__ && window.__LANG__.lang) || 'en'), { method: 'POST', body: fd });
        const data = await res.json();
        if (!data.ok) { errBox.textContent = data.error || 'Error'; errBox.style.display = 'block'; return; }
        lastGeneratedContracts = data;
        renderQrMulti('qrCanvasContracts', data.payload, 'qrHintContracts');
        document.getElementById('metaIdContracts').textContent = data.id;
        document.getElementById('metaMd5Contracts').textContent = data.md5;
        document.getElementById('metaPayloadLenContracts').textContent = data.payloadLength + ' ' + ((window.__LANG__ && window.__LANG__.unit_chars) || 'chars');
        document.getElementById('qrResultContracts').classList.add('show');
        document.getElementById('qrResultContracts').scrollIntoView({ behavior: 'smooth', block: 'start' });
      } catch (err) { errBox.textContent = 'Network error: ' + err.message; errBox.style.display = 'block'; }
      finally { generateContractsBtn.disabled = false; generateContractsBtn.textContent = orig; }
    });
  }
  document.getElementById('downloadTxtBtnContracts')?.addEventListener('click', function() { if (!lastGeneratedContracts) return; downloadText(lastGeneratedContracts.txt, lastGeneratedContracts.filename); });
  document.getElementById('downloadJsonBtnContracts')?.addEventListener('click', function() { if (!lastGeneratedContracts || !lastGeneratedContracts.json) return; downloadText(lastGeneratedContracts.json, lastGeneratedContracts.jsonFilename || 'contract_velden.json', 'application/json'); });
  document.getElementById('printBtnContracts')?.addEventListener('click', async function() { if (!lastGeneratedContracts) return; const btn = this; const original = btn.textContent; btn.disabled = true; btn.textContent = withIcon('⏳', 'MHTML…'); try { await exportContractAsMhtml(lastGeneratedContracts); } finally { btn.disabled = false; btn.textContent = original; } });
  document.getElementById('zipBtnContracts')?.addEventListener('click', async function() { if (!lastGeneratedContracts) return; const btn = this; const original = btn.textContent; btn.disabled = true; btn.textContent = withIcon('⏳', 'ZIP…'); try { await downloadQrZip(lastGeneratedContracts); } finally { btn.disabled = false; btn.textContent = original; } });

  function renderQrMulti(containerId, text, hintId) {
    const el = document.getElementById(containerId); const hint = hintId ? document.getElementById(hintId) : null;
    if (!el) return;
    if (typeof QRCode === 'undefined') { el.textContent = '(QR library not loaded)'; return; }
    el.innerHTML = '';
    const CHUNK = 700; const total = Math.max(1, Math.ceil(text.length / CHUNK));
    if (total === 1) {
      const wrap = document.createElement('div'); wrap.className = 'qr-part'; el.appendChild(wrap);
      try { new QRCode(wrap, { text: text, width: 260, height: 260, correctLevel: QRCode.CorrectLevel.L }); }
      catch (e) { wrap.textContent = 'QR error: ' + e.message; }
      if (hint) hint.textContent = (window.__LANG__ && window.__LANG__.qr_single) || 'Scan to read the PAYLOAD';
      return;
    }
    const parts = document.createElement('div'); parts.className = 'qr-parts'; el.appendChild(parts);
    for (let i = 0; i < total; i++) {
      const chunk = text.slice(i * CHUNK, (i + 1) * CHUNK);
      const payload = 'PART' + (i + 1) + '/' + total + ':' + chunk;
      const wrap = document.createElement('div'); wrap.className = 'qr-part'; parts.appendChild(wrap);
      try { new QRCode(wrap, { text: payload, width: 160, height: 160, correctLevel: QRCode.CorrectLevel.L }); }
      catch (e) { wrap.textContent = 'QR ' + (i + 1) + ' error: ' + e.message; }
      const lbl = document.createElement('div'); lbl.className = 'lbl';
      lbl.textContent = ((window.__LANG__ && window.__LANG__.scan_part) || 'Part ') + (i + 1) + '/' + total;
      wrap.appendChild(lbl);
    }
    if (hint) hint.textContent = (window.__LANG__ && window.__LANG__.qr_multi) || ('Split into ' + total + ' QR codes. Scan them one by one.');
  }
  function downloadText(text, filename, mime) {
    const blob = new Blob([text], { type: (mime || 'text/plain') + ';charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
  }
  function waitForQrRender(tmp) {
    return new Promise(resolve => {
      let tries = 0;
      function check() {
        const img = tmp.querySelector('img'); const canvas = tmp.querySelector('canvas');
        if (img && img.src && img.src.indexOf('data:image') === 0 && img.complete) { resolve(); return; }
        if (!img && canvas) { resolve(); return; }
        tries++; if (tries > 25) { resolve(); return; }
        setTimeout(check, 30);
      }
      setTimeout(check, 30);
    });
  }
  async function generatePrintQrDataUrls(text) {
    const PRINT_SIZE = 500; const CHUNK = 700;
    const total = Math.max(1, Math.ceil(text.length / CHUNK));
    const urls = [];
    for (let i = 0; i < total; i++) {
      const payload = total === 1 ? text : 'PART' + (i + 1) + '/' + total + ':' + text.slice(i * CHUNK, (i + 1) * CHUNK);
      const tmp = document.createElement('div');
      tmp.style.position = 'absolute'; tmp.style.left = '-9999px';
      document.body.appendChild(tmp);
      try {
        new QRCode(tmp, { text: payload, width: PRINT_SIZE, height: PRINT_SIZE, correctLevel: QRCode.CorrectLevel.L });
        await waitForQrRender(tmp);
        const elImg = tmp.querySelector('img'); const elCanvas = tmp.querySelector('canvas');
        let src = '';
        if (elImg && elImg.src) src = elImg.src;
        else if (elCanvas) src = elCanvas.toDataURL('image/png');
        urls.push(src);
      } catch (e) { urls.push(''); }
      document.body.removeChild(tmp);
    }
    return urls;
  }
  // ===============================================================
  // MHTML-EXPORT — vervangt de vroegere PDF-export (jsPDF). Alle generaties
  // (nieuw contract, tabblad "Contracten", "PAYLOAD opnieuw inlezen") leveren
  // nu een los .mhtml-bestand op i.p.v. een .pdf: een multipart/related
  // MIME-archief (hetzelfde formaat dat een browser gebruikt bij "Opslaan als
  // webpagina, alleen HTML") met de contracttekst als HTML en de handtekening-
  // watermerken + QR-code(s) als ingesloten afbeeldingen, verwezen via
  // "cid:"-URL's — dus nog steeds één zelfstandig bestand, zonder externe
  // dependency (jsPDF is niet meer nodig).
  // ===============================================================

  // Haalt het echte MIME-type uit een data:-URL (bv. "image/png"); de browser
  // heeft dat al correct gezet (canvas.toDataURL/QRCode-output), dus hier
  // hoeft niets geraden te worden zoals voorheen voor jsPDF's addImage().
  function dataUrlMimeType(src) {
    const m = /^data:([a-zA-Z0-9.+\/-]+);base64,/i.exec(src || '');
    return m ? m[1].toLowerCase() : 'image/png';
  }

  // Geeft alleen het base64-gedeelte van een data:-URL terug (zonder het
  // "data:...;base64," voorvoegsel), klaar om als losse MIME-part te dienen.
  function dataUrlBase64(src) {
    const i = (src || '').indexOf(';base64,');
    return i === -1 ? '' : src.slice(i + 8);
  }

  // UTF-8-veilige base64-codering van tekst: btoa() werkt alleen op Latin1,
  // vandaar de omweg via TextEncoder (nodig omdat contractteksten accenten,
  // aanhalingstekens e.d. kunnen bevatten in elke taal).
  function utf8ToBase64(str) {
    const bytes = new TextEncoder().encode(str);
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }

  // MIME schrijft base64-inhoud voor in regels van max. 76 tekens.
  function wrapBase64(b64) {
    return b64.replace(/.{1,76}/g, '$&\r\n');
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // Bouwt één multipart/related .mhtml-bestand (MIME-Version 1.0) van een
  // HTML-hoofddocument plus een lijst ingesloten afbeeldingen. Elke afbeelding
  // krijgt een eigen Content-ID waarnaar de HTML met "cid:" verwijst — exact
  // het formaat dat browsers zelf gebruiken bij "Opslaan als webpagina,
  // alleen HTML" (.mhtml/.mht), en dat elke moderne browser weer kan openen.
  function buildMhtml(htmlContent, parts) {
    const boundary = '----=_NextPart_contract_' + Date.now().toString(16) + '_' + Math.random().toString(16).slice(2);
    let out = 'MIME-Version: 1.0\r\n'
      + 'Content-Type: multipart/related; type="text/html"; boundary="' + boundary + '"\r\n\r\n'
      + 'This is a single-file web page (MHTML archive) generated by the contract register.\r\n\r\n'
      + '--' + boundary + '\r\n'
      + 'Content-Type: text/html; charset="utf-8"\r\n'
      + 'Content-Transfer-Encoding: base64\r\n\r\n'
      + wrapBase64(utf8ToBase64(htmlContent)) + '\r\n';
    parts.forEach(function(p) {
      out += '--' + boundary + '\r\n'
        + 'Content-Type: ' + p.mime + '\r\n'
        + 'Content-Transfer-Encoding: base64\r\n'
        + 'Content-ID: <' + p.cid + '>\r\n'
        + 'Content-Location: cid:' + p.cid + '\r\n\r\n'
        + wrapBase64(p.base64) + '\r\n';
    });
    out += '--' + boundary + '--\r\n';
    return out;
  }

  async function exportContractAsMhtml(data) {
    if (!data || !data.payload) return;

    const parts = [];
    let partSeq = 0;
    // Zet een data:-URL om in een losse "cid:"-MIME-part en geeft de
    // bijbehorende <img>-src terug; slaat lege/ongeldige bronnen over (dan
    // komt er simpelweg geen <img> te staan).
    function embedImage(src) {
      if (!src || src.indexOf('data:image') !== 0) return '';
      const base64 = dataUrlBase64(src);
      if (!base64) return '';
      partSeq++;
      const cid = 'img' + partSeq + '@contract.local';
      parts.push({ cid: cid, mime: dataUrlMimeType(src), base64: base64 });
      return 'cid:' + cid;
    }

    // Handtekeningen (indien aanwezig) als watermerk. In de PDF stonden deze
    // klein en transparant rechtsonder op ELKE pagina; hier gebeurt hetzelfde
    // via CSS "position:fixed" (rechtsonder in beeld), wat bij het afdrukken
    // van dit .mhtml-bestand vanuit de browser op elke afgedrukte pagina
    // terugkomt.
    const sigSrcs = [data.signature1, data.signature2].filter(function(s) { return typeof s === 'string' && s.indexOf('data:image') === 0; });
    const sigCids = sigSrcs.map(embedImage).filter(Boolean);

    // QR-code(s): zelfde bron/mechanisme als voorheen voor de PDF-export.
    const qrDataUrls = (await generatePrintQrDataUrls(data.payload)).filter(Boolean);
    const qrCids = qrDataUrls.map(embedImage).filter(Boolean);

    // Contracttekst: start net als voorheen meteen bij "Preambule" (de
    // integriteits-header/PAYLOAD-dump ervoor wordt overgeslagen — de MD5,
    // hieronder los in de kop gezet, blijft de manier om dit exemplaar terug
    // te herleiden tot het onderliggende bestand). Elke "<<<PAGEBREAK>>>"-regel
    // (zie PDF_PAGEBREAK_MARKER in pdf_translate.php) wordt een nieuwe
    // taalsectie die bij het afdrukken op een nieuwe pagina begint, zodat je
    // per taal kunt doorscrollen/bladeren: eerst de interfacetaal, dan taal 1,
    // taal 2, taal 3, enzovoort.
    const bodyMarker = '================================\n\n';
    const markerIdx = data.txt.indexOf(bodyMarker);
    const bodyText = markerIdx !== -1 ? data.txt.slice(markerIdx + bodyMarker.length) : data.txt;
    const rawSections = bodyText.split('<<<PAGEBREAK>>>');
    const sectionsHtml = rawSections.map(function(section, idx) {
      const cls = idx > 0 ? ' class="lang-section"' : '';
      const trimmed = section.replace(/^\n+/, '').replace(/\n+$/, '');
      return '<div' + cls + '><pre>' + escapeHtml(trimmed) + '</pre></div>';
    }).join('\n');

    const qrTitle = (window.__LANG__ && (window.__LANG__.qr_hint || window.__LANG__.result_sub)) || 'QR code';
    const qrHtml = qrCids.length
      ? '<div class="qr-page"><h2>' + escapeHtml(qrTitle) + '</h2><div class="qr-grid">'
        + qrCids.map(function(cid, i) {
            const label = qrCids.length > 1 ? '<div class="qr-label">Deel ' + (i + 1) + '/' + qrCids.length + '</div>' : '';
            return '<div class="qr-item"><img src="' + cid + '" alt="QR ' + (i + 1) + '">' + label + '</div>';
          }).join('')
        + '</div></div>'
      : '';

    const watermarkHtml = sigCids.length
      ? '<div class="watermark">' + sigCids.map(function(cid) { return '<img src="' + cid + '" alt="">'; }).join('') + '</div>'
      : '';

    const title = 'Contract ' + escapeHtml(data.id || '');

    // Paginanummering ("Pagina X van Y") + de MD5 in de afdruk: beide puur via
    // CSS @page margin-boxes (counter(page)/counter(pages) resp. een letterlijke
    // content-string) — dit staat dus alleen op het papier/PDF wanneer het
    // .mhtml-bestand vanuit de browser wordt afgedrukt, niet in de schermweer-
    // gave zelf. Een margin-box leeft altijd in de paginarand, buiten het
    // content-vak, dus overlapt nooit de contracttekst (in tegenstelling tot
    // de vorige "position:fixed"-stempel). Het woordje ("Pagina …van"/
    // "Page …of"/…) volgt de interfacetaal waarin dit exemplaar is gegenereerd.
    const pageOfWords = {
      nl: ['Pagina ', ' van '],
      en: ['Page ', ' of '],
      de: ['Seite ', ' von '],
      es: ['Página ', ' de '],
      fr: ['Page ', ' sur ']
    };
    const pw = pageOfWords[data.lang] || pageOfWords.en;
    // De QR-pagina krijgt een eigen paginanaam ("qrpage") zodat we de MD5
    // daar via een specifiekere @page-regel weer kunnen uitzetten — de QR-
    // code(s) moeten leesbaar/scanbaar blijven zonder tekst erover.
    const md5TopRight = data.md5
      ? '@top-right{content:"MD5: ' + String(data.md5).replace(/["\\]/g, '') + '";font-family:Helvetica,Arial,sans-serif;font-size:8pt;color:#828282;}'
      : '';

    const html = '<!DOCTYPE html>\n<html lang="' + escapeHtml(data.lang || 'en') + '">\n<head>\n<meta charset="utf-8">\n<title>' + title + '</title>\n<style>\n'
      + 'body{font-family:"Courier New",Courier,monospace;font-size:12px;line-height:1.45;color:#141414;margin:40pt;background:#fff;}\n'
      + 'pre{white-space:pre-wrap;word-wrap:break-word;font-family:inherit;margin:0;}\n'
      + '.lang-section{page-break-before:always;margin-top:28pt;}\n'
      + '.watermark{position:fixed;bottom:20pt;right:20pt;width:150pt;opacity:.32;text-align:right;}\n'
      + '.watermark img{max-width:150pt;max-height:70pt;display:block;margin-left:auto;}\n'
      + '.qr-page{page-break-before:always;font-family:Helvetica,Arial,sans-serif;page:qrpage;}\n'
      + '.qr-grid{display:flex;flex-wrap:wrap;gap:18pt;justify-content:center;margin-top:14pt;}\n'
      + '.qr-item{text-align:center;}\n'
      + '.qr-item img{width:220pt;height:220pt;}\n'
      + '.qr-label{font-size:8pt;margin-top:6pt;}\n'
      + '@page{margin:32pt 32pt 54pt 32pt;' + md5TopRight + '@bottom-right{content:"' + pw[0] + '" counter(page) "' + pw[1] + '" counter(pages);font-family:Helvetica,Arial,sans-serif;font-size:8pt;color:#828282;}}\n'
      + '@page qrpage{@top-right{content:normal;}}\n'
      + '</style>\n</head>\n<body>\n'
      + watermarkHtml
      + '<div class="contract-body">' + sectionsHtml + '</div>\n'
      + qrHtml
      + '</body>\n</html>\n';

    const mhtml = buildMhtml(html, parts);
    downloadText(mhtml, data.filename.replace(/\.txt$/i, '.mhtml'), 'multipart/related');
  }

  // Downloadt de PRINT-kwaliteit QR-afbeelding(en) van dit contract als een
  // met wachtwoord beveiligde ZIP. Wachtwoord = de MD5 van het contract
  // (dezelfde MD5 die op het contract en in de QR-code staat). De afbeeldingen
  // worden client-side gerenderd (net als voor de MHTML-export) en naar de server
  // gestuurd om ingepakt en versleuteld te worden; er wordt niets bewaard.
  async function downloadQrZip(data) {
    if (!data || !data.payload || !data.md5) return;
    const errBoxId = data === lastGenerated ? 'genError' : (data === lastGeneratedContracts ? 'genErrorContracts' : 'regenError');
    const errBox = document.getElementById(errBoxId);
    if (errBox) errBox.style.display = 'none';
    try {
      const qrImgs = (await generatePrintQrDataUrls(data.payload)).filter(Boolean);
      if (!qrImgs.length) throw new Error((window.__LANG__ && window.__LANG__.error_zip_empty) || 'No QR images to zip.');
      const fd = new FormData();
      fd.append('action', 'qrzip_json');
      fd.append('md5', data.md5);
      fd.append('id', data.id || 'contract');
      qrImgs.forEach(src => fd.append('images[]', src));
      const res = await fetch(window.location.pathname + '?tab=generate&lang=' + ((window.__LANG__ && window.__LANG__.lang) || 'en'), { method: 'POST', body: fd });
      const contentType = res.headers.get('Content-Type') || '';
      if (contentType.indexOf('application/json') !== -1) {
        const errData = await res.json();
        throw new Error(errData.error || 'Error');
      }
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'contract_' + (data.id || 'contract') + '_qr.zip';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      if (errBox) { errBox.textContent = err.message || String(err); errBox.style.display = 'block'; }
      else alert(err.message || String(err));
    }
  }

  const regenBtn = document.getElementById('regenBtn');
  let lastRegen = null;
  if (regenBtn) {
    regenBtn.addEventListener('click', async function() {
      const input = document.getElementById('regenInput');
      const errBox = document.getElementById('regenError'); errBox.style.display = 'none';
      if (!input.value.trim()) {
        errBox.textContent = (window.__LANG__ && window.__LANG__.error_empty_input) || 'Paste or scan the integrity block or the PAYLOAD first.';
        errBox.style.display = 'block'; return;
      }
      regenBtn.disabled = true; const orig = regenBtn.textContent; regenBtn.textContent = withIcon('⏳', '…');
      try {
        const fd = new FormData(); fd.append('action', 'regen_json'); fd.append('regen_input', input.value);
        const res = await fetch(window.location.pathname + '?tab=regen&lang=' + ((window.__LANG__ && window.__LANG__.lang) || 'en'), { method: 'POST', body: fd });
        const data = await res.json();
        if (!data.ok) { errBox.textContent = data.error || 'Error'; errBox.style.display = 'block'; return; }
        lastRegen = data;
        renderQrMulti('qrCanvasRegen', data.payload, 'qrHintRegen');
        document.getElementById('metaIdRegen').textContent = data.id;
        document.getElementById('metaMd5Regen').textContent = data.md5;
        document.getElementById('metaPayloadLenRegen').textContent = data.payloadLength + ' ' + ((window.__LANG__ && window.__LANG__.unit_chars) || 'chars');
        document.getElementById('qrResultRegen').classList.add('show');
        document.getElementById('qrResultRegen').scrollIntoView({ behavior: 'smooth', block: 'start' });
      } catch (err) { errBox.textContent = 'Network error: ' + err.message; errBox.style.display = 'block'; }
      finally { regenBtn.disabled = false; regenBtn.textContent = orig; }
    });
  }
  document.getElementById('downloadTxtBtnRegen')?.addEventListener('click', function() { if (!lastRegen) return; downloadText(lastRegen.txt, lastRegen.filename); });
  document.getElementById('downloadJsonBtnRegen')?.addEventListener('click', function() { if (!lastRegen || !lastRegen.json) return; downloadText(lastRegen.json, lastRegen.jsonFilename || 'contract_velden.json', 'application/json'); });
  document.getElementById('printBtnRegen')?.addEventListener('click', async function() { if (!lastRegen) return; const btn = this; const original = btn.textContent; btn.disabled = true; btn.textContent = withIcon('⏳', 'MHTML…'); try { await exportContractAsMhtml(lastRegen); } finally { btn.disabled = false; btn.textContent = original; } });
  document.getElementById('zipBtnRegen')?.addEventListener('click', async function() { if (!lastRegen) return; const btn = this; const original = btn.textContent; btn.disabled = true; btn.textContent = withIcon('⏳', 'ZIP…'); try { await downloadQrZip(lastRegen); } finally { btn.disabled = false; btn.textContent = original; } });

  let scanStream = null; let scanRAF = null; let scannedParts = {}; let scannedTotal = 0;
  const startCameraBtn = document.getElementById('startCameraBtn');
  const stopCameraBtn = document.getElementById('stopCameraBtn');
  const video = document.getElementById('scanVideo');
  const hiddenCanvas = document.getElementById('scanCanvasHidden');
  const scanStatus = document.getElementById('scanStatus');
  const resetPartsBtn = document.getElementById('resetPartsBtn');

  resetPartsBtn?.addEventListener('click', function() {
    scannedParts = {}; scannedTotal = 0;
    document.getElementById('regenInput').value = '';
    scanStatus.textContent = ((window.__LANG__ && window.__LANG__.msg_parts_reset) || 'Scanned parts reset.');
    resetPartsBtn.style.display = 'none';
  });
  startCameraBtn?.addEventListener('click', async function() {
    if (typeof jsQR === 'undefined') { scanStatus.textContent = 'QR scan library not loaded.'; return; }
    try {
      scanStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      video.srcObject = scanStream; video.style.display = 'block'; await video.play();
      startCameraBtn.style.display = 'none'; stopCameraBtn.style.display = 'inline-flex';
      scanStatus.textContent = (window.__LANG__ && window.__LANG__.scan_camera_on) || 'Camera active…';
      scanLoop();
    } catch (err) { scanStatus.textContent = ((window.__LANG__ && window.__LANG__.scan_camera_err) || 'Could not start camera: ') + err.message; }
  });
  stopCameraBtn?.addEventListener('click', stopCamera);
  function stopCamera() {
    if (scanRAF) cancelAnimationFrame(scanRAF);
    if (scanStream) { scanStream.getTracks().forEach(t => t.stop()); scanStream = null; }
    video.style.display = 'none'; startCameraBtn.style.display = 'inline-flex'; stopCameraBtn.style.display = 'none';
  }
  function scanLoop() {
    if (!scanStream) return;
    const ctx = hiddenCanvas.getContext('2d');
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      hiddenCanvas.width = video.videoWidth; hiddenCanvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, hiddenCanvas.width, hiddenCanvas.height);
      const imageData = ctx.getImageData(0, 0, hiddenCanvas.width, hiddenCanvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height);
      if (code && code.data) { handleScannedQr(code.data); return; }
    }
    scanRAF = requestAnimationFrame(scanLoop);
  }
  function handleScannedQr(data) {
    const m = data.match(/^PART(\d+)\/(\d+):([\s\S]*)$/);
    if (!m) {
      document.getElementById('regenInput').value = data;
      scanStatus.textContent = withIcon('✅', (window.__LANG__ && window.__LANG__.msg_qr_scanned_filled) || 'QR scanned and filled in.');
      stopCamera(); return;
    }
    const idx = parseInt(m[1], 10) - 1;
    const total = parseInt(m[2], 10);
    scannedTotal = total; scannedParts[idx] = m[3];
    const found = Object.keys(scannedParts).length;
    scanStatus.textContent = ((window.__LANG__ && window.__LANG__.scan_part) || 'Part ') + found + '/' + total + ' …';
    resetPartsBtn.style.display = 'inline-flex';
    if (found === total) {
      const full = Array.from({ length: total }, (_, i) => scannedParts[i] || '').join('');
      document.getElementById('regenInput').value = full;
      scanStatus.textContent = (window.__LANG__ && window.__LANG__.scan_all_done) || '✅ All parts scanned.';
      stopCamera();
    } else scanRAF = requestAnimationFrame(scanLoop);
  }
  // Decodeert één afbeeldingsbestand en levert de QR-tekst op (of null).
  function decodeImageFile(file) {
    return new Promise(function(resolve) {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = function() {
        try {
          const c = document.createElement('canvas');
          c.width = img.naturalWidth || img.width;
          c.height = img.naturalHeight || img.height;
          const ctx = c.getContext('2d');
          ctx.drawImage(img, 0, 0);
          const imageData = ctx.getImageData(0, 0, c.width, c.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          resolve(code && code.data ? code.data : null);
        } catch (err) {
          resolve(null);
        } finally {
          URL.revokeObjectURL(url);
        }
      };
      img.onerror = function() { URL.revokeObjectURL(url); resolve(null); };
      img.src = url;
    });
  }

  // Eén of meerdere foto's van QR-codes uploaden. Elke foto wordt gedecodeerd
  // en de herkende delen worden automatisch samengevoegd (net als bij scannen
  // met de camera) — zo kan het hele contract worden her-gegenereerd vanaf
  // een serie geüploade QR-foto's, zonder ze één voor één te hoeven scannen.
  document.getElementById('scanFileInput')?.addEventListener('change', async function(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length || typeof jsQR === 'undefined') return;

    let recognized = 0;
    let failed = 0;

    for (let i = 0; i < files.length; i++) {
      scanStatus.textContent = withIcon('📷', L3(
        'Processing photo ' + (i + 1) + '/' + files.length + '…',
        'Foto ' + (i + 1) + '/' + files.length + ' verwerken…',
        'Foto ' + (i + 1) + '/' + files.length + ' wird verarbeitet…',
        'Procesando foto ' + (i + 1) + '/' + files.length + '…',
        'Traitement de la photo ' + (i + 1) + '/' + files.length + '…'
      ));
      const data = await decodeImageFile(files[i]);
      if (data) {
        recognized++;
        handleScannedQr(data);
      } else {
        failed++;
      }
    }

    let summary = withIcon('✅', L3(
      recognized + '/' + files.length + ' photos recognised as QR code.',
      recognized + '/' + files.length + ' foto\'s herkend als QR-code.',
      recognized + '/' + files.length + ' Fotos als QR-Code erkannt.',
      recognized + '/' + files.length + ' fotos reconocidas como código QR.',
      recognized + '/' + files.length + ' photos reconnues comme code QR.'
    ));
    if (failed) {
      summary += L3(
        ' ' + failed + ' not recognised — try a sharper photo.',
        ' ' + failed + ' niet herkend — probeer een scherpere foto.',
        ' ' + failed + ' nicht erkannt — versuchen Sie ein schärferes Foto.',
        ' ' + failed + ' no reconocidas — prueba con una foto más nítida.',
        ' ' + failed + ' non reconnues — essayez une photo plus nette.'
      );
    }
    if (recognized === 0) {
      summary = (window.__LANG__ && window.__LANG__.scan_no_qr) || '⚠️ No QR code recognised in the photo(s).';
    }
    scanStatus.textContent = summary;

    // Zelfde bestand(en) opnieuw kunnen selecteren.
    e.target.value = '';
  });

})();
</script>
</body>
</html>