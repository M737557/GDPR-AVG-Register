<?php
/**
 * totp_setup.php — EENMALIG gebruiken om de secret in je authenticator-app
 * te zetten, daarna verwijderen of achter een extra check plaatsen: dit
 * bestand toont de secret in leesbare vorm en een QR-code, dus het hoort
 * niet permanent publiek toegankelijk te blijven staan.
 */
declare(strict_types=1);
require_once __DIR__ . '/configmain.php';
require_once __DIR__ . '/totp.php';

$secret = totp_get_secret();
$uri = totp_provisioning_uri($secret, TOTP_ISSUER, TOTP_ACCOUNT);
$qrImg = 'https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=' . urlencode($uri);
?><!DOCTYPE html>
<html lang="nl"><head><meta charset="UTF-8"><title>TOTP-setup</title>
<style>body{font-family:system-ui;max-width:480px;margin:40px auto;padding:0 16px}
code{background:#eee;padding:2px 6px;border-radius:4px;word-break:break-all}</style>
</head><body>
<h1>Eenmalige TOTP-setup</h1>
<p>Scan deze QR-code met je authenticator-app (Google Authenticator, Aegis, 1Password, enz.):</p>
<img src="<?= htmlspecialchars($qrImg, ENT_QUOTES) ?>" alt="QR-code" width="240" height="240">
<p>Of voer handmatig in:</p>
<p><code><?= htmlspecialchars($secret, ENT_QUOTES) ?></code></p>
<p style="color:#a00">Verwijder dit bestand (totp_setup.php) van de server zodra je klaar bent — het toont de secret in leesbare vorm.</p>
</body></html>