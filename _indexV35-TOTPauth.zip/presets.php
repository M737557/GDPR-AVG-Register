<?php
/**
 * presets.php — Verwerkingsdetails- en Commerciële-voorwaarden-presets.
 *
 * Drop-in module voor index.php (contractregister), zelfde patroon als
 * contract_translate.php. Voegt een tabblad "Presets" toe waar je
 * herbruikbare presets aanmaakt voor de twee veldgroepen die bovenaan
 * "Nieuw contract" staan, vlak na het kiezen van het contractsjabloon:
 *
 *   - Verwerkingsdetails: doel, gegevenscategorieën, betrokkenen,
 *     ingangsdatum, looptijd, opzegtermijn.
 *   - Commerciële voorwaarden: contractwaarde, valuta, aansprakelijkheid,
 *     betaling, boetebeding, SLA's, subverwerkers, geheimhouding,
 *     toepasselijk recht, bevoegde rechter, verzekering, auditrechten,
 *     aanvullende opmerkingen.
 *
 * Presets zijn GLOBAAL: ze zijn niet gekoppeld aan één contractsjabloon en
 * staan dus altijd in de lijst, ongeacht welk sjabloon boven aan "Nieuw
 * contract" gekozen is. Elke preset heeft per taal een eigen set
 * tekstwaarden. Standaard staan en/nl/de/es/fr altijd als kolom klaar
 * (PRESET_UI_LANGS, "snelle" talen — zelfde vijf als de rest van de tool
 * al kende), maar via "+ Taal toevoegen" kan een preset worden uitgebreid
 * met ELKE taal die een van de geconfigureerde vertaalengines kent
 * (deepl_languages() in contract_translate.php — dat is DeepL zelf, plus,
 * zodra translateapi.ai ook geconfigureerd is, de talen die alleen
 * translateapi.ai kent, bv. Swahili, Wales, Somalisch), niet alleen die
 * vaste vijf. Nieuwe talen worden LUI (on-demand) vertaald vanuit het
 * Nederlands zodra ze worden toegevoegd of voor het eerst in "Nieuw
 * contract" gekozen (zie ensure_preset_lang()/handle_preset_ensure_lang_ajax()
 * hieronder), en blijven daarna bij het preset opgeslagen — dus maar één
 * vertaalaanroep per veld per taal, niet bij elk gebruik opnieuw. Kies je een
 * preset waarvan een bepaalde taal niet is ingevuld, dan valt de app terug
 * op Engels, dan Nederlands, en anders de eerste taal die wél gevuld is.
 *
 * Opslag: JSON-bestanden in presets/processing.json en
 * presets/commercial.json, elk een object van id => preset. Net als bij
 * contracts/ wordt elke schrijfactie atomisch gedaan (tmp + rename).
 *
 * Installatie: require_once dit bestand in index.php, op dezelfde plek als
 * contract_translate.php (vóór de POST-afhandeling); voeg 'presets' toe aan
 * de tabbladbalk en roep render_presets_tab() aan wanneer $tab === 'presets'.
 */

declare(strict_types=1);

define('PRESETS_DIR', __DIR__ . '/presets');

// "Snelle" content-talen die een preset ALTIJD als kolom toont, ook leeg: NL
// is de brontaal (de webinterface zelf is uitsluitend Nederlands, zie
// current_lang() in index.php) en en/de/es/fr zijn de vaak gebruikte
// vertalingen daarvan. Dit is dezelfde lijst als UI_LANGS in index.php.
// Dit is NIET meer de volledige lijst ondersteunde talen: via "+ Taal
// toevoegen" (zie preset_extra_lang_options() hieronder) kan een preset ook
// met elke andere taal worden aangevuld die een geconfigureerde vertaalengine
// (DeepL en/of translateapi.ai) kent — die extra talen staan dan gewoon als
// extra sleutel in preset['values'], en worden overal in dit bestand
// (preset_field_value(), render_preset_type_section(), enz.) als zodanig
// meegenomen zodra ze aanwezig zijn.
define('PRESET_UI_LANGS', ['en', 'nl', 'de', 'es', 'fr']);

// Talen die nog NIET als "snelle" kolom in beeld staan — de opties voor de
// "+ Taal toevoegen"-dropdown, met leesbare naam via deepl_lang_label().
// deepl_languages() bevat zowel DeepL-talen als (indien translateapi.ai
// geconfigureerd is) de extra talen die alleen translateapi.ai kent.
// $already: taalcodes die voor dit preset al een kolom hebben (PRESET_UI_LANGS
// + eventueel eerder toegevoegde extra talen), zodat die niet dubbel getoond
// worden.
function preset_extra_lang_options(array $already = []): array {
    if (!function_exists('deepl_languages')) return [];
    $already = array_map('strtolower', $already);
    $out = [];
    foreach (deepl_languages() as $code => $meta) {
        $code = strtolower((string)$code);
        if ($code === '' || in_array($code, $already, true)) continue;
        $label = is_array($meta) ? (string)($meta['label'] ?? strtoupper($code)) : strtoupper($code);
        $out[$code] = $label;
    }
    asort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return $out;
}

// ===============================================================
// VELDDEFINITIES
// ===============================================================
function preset_field_groups(): array {
    return [
        'processing' => ['purpose', 'dataCategories', 'dataSubjects', 'effectiveDate', 'duration', 'noticePeriod'],
        'commercial' => [
            'contractValue', 'currency', 'liabilityCap', 'paymentTerms', 'penaltyClause',
            'slaUptime', 'slaResponse', 'subProcessors', 'confidentiality', 'governingLaw',
            'jurisdiction', 'insurance', 'auditRights', 'extraNotes',
        ],
    ];
}

// Velden die meerdere zinnen kunnen bevatten, tonen we als <textarea> in
// plaats van <input type="text"> — zowel in het Presets-tabblad als in het
// formulier "Nieuw contract" (zie render_preset_field_input() hieronder).
function preset_textarea_fields(): array {
    return [
        'purpose', 'dataCategories', 'dataSubjects', 'liabilityCap', 'paymentTerms',
        'penaltyClause', 'subProcessors', 'insurance', 'auditRights', 'extraNotes',
    ];
}

// Vertaalsleutel (t()) per veld, hergebruikt uit de bestaande woordenboeken
// in index.php — deze labels stonden daar al (van vóór de "stage 2"
// hidden-ificatie van het formulier), dus er zijn geen nieuwe sleutels nodig
// voor de velden zelf.
function preset_field_label_key(string $field): string {
    $map = [
        'purpose' => 'purpose', 'dataCategories' => 'data_categories', 'dataSubjects' => 'data_subjects',
        'effectiveDate' => 'effective_date', 'duration' => 'duration', 'noticePeriod' => 'notice_period',
        'contractValue' => 'contract_value', 'currency' => 'currency', 'liabilityCap' => 'liability_cap',
        'paymentTerms' => 'payment_terms', 'penaltyClause' => 'penalty_clause', 'slaUptime' => 'sla_uptime',
        'slaResponse' => 'sla_response', 'subProcessors' => 'sub_processors', 'confidentiality' => 'confidentiality',
        'governingLaw' => 'governing_law', 'jurisdiction' => 'jurisdiction', 'insurance' => 'insurance',
        'auditRights' => 'audit_rights', 'extraNotes' => 'extra_notes',
    ];
    return $map[$field] ?? $field;
}

// Nederlandse namen voor de vijf "snelle" talen — zelfde reden als
// lang_dutch_names() in contract_translate.php: de interface is vast
// Nederlands, dus ook de taalnamen zelf worden consequent in het Nederlands
// getoond i.p.v. een mix van Engelse/native namen ("English", "Deutsch",
// "Français", ...).
function preset_lang_names(): array {
    return ['en' => 'Engels', 'nl' => 'Nederlands', 'de' => 'Duits', 'es' => 'Spaans', 'fr' => 'Frans'];
}

// Leesbare naam voor een willekeurige taalcode: eerst de vaste kaart
// hierboven (snelle talen), anders deepl_lang_label() uit
// contract_translate.php (dekt de volledige gecombineerde talenlijst: DeepL
// plus, indien geconfigureerd, de extra translateapi.ai-talen), en anders
// gewoon de code zelf in hoofdletters.
function preset_lang_display_name(string $lang): string {
    $names = preset_lang_names();
    if (isset($names[$lang])) return $names[$lang];
    if (function_exists('deepl_lang_label')) {
        $label = deepl_lang_label($lang);
        if ($label !== '') return $label;
    }
    return strtoupper($lang);
}

// Eigen mini-woordenboek voor de vertaalknop en zijn statusmeldingen, zodat
// dit bestand niet afhankelijk is van nieuwe t()-sleutels in index.php se
// dictionaries. Sleutel per huidige interfacetaal (current_lang()), met
// terugval op Engels.
function preset_translate_ui_strings(): array {
    $all = [
        'en' => [
            'btn'      => '🌐 Translate selected languages',
            'pick_label' => 'Languages to translate from Dutch (NL) — adds to/refreshes the checked columns, existing text in unchecked columns is left alone:',
            'pick_none'  => 'Select at least one language first.',
            'busy'     => 'Translating…',
            'done'     => 'Translated. Review the filled-in text before saving.',
            'empty'    => 'Fill in the Dutch (NL) fields first.',
            'nokey'    => 'No translation engine is configured — set a DeepL, translateapi.ai, Lingvanex and/or Microsoft Translator API key.',
            'error'    => 'Translation was interrupted (translation error): ',
            'confirm'  => 'This overwrites the current text of the checked language(s) for this preset with a new machine translation of the Dutch fields. Continue?',
            'addlang_label'       => 'Add another language (every language DeepL, translateapi.ai, Lingvanex or Microsoft Translator knows, e.g. Arabic, Russian, Swahili):',
            'addlang_placeholder' => '— Choose a language —',
            'addlang_btn'         => '+ Add',
            'addlang_exists'      => 'This language is already in the list below.',
            'loadlang_label'      => 'Load preset in language:',
            'loadlang_busy'       => 'Translating this preset into the chosen language…',
            'loadlang_error'      => 'Could not translate this preset into the chosen language (translation error): ',
        ],
        'nl' => [
            'btn'      => '🌐 Vertaal geselecteerde talen',
            'pick_label' => 'Talen om vanuit het Nederlands (NL) te vertalen — vult/ververst alleen de aangevinkte kolommen, tekst in niet-aangevinkte kolommen blijft ongewijzigd:',
            'pick_none'  => 'Kies eerst minstens één taal.',
            'busy'     => 'Bezig met vertalen…',
            'done'     => 'Vertaald. Controleer de ingevulde tekst voor je opslaat.',
            'empty'    => 'Vul eerst de Nederlandse (NL) velden in.',
            'nokey'    => 'Geen vertaalengine geconfigureerd — stel een DeepL-, translateapi.ai-, Lingvanex- en/of Microsoft Translator-sleutel in.',
            'error'    => 'Vertalen is onderbroken (vertaalfout): ',
            'confirm'  => 'Dit overschrijft de huidige tekst van de aangevinkte taal/talen van deze preset met een nieuwe automatische vertaling van de Nederlandse velden. Doorgaan?',
            'addlang_label'       => 'Extra taal toevoegen (elke taal die DeepL, translateapi.ai, Lingvanex of Microsoft Translator kent, bv. Arabisch, Russisch, Swahili):',
            'addlang_placeholder' => '— Kies een taal —',
            'addlang_btn'         => '+ Toevoegen',
            'addlang_exists'      => 'Deze taal staat al in de lijst hieronder.',
            'loadlang_label'      => 'Preset inladen in taal:',
            'loadlang_busy'       => 'Dit preset wordt vertaald naar de gekozen taal…',
            'loadlang_error'      => 'Kon dit preset niet vertalen naar de gekozen taal (vertaalfout): ',
        ],
        'de' => [
            'btn'      => '🌐 Ausgewählte Sprachen übersetzen',
            'pick_label' => 'Sprachen, die aus dem Niederländischen (NL) übersetzt werden — füllt/erneuert nur die angehakten Spalten, Text in nicht angehakten Spalten bleibt unverändert:',
            'pick_none'  => 'Wählen Sie zuerst mindestens eine Sprache.',
            'busy'     => 'Wird übersetzt…',
            'done'     => 'Übersetzt. Bitte den eingefügten Text vor dem Speichern prüfen.',
            'empty'    => 'Bitte zuerst die niederländischen (NL) Felder ausfüllen.',
            'nokey'    => 'Keine Übersetzungsengine konfiguriert — richten Sie einen DeepL-, translateapi.ai-, Lingvanex- und/oder Microsoft-Translator-Schlüssel ein.',
            'error'    => 'Übersetzung wurde unterbrochen (Übersetzungsfehler): ',
            'confirm'  => 'Dadurch wird der aktuelle Text der angehakten Sprache(n) dieser Preset durch eine neue automatische Übersetzung der niederländischen Felder ersetzt. Fortfahren?',
            'addlang_label'       => 'Weitere Sprache hinzufügen (jede Sprache, die DeepL, translateapi.ai, Lingvanex oder Microsoft Translator kennt, z. B. Arabisch, Russisch, Suaheli):',
            'addlang_placeholder' => '— Sprache wählen —',
            'addlang_btn'         => '+ Hinzufügen',
            'addlang_exists'      => 'Diese Sprache steht bereits in der Liste unten.',
            'loadlang_label'      => 'Preset in Sprache laden:',
            'loadlang_busy'       => 'Dieses Preset wird in die gewählte Sprache übersetzt…',
            'loadlang_error'      => 'Konnte dieses Preset nicht in die gewählte Sprache übersetzen (Übersetzungsfehler): ',
        ],
        'es' => [
            'btn'      => '🌐 Traducir idiomas seleccionados',
            'pick_label' => 'Idiomas a traducir desde el neerlandés (NL) — solo rellena/actualiza las columnas marcadas, el texto de las columnas no marcadas no se toca:',
            'pick_none'  => 'Selecciona primero al menos un idioma.',
            'busy'     => 'Traduciendo…',
            'done'     => 'Traducido. Revisa el texto antes de guardar.',
            'empty'    => 'Primero completa los campos en neerlandés (NL).',
            'nokey'    => 'No hay ningún motor de traducción configurado — configura una clave de DeepL, translateapi.ai, Lingvanex y/o Microsoft Translator.',
            'error'    => 'La traducción se interrumpió (error de traducción): ',
            'confirm'  => 'Esto sobrescribirá el texto actual del/de los idioma(s) marcado(s) de esta preset con una nueva traducción automática de los campos en neerlandés. ¿Continuar?',
            'addlang_label'       => 'Añadir otro idioma (cualquier idioma que conozca DeepL, translateapi.ai, Lingvanex o Microsoft Translator, p. ej. árabe, ruso, suajili):',
            'addlang_placeholder' => '— Elige un idioma —',
            'addlang_btn'         => '+ Añadir',
            'addlang_exists'      => 'Este idioma ya está en la lista de abajo.',
            'loadlang_label'      => 'Cargar preset en el idioma:',
            'loadlang_busy'       => 'Traduciendo este preset al idioma elegido…',
            'loadlang_error'      => 'No se pudo traducir este preset al idioma elegido (error de traducción): ',
        ],
        'fr' => [
            'btn'      => '🌐 Traduire les langues sélectionnées',
            'pick_label' => 'Langues à traduire depuis le néerlandais (NL) — ne remplit/actualise que les colonnes cochées, le texte des colonnes non cochées reste inchangé :',
            'pick_none'  => 'Choisissez d\'abord au moins une langue.',
            'busy'     => 'Traduction en cours…',
            'done'     => 'Traduit. Vérifiez le texte avant d\'enregistrer.',
            'empty'    => 'Remplissez d\'abord les champs en néerlandais (NL).',
            'nokey'    => 'Aucun moteur de traduction n\'est configuré — configurez une clé DeepL, translateapi.ai, Lingvanex et/ou Microsoft Translator.',
            'error'    => 'La traduction a été interrompue (erreur de traduction) : ',
            'confirm'  => 'Cela remplacera le texte actuel de la ou des langue(s) cochée(s) de cette preset par une nouvelle traduction automatique des champs néerlandais. Continuer ?',
            'addlang_label'       => 'Ajouter une autre langue (toute langue connue de DeepL, translateapi.ai, Lingvanex ou Microsoft Translator, p. ex. arabe, russe, swahili) :',
            'addlang_placeholder' => '— Choisir une langue —',
            'addlang_btn'         => '+ Ajouter',
            'addlang_exists'      => 'Cette langue figure déjà dans la liste ci-dessous.',
            'loadlang_label'      => 'Charger le preset dans la langue :',
            'loadlang_busy'       => 'Traduction de ce preset vers la langue choisie…',
            'loadlang_error'      => 'Impossible de traduire ce preset vers la langue choisie (erreur de traduction) : ',
        ],
    ];
    $lang = function_exists('current_lang') ? current_lang() : 'en';
    return $all[$lang] ?? $all['en'];
}

// Rij klikbare variabele-chips ({{P1}}, {{PURPOSE}}, …), zelfde bron
// (placeholder_tokens()) en dezelfde opmaak (.var-toolbar/.var-chip) als het
// tabblad "Configuratie contracten". Los gedefinieerd (i.p.v. hergebruik van
// de config-tab z'n render_var_toolbar()) omdat die laatste een lokale
// functie is die pas bestaat nadat dat tabblad zelf gerenderd is.
function preset_var_toolbar(): string {
    $html = '<div class="var-toolbar"><span class="var-toolbar-label">' . e(t('ph_vars_label')) . '</span>';
    foreach (placeholder_tokens() as $pt) {
        $token = e($pt['token']);
        $desc  = e(t($pt['descKey']));
        $html .= '<button type="button" class="var-chip" data-token="{{' . $token . '}}" title="' . $desc . '">{{' . $token . '}}</button>';
    }
    $html .= '</div>';
    return $html;
}

// ===============================================================
// OPSLAG
// ===============================================================
function preset_file_path(string $type): ?string {
    $map = ['processing' => 'processing.json', 'commercial' => 'commercial.json'];
    if (!isset($map[$type])) return null;
    return PRESETS_DIR . '/' . $map[$type];
}

// Geeft alle presets van dit type terug als [id => preset]. Een preset heeft
// altijd de vorm ['id'=>.., 'name'=>.., 'values'=>['en'=>[field=>tekst, ...], 'nl'=>..., ...], 'createdAt'=>.., 'updatedAt'=>..].
function load_presets(string $type): array {
    $path = preset_file_path($type);
    if ($path === null || !is_file($path)) return [];
    $raw = @file_get_contents($path);
    if ($raw === false || trim($raw) === '') return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function save_presets(string $type, array $presetsById): bool {
    $path = preset_file_path($type);
    if ($path === null) return false;
    if (!is_dir(PRESETS_DIR)) @mkdir(PRESETS_DIR, 0775, true);

    $encoded = json_encode($presetsById, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_FORCE_OBJECT);
    if ($encoded === false) return false;

    $tmp = $path . '.tmp' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $encoded) === false) return false;
    if (!@rename($tmp, $path)) { @unlink($tmp); return false; }
    return true;
}

function preset_new_id(): string {
    return 'p_' . bin2hex(random_bytes(6));
}

// Waarde van één veld voor één preset in de gevraagde taal, met terugval naar
// Engels en dan de eerste taal die wél gevuld is — zodat een preset dat
// bijvoorbeeld alleen in het Nederlands is ingevuld, ook bruikbaar blijft
// wanneer de interface op Frans staat.
function preset_field_value(array $preset, string $field, string $lang): string {
    $values = $preset['values'] ?? [];
    if (isset($values[$lang][$field]) && trim((string)$values[$lang][$field]) !== '') {
        return (string)$values[$lang][$field];
    }
    if (isset($values['en'][$field]) && trim((string)$values['en'][$field]) !== '') {
        return (string)$values['en'][$field];
    }
    if (isset($values['nl'][$field]) && trim((string)$values['nl'][$field]) !== '') {
        return (string)$values['nl'][$field];
    }
    // Val terug op elke andere taal die daadwerkelijk bij dit preset is
    // opgeslagen — niet meer beperkt tot PRESET_UI_LANGS: een preset kan
    // intussen ook Arabisch, Russisch, enz. bevatten (zie preset_extra_lang_*
    // hieronder), en die moeten hier ook als terugval meetellen.
    foreach (array_keys($values) as $l) {
        if (isset($values[$l][$field]) && trim((string)$values[$l][$field]) !== '') {
            return (string)$values[$l][$field];
        }
    }
    return '';
}

// Levert de presets van één type als kaal JS-vriendelijk array, voor het
// invulmechanisme in het formulier "Nieuw contract" (zie render_preset_js()).
function presets_for_js(string $type): array {
    $out = [];
    foreach (load_presets($type) as $id => $p) {
        $out[$id] = ['name' => (string)($p['name'] ?? $id), 'values' => $p['values'] ?? []];
    }
    return $out;
}

// ===============================================================
// POST-AFHANDELING — action=save_preset / delete_preset
// ===============================================================
function handle_preset_post(): void {
    $action = (string)($_POST['action'] ?? '');

    // $anchor: optioneel URL-fragment (bv. '#preset-form-processing'), zodat
    // de browser na de redirect automatisch terugscrolt naar het
    // bewerkformulier i.p.v. bovenaan de pagina te blijven staan.
    $back = static function (array $params, string $anchor = ''): void {
        $params = array_merge(['tab' => 'presets', 'lang' => current_lang()], $params);
        header('Location: ?' . http_build_query($params) . $anchor);
        exit;
    };

    $groups = preset_field_groups();

    if ($action === 'save_preset') {
        $type = (string)($_POST['type'] ?? '');
        if (!isset($groups[$type])) $back(['presetError' => 'type']);

        $name = trim((string)($_POST['name'] ?? ''));
        if ($name === '') $back(['presetError' => 'name', 'presetType' => $type]);

        $presets = load_presets($type);
        $id = preg_replace('/[^A-Za-z0-9_]/', '', (string)($_POST['id'] ?? ''));
        if ($id === '' || !isset($presets[$id])) $id = preset_new_id();

        $incoming = $_POST['values'] ?? [];
        if (!is_array($incoming)) $incoming = [];

        // Talen om op te slaan: de vijf "snelle" talen (altijd, ook leeg) plus
        // elke andere taalcode die in de POST voorkomt en door een
        // geconfigureerde vertaalengine wordt herkend — dus ook een taal die
        // via "+ Taal toevoegen" is bijgekomen (bv. Arabisch, Russisch,
        // Swahili). Zonder dit zou zo'n extra kolom bij het opslaan
        // stilzwijgend worden weggegooid, omdat hij buiten PRESET_UI_LANGS valt.
        $langsToSave = PRESET_UI_LANGS;
        foreach (array_keys($incoming) as $l) {
            $l = strtolower((string)$l);
            if ($l === '' || in_array($l, $langsToSave, true)) continue;
            if (function_exists('deepl_lang_known') && !deepl_lang_known($l)) continue;
            $langsToSave[] = $l;
        }

        $values = [];
        foreach ($langsToSave as $l) {
            $values[$l] = [];
            foreach ($groups[$type] as $field) {
                $values[$l][$field] = trim((string)($incoming[$l][$field] ?? ''));
            }
        }

        $presets[$id] = [
            'id'        => $id,
            'name'      => $name,
            'values'    => $values,
            'createdAt' => $presets[$id]['createdAt'] ?? date('c'),
            'updatedAt' => date('c'),
        ];

        $writeOk = save_presets($type, $presets);
        $anchor  = '#preset-form-' . $type;
        if (!$writeOk) {
            $back(['presetError' => 'write', 'presetType' => $type], $anchor);
        }
        // Na opslaan terug naar dezelfde preset in bewerkmodus (edittype/
        // editid meesturen), i.p.v. terug te vallen op de lege "nieuwe
        // preset"-sectie: dat gaf het effect dat de preset "reset" en je
        // steeds opnieuw naar boven moest scrollen en "Bewerken" moest
        // kiezen om je wijziging terug te zien.
        $back(['presetSaved' => $id, 'presetType' => $type, 'edittype' => $type, 'editid' => $id], $anchor);
    }

    if ($action === 'delete_preset') {
        $type = (string)($_POST['type'] ?? '');
        $id   = preg_replace('/[^A-Za-z0-9_]/', '', (string)($_POST['id'] ?? ''));
        if (!isset($groups[$type]) || $id === '') $back(['presetError' => 'type']);

        $presets = load_presets($type);
        unset($presets[$id]);
        $writeOk = save_presets($type, $presets);
        $back($writeOk ? ['presetDeleted' => $id, 'presetType' => $type] : ['presetError' => 'write', 'presetType' => $type], '#preset-form-' . $type);
    }
}

// ===============================================================
// AJAX — action=translate_preset_fields
// ---------------------------------------------------------------
// Vertaalt de (nog niet opgeslagen) Nederlandse veldwaarden uit het
// formulier naar EN/DE/ES/FR, via dezelfde vertaalfunctie
// (deepl_translate_block(), uit contract_translate.php — die intern DeepL of
// translateapi.ai kiest, zie dat bestand) als "Configuratie contracten" en
// pdf_translate.php gebruiken. De brontaal ligt vast op Nederlands (net als
// in de rest van de presets-UX: één "Vertaal"-knop, altijd vanuit NL) — een
// eventueel meegestuurde src_lang wordt genegeerd. Reageert met JSON zodat de
// al ingevulde velden in andere talen in de browser bijgewerkt kunnen worden
// zonder de pagina te herladen (en dus zonder nog niet opgeslagen wijzigingen
// elders in het formulier te verliezen).
function handle_preset_translate_ajax(): void {
    header('Content-Type: application/json; charset=utf-8');

    $fail = static function (string $error) {
        echo json_encode(['ok' => false, 'error' => $error]);
        exit;
    };

    if (!function_exists('deepl_translate_block') || !function_exists('deepl_enabled')) {
        $fail('unavailable'); // contract_translate.php nog niet geladen
    }
    if (!deepl_enabled()) $fail('nokey');

    $type = (string)($_POST['type'] ?? '');
    $groups = preset_field_groups();
    if (!isset($groups[$type])) $fail('type');

    $srcLang = 'nl';
    if (!deepl_lang_known($srcLang)) $fail('lang');

    $incoming = $_POST['values'] ?? [];
    if (!is_array($incoming)) $incoming = [];

    // $targets: optioneel meegestuurde taalcode(s) (POST "targets[]"), voor de
    // "+ Taal toevoegen"-knop die één specifieke nieuwe taal vertaalt (bv.
    // Arabisch, of een translateapi.ai-only taal). Zonder "targets[]" blijft
    // het oude standaardgedrag van de "Vertaal NL → EN/DE/ES/FR"-knop
    // ongewijzigd bestaan.
    $rawTargets = $_POST['targets'] ?? null;
    if (is_array($rawTargets) && $rawTargets !== []) {
        $targets = [];
        foreach ($rawTargets as $t) {
            $t = strtolower(trim((string)$t));
            if ($t !== '' && $t !== $srcLang && !in_array($t, $targets, true)) $targets[] = $t;
        }
    } else {
        $targets = array_values(array_diff(PRESET_UI_LANGS, [$srcLang]));
    }
    $out = [];
    $translateError = null;

    foreach ($targets as $tgt) {
        if (!deepl_lang_known($tgt)) continue;
        $out[$tgt] = [];
        foreach ($groups[$type] as $field) {
            $val = trim((string)($incoming[$field] ?? ''));
            if ($val === '') { $out[$tgt][$field] = ''; continue; }

            $res = deepl_translate_block($val, $srcLang, $tgt, "preset:$type/$field");
            if (!$res['ok']) {
                // Circuit breaker: bij de eerste mislukking direct stoppen met
                // alle volgende velden/talen, i.p.v. per veld te blijven falen
                // (zelfde aanpak als pdf_translate.php).
                $translateError = (string)($res['message'] ?? ($res['error'] ?? 'unknown'));
                break 2;
            }
            $out[$tgt][$field] = (string)($res['text'] ?? $val);
        }
    }

    if ($translateError !== null) {
        echo json_encode(['ok' => false, 'error' => 'deepl', 'message' => $translateError, 'translations' => $out]);
        exit;
    }

    echo json_encode(['ok' => true, 'translations' => $out]);
    exit;
}

// ===============================================================
// LUI VERTALEN + PERSISTEREN — één specifieke taal voor één bestaand preset
// ---------------------------------------------------------------
// Gebruikt door zowel "+ Taal toevoegen" in het Presets-tabblad als de
// taalkiezer naast de preset-dropdowns in "Nieuw contract": vertaalt alleen
// de velden die voor $lang nog ONTBREKEN bij dit specifieke preset (niet
// opnieuw als ze al eerder vertaald/handmatig ingevuld zijn), en schrijft het
// resultaat meteen terug naar presets/<type>.json. Dus maar één
// vertaalaanroep per veld per taal per preset, ooit — elk volgend gebruik
// (ook door een andere gebruiker/browser) komt uit de opslag i.p.v. opnieuw
// een vertaalengine aan te roepen. Dit is de "lui/on-demand"-vertaling voor de
// volledige (gecombineerde DeepL + translateapi.ai) talenlijst, i.p.v. alles
// in één keer bij het opslaan van het preset te vertalen.
// ===============================================================
function ensure_preset_lang_translated(string $type, string $id, string $lang): array {
    $groups = preset_field_groups();
    if (!isset($groups[$type])) return ['ok' => false, 'error' => 'type'];

    $presets = load_presets($type);
    if (!isset($presets[$id])) return ['ok' => false, 'error' => 'notfound'];
    $preset = $presets[$id];

    $lang = strtolower(trim($lang));
    if ($lang === '' || !function_exists('deepl_lang_known') || !deepl_lang_known($lang)) {
        return ['ok' => false, 'error' => 'lang'];
    }

    // 'nl' is de brontaal van elk preset en dus altijd al "compleet".
    if ($lang === 'nl') {
        return ['ok' => true, 'lang' => 'nl', 'values' => $preset['values']['nl'] ?? [], 'changed' => false];
    }

    $srcValues = $preset['values']['nl'] ?? [];
    $existing  = $preset['values'][$lang] ?? [];
    $fields    = $groups[$type];

    $missing = [];
    foreach ($fields as $f) {
        $src = trim((string)($srcValues[$f] ?? ''));
        if ($src === '') continue; // niets om te vertalen voor dit veld
        $cur = trim((string)($existing[$f] ?? ''));
        if ($cur === '') $missing[] = $f;
    }

    if ($missing === []) {
        // Al compleet voor deze taal (of de NL-bron is leeg) — niets te doen.
        return ['ok' => true, 'lang' => $lang, 'values' => $existing, 'changed' => false];
    }

    if (!function_exists('deepl_enabled') || !deepl_enabled() || !function_exists('deepl_translate_block')) {
        return ['ok' => false, 'error' => 'nokey', 'lang' => $lang, 'values' => $existing];
    }

    $out = $existing;
    foreach ($missing as $f) {
        $res = deepl_translate_block((string)$srcValues[$f], 'nl', $lang, "preset:$type/$id/$f");
        if (!is_array($res) || empty($res['ok'])) {
            // Wat al vertaald is (eerdere velden in deze lus) blijft bewaard;
            // alleen het mislukte en de nog niet geprobeerde velden vallen
            // terug op leeg, net als bij een gedeeltelijk mislukte PDF/MHTML-
            // export elders in de tool.
            return ['ok' => false, 'error' => 'deepl', 'message' => (string)($res['message'] ?? ($res['error'] ?? 'unknown')), 'lang' => $lang, 'values' => $out];
        }
        $out[$f] = (string)($res['text'] ?? $srcValues[$f]);
    }

    $preset['values'][$lang] = $out;
    $preset['updatedAt'] = date('c');
    $presets[$id] = $preset;
    save_presets($type, $presets);

    return ['ok' => true, 'lang' => $lang, 'values' => $out, 'changed' => true];
}

// AJAX — action=ensure_preset_lang: aangeroepen door (a) de taalkiezer naast
// de preset-dropdowns in "Nieuw contract" zodra een taal gekozen wordt die
// dit preset nog niet (volledig) heeft, en (b) "+ Taal toevoegen" in het
// Presets-tabblad. Vertaalt-en-bewaart (zie hierboven) en geeft de
// veldwaarden voor die taal terug.
function handle_preset_ensure_lang_ajax(): void {
    header('Content-Type: application/json; charset=utf-8');
    $type = (string)($_POST['type'] ?? '');
    $id   = preg_replace('/[^A-Za-z0-9_]/', '', (string)($_POST['id'] ?? ''));
    $lang = (string)($_POST['lang'] ?? '');
    if ($id === '') { echo json_encode(['ok' => false, 'error' => 'id']); exit; }
    $result = ensure_preset_lang_translated($type, $id, $lang);
    echo json_encode($result);
    exit;
}

// ===============================================================
// UI — herbruikbaar veld-invoerelement (gedeeld tussen het Presets-
// tabblad en het formulier "Nieuw contract")
// ===============================================================
function render_preset_field_input(string $name, string $field, string $value, string $idAttr = ''): string {
    $isTextarea = in_array($field, preset_textarea_fields(), true);
    $idPart = $idAttr !== '' ? ' id="' . e($idAttr) . '"' : '';
    if ($isTextarea) {
        return '<textarea name="' . e($name) . '"' . $idPart . ' rows="2">' . e($value) . '</textarea>';
    }
    return '<input type="text" name="' . e($name) . '"' . $idPart . ' value="' . e($value) . '">';
}

// ===============================================================
// UI — tabblad "Presets"
// ===============================================================
function render_preset_type_section(string $type): string {
    $groups = preset_field_groups();
    if (!isset($groups[$type])) return '';
    $fields   = $groups[$type];
    $presets  = load_presets($type);
    $curLang  = current_lang();

    $editType = (string)($_GET['edittype'] ?? '');
    $editId   = (string)($_GET['editid'] ?? '');
    $editing  = ($editType === $type && $editId !== '' && isset($presets[$editId])) ? $presets[$editId] : null;

    $titleKey = $type === 'processing' ? 'section_processing' : 'section_commercial';
    $formId   = 'preset-editor-' . $type;

    // Kolommen die getoond worden: de vijf "snelle" talen (PRESET_UI_LANGS)
    // plus — als dit een bestaand preset is dat wordt bewerkt — elke extra
    // taal die eerder via "+ Taal toevoegen" is toegevoegd (bv. Arabisch,
    // Russisch, of een translateapi.ai-only taal). Bij een NIEUW preset (nog
    // niet opgeslagen) zijn dat alleen de vijf snelle talen; extra talen
    // kunnen na het aanmaken via "Bewerken" worden toegevoegd, of meteen in
    // het formulier met "+ Taal toevoegen" (die voegt clientside een kolom
    // toe, zie render_preset_lang_grid_assets()).
    $shownLangs = PRESET_UI_LANGS;
    if ($editing) {
        foreach (array_keys($editing['values'] ?? []) as $l) {
            if (!in_array($l, $shownLangs, true)) $shownLangs[] = $l;
        }
    }
    $langCount = count($shownLangs);

    ob_start(); ?>
    <div class="panel" style="margin-bottom:22px;">
      <div class="section-title" style="font-size:15px;margin-top:0;"><?= e(t($titleKey)) ?> — <?= e(t('presets_title')) ?></div>

      <?php if ($presets === []): ?>
        <p class="message"><?= e(t('presets_none')) ?></p>
      <?php else: ?>
        <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
          <?php foreach ($presets as $p): ?>
            <tr style="border-top:1px solid var(--rule-hair);">
              <td style="padding:8px 10px;"><?= e((string)($p['name'] ?? $p['id'])) ?></td>
              <td style="padding:8px 10px;text-align:right;white-space:nowrap;">
                <a class="btn btn-sm btn-outline" href="?tab=presets&amp;lang=<?= e($curLang) ?>&amp;edittype=<?= e($type) ?>&amp;editid=<?= e((string)$p['id']) ?>#preset-form-<?= e($type) ?>"><?= e(t('presets_edit')) ?></a>
                <form method="post" style="display:inline;" onsubmit="return confirm(<?= json_encode(t('presets_delete_confirm')) ?>);">
                  <input type="hidden" name="action" value="delete_preset">
                  <input type="hidden" name="type" value="<?= e($type) ?>">
                  <input type="hidden" name="id" value="<?= e((string)$p['id']) ?>">
                  <button type="submit" class="btn btn-sm btn-outline"><?= e(t('presets_delete')) ?></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>

      <div id="preset-form-<?= e($type) ?>">
        <div class="section-title" style="font-size:13px;"><?= e($editing ? t('presets_edit_title') : t('presets_new_title')) ?></div>
        <form method="post" id="<?= e($formId) ?>" class="preset-lang-form">
          <input type="hidden" name="action" value="save_preset">
          <input type="hidden" name="type" value="<?= e($type) ?>">
          <input type="hidden" name="id" value="<?= e((string)($editing['id'] ?? '')) ?>">

          <div class="form-group">
            <label><?= e(t('presets_name')) ?></label>
            <input type="text" name="name" required value="<?= e((string)($editing['name'] ?? '')) ?>">
          </div>

          <?php $trUi = preset_translate_ui_strings(); ?>
          <div class="preset-translate-row" data-type="<?= e($type) ?>" data-i18n="<?= e(json_encode($trUi, JSON_UNESCAPED_UNICODE)) ?>">
            <div class="preset-inline-label"><?= e($trUi['pick_label']) ?></div>
            <div class="preset-translate-checks">
              <?php foreach ($shownLangs as $l): if ($l === 'nl') continue; ?>
                <label class="preset-translate-check" data-lang="<?= e($l) ?>">
                  <input type="checkbox" class="preset-translate-lang" value="<?= e($l) ?>">
                  <span><?= e(strtoupper($l)) ?> — <?= e(preset_lang_display_name($l)) ?></span>
                </label>
              <?php endforeach; ?>
            </div>
            <button type="button" class="btn btn-sm btn-outline preset-translate-btn"><?= e($trUi['btn']) ?></button>
            <span class="preset-translate-status" aria-live="polite"></span>
          </div>

          <div class="preset-addlang-row" data-type="<?= e($type) ?>" data-i18n="<?= e(json_encode($trUi, JSON_UNESCAPED_UNICODE)) ?>">
            <label class="preset-inline-label"><?= e($trUi['addlang_label']) ?></label>
            <select class="preset-addlang-select">
              <option value=""><?= e($trUi['addlang_placeholder']) ?></option>
              <?php foreach (preset_extra_lang_options($shownLangs) as $code => $label): ?>
                <option value="<?= e($code) ?>"><?= e(strtoupper($code)) ?> — <?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
            <button type="button" class="btn btn-sm btn-outline preset-addlang-btn"><?= e($trUi['addlang_btn']) ?></button>
            <span class="preset-addlang-status" aria-live="polite"></span>
          </div>

          <div class="preset-field-groups" data-type="<?= e($type) ?>">
            <?php foreach ($fields as $f): ?>
              <div class="preset-field-group" data-field="<?= e($f) ?>">
                <div class="form-group" style="margin-bottom:4px;">
                  <label><?= e(t(preset_field_label_key($f))) ?></label>
                </div>
                <div class="grid-3 preset-lang-grid" style="margin-bottom:16px;">
                  <?php foreach ($shownLangs as $l): ?>
                    <div class="form-group preset-lang-cell" data-lang="<?= e($l) ?>" style="margin-bottom:0;">
                      <label class="preset-lang-col-label"><?= e(strtoupper($l)) ?> — <?= e(preset_lang_display_name($l)) ?></label>
                      <?= render_preset_field_input(
                            'values[' . $l . '][' . $f . ']',
                            $f,
                            (string)($editing['values'][$l][$f] ?? ''),
                            'preset_' . $type . '_' . $l . '_' . $f
                          ) ?>
                    </div>
                  <?php endforeach; ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <div style="text-align:right;margin-top:10px;">
            <?php if ($editing): ?>
              <a class="btn btn-sm btn-outline" href="?tab=presets&amp;lang=<?= e($curLang) ?>"><?= e(t('presets_cancel_edit')) ?></a>
            <?php endif; ?>
            <button type="submit" class="btn btn-gold"><?= e($editing ? t('presets_save') : t('presets_create')) ?></button>
          </div>
        </form>
      </div>
    </div>
    <?php
    return (string)ob_get_clean();
}

// CSS + JS voor de side-by-side taalkolommen, eenmalig uitgevoerd door
// render_presets_tab(). Zelfde grid-gedachte als .grid-3 in de "Configuratie
// contracten"-tab (die van nature wrapt naar meerdere rijen), maar nu met een
// VARIABEL aantal kolommen: de vijf "snelle" talen (PRESET_UI_LANGS) plus elke
// taal die via "+ Taal toevoegen" is bijgekomen (bv. Arabisch, Russisch, of
// een translateapi.ai-only taal — de volledige gecombineerde talenlijst, zie
// preset_extra_lang_options()). Op smalle schermen valt de rij terug op
// gestapeld (1 kolom), net als .grid-3 dat bij max-width:900px al doet.
function render_preset_lang_grid_assets(): string {
    ob_start(); ?>
    <style>
      /* Zelfde skin als index.php: mono/uppercase micro-status (zoals
         .signature-status/.scan-status daar), ink/paper-vars, scherpe hoeken
         (border-radius:0) en de bestaande destructieve-actie-kleur (#a33,
         ook gebruikt door .btn-remove-article in index.php) i.p.v. een eigen
         groen/rood palet. */
      .preset-translate-row{
        display:flex;align-items:center;gap:8px 12px;margin:4px 0 16px;flex-wrap:wrap;
        background:var(--paper-2);border:1px solid var(--rule-soft);padding:12px 14px;
      }
      .preset-translate-row > .preset-inline-label{margin-right:0;flex-basis:100%;}
      .preset-translate-checks{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
      .preset-translate-check{
        display:inline-flex;align-items:center;gap:5px;font-weight:400;font-size:13px;
        white-space:nowrap;
      }
      .preset-translate-status,.preset-addlang-status,.preset-lang-picker-status{
        font-family:var(--mono);font-size:11px;font-weight:500;letter-spacing:.05em;
        text-transform:uppercase;color:var(--ink-3);
      }
      .preset-translate-status.is-error,.preset-addlang-status.is-error,.preset-lang-picker-status.is-error{color:#a33;}
      .preset-translate-status.is-done,.preset-addlang-status.is-done,.preset-lang-picker-status.is-done{color:var(--ink);font-weight:700;}
      .preset-addlang-row{
        display:flex;align-items:center;gap:8px;margin:0 0 16px;flex-wrap:wrap;
        background:var(--paper-2);border:1px solid var(--rule-soft);padding:12px 14px;
      }
      .preset-inline-label{
        display:inline-block;margin-right:6px;font-size:10.5px;font-weight:600;
        letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3);
      }
      .preset-lang-col-label{
        display:block;margin-bottom:5px;font-size:10.5px;font-weight:600;
        letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3);
      }
      /* Bare <select>-elementen buiten .form-group krijgen hier dezelfde
         invoerstijl als .form-group select in index.php, i.p.v. de
         standaard-browserstijl. */
      .preset-addlang-select,.preset-lang-picker select{
        font-family:inherit;font-size:14px;line-height:1.5;color:var(--ink);
        background:var(--paper);border:1px solid var(--ink-4);border-radius:0;
        padding:9px 11px;transition:border-color .12s,box-shadow .12s;max-width:280px;
      }
      .preset-addlang-select:focus,.preset-lang-picker select:focus{
        outline:none;border-color:var(--ink);box-shadow:inset 0 -2px 0 var(--ink);
      }
      /* Auto-groeiende tekstvakken: geen eigen scrollbalk/resize-handle meer
         (de hoogte volgt de inhoud via JS — zie autoGrowTextarea()), zodat
         wat je typt altijd meteen zichtbaar blijft i.p.v. weg te scrollen in
         een te klein vak. */
      .preset-field-groups textarea{
        overflow:hidden;resize:none;min-height:2.6em;
      }
    </style>
    <script>
    (function() {
      'use strict';

      // De taalen die de gebruiker heeft AANGEVINKT in de "Vertaal
      // geselecteerde talen"-rij (checkboxes .preset-translate-lang) — dit
      // bepaalt welke kolommen de vertaalknop vult/ververst. Niet-aangevinkte
      // kolommen blijven onaangeroerd (additief vertalen), in plaats van
      // steeds een vaste ['en','de','es','fr']-set te overschrijven.
      function checkedLangColumns(form, type) {
        var out = [];
        form.querySelectorAll('.preset-translate-row[data-type="' + type + '"] .preset-translate-lang:checked').forEach(function(cb) {
          if (out.indexOf(cb.value) === -1) out.push(cb.value);
        });
        return out;
      }

      // Voegt (indien nog niet aanwezig) een checkbox voor $lang toe aan de
      // "Vertaal geselecteerde talen"-rij van dit type, zodat een via "+ Taal
      // toevoegen" nieuw aangemaakte kolom ook meteen als keuze verschijnt.
      function ensureTranslateCheckbox(form, type, lang, label) {
        var row = form.querySelector('.preset-translate-row[data-type="' + type + '"] .preset-translate-checks');
        if (!row || row.querySelector('.preset-translate-check[data-lang="' + lang + '"]')) return;

        var wrap = document.createElement('label');
        wrap.className = 'preset-translate-check';
        wrap.setAttribute('data-lang', lang);

        var cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.className = 'preset-translate-lang';
        cb.value = lang;
        wrap.appendChild(cb);

        var span = document.createElement('span');
        span.textContent = label || lang.toUpperCase();
        wrap.appendChild(span);

        row.appendChild(wrap);
      }

      // Auto-groeiende tekstvakken: hoogte volgt de inhoud terwijl je typt,
      // zodat lange preset-teksten niet in een klein scrollvakje verstopt
      // raken. Werkt via event-delegatie op 'input', dus ook voor tekstvakken
      // die pas na het laden zijn toegevoegd ("+ Taal toevoegen") of gevuld
      // (fillTranslations() hieronder dispatcht zelf een 'input'-event).
      function autoGrowTextarea(el) {
        el.style.height = 'auto';
        el.style.height = el.scrollHeight + 'px';
      }
      function autoGrowAllPresetTextareas() {
        document.querySelectorAll('.preset-field-groups textarea').forEach(autoGrowTextarea);
      }
      document.addEventListener('input', function(e) {
        var el = e.target;
        if (el && el.tagName === 'TEXTAREA' && el.closest('.preset-field-groups')) {
          autoGrowTextarea(el);
          // Blijf zichtbaar terwijl het vak meegroeit (bv. onderaan het
          // scherm typen duwt het vak anders buiten beeld).
          if (typeof el.scrollIntoView === 'function') {
            el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
          }
        }
      });

      function readNlValues(form, type) {
        var nlPrefix = 'preset_' + type + '_nl_';
        var values = {};
        var hasText = false;
        form.querySelectorAll('[id^="' + nlPrefix + '"]').forEach(function(el) {
          var field = el.id.slice(nlPrefix.length);
          values[field] = el.value;
          if (el.value.trim() !== '') hasText = true;
        });
        return { values: values, hasText: hasText };
      }

      function fillTranslations(type, translations) {
        Object.keys(translations || {}).forEach(function(l) {
          var fields = translations[l];
          Object.keys(fields || {}).forEach(function(field) {
            var el = document.getElementById('preset_' + type + '_' + l + '_' + field);
            if (!el) return;
            var v = fields[field];
            if (v !== '') {
              el.value = v;
              el.dispatchEvent(new Event('input', { bubbles: true }));
            }
          });
        });
      }

      function initPresetLangAssets() {
        // "Vertaal geselecteerde talen"-knop: stuurt de huidige (nog niet
        // opgeslagen) NL-veldwaarden naar action=translate_preset_fields voor
        // precies de AANGEVINKTE taalkolommen (checkedLangColumns()) en vult
        // alleen die kolommen met het resultaat — zonder de pagina te
        // herladen en zonder niet-aangevinkte kolommen aan te raken. Dit
        // vervangt de vroegere vaste "NL → EN/DE/ES/FR"-knop: welke talen
        // vertaald worden is nu altijd de eigen keuze van de gebruiker, voor
        // elke taal die als kolom in het formulier staat (de vijf snelle
        // talen plus alles wat via "+ Taal toevoegen" is bijgekomen).
        document.querySelectorAll('.preset-translate-row').forEach(function(row) {
          var ui;
          try { ui = JSON.parse(row.getAttribute('data-i18n') || '{}'); } catch (e) { ui = {}; }
          var type = row.getAttribute('data-type');
          var btn = row.querySelector('.preset-translate-btn');
          var form = row.closest('form.preset-lang-form');
          var status = row.querySelector('.preset-translate-status');
          if (!btn || !form || !type) return;

          function setStatus(text, cls) {
            if (!status) return;
            status.textContent = text || '';
            status.classList.remove('is-error', 'is-done');
            if (cls) status.classList.add(cls);
          }

          btn.addEventListener('click', function() {
            var nl = readNlValues(form, type);
            if (!nl.hasText) { setStatus(ui.empty || '', 'is-error'); return; }

            var targetLangs = checkedLangColumns(form, type);
            if (!targetLangs.length) { setStatus(ui.pick_none || '', 'is-error'); return; }

            // Waarschuwen als er bij een AANGEVINKTE taal al vertaalde tekst
            // staat die overschreven zou worden, zodat een handmatige
            // correctie niet per ongeluk verloren gaat. Niet-aangevinkte
            // kolommen worden sowieso niet aangeraakt.
            var hasExisting = false;
            targetLangs.forEach(function(l) {
              form.querySelectorAll('[id^="preset_' + type + '_' + l + '_"]').forEach(function(el) {
                if (el.value.trim() !== '') hasExisting = true;
              });
            });
            if (hasExisting && !window.confirm(ui.confirm || '')) return;

            var body = new URLSearchParams();
            body.set('action', 'translate_preset_fields');
            body.set('type', type);
            targetLangs.forEach(function(l) { body.append('targets[]', l); });
            Object.keys(nl.values).forEach(function(field) {
              body.set('values[' + field + ']', nl.values[field]);
            });

            btn.disabled = true;
            setStatus(ui.busy || '');

            fetch(window.location.href, {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: body.toString()
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
              btn.disabled = false;
              if (!data) { setStatus(ui.error || '', 'is-error'); return; }

              if (data.translations) fillTranslations(type, data.translations);

              if (data.ok) {
                setStatus(ui.done || '', 'is-done');
              } else if (data.error === 'nokey') {
                setStatus(ui.nokey || '', 'is-error');
              } else if (data.error === 'deepl') {
                setStatus((ui.error || '') + (data.message || ''), 'is-error');
              } else {
                setStatus(ui.error || '', 'is-error');
              }
            })
            .catch(function() {
              btn.disabled = false;
              setStatus(ui.error || '', 'is-error');
            });
          });
        });
      }

      // "+ Taal toevoegen": voegt clientside een nieuwe kolom toe (voor elk
      // veld van deze veldgroep) voor een taalcode uit de volledige,
      // gecombineerde talenlijst (preset_extra_lang_options() in presets.php
      // — DeepL plus, indien geconfigureerd, translateapi.ai, bv. Arabisch,
      // Russisch, Swahili), en vertaalt die meteen vanuit de huidige NL-tekst
      // in het formulier (net als de "Vertaal"-knop hierboven, maar dan voor
      // precies deze ene, net toegevoegde taal).
      function initPresetAddLangAssets() {
        document.querySelectorAll('.preset-addlang-row').forEach(function(row) {
          var ui;
          try { ui = JSON.parse(row.getAttribute('data-i18n') || '{}'); } catch (e) { ui = {}; }
          var type = row.getAttribute('data-type');
          var select = row.querySelector('.preset-addlang-select');
          var btn = row.querySelector('.preset-addlang-btn');
          var status = row.querySelector('.preset-addlang-status');
          var form = row.closest('form.preset-lang-form');
          var groupsWrap = form ? form.querySelector('.preset-field-groups[data-type="' + type + '"]') : null;
          if (!btn || !select || !form || !groupsWrap || !type) return;

          function setStatus(text, cls) {
            if (!status) return;
            status.textContent = text || '';
            status.classList.remove('is-error', 'is-done');
            if (cls) status.classList.add(cls);
          }

          btn.addEventListener('click', function() {
            var lang = select.value;
            if (!lang) return;
            if (form.querySelector('.preset-lang-cell[data-lang="' + lang + '"]')) {
              setStatus(ui.addlang_exists || '', 'is-error');
              return;
            }
            var chosenOption = select.options[select.selectedIndex];
            var optLabel = chosenOption ? chosenOption.textContent : lang.toUpperCase();

            groupsWrap.querySelectorAll('.preset-field-group').forEach(function(group) {
              var field = group.getAttribute('data-field');
              var grid = group.querySelector('.preset-lang-grid');
              if (!grid || !field) return;

              var cell = document.createElement('div');
              cell.className = 'form-group preset-lang-cell';
              cell.setAttribute('data-lang', lang);
              cell.style.marginBottom = '0';

              var label = document.createElement('label');
              label.className = 'preset-lang-col-label';
              label.textContent = optLabel;
              cell.appendChild(label);

              // Zelfde veldtype (input/textarea) als de bestaande kolommen
              // van dit veld, zodat lange velden ook voor de nieuwe taal een
              // meerregelig <textarea> krijgen i.p.v. een enkele <input>.
              var sample = grid.querySelector('textarea, input[type="text"]');
              var input = (sample && sample.tagName === 'TEXTAREA')
                ? document.createElement('textarea')
                : document.createElement('input');
              if (input.tagName === 'TEXTAREA') input.rows = 2;
              else input.type = 'text';
              input.name = 'values[' + lang + '][' + field + ']';
              input.id = 'preset_' + type + '_' + lang + '_' + field;
              cell.appendChild(input);

              grid.appendChild(cell);
            });

            // Voorkomt dat dezelfde taal twee keer wordt toegevoegd.
            var opt = select.querySelector('option[value="' + lang + '"]');
            if (opt) opt.remove();
            select.value = '';

            // Nieuwe kolom meteen ook als keuze aanbieden bij "Vertaal
            // geselecteerde talen", zodat de gebruiker deze taal later opnieuw
            // kan (her)vertalen zonder hem eerst te moeten verwijderen en
            // opnieuw toe te voegen. optLabel is dezelfde "CODE — Naam"-tekst
            // (in het Nederlands) als in de "+ Taal toevoegen"-dropdown.
            ensureTranslateCheckbox(form, type, lang, optLabel);

            var nl = readNlValues(form, type);
            if (!nl.hasText) return; // niets om te vertalen; lege kolom blijft gewoon staan, handmatig in te vullen

            var body = new URLSearchParams();
            body.set('action', 'translate_preset_fields');
            body.set('type', type);
            body.append('targets[]', lang);
            Object.keys(nl.values).forEach(function(field) {
              body.set('values[' + field + ']', nl.values[field]);
            });

            btn.disabled = true;
            setStatus(ui.addlang_busy || ui.busy || '');

            fetch(window.location.href, {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: body.toString()
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
              btn.disabled = false;
              if (!data) { setStatus(ui.error || '', 'is-error'); return; }

              if (data.translations) fillTranslations(type, data.translations);

              if (data.ok) {
                setStatus(ui.done || '', 'is-done');
              } else if (data.error === 'nokey') {
                setStatus(ui.nokey || '', 'is-error');
              } else if (data.error === 'deepl') {
                setStatus((ui.loadlang_error || ui.error || '') + (data.message || ''), 'is-error');
              } else {
                setStatus(ui.error || '', 'is-error');
              }
            })
            .catch(function() {
              btn.disabled = false;
              setStatus(ui.error || '', 'is-error');
            });
          });
        });
      }

      // Defensief: normaal staat dit script al ná de formulieren in de HTML
      // (zie render_presets_tab()), maar mocht het document nog aan het
      // laden zijn, wacht dan alsnog op DOMContentLoaded i.p.v. niets te
      // vinden.
      function initAll() {
        initPresetLangAssets();
        initPresetAddLangAssets();
        autoGrowAllPresetTextareas();
      }
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAll);
      } else {
        initAll();
      }
    })();
    </script>
    <?php
    return (string)ob_get_clean();
}

function render_presets_tab(): string {
    $langs = preset_lang_names();
    ob_start(); ?>
    <div class="section-title"><?= e(t('tab_presets')) ?> <small><?= e(t('presets_sub')) ?></small></div>
    <div class="info-box"><?= t('presets_info') ?></div>

    <?php if (!empty($_GET['presetError'])): ?>
      <div class="message danger"><?= e(t('presets_error')) ?></div>
    <?php elseif (!empty($_GET['presetSaved'])): ?>
      <div class="message"><?= e(t('presets_saved')) ?></div>
    <?php elseif (!empty($_GET['presetDeleted'])): ?>
      <div class="message"><?= e(t('presets_deleted')) ?></div>
    <?php endif; ?>

    <?= render_preset_type_section('processing') ?>
    <?= render_preset_type_section('commercial') ?>

    <?php
    // Pas ná de formulieren geladen (i.p.v. ervoor): het script zoekt
    // .preset-lang-form / .preset-translate-btn op met querySelectorAll op
    // het moment dat het <script>-blok wordt uitgevoerd. Stond dit vóór de
    // formulieren in de HTML, dan bestonden die elementen op dat moment nog
    // niet in de DOM en deed de vertaalknop dus niets.
    ?>
    <?= render_preset_lang_grid_assets() ?>
    <?php
    return (string)ob_get_clean();
}

// ===============================================================
// UI — helpers voor het formulier "Nieuw contract"
// ===============================================================
function render_preset_options(string $type): string {
    $out = '';
    foreach (load_presets($type) as $id => $p) {
        $out .= '<option value="' . e((string)$id) . '">' . e((string)($p['name'] ?? $id)) . '</option>';
    }
    return $out;
}

// Taalkiezer naast een preset-dropdown in "Nieuw contract": bepaalt in welke
// taal het gekozen preset in de zichtbare velden wordt geladen — los van de
// interfacetaal (die vast Nederlands blijft, zie current_lang() in
// index.php) en los van de eigenlijke contracttaalkiezer verderop in het
// formulier. Toont eerst de vijf "snelle" talen (NL bovenaan, al voorgeselec-
// teerd) en daarna, in een <optgroup>, de rest van de volledige, gecombineerde
// talenlijst (DeepL plus, indien geconfigureerd, de extra translateapi.ai-
// talen — preset_extra_lang_options()). Kiest de gebruiker een taal die dit
// specifieke preset nog niet heeft, dan vertaalt en bewaart render_preset_js()
// hieronder die de eerste keer automatisch (ensure_preset_lang_translated())
// vóór de velden gevuld worden.
function render_preset_lang_picker(string $type, string $selectId): string {
    $trUi = preset_translate_ui_strings();
    // NL blijft bovenaan staan (en voorgeselecteerd): dat is de brontaal van
    // elk preset, dus altijd al "compleet" — zie ensure_preset_lang_translated().
    // De overige "snelle" talen sorteren we, net als alle andere taallijsten
    // in de interface, alfabetisch op hun Nederlandse naam i.p.v. de vaste
    // en/de/es/fr-volgorde van PRESET_UI_LANGS.
    $quick = PRESET_UI_LANGS;
    usort($quick, function (string $a, string $b): int {
        if ($a === 'nl') return -1;
        if ($b === 'nl') return 1;
        return strnatcasecmp(preset_lang_display_name($a), preset_lang_display_name($b));
    });

    $html = '<div class="preset-lang-picker" data-type="' . e($type) . '" style="display:flex;align-items:center;gap:8px;margin:-8px 0 16px;flex-wrap:wrap;">';
    $html .= '<label class="preset-inline-label">' . e($trUi['loadlang_label']) . '</label>';
    $html .= '<select id="' . e($selectId) . '">';
    foreach ($quick as $l) {
        $html .= '<option value="' . e($l) . '"' . ($l === 'nl' ? ' selected' : '') . '>' . e(strtoupper($l)) . ' — ' . e(preset_lang_display_name($l)) . '</option>';
    }
    $extra = preset_extra_lang_options($quick);
    if ($extra !== []) {
        $html .= '<optgroup label="' . e($trUi['addlang_placeholder']) . '">';
        foreach ($extra as $code => $label) {
            $html .= '<option value="' . e($code) . '">' . e(strtoupper($code)) . ' — ' . e($label) . '</option>';
        }
        $html .= '</optgroup>';
    }
    $html .= '</select>';
    $html .= '<span class="preset-lang-picker-status" aria-live="polite"></span>';
    $html .= '</div>';
    return $html;
}

// Vult de twee preset-dropdowns in "Nieuw contract" met JS-data en koppelt
// er een change-handler aan die de zichtbare velden vult met de waarden van
// het gekozen preset, in de taal die naast de dropdown gekozen is (zie
// render_preset_lang_picker() hierboven) — met terugval op EN/NL en dan de
// eerste taal die wél gevuld is (zelfde volgorde als preset_field_value()).
// Staat de gekozen taal nog niet bij dit preset, dan wordt hij LUI vertaald
// en bewaard via action=ensure_preset_lang (presets.php) vóórdat de velden
// gevuld worden — dat kan de eerste keer per taal/preset even duren, daarna
// komt het meteen uit de opslag. De velden blijven gewoon tekstvelden: na het
// kiezen van een preset kan de gebruiker de tekst nog steeds handmatig
// aanpassen.
function render_preset_js(): string {
    $processing = json_encode(presets_for_js('processing'), JSON_UNESCAPED_UNICODE);
    $commercial = json_encode(presets_for_js('commercial'), JSON_UNESCAPED_UNICODE);
    $uiStrings  = json_encode(preset_translate_ui_strings(), JSON_UNESCAPED_UNICODE);

    $fieldMap = static function (array $fields): string {
        $pairs = [];
        foreach ($fields as $f) $pairs[] = json_encode($f) . ':' . json_encode($f . '_field');
        return '{' . implode(',', $pairs) . '}';
    };
    $processingFields = $fieldMap(preset_field_groups()['processing']);
    $commercialFields = $fieldMap(preset_field_groups()['commercial']);

    ob_start(); ?>
    <script>
    (function() {
      'use strict';
      var PROCESSING_PRESETS = <?= $processing ?>;
      var COMMERCIAL_PRESETS = <?= $commercial ?>;
      var UI = <?= $uiStrings ?>;
      var LANGS = ['en', 'nl', 'de', 'es', 'fr'];

      function valueFor(values, field, lang) {
        values = values || {};
        if (values[lang] && values[lang][field]) return values[lang][field];
        if (values.en && values.en[field]) return values.en[field];
        if (values.nl && values.nl[field]) return values.nl[field];
        for (var i = 0; i < LANGS.length; i++) {
          var l = LANGS[i];
          if (values[l] && values[l][field]) return values[l][field];
        }
        for (var k in values) {
          if (Object.prototype.hasOwnProperty.call(values, k) && values[k] && values[k][field]) return values[k][field];
        }
        return '';
      }

      function fillFields(preset, lang, fieldIds) {
        Object.keys(fieldIds).forEach(function(field) {
          var el = document.getElementById(fieldIds[field]);
          if (!el) return;
          var v = valueFor(preset.values, field, lang);
          if (v !== '') {
            el.value = v;
            el.dispatchEvent(new Event('input', { bubbles: true }));
          }
        });
      }

      // True zodra dit preset al minstens één niet-lege waarde voor $lang
      // heeft opgeslagen — dan hoeft er niet (opnieuw) vertaald te worden.
      function hasLang(preset, lang) {
        var vals = preset.values && preset.values[lang];
        if (!vals) return false;
        return Object.keys(vals).some(function(f) { return (vals[f] || '').toString().trim() !== ''; });
      }

      function wire(presets, type, selectId, langSelectId, fieldIds) {
        var select = document.getElementById(selectId);
        var langSelect = document.getElementById(langSelectId);
        var status = langSelect && langSelect.parentElement ? langSelect.parentElement.querySelector('.preset-lang-picker-status') : null;
        if (!select) return;

        function setStatus(text, cls) {
          if (!status) return;
          status.textContent = text || '';
          status.classList.remove('is-error');
          if (cls) status.classList.add(cls);
        }

        function apply() {
          var preset = presets[select.value];
          if (!preset) return;
          var lang = langSelect ? langSelect.value : 'nl';

          if (lang === 'nl' || hasLang(preset, lang)) {
            setStatus('');
            fillFields(preset, lang, fieldIds);
            return;
          }

          // Onbekende taal voor dit preset: lui vertalen + bewaren
          // (ensure_preset_lang_translated() in presets.php — bv. Arabisch,
          // Russisch, of een translateapi.ai-only taal), dan pas vullen.
          // Volgende keer komt dezelfde taal+preset-combinatie direct uit de
          // opslag (hasLang() hierboven is dan al true).
          if (!langSelect) return;
          langSelect.disabled = true;
          setStatus(UI.loadlang_busy || '');

          var body = new URLSearchParams();
          body.set('action', 'ensure_preset_lang');
          body.set('type', type);
          body.set('id', select.value);
          body.set('lang', lang);

          fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
          })
          .then(function(r) { return r.json(); })
          .then(function(data) {
            langSelect.disabled = false;
            if (data && data.values) {
              preset.values = preset.values || {};
              preset.values[lang] = data.values;
            }
            if (data && data.ok) {
              setStatus('');
            } else {
              setStatus((UI.loadlang_error || '') + ((data && data.message) || ''), 'is-error');
            }
            // Ook bij een gedeeltelijke mislukking vullen we met wat er wél
            // vertaald kon worden (valueFor() valt daarna verder terug op
            // EN/NL) — beter dan de velden leeg te laten.
            fillFields(preset, lang, fieldIds);
          })
          .catch(function() {
            langSelect.disabled = false;
            setStatus(UI.loadlang_error || '', 'is-error');
          });
        }

        select.addEventListener('change', apply);
        if (langSelect) langSelect.addEventListener('change', apply);
      }

      wire(PROCESSING_PRESETS, 'processing', 'processingPresetSelect', 'processingPresetLang', <?= $processingFields ?>);
      wire(COMMERCIAL_PRESETS, 'commercial', 'commercialPresetSelect', 'commercialPresetLang', <?= $commercialFields ?>);
    })();
    </script>
    <?php
    return (string)ob_get_clean();
}

// Zelf-registratie: als index.php ons vóór zijn eigen POST-afhandeling
// inlaadt, pakken we onze eigen acties hier al op (zelfde patroon als
// contract_translate.php).
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['action'] ?? '') === 'translate_preset_fields') {
    handle_preset_translate_ajax();
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['action'] ?? '') === 'ensure_preset_lang') {
    handle_preset_ensure_lang_ajax();
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && in_array($_POST['action'] ?? '', ['save_preset', 'delete_preset'], true)) {
    handle_preset_post();
}