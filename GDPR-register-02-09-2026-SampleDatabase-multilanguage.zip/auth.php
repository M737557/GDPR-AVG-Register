<?php
// ============================================================
// auth.php — Shared TOTP (Time-based One-Time Password) authentication
// ============================================================
// This file is identical for every site instance. It expects ONE
// variable to already be defined (normally by auth_config.php, which
// you include right before this file):
//
//   $totpSecret   string  Base32-encoded secret for THIS site, used to
//                         generate/verify 6-digit codes with a
//                         standard authenticator app (Google
//                         Authenticator, Authy, 1Password, etc.)
//
// There is no username and no password — only the 6-digit code from
// the authenticator app. This is a deliberate design choice: the
// secret only ever leaves the server once, out-of-band, in the
// client's welcome email (see includes/functions.php in the
// onboarding panel) — never shown again on this login page itself.
//
// Usage, at the very top of a site's index.php:
//
//   require_once __DIR__ . '/auth_config.php';   // sets $totpSecret
//   require_once __DIR__ . '/auth.php';          // this file
//
// Add a logout link anywhere in the UI:
//   <a href="?logout=1">Logout</a>
// ============================================================

if (!isset($totpSecret) || trim($totpSecret) === '') {
    die('Auth configuration error: $totpSecret is not set. Check auth_config.php.');
}
if (!isset($authRealm)) {
    $authRealm = 'Protected Area';
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Namespace the session key per secret so multiple sites running under
// the same PHP sessionsession (e.g. same domain, different sub-paths) never
// share or overwrite each other's login state.
$authSessionKey = 'totp_auth_ok_' . md5($totpSecret);

// ------------------------------------------------------------
// TOTP ALGORITHM (RFC 6238 / RFC 4226) — self-contained, no
// dependencies. 30-second time step, SHA-1, 6 digits — the same
// defaults every standard authenticator app assumes.
// ------------------------------------------------------------

function totp_base32_decode(string $b32): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $b32));
    $bits = '';
    for ($i = 0; $i < strlen($b32); $i++) {
        $val = strpos($alphabet, $b32[$i]);
        if ($val === false) {
            continue;
        }
        $bits .= str_pad(decbin($val), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    for ($i = 0; $i + 8 <= strlen($bits); $i += 8) {
        $bytes .= chr(bindec(substr($bits, $i, 8)));
    }
    return $bytes;
}

function totp_code(string $secretBase32, ?int $timestamp = null, int $period = 30, int $digits = 6): string
{
    $timestamp = $timestamp ?? time();
    $key = totp_base32_decode($secretBase32);
    $counter = (int) floor($timestamp / $period);
    $counterBytes = pack('N*', 0, $counter); // 8-byte big-endian counter
    $hash = hash_hmac('sha1', $counterBytes, $key, true);
    $offset = ord($hash[19]) & 0x0F;
    $binary = ((ord($hash[$offset]) & 0x7F) << 24)
            | ((ord($hash[$offset + 1]) & 0xFF) << 16)
            | ((ord($hash[$offset + 2]) & 0xFF) << 8)
            | (ord($hash[$offset + 3]) & 0xFF);
    $otp = $binary % (10 ** $digits);
    return str_pad((string) $otp, $digits, '0', STR_PAD_LEFT);
}

/**
 * Verifies a submitted code against the secret, allowing a small
 * window either side of "now" (default ±1 step = ±30s) to tolerate
 * normal clock drift between the visitor's phone and this server.
 */
function totp_verify(string $secretBase32, string $submittedCode, int $window = 1, int $period = 30, int $digits = 6): bool
{
    $submittedCode = trim($submittedCode);
    if (!preg_match('/^\d{' . $digits . '}$/', $submittedCode)) {
        return false;
    }
    $now = time();
    for ($i = -$window; $i <= $window; $i++) {
        if (hash_equals(totp_code($secretBase32, $now + ($i * $period), $period, $digits), $submittedCode)) {
            return true;
        }
    }
    return false;
}

// ------------------------------------------------------------
// LOGOUT
// ------------------------------------------------------------
// Unlike HTTP auth, a normal PHP session has a real logout: just
// destroy it. No browser-credential caching to fight against.
if (isset($_GET['logout'])) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

// ------------------------------------------------------------
// ALREADY AUTHENTICATED THIS SESSION?
// ------------------------------------------------------------
if (empty($_SESSION[$authSessionKey])) {

    $error = '';
    $failKey = 'totp_fail_count_' . md5($totpSecret);
    $lockKey = 'totp_lock_until_' . md5($totpSecret);
    $_SESSION[$failKey] = $_SESSION[$failKey] ?? 0;
    $_SESSION[$lockKey] = $_SESSION[$lockKey] ?? 0;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['totp_code'])) {
        if (time() < $_SESSION[$lockKey]) {
            $waitSeconds = $_SESSION[$lockKey] - time();
            $error = "Too many incorrect attempts. Please wait {$waitSeconds}s and try again.";
        } elseif (totp_verify($totpSecret, $_POST['totp_code'])) {
            $_SESSION[$authSessionKey] = true;
            $_SESSION[$failKey] = 0;
            // Redirect so the code isn't left sitting in POST data / resubmittable on refresh.
            header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
            exit;
        } else {
            $_SESSION[$failKey]++;
            if ($_SESSION[$failKey] >= 5) {
                $_SESSION[$lockKey] = time() + 30;
                $_SESSION[$failKey] = 0;
                $error = 'Too many incorrect attempts. Please wait 30s and try again.';
            } else {
                $error = 'Incorrect code. Please try again.';
            }
        }
    }

    $realmLabel = htmlspecialchars($authRealm, ENT_QUOTES, 'UTF-8');
    $errorHtml  = $error !== '' ? '<div class="totp-error">' . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . '</div>' : '';

    header('Content-Type: text/html; charset=utf-8');
    echo <<<HTML
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Sign in — {$realmLabel}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="noindex">
        <style>
            body { font-family: Arial, Helvetica, sans-serif; background: #f4f6f9; color: #1a1a1a;
                   display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
            .box { max-width: 360px; width: 100%; background: #fff; border: 1px solid #dfe3ea;
                   border-radius: 6px; padding: 36px 32px; box-shadow: 0 2px 10px rgba(0,0,0,0.04); }
            h1 { font-size: 18px; margin: 0 0 6px; }
            p.sub { font-size: 13px; color: #666; margin: 0 0 24px; }
            label { display: block; font-size: 13px; color: #444; margin-bottom: 6px; }
            input[type=text] { width: 100%; box-sizing: border-box; padding: 12px 14px; font-size: 22px;
                   letter-spacing: 6px; text-align: center; border: 1px solid #ccc; border-radius: 4px;
                   font-family: 'Courier New', monospace; }
            button { width: 100%; margin-top: 16px; padding: 12px; font-size: 14px; font-weight: bold;
                   background: #2563eb; color: #fff; border: none; border-radius: 4px; cursor: pointer; }
            button:hover { background: #1d4ed8; }
            .totp-error { margin-bottom: 16px; padding: 10px 14px; background: #fdecea; color: #a13d3d;
                   border: 1px solid #f3c4c0; border-radius: 4px; font-size: 13px; }
            /* Auto-submit: hide the button, it will be triggered by JavaScript */
            #totp_submit { display: none; }
            /* Loading indicator styling */
            .spinner { display: none; text-align: center; margin-top: 12px; font-size: 14px; color: #666; }
            .spinner.active { display: block; }
            .spinner i { display: inline-block; animation: spin 1s linear infinite; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
    </head>
    <body>
        <div class="box">
            <h1>{$realmLabel}</h1>
            <p class="sub">Enter the 6-digit code from your authenticator app.</p>
            {$errorHtml}
            <form method="post" autocomplete="off" id="totpForm">
                <label for="totp_code">Authentication code</label>
                <input type="text" id="totp_code" name="totp_code" inputmode="numeric" pattern="[0-9]*"
                       maxlength="6" autofocus required placeholder="000000">
                <button type="submit" id="totp_submit">Sign In</button>
                
            </form>
        </div>
        <script>
            (function() {
                var codeInput = document.getElementById('totp_code');
                var form = document.getElementById('totpForm');
                var spinner = document.getElementById('totpSpinner');
                var errorDiv = document.querySelector('.totp-error');
                
                // Function to submit the form
                function submitForm() {
                    // Show spinner
                    if (spinner) spinner.classList.add('active');
                    
                    // Submit the form
                    form.submit();
                }
                
                // Auto-submit when 6 digits are entered
                codeInput.addEventListener('input', function(e) {
                    // Only digits
                    this.value = this.value.replace(/[^0-9]/g, '');
                    
                    // If we have 6 digits, submit
                    if (this.value.length === 6) {
                        // Small delay to show the spinner before submission
                        setTimeout(submitForm, 200);
                    }
                });
                
                // Also allow Enter key
                codeInput.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        if (this.value.length === 6) {
                            submitForm();
                        }
                    }
                });
                
                // If there's an error, focus the input and select all text
                if (errorDiv) {
                    codeInput.focus();
                    codeInput.select();
                }
            })();
        </script>
    </body>
    </html>
    HTML;
    exit;
}

// Expose a generic "authenticated" flag to the rest of the app if useful
// (there is no username in this scheme, only a shared per-site secret).
$authenticatedUser = 'authenticated';