<?php
// ============================================================
// CONFIGURATIE BESTAND - AVG Register
// ============================================================
//
// LET OP: de waarden in de onderstaande arrays (bijv. 'low', 'active',
// 'not_started', 'safeguard_scc', ...) zijn STABIELE INTERNE SLEUTELS.
// Ze worden nergens rechtstreeks getoond aan de gebruiker. De weergave-tekst
// komt altijd uit de $translations-array in index.php via de t($key)
// functie, zodat elk label automatisch meevertaalt naar de taal die de
// gebruiker heeft gekozen. Voeg hier dus geen vertaalde tekst toe -- voeg
// in plaats daarvan de sleutel toe aan $translations['en'] (en de overige
// talen) in index.php.

$config = array (
  'company_name' => 'Company',
  'company_subtitle' => 'Privacy & Compliance',
  'app_title' => 'AVG Register',
  'app_version' => '1.0',
  'gdpr_file' => 'gdpr_register.json',
  'dpia_file' => 'dpia_registrations.json',
  'breach_file' => 'data_breaches.json',
  'thirdparty_file' => 'third_parties.json',
  'departments_file' => 'departments.json',
  'measure_owners_file' => 'measure_owners.json',
  'default_user_id' => 100000006,
  'default_user_name' => 'System Administrator',
  'gdpr_id_start' => 200000001,
  'dpia_id_start' => 300000001,
  'breach_id_start' => 400000001,
  'thirdparty_id_start' => 500000001,
  // Elke sleutel hieronder komt overeen met een vertaalsleutel in
  // $translations in index.php (bv. t('low'), t('active'), ...).
  'risk_levels' =>
  array (
    'low' => 'low',
    'medium' => 'medium',
    'high' => 'high',
  ),
  'gdpr_statuses' =>
  array (
    'active' => 'active',
    'inactive' => 'inactive',
    'draft' => 'draft',
  ),
  'dpia_statuses' =>
  array (
    'not_started' => 'not_started',
    'draft' => 'draft',
    'in_progress' => 'in_progress',
    'completed' => 'completed',
    'approved' => 'approved',
    'not_required' => 'not_required',
  ),
  'breach_statuses' =>
  array (
    'open' => 'open',
    'investigating' => 'investigating',
    'contained' => 'contained',
    'resolved' => 'resolved',
    'closed' => 'closed',
  ),
  'breach_types' =>
  array (
    'confidentiality' => 'confidentiality',
    'integrity' => 'integrity',
    'availability' => 'availability',
    'mixed' => 'mixed',
  ),
  'compliance_statuses' =>
  array (
    'compliant' => 'compliant',
    'non_compliant' => 'non_compliant',
    'review_needed' => 'review_needed',
  ),
  'legal_basis' =>
  array (
    'contract' => 'contract',
    'consent' => 'consent',
    'legal_obligation' => 'legal_obligation',
    'legitimate_interests' => 'legitimate_interests',
    'vital_interests' => 'vital_interests',
    'public_task' => 'public_task',
  ),
  'risk_origin' =>
  array (
    'technical' => 'technical',
    'organizational' => 'organizational',
    'human_error' => 'human_error',
    'external' => 'external',
    'systematic_monitoring' => 'systematic_monitoring',
    'sensitive_data' => 'sensitive_data',
    'other' => 'other',
  ),
  'consultation_options' =>
  array (
    'yes' => 'yes',
    'no' => 'no',
    'planned' => 'planned',
  ),
  'management_approval_options' =>
  array (
    'pending' => 'pending',
    'approved' => 'approved',
    'rejected' => 'rejected',
  ),
  'yes_no_progress_options' =>
  array (
    'yes' => 'yes',
    'no' => 'no',
    'in_progress' => 'in_progress',
  ),
  'yes_no_options' =>
  array (
    'yes' => 'yes',
    'no' => 'no',
  ),
  'international_transfer_options' =>
  array (
    'yes' => 'yes',
    'no' => 'no',
    'unknown' => 'unknown',
  ),
  // Elke waarde hieronder is zelf ook een vertaalsleutel (safeguard_scc,
  // safeguard_bcr, ...), zodat deze standaardopties net als alle andere
  // labels automatisch meevertalen. Door de gebruiker zelf toegevoegde
  // (vrije tekst) waarborgen blijven onvertaald getoond zoals ze zijn
  // ingevoerd -- t() valt terug op de letterlijke tekst als er geen
  // vertaalsleutel bestaat.
  'safeguards_options' =>
  array (
    0 => 'safeguard_scc',
    1 => 'safeguard_bcr',
    2 => 'safeguard_privacy_shield',
    3 => 'safeguard_adequacy_decision',
    4 => 'safeguard_consent',
    5 => 'safeguard_model_contracts',
    6 => 'safeguard_certification',
    7 => 'safeguard_codes_of_conduct',
    8 => 'safeguard_dpia',
    9 => 'safeguard_tia',
  ),
  'language' => 'nl',
  'date_format' => 'd-m-Y',
  'datetime_format' => 'd-m-Y H:i',
  'items_per_page' => 50,
  'truncate_length' => 60,
  'bank_style' => true,
  'show_stats' => true,
);

// --- Helper functies ---
function getConfig($key, $default = null) { global $config; return isset($config[$key]) ? $config[$key] : $default; }
function setConfig($key, $value) { global $config; $config[$key] = $value; }
function getCompanyName() { return getConfig('company_name', 'Company Name'); }
function getDepartments() {
    $file = getConfig('departments_file', 'departments.json');
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}
function saveDepartments($departments) {
    $file = getConfig('departments_file', 'departments.json');
    return file_put_contents($file, json_encode($departments, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
}
// Measure owners: who is responsible for a given technical/organizational
// measure. Keyed as "technical::Measure name" / "organizational::Measure name"
// so the same label can exist independently in both lists.
function getMeasureOwners() {
    $file = getConfig('measure_owners_file', 'measure_owners.json');
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}
function saveMeasureOwners($owners) {
    $file = getConfig('measure_owners_file', 'measure_owners.json');
    return file_put_contents($file, json_encode($owners, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
}
function getSafeguardsOptions() { return getConfig('safeguards_options', []); }
// NOTE: these three helpers return raw internal keys (e.g. 'low',
// 'not_started', 'safeguard_scc'), NOT display text. index.php's t($key)
// is the single source of truth for the language-specific label; call
// t(getRiskLabel($risk)) etc. if you need a translated string, or just
// call t($risk) / t($status) / t($safeguard) directly.
function getStatusLabel($status, $type = 'gdpr') { $statuses = []; if ($type === 'gdpr') { $statuses = getConfig('gdpr_statuses', []); } elseif ($type === 'dpia') { $statuses = getConfig('dpia_statuses', []); } elseif ($type === 'breach') { $statuses = getConfig('breach_statuses', []); } elseif ($type === 'thirdparty') { $statuses = getConfig('compliance_statuses', []); } return isset($statuses[$status]) ? $statuses[$status] : $status; }
function getRiskLabel($risk) { $risks = getConfig('risk_levels', []); return isset($risks[$risk]) ? $risks[$risk] : $risk; }
function getSafeguardsLabel($safeguard) { $options = getConfig('safeguards_options', []); return isset($options[$safeguard]) ? $options[$safeguard] : $safeguard; }
$companyName = getCompanyName();
$companySubtitle = getConfig('company_subtitle', 'Privacy & Compliance');
$appTitle = getConfig('app_title', 'AVG Register');
$appVersion = getConfig('app_version', '1.0');
$gdprFile = getConfig('gdpr_file', 'gdpr_register.json');
$dpiaFile = getConfig('dpia_file', 'dpia_registrations.json');
$breachFile = getConfig('breach_file', 'data_breaches.json');
$thirdpartyFile = getConfig('thirdparty_file', 'third_parties.json');
$departmentsFile = getConfig('departments_file', 'departments.json');
$defaultUserId = getConfig('default_user_id', 1);
$gdprIdStart = getConfig('gdpr_id_start', 200000001);
$dpiaIdStart = getConfig('dpia_id_start', 300000001);
$breachIdStart = getConfig('breach_id_start', 400000001);
$thirdpartyIdStart = getConfig('thirdparty_id_start', 500000001);
$itemsPerPage = getConfig('items_per_page', 25);
$truncateLength = getConfig('truncate_length', 60);
?>
