translations

en= english etc..
nl = nederlands etc..

rename  [en_]gpdr_register.json
rename to: gdpr_register.json (system usage)