<?php
// ============================================================
// auth_config.php — default TOTP secret for a NEW client
// ============================================================
// This is the real file index.php requires — it ships with the
// template so a freshly provisioned portal is never broken by a
// missing auth_config.php, even before a secret has been pushed.
//
// In normal use through the onboarding panel, you'll never actually
// see this default secret in a live client folder: the moment a
// client is provisioned, push_totp_secret_to_client() in
// includes/functions.php overwrites this file with a fresh, random
// secret (see AUTO_PUSH_TOTP_ON_PROVISION in configmain.php, and the
// "Push New TOTP Secret" button in admin.php). This file is only what
// a client's portal falls back to if that push is ever skipped or
// turned off — a known, working default rather than a fatal error.
//
// Deploying this template by hand, outside the onboarding panel? Just
// replace the value below with your own base32 secret (e.g. generated
// by any TOTP secret generator), or scan/enter it directly into an
// authenticator app to use the shipped default as-is for testing.
//
// IMPORTANT: keep auth_config.php out of public web access if you can,
// e.g. one directory above the webroot, or protect the .php
// extension so it is never served as plain text by mistake.
// ============================================================

$totpSecret = 'D3RROBG6WSNJSO4BUNSQJQTCYAD7IXGH';
