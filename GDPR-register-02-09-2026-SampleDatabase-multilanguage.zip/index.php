<?php
// ============================================================
// AVG Register - GDPR, DPIA, Data Breach & Third Parties
// ============================================================

// --- TOTP authentication (per-site) ---
// $authRealm is just a display label on the login page. The actual
// secret comes from auth_config.php ($totpSecret) — no username, no
// password, only a 6-digit code from an authenticator app.
$authRealm = 'Portal ' . basename(__DIR__);
require_once __DIR__ . '/auth_config.php'; // ships with a default secret; overwritten with a random one on provisioning/push — see admin.php
require_once __DIR__ . '/auth.php';        // shared TOTP auth handler (same file for every site)

// --- Include configuratie ---
require_once 'config.php';

// --- Gebruik configuratie ---
$gdprFile = getConfig('gdpr_file', 'gdpr_register.json');
$dpiaFile = getConfig('dpia_file', 'dpia_registrations.json');
$breachFile = getConfig('breach_file', 'data_breaches.json');
$thirdpartyFile = getConfig('thirdparty_file', 'third_parties.json');
$companyName = getConfig('company_name', 'Company Name');
$companySubtitle = getConfig('company_subtitle', 'Privacy & Compliance');
$appTitle = getConfig('app_title', 'AVG Register');
$appVersion = getConfig('app_version', '2.0');
$defaultUserId = getConfig('default_user_id', 1);
$truncateLength = getConfig('truncate_length', 60);

// --- Language Settings ---
$availableLanguages = [
    'en' => 'English',
    'nl' => 'Nederlands',
    'fr' => 'Français',
    'de' => 'Deutsch',
    'es' => 'Español',
    'it' => 'Italiano',
    'pt' => 'Português',
    'ru' => 'Русский',
    'zh' => '中文',
    'ja' => '日本語',
    'ko' => '한국어',
    'ar' => 'العربية',
    'hi' => 'हिन्दी',
    'tr' => 'Türkçe',
    'pl' => 'Polski',
    'uk' => 'Українська',
    'sv' => 'Svenska',
    'no' => 'Norsk',
    'da' => 'Dansk',
    'fi' => 'Suomi',
    'id' => 'Bahasa Indonesia',
    'vi' => 'Tiếng Việt',
    'th' => 'ไทย',
    'fa' => 'فارسی',
    'he' => 'עברית',
    'el' => 'Ελληνικά',
    'cs' => 'Čeština',
    'ro' => 'Română',
    'hu' => 'Magyar',
    'bg' => 'Български',
    'hr' => 'Hrvatski',
    'sk' => 'Slovenčina',
    'sl' => 'Slovenščina',
    'lt' => 'Lietuvių',
    'lv' => 'Latviešu',
    'et' => 'Eesti',
    'sr' => 'Српски',
    'bn' => 'বাংলা',
    'ur' => 'اردو',
    'ms' => 'Bahasa Melayu',
    'tl' => 'Filipino'
];

// Set language from session, cookie, or default
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$defaultLang = getConfig('language', 'en');
$lang = isset($_GET['lang']) ? $_GET['lang'] : (isset($_COOKIE['app_lang']) ? $_COOKIE['app_lang'] : (isset($_SESSION['app_lang']) ? $_SESSION['app_lang'] : $defaultLang));

// Validate language
if (!isset($availableLanguages[$lang])) {
    $lang = isset($availableLanguages[$defaultLang]) ? $defaultLang : 'en';
}

// Save language preference
$_SESSION['app_lang'] = $lang;
setcookie('app_lang', $lang, time() + (86400 * 30), '/');

// --- Language Translations ---
$translations = [];

// ==================== ENGLISH ====================
$translations['en'] = [
    'app_title' => 'GDPR Register',
    'company_subtitle' => 'Privacy & Compliance',
    'dashboard' => 'Dashboard',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Data Breaches',
    'breach' => 'Data Breach',
    'third_parties' => 'Third Parties',
    'third_party' => 'Third Party',
    'measures' => 'Measures',
    'reporting' => 'Reporting',
    'total' => 'Total',
    'active' => 'Active',
    'high_risk' => 'High Risk',
    'dpia_required' => 'DPIA Required',
    'dpia_completed' => 'DPIA Completed',
    'new' => 'New',
    'export_json' => 'Export JSON',
    'search' => 'Search...',
    'search_company' => 'Search company...',
    'filter' => 'Filter',
    'clear' => 'Clear',
    'risk' => 'Risk',
    'risk_level' => 'Risk Level',
    'status' => 'Status',
    'retention_period' => 'Retention Period',
    'actions' => 'Actions',
    'view' => 'View',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'print' => 'Print',
    'confirm_delete' => 'Are you sure you want to delete this record? This cannot be undone.',
    'processing_activity' => 'Processing Activity',
    'purpose' => 'Purpose',
    'data_subjects' => 'Data Subjects',
    'personal_data' => 'Personal Data',
    'recipients' => 'Recipients',
    'legal_basis' => 'Legal Basis',
    'legitimate_interest' => 'Legitimate Interest',
    'department' => 'Department',
    'or_type_custom_department' => 'Or type a custom department',
    'or_type_custom_name' => 'Or type a name',
    'or_type_custom_risk_origin' => 'Or type a custom risk origin',
    'or_type_custom_status' => 'Or type a custom status',
    'or_type_custom_approval' => 'Or type a custom approval status',
    'or_type_custom_consultation' => 'Or type a custom value',
    'or_type_custom_compliance_status' => 'Or type a custom compliance status',
    'or_type_custom_breach_type' => 'Or type a custom breach type',
    'international_transfer' => 'International Transfer',
    'to_country' => 'To Country',
    'we_are_processor' => 'We are Processor',
    'processing_agreement_third_party' => 'Processing Agreement with Third Party',
    'technical_measures' => 'Technical Measures',
    'organizational_measures' => 'Organizational Measures',
    'safeguards' => 'Safeguards',
    'review_date' => 'Review Date',
    'controller' => 'Controller',
    'joint_controller' => 'Joint Controller',
    'dpo' => 'DPO',
    'representative' => 'Representative',
    'name' => 'Name',
    'contact' => 'Contact',
    'title' => 'Title',
    'description' => 'Description',
    'risk_origin' => 'Risk Origin',
    'affected_subjects' => 'Affected Subjects',
    'management_approval' => 'Management Approval',
    'approved_by' => 'Approved By',
    'approval_date' => 'Approval Date',
    'consultation_conducted' => 'Consultation Conducted',
    'consultation_details' => 'Consultation Details',
    'recommendations' => 'Recommendations',
    'notes' => 'Notes',
    'necessity_test' => 'Necessity Test',
    'proportionality_test' => 'Proportionality Test',
    'mitigation_measures' => 'Mitigation Measures',
    'residual_risk' => 'Residual Risk',
    'breach_date' => 'Breach Date',
    'discovery_date' => 'Discovery Date',
    'breach_type' => 'Breach Type',
    'causes' => 'Causes',
    'measures_taken' => 'Measures Taken',
    'notified_authority' => 'Notified Authority',
    'notification_date' => 'Notification Date',
    'notified_affected' => 'Notified Affected Persons',
    'company_name' => 'Company Name',
    'contact_person' => 'Contact Person',
    'email' => 'Email',
    'phone' => 'Phone',
    'address' => 'Address',
    'service_provided' => 'Service Provided',
    'agreement_signed' => 'Agreement Signed',
    'agreement_date' => 'Agreement Date',
    'expiry_date' => 'Expiry Date',
    'compliance_status' => 'Compliance Status',
    'save' => 'Save',
    'cancel' => 'Cancel',
    'add' => 'Add',
    'close' => 'Close',
    'language' => 'Language',
    'logout' => 'Logout',
    'logout_confirm' => 'Log out of this session?',
    'full_report' => 'Full Report',
    'backup' => 'Backup',
    'zip_backup' => 'ZIP Backup',
    'statistics' => 'Statistics',
    'no_records' => 'No records found',
    'showing' => 'Showing',
    'of' => 'of',
    'yes' => 'Yes',
    'no' => 'No',
    'unknown' => 'Unknown',
    'not_required' => 'Not Required',
    'in_progress' => 'In Progress',
    'completed' => 'Completed',
    'approved' => 'Approved',
    'draft' => 'Draft',
    'open' => 'Open',
    'investigating' => 'Investigating',
    'contained' => 'Contained',
    'resolved' => 'Resolved',
    'closed' => 'Closed',
    'compliant' => 'Compliant',
    'non_compliant' => 'Non-Compliant',
    'review_needed' => 'Review Needed',
    'low' => 'Low',
    'medium' => 'Medium',
    'high' => 'High',
    'confidentiality' => 'Confidentiality',
    'integrity' => 'Integrity',
    'availability' => 'Availability',
    'mixed' => 'Mixed',
    'contract' => 'Contract',
    'consent' => 'Consent',
    'legal_obligation' => 'Legal Obligation',
    'legitimate_interests' => 'Legitimate Interests',
    'vital_interests' => 'Vital Interests',
    'public_task' => 'Public Task',
    'technical' => 'Technical',
    'organizational' => 'Organizational',
    'human_error' => 'Human Error',
    'external' => 'External',
    'systematic_monitoring' => 'Systematic Monitoring',
    'sensitive_data' => 'Sensitive Data',
    'other' => 'Other',
    'administration' => 'Administration',
    'hr' => 'HR',
    'finance' => 'Finance',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Operations',
    'pending' => 'Pending',
    'rejected' => 'Rejected',
    'planned' => 'Planned',
    'donations' => 'Donations',
    'create_dpia' => 'Create DPIA',
    'create_dpia_from_gdpr' => 'Create DPIA from GDPR',
    'click_create_dpia_for_gdpr' => 'Click "Create DPIA" for a GDPR record that requires a DPIA:',
    'new_gdpr_record' => 'New GDPR Record',
    'edit_gdpr_record' => 'Edit GDPR Record',
    'new_dpia' => 'New DPIA',
    'edit_dpia' => 'Edit DPIA',
    'new_breach' => 'New Data Breach',
    'edit_breach' => 'Edit Data Breach',
    'new_third_party' => 'New Third Party',
    'edit_third_party' => 'Edit Third Party',
    'record' => 'Record',
    'page' => 'Page',
    'generated' => 'Generated',
    'successfully_added' => 'successfully added',
    'successfully_updated' => 'successfully updated',
    'unsaved_changes_confirm' => 'There are unsaved changes. Are you sure you want to cancel?',
    'select_or_type_below' => 'Select or type below',
    'or_type_custom_retention_period' => 'Or type custom retention period',
    'or_type_custom_safeguards' => 'Or type custom safeguards (semicolon separated)',
    'or_type_custom_measures' => 'Or type custom measures (semicolon separated)',
    'hold_ctrl_to_select_multiple' => 'Hold Ctrl (Windows) or Cmd (Mac) to select multiple',
    'custom_mitigation_measures' => 'Custom mitigation measures (semicolon separated)',
    'custom_measures_taken' => 'Custom measures taken (semicolon separated)',
    'custom_measures_placeholder' => 'e.g. Custom measure 1; Custom measure 2',
    'gdpr_record_id' => 'GDPR Record ID',
    'gdpr_record' => 'GDPR Record',
    'dpia_for_gdpr' => 'DPIA for GDPR',
    'dpia_exists_for_gdpr' => 'A DPIA already exists for GDPR',
    'for_gdpr_record' => 'for GDPR record',
    'only_one_dpia_allowed' => 'Only one DPIA is allowed per GDPR record.',
    'risk_distribution' => 'Risk Distribution',
    'gdpr_compliance_overview' => 'GDPR Compliance Overview',
    'inactive_draft' => 'Inactive / Draft',
    'collected_from_records' => 'Collected from records',
    'measure' => 'Measure',
    'value' => 'Value',
    'source' => 'Source',
    'configuration' => 'Configuration',
    'no_technical_measures' => 'No technical measures found',
    'no_organizational_measures' => 'No organizational measures found',
    'edit_measure' => 'Edit Measure',
    'current_measure' => 'Current Measure',
    'new_measure_name' => 'New Measure Name',
    'measure_renamed_success' => 'Measure successfully renamed everywhere it is used.',
    'measure_rename_warning' => 'This renames the measure in every GDPR, DPIA, and Data Breach record where it is used.',
    'measure_deleted_success' => 'Measure successfully deleted everywhere it was used.',
    'confirm_delete_measure' => 'Are you sure you want to delete this measure? It will be removed from every GDPR, DPIA, and Data Breach record where it is used. This cannot be undone.',
    'responsible' => 'Responsible',
    'responsible_placeholder' => 'Who is responsible for this measure?',
    'unassigned' => 'Unassigned',
    'value_renamed_success' => 'Value successfully renamed everywhere it is used.',
    'value_deleted_success' => 'Value successfully removed everywhere it was used.',
    'edit_value' => 'Edit value',
    'delete_value' => 'Delete value',
    'current_value' => 'Current value',
    'new_value' => 'New value',
    'value_rename_warning' => 'Renaming updates this value everywhere it is currently used.',
    'value_delete_warning' => 'Deleting clears this value from every record where it is currently used. This cannot be undone.',
    'confirm_delete_value' => 'Delete this value everywhere it is used? This cannot be undone.',
    'used_in' => 'Used in',
    'not_currently_used' => 'Not currently used',
    'no_values' => 'No values found',
    'total_gdpr_records' => 'Total GDPR records',
    'dpia_in_progress' => 'DPIA in progress',
    'total_breaches' => 'Total breaches',
    'open_breaches' => 'Open breaches',
    'total_third_parties' => 'Total third parties',
    'compliant_third_parties' => 'Compliant third parties',
    'dpia_coverage' => 'DPIA Coverage',
    'gdpr_with_dpia_required' => 'GDPR with DPIA required',
    'dpia_completion_rate' => 'DPIA completion rate',
    'category' => 'Category',
    'overview' => 'Overview',
    'per_category' => 'Per Category',
    'total_risk' => 'Total Risk',
    'completion_rate' => 'Completion Rate',
    'record_type' => 'Record Type',
    'print_report_title' => 'Compliance Report',
    'generated_on' => 'Generated on',
    'not_started' => 'Not Started',
    'safeguard_scc' => 'Standard Contractual Clauses (SCCs)',
    'safeguard_bcr' => 'Binding Corporate Rules (BCRs)',
    'safeguard_privacy_shield' => 'Privacy Shield (no longer valid)',
    'safeguard_adequacy_decision' => 'European Commission Adequacy Decision',
    'safeguard_consent' => 'Specific consent from the data subject',
    'safeguard_model_contracts' => 'Model contracts',
    'safeguard_certification' => 'Certification mechanisms',
    'safeguard_codes_of_conduct' => 'Codes of conduct',
    'safeguard_dpia' => 'Data Protection Impact Assessment (DPIA)',
    'safeguard_tia' => 'International Data Transfer Impact Assessment (TIA)',
    'inactive' => 'Inactive',
];

// ==================== DUTCH ====================
$translations['nl'] = [
    'app_title' => 'AVG Register',
    'company_subtitle' => 'Privacy & Compliance',
    'dashboard' => 'Dashboard',
    'gdpr' => 'AVG',
    'dpia' => 'DPIA',
    'breaches' => 'Datalekken',
    'breach' => 'Datalek',
    'third_parties' => 'Derden',
    'third_party' => 'Derde Partij',
    'measures' => 'Maatregelen',
    'reporting' => 'Rapportage',
    'total' => 'Totaal',
    'active' => 'Actief',
    'high_risk' => 'Hoog risico',
    'dpia_required' => 'DPIA vereist',
    'dpia_completed' => 'DPIA afgerond',
    'new' => 'Nieuw',
    'export_json' => 'Exporteer JSON',
    'search' => 'Zoeken...',
    'search_company' => 'Zoek op bedrijf...',
    'filter' => 'Filter',
    'clear' => 'Wis',
    'risk' => 'Risico',
    'risk_level' => 'Risiconiveau',
    'status' => 'Status',
    'retention_period' => 'Bewaarperiode',
    'actions' => 'Acties',
    'view' => 'Bekijken',
    'edit' => 'Bewerken',
    'delete' => 'Verwijderen',
    'print' => 'Printen',
    'confirm_delete' => 'Weet u zeker dat u dit record wilt verwijderen? Dit kan niet ongedaan worden gemaakt.',
    'processing_activity' => 'Verwerkingsactiviteit',
    'purpose' => 'Doel',
    'data_subjects' => 'Betrokkenen',
    'personal_data' => 'Persoonsgegevens',
    'recipients' => 'Ontvangers',
    'legal_basis' => 'Rechtsbasis',
    'legitimate_interest' => 'Gerechtvaardigd belang',
    'department' => 'Afdeling',
    'or_type_custom_department' => 'Of typ zelf een afdeling in',
    'or_type_custom_name' => 'Of typ zelf een naam in',
    'or_type_custom_risk_origin' => 'Of typ zelf een risico-oorsprong in',
    'or_type_custom_status' => 'Of typ zelf een status in',
    'or_type_custom_approval' => 'Of typ zelf een goedkeuringsstatus in',
    'or_type_custom_consultation' => 'Of typ zelf een waarde in',
    'or_type_custom_compliance_status' => 'Of typ zelf een compliance status in',
    'or_type_custom_breach_type' => 'Of typ zelf een type lek in',
    'international_transfer' => 'Internationale doorgifte',
    'to_country' => 'Naar land',
    'we_are_processor' => 'Wij zijn verwerker',
    'processing_agreement_third_party' => 'Verwerkersovereenkomst met derde',
    'technical_measures' => 'Technische maatregelen',
    'organizational_measures' => 'Organisatorische maatregelen',
    'safeguards' => 'Waarborgen',
    'review_date' => 'Review datum',
    'controller' => 'Verwerkingsverantwoordelijke',
    'joint_controller' => 'Gezamenlijke verwerkingsverantwoordelijke',
    'dpo' => 'Functionaris Gegevensbescherming',
    'representative' => 'Vertegenwoordiger',
    'name' => 'Naam',
    'contact' => 'Contact',
    'title' => 'Titel',
    'description' => 'Beschrijving',
    'risk_origin' => 'Risico oorsprong',
    'affected_subjects' => 'Aantal betrokkenen',
    'management_approval' => 'Management goedkeuring',
    'approved_by' => 'Goedgekeurd door',
    'approval_date' => 'Goedkeuringsdatum',
    'consultation_conducted' => 'Consultatie uitgevoerd',
    'consultation_details' => 'Consultatie details',
    'recommendations' => 'Aanbevelingen',
    'notes' => 'Notities',
    'necessity_test' => 'Noodzakelijkheidstoets',
    'proportionality_test' => 'Proportionaliteitstoets',
    'mitigation_measures' => 'Mitigerende maatregelen',
    'residual_risk' => 'Restrisico',
    'breach_date' => 'Datum lek',
    'discovery_date' => 'Datum ontdekking',
    'breach_type' => 'Type lek',
    'causes' => 'Oorzaken',
    'measures_taken' => 'Genomen maatregelen',
    'notified_authority' => 'AP gemeld',
    'notification_date' => 'Datum melding AP',
    'notified_affected' => 'Betrokkenen geïnformeerd',
    'company_name' => 'Bedrijfsnaam',
    'contact_person' => 'Contactpersoon',
    'email' => 'E-mail',
    'phone' => 'Telefoon',
    'address' => 'Adres',
    'service_provided' => 'Geleverde dienst',
    'agreement_signed' => 'Overeenkomst getekend',
    'agreement_date' => 'Datum overeenkomst',
    'expiry_date' => 'Vervaldatum',
    'compliance_status' => 'Compliance status',
    'save' => 'Opslaan',
    'cancel' => 'Annuleren',
    'add' => 'Toevoegen',
    'close' => 'Sluiten',
    'language' => 'Taal',
    'full_report' => 'Volledig rapport',
    'backup' => 'Backup',
    'zip_backup' => 'ZIP Backup',
    'statistics' => 'Statistieken',
    'no_records' => 'Geen records gevonden',
    'showing' => 'Toont',
    'of' => 'van',
    'yes' => 'Ja',
    'no' => 'Nee',
    'unknown' => 'Onbekend',
    'not_required' => 'Niet vereist',
    'in_progress' => 'In uitvoering',
    'completed' => 'Afgerond',
    'approved' => 'Goedgekeurd',
    'draft' => 'Concept',
    'open' => 'Open',
    'investigating' => 'In onderzoek',
    'contained' => 'Ingedamd',
    'resolved' => 'Opgelost',
    'closed' => 'Gesloten',
    'compliant' => 'Compliant',
    'non_compliant' => 'Niet compliant',
    'review_needed' => 'Beoordeling nodig',
    'low' => 'Laag',
    'medium' => 'Middel',
    'high' => 'Hoog',
    'confidentiality' => 'Vertrouwelijkheid',
    'integrity' => 'Integriteit',
    'availability' => 'Beschikbaarheid',
    'mixed' => 'Gemengd',
    'contract' => 'Overeenkomst',
    'consent' => 'Toestemming',
    'legal_obligation' => 'Wettelijke verplichting',
    'legitimate_interests' => 'Gerechtvaardigd belang',
    'vital_interests' => 'Levendige belangen',
    'public_task' => 'Publieke taak',
    'technical' => 'Technisch',
    'organizational' => 'Organisatorisch',
    'human_error' => 'Menselijke fout',
    'external' => 'Extern',
    'systematic_monitoring' => 'Systematische monitoring',
    'sensitive_data' => 'Gevoelige gegevens',
    'other' => 'Overig',
    'administration' => 'Administratie',
    'hr' => 'HR',
    'finance' => 'Financiën',
    'marketing' => 'Marketing',
    'it' => 'ICT',
    'operations' => 'Operationeel',
    'pending' => 'In afwachting',
    'rejected' => 'Afgewezen',
    'planned' => 'Gepland',
    'donations' => 'Donaties',
    'create_dpia' => 'Maak DPIA',
    'create_dpia_from_gdpr' => 'DPIA aanmaken vanuit AVG',
    'click_create_dpia_for_gdpr' => 'Klik op "Maak DPIA" voor een AVG record dat een DPIA vereist:',
    'new_gdpr_record' => 'Nieuw AVG Record',
    'edit_gdpr_record' => 'AVG Record bewerken',
    'new_dpia' => 'Nieuwe DPIA',
    'edit_dpia' => 'DPIA bewerken',
    'new_breach' => 'Nieuw datalek',
    'edit_breach' => 'Datalek bewerken',
    'new_third_party' => 'Nieuwe derde partij',
    'edit_third_party' => 'Derde partij bewerken',
    'record' => 'Record',
    'page' => 'Pagina',
    'generated' => 'Gegenereerd',
    'successfully_added' => 'succesvol toegevoegd',
    'successfully_updated' => 'succesvol bijgewerkt',
    'unsaved_changes_confirm' => 'Er zijn niet-opgeslagen wijzigingen. Weet je zeker dat je wilt annuleren?',
    'select_or_type_below' => 'Selecteer of typ hieronder',
    'or_type_custom_retention_period' => 'Of typ eigen bewaarperiode',
    'or_type_custom_safeguards' => 'Of typ eigen waarborgen (puntkomma gescheiden)',
    'or_type_custom_measures' => 'Of typ eigen maatregelen (puntkomma gescheiden)',
    'hold_ctrl_to_select_multiple' => 'Houd Ctrl (Windows) of Cmd (Mac) ingedrukt om meerdere te selecteren',
    'custom_mitigation_measures' => 'Eigen mitigerende maatregelen (puntkomma gescheiden)',
    'custom_measures_taken' => 'Eigen genomen maatregelen (puntkomma gescheiden)',
    'custom_measures_placeholder' => 'Bijv. Eigen maatregel 1; Eigen maatregel 2',
    'gdpr_record_id' => 'AVG Record ID',
    'gdpr_record' => 'AVG Record',
    'dpia_for_gdpr' => 'DPIA voor AVG',
    'dpia_exists_for_gdpr' => 'Er bestaat al een DPIA voor AVG',
    'for_gdpr_record' => 'voor AVG record',
    'only_one_dpia_allowed' => 'Per AVG record mag slechts 1 DPIA bestaan.',
    'risk_distribution' => 'Risico distributie',
    'gdpr_compliance_overview' => 'AVG-compliance overzicht',
    'inactive_draft' => 'Inactief / Concept',
    'collected_from_records' => 'Verzameld uit alle records',
    'measure' => 'Maatregel',
    'value' => 'Waarde',
    'source' => 'Bron',
    'configuration' => 'Configuratie',
    'no_technical_measures' => 'Geen technische maatregelen gevonden',
    'no_organizational_measures' => 'Geen organisatorische maatregelen gevonden',
    'edit_measure' => 'Maatregel bewerken',
    'current_measure' => 'Huidige maatregel',
    'new_measure_name' => 'Nieuwe naam maatregel',
    'measure_renamed_success' => 'Maatregel is overal waar deze gebruikt wordt hernoemd.',
    'measure_rename_warning' => 'Dit hernoemt de maatregel in elk AVG-, DPIA- en datalek-record waarin deze wordt gebruikt.',
    'measure_deleted_success' => 'Maatregel is overal waar deze gebruikt werd verwijderd.',
    'confirm_delete_measure' => 'Weet je zeker dat je deze maatregel wilt verwijderen? Deze wordt verwijderd uit elk AVG-, DPIA- en datalek-record waarin deze wordt gebruikt. Dit kan niet ongedaan worden gemaakt.',
    'responsible' => 'Verantwoordelijke',
    'responsible_placeholder' => 'Wie is verantwoordelijk voor deze maatregel?',
    'unassigned' => 'Niet toegewezen',
    'value_renamed_success' => 'Waarde is overal waar deze gebruikt wordt hernoemd.',
    'value_deleted_success' => 'Waarde is overal waar deze gebruikt werd verwijderd.',
    'edit_value' => 'Waarde bewerken',
    'delete_value' => 'Waarde verwijderen',
    'current_value' => 'Huidige waarde',
    'new_value' => 'Nieuwe waarde',
    'value_rename_warning' => 'Hernoemen werkt de waarde overal bij waar deze op dit moment gebruikt wordt.',
    'value_delete_warning' => 'Verwijderen wist deze waarde uit elk record waarin deze op dit moment gebruikt wordt. Dit kan niet ongedaan worden gemaakt.',
    'confirm_delete_value' => 'Deze waarde overal verwijderen waar hij gebruikt wordt? Dit kan niet ongedaan worden gemaakt.',
    'used_in' => 'Gebruikt in',
    'not_currently_used' => 'Wordt momenteel niet gebruikt',
    'no_values' => 'Geen waarden gevonden',
    'total_gdpr_records' => 'Totaal AVG records',
    'dpia_in_progress' => 'DPIA in uitvoering',
    'total_breaches' => 'Totaal datalekken',
    'open_breaches' => 'Open datalekken',
    'total_third_parties' => 'Totaal derden',
    'compliant_third_parties' => 'Compliant derden',
    'dpia_coverage' => 'DPIA dekking',
    'gdpr_with_dpia_required' => 'AVG met DPIA vereist',
    'dpia_completion_rate' => 'DPIA afronding',
    'category' => 'Categorie',
    'overview' => 'Overzicht',
    'per_category' => 'Per categorie',
    'total_risk' => 'Totaal risico',
    'completion_rate' => 'Afrondingspercentage',
    'record_type' => 'Recordtype',
    'print_report_title' => 'Compliance Rapportage',
    'generated_on' => 'Gegenereerd op',
    'logout' => 'Uitloggen',
    'logout_confirm' => 'Wil je uitloggen van deze sessie?',
    'not_started' => 'Niet gestart',
    'safeguard_scc' => 'Standaardcontractbepalingen (SCC\'s)',
    'safeguard_bcr' => 'Binding Corporate Rules (BCR\'s)',
    'safeguard_privacy_shield' => 'Privacy Shield (niet meer geldig)',
    'safeguard_adequacy_decision' => 'Adequaatheidsbesluit Europese Commissie',
    'safeguard_consent' => 'Specifieke toestemming van betrokkene',
    'safeguard_model_contracts' => 'Modelcontracten',
    'safeguard_certification' => 'Certificeringsmechanismen',
    'safeguard_codes_of_conduct' => 'Gedragscodes',
    'safeguard_dpia' => 'Data Protection Impact Assessment (DPIA)',
    'safeguard_tia' => 'Internationale Data Transfer Impact Assessment (TIA)',
    'inactive' => 'Inactief',
];
// ==================== French ====================

// ==================== FRENCH ====================
$translations['fr'] = [
    'app_title' => 'Registre RGPD',
    'company_subtitle' => 'Confidentialité & Conformité',
    'dashboard' => 'Tableau de bord',
    'gdpr' => 'RGPD',
    'dpia' => 'AIPD',
    'breaches' => 'Violations de données',
    'breach' => 'Violation de données',
    'third_parties' => 'Tiers',
    'third_party' => 'Tierce Partie',
    'measures' => 'Mesures',
    'reporting' => 'Rapports',
    'total' => 'Total',
    'active' => 'Actif',
    'high_risk' => 'Risque élevé',
    'dpia_required' => 'AIPD requise',
    'dpia_completed' => 'AIPD terminée',
    'new' => 'Nouveau',
    'export_json' => 'Exporter JSON',
    'search' => 'Rechercher...',
    'search_company' => 'Rechercher une société...',
    'filter' => 'Filtrer',
    'clear' => 'Effacer',
    'risk' => 'Risque',
    'risk_level' => 'Niveau de risque',
    'status' => 'Statut',
    'retention_period' => 'Période de conservation',
    'actions' => 'Actions',
    'view' => 'Voir',
    'edit' => 'Modifier',
    'delete' => 'Supprimer',
    'print' => 'Imprimer',
    'confirm_delete' => 'Êtes-vous sûr de vouloir supprimer cet enregistrement ? Cette action est irréversible.',
    'processing_activity' => 'Activité de traitement',
    'purpose' => 'Finalité',
    'data_subjects' => 'Personnes concernées',
    'personal_data' => 'Données personnelles',
    'recipients' => 'Destinataires',
    'legal_basis' => 'Base juridique',
    'legitimate_interest' => 'Intérêt légitime',
    'department' => 'Département',
    'international_transfer' => 'Transfert international',
    'to_country' => 'Vers le pays',
    'we_are_processor' => 'Nous sommes sous-traitant',
    'processing_agreement_third_party' => 'Contrat de sous-traitance avec un tiers',
    'technical_measures' => 'Mesures techniques',
    'organizational_measures' => 'Mesures organisationnelles',
    'safeguards' => 'Garanties',
    'review_date' => 'Date de révision',
    'controller' => 'Responsable de traitement',
    'joint_controller' => 'Responsable de traitement conjoint',
    'dpo' => 'Délégué à la Protection des Données',
    'representative' => 'Représentant',
    'name' => 'Nom',
    'contact' => 'Contact',
    'title' => 'Titre',
    'description' => 'Description',
    'risk_origin' => 'Origine du risque',
    'affected_subjects' => 'Personnes concernées',
    'management_approval' => 'Approbation de la direction',
    'approved_by' => 'Approuvé par',
    'approval_date' => 'Date d\'approbation',
    'consultation_conducted' => 'Consultation effectuée',
    'consultation_details' => 'Détails de la consultation',
    'recommendations' => 'Recommandations',
    'notes' => 'Notes',
    'necessity_test' => 'Test de nécessité',
    'proportionality_test' => 'Test de proportionnalité',
    'mitigation_measures' => 'Mesures d\'atténuation',
    'residual_risk' => 'Risque résiduel',
    'breach_date' => 'Date de la violation',
    'discovery_date' => 'Date de découverte',
    'breach_type' => 'Type de violation',
    'causes' => 'Causes',
    'measures_taken' => 'Mesures prises',
    'notified_authority' => 'Autorité notifiée',
    'notification_date' => 'Date de notification',
    'notified_affected' => 'Personnes concernées informées',
    'company_name' => 'Nom de la société',
    'contact_person' => 'Personne de contact',
    'email' => 'E-mail',
    'phone' => 'Téléphone',
    'address' => 'Adresse',
    'service_provided' => 'Service fourni',
    'agreement_signed' => 'Contrat signé',
    'agreement_date' => 'Date du contrat',
    'expiry_date' => 'Date d\'expiration',
    'compliance_status' => 'Statut de conformité',
    'save' => 'Enregistrer',
    'cancel' => 'Annuler',
    'add' => 'Ajouter',
    'close' => 'Fermer',
    'language' => 'Langue',
    'full_report' => 'Rapport complet',
    'backup' => 'Sauvegarde',
    'zip_backup' => 'Sauvegarde ZIP',
    'statistics' => 'Statistiques',
    'no_records' => 'Aucun enregistrement trouvé',
    'showing' => 'Affichage de',
    'of' => 'sur',
    'yes' => 'Oui',
    'no' => 'Non',
    'unknown' => 'Inconnu',
    'not_required' => 'Non requis',
    'in_progress' => 'En cours',
    'completed' => 'Terminé',
    'approved' => 'Approuvé',
    'draft' => 'Brouillon',
    'open' => 'Ouvert',
    'investigating' => 'En investigation',
    'contained' => 'Contenu',
    'resolved' => 'Résolu',
    'closed' => 'Fermé',
    'compliant' => 'Conforme',
    'non_compliant' => 'Non conforme',
    'review_needed' => 'Révision nécessaire',
    'low' => 'Faible',
    'medium' => 'Moyen',
    'high' => 'Élevé',
    'confidentiality' => 'Confidentialité',
    'integrity' => 'Intégrité',
    'availability' => 'Disponibilité',
    'mixed' => 'Mixte',
    'contract' => 'Contrat',
    'consent' => 'Consentement',
    'legal_obligation' => 'Obligation légale',
    'legitimate_interests' => 'Intérêts légitimes',
    'vital_interests' => 'Intérêts vitaux',
    'public_task' => 'Mission d\'intérêt public',
    'technical' => 'Technique',
    'organizational' => 'Organisationnel',
    'human_error' => 'Erreur humaine',
    'external' => 'Externe',
    'systematic_monitoring' => 'Surveillance systématique',
    'sensitive_data' => 'Données sensibles',
    'other' => 'Autre',
    'administration' => 'Administration',
    'hr' => 'RH',
    'finance' => 'Finances',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Opérations',
    'pending' => 'En attente',
    'rejected' => 'Rejeté',
    'planned' => 'Planifié',
    'donations' => 'Dons',
    'create_dpia' => 'Créer une AIPD',
    'create_dpia_from_gdpr' => 'Créer une AIPD depuis le RGPD',
    'click_create_dpia_for_gdpr' => 'Cliquez sur "Créer une AIPD" pour un enregistrement RGPD qui nécessite une AIPD :',
    'new_gdpr_record' => 'Nouvel enregistrement RGPD',
    'edit_gdpr_record' => 'Modifier l\'enregistrement RGPD',
    'new_dpia' => 'Nouvelle AIPD',
    'edit_dpia' => 'Modifier l\'AIPD',
    'new_breach' => 'Nouvelle violation de données',
    'edit_breach' => 'Modifier la violation de données',
    'new_third_party' => 'Nouveau tiers',
    'edit_third_party' => 'Modifier le tiers',
    'record' => 'Enregistrement',
    'page' => 'Page',
    'generated' => 'Généré',
    'successfully_added' => 'ajouté avec succès',
    'successfully_updated' => 'mis à jour avec succès',
    'unsaved_changes_confirm' => 'Des modifications non enregistrées existent. Êtes-vous sûr de vouloir annuler ?',
    'select_or_type_below' => 'Sélectionnez ou saisissez ci-dessous',
    'or_type_custom_retention_period' => 'Ou saisissez une période de conservation personnalisée',
    'or_type_custom_safeguards' => 'Ou saisissez des garanties personnalisées (séparées par des virgules)',
    'or_type_custom_measures' => 'Ou saisissez des mesures personnalisées (séparées par des virgules)',
    'hold_ctrl_to_select_multiple' => 'Maintenez Ctrl (Windows) ou Cmd (Mac) pour sélectionner plusieurs éléments',
    'custom_mitigation_measures' => 'Mesures d\'atténuation personnalisées (séparées par des virgules)',
    'custom_measures_taken' => 'Mesures prises personnalisées (séparées par des virgules)',
    'custom_measures_placeholder' => 'ex. Mesure personnalisée 1, Mesure personnalisée 2',
    'gdpr_record_id' => 'ID de l\'enregistrement RGPD',
    'gdpr_record' => 'Enregistrement RGPD',
    'dpia_for_gdpr' => 'AIPD pour le RGPD',
    'dpia_exists_for_gdpr' => 'Une AIPD existe déjà pour ce RGPD',
    'for_gdpr_record' => 'pour l\'enregistrement RGPD',
    'only_one_dpia_allowed' => 'Une seule AIPD est autorisée par enregistrement RGPD.',
    'risk_distribution' => 'Répartition des risques',
    'gdpr_compliance_overview' => 'Aperçu de la conformité RGPD',
    'inactive_draft' => 'Inactif / Brouillon',
    'collected_from_records' => 'Collecté à partir des enregistrements',
    'measure' => 'Mesure',
    'source' => 'Source',
    'configuration' => 'Configuration',
    'no_technical_measures' => 'Aucune mesure technique trouvée',
    'no_organizational_measures' => 'Aucune mesure organisationnelle trouvée',
    'total_gdpr_records' => 'Total des enregistrements RGPD',
    'dpia_in_progress' => 'AIPD en cours',
    'total_breaches' => 'Total des violations',
    'open_breaches' => 'Violations ouvertes',
    'total_third_parties' => 'Total des tiers',
    'compliant_third_parties' => 'Tiers conformes',
    'dpia_coverage' => 'Couverture AIPD',
    'gdpr_with_dpia_required' => 'RGPD avec AIPD requise',
    'dpia_completion_rate' => 'Taux d\'achèvement des AIPD',
    'category' => 'Catégorie',
    'overview' => 'Aperçu',
    'per_category' => 'Par catégorie',
    'total_risk' => 'Risque total',
    'completion_rate' => 'Taux d\'achèvement',
    'record_type' => 'Type d\'enregistrement',
    'print_report_title' => 'Rapport de conformité',
    'generated_on' => 'Généré le',
    'discovered' => 'Découvert',
    'registered_at' => 'Enregistré le',
    'created_at' => 'Créé le',
    'or_type_custom_department' => 'Ou saisissez un service personnalisé',
    'or_type_custom_name' => 'Ou saisissez un nom',
    'or_type_custom_risk_origin' => 'Ou saisissez une origine de risque personnalisée',
    'or_type_custom_status' => 'Ou saisissez un statut personnalisé',
    'or_type_custom_approval' => 'Ou saisissez un statut d\'approbation personnalisé',
    'or_type_custom_consultation' => 'Ou saisissez une valeur personnalisée',
    'or_type_custom_compliance_status' => 'Ou saisissez un statut de conformité personnalisé',
    'or_type_custom_breach_type' => 'Ou saisissez un type de violation personnalisé',
    'logout' => 'Déconnexion',
    'logout_confirm' => 'Voulez-vous vous déconnecter de cette session ?',
    'value' => 'Valeur',
    'edit_measure' => 'Modifier la mesure',
    'current_measure' => 'Mesure actuelle',
    'new_measure_name' => 'Nouveau nom de la mesure',
    'measure_renamed_success' => 'La mesure a été renommée avec succès partout où elle est utilisée.',
    'measure_rename_warning' => 'Cette action renomme la mesure dans tous les enregistrements RGPD, AIPD et violations de données où elle est utilisée.',
    'measure_deleted_success' => 'La mesure a été supprimée avec succès partout où elle était utilisée.',
    'confirm_delete_measure' => 'Êtes-vous sûr de vouloir supprimer cette mesure ? Elle sera retirée de tous les enregistrements RGPD, AIPD et violations de données où elle est utilisée. Cette action est irréversible.',
    'responsible' => 'Responsable',
    'responsible_placeholder' => 'Qui est responsable de cette mesure ?',
    'unassigned' => 'Non attribué',
    'value_renamed_success' => 'La valeur a été renommée avec succès partout où elle est utilisée.',
    'value_deleted_success' => 'La valeur a été supprimée avec succès partout où elle était utilisée.',
    'edit_value' => 'Modifier la valeur',
    'delete_value' => 'Supprimer la valeur',
    'current_value' => 'Valeur actuelle',
    'new_value' => 'Nouvelle valeur',
    'value_rename_warning' => 'Le renommage met à jour cette valeur partout où elle est actuellement utilisée.',
    'value_delete_warning' => 'La suppression efface cette valeur de tous les enregistrements où elle est actuellement utilisée. Cette action est irréversible.',
    'confirm_delete_value' => 'Supprimer cette valeur partout où elle est utilisée ? Cette action est irréversible.',
    'used_in' => 'Utilisée dans',
    'not_currently_used' => 'Actuellement inutilisée',
    'no_values' => 'Aucune valeur trouvée',
    'not_started' => 'Non commencé',
    'safeguard_scc' => 'Clauses contractuelles types (CCT)',
    'safeguard_bcr' => 'Règles d\'entreprise contraignantes (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (n\'est plus valide)',
    'safeguard_adequacy_decision' => 'Décision d\'adéquation de la Commission européenne',
    'safeguard_consent' => 'Consentement spécifique de la personne concernée',
    'safeguard_model_contracts' => 'Contrats types',
    'safeguard_certification' => 'Mécanismes de certification',
    'safeguard_codes_of_conduct' => 'Codes de conduite',
    'safeguard_dpia' => 'Analyse d\'impact relative à la protection des données (AIPD)',
    'safeguard_tia' => 'Analyse d\'impact du transfert international de données (TIA)',
    'inactive' => 'Inactif',
];

// ==================== GERMAN ====================
$translations['de'] = [
    'app_title' => 'DSGVO-Register',
    'company_subtitle' => 'Datenschutz & Compliance',
    'dashboard' => 'Dashboard',
    'gdpr' => 'DSGVO',
    'dpia' => 'DSFA',
    'breaches' => 'Datenpannen',
    'breach' => 'Datenpanne',
    'third_parties' => 'Dritte',
    'third_party' => 'Dritter',
    'measures' => 'Maßnahmen',
    'reporting' => 'Berichterstattung',
    'total' => 'Gesamt',
    'active' => 'Aktiv',
    'high_risk' => 'Hohes Risiko',
    'dpia_required' => 'DSFA erforderlich',
    'dpia_completed' => 'DSFA abgeschlossen',
    'new' => 'Neu',
    'export_json' => 'JSON exportieren',
    'search' => 'Suchen...',
    'search_company' => 'Firma suchen...',
    'filter' => 'Filtern',
    'clear' => 'Löschen',
    'risk' => 'Risiko',
    'risk_level' => 'Risikostufe',
    'status' => 'Status',
    'retention_period' => 'Aufbewahrungsfrist',
    'actions' => 'Aktionen',
    'view' => 'Anzeigen',
    'edit' => 'Bearbeiten',
    'delete' => 'Löschen',
    'print' => 'Drucken',
    'confirm_delete' => 'Möchten Sie diesen Datensatz wirklich löschen? Dies kann nicht rückgängig gemacht werden.',
    'processing_activity' => 'Verarbeitungstätigkeit',
    'purpose' => 'Zweck',
    'data_subjects' => 'Betroffene',
    'personal_data' => 'Personenbezogene Daten',
    'recipients' => 'Empfänger',
    'legal_basis' => 'Rechtsgrundlage',
    'legitimate_interest' => 'Berechtigtes Interesse',
    'department' => 'Abteilung',
    'international_transfer' => 'Internationale Übermittlung',
    'to_country' => 'In das Land',
    'we_are_processor' => 'Wir sind Auftragsverarbeiter',
    'processing_agreement_third_party' => 'Auftragsverarbeitungsvertrag mit Dritten',
    'technical_measures' => 'Technische Maßnahmen',
    'organizational_measures' => 'Organisatorische Maßnahmen',
    'safeguards' => 'Garantien',
    'review_date' => 'Überprüfungsdatum',
    'controller' => 'Verantwortlicher',
    'joint_controller' => 'Gemeinsamer Verantwortlicher',
    'dpo' => 'Datenschutzbeauftragter',
    'representative' => 'Vertreter',
    'name' => 'Name',
    'contact' => 'Kontakt',
    'title' => 'Titel',
    'description' => 'Beschreibung',
    'risk_origin' => 'Risikoursprung',
    'affected_subjects' => 'Betroffene Personen',
    'management_approval' => 'Genehmigung der Geschäftsleitung',
    'approved_by' => 'Genehmigt von',
    'approval_date' => 'Genehmigungsdatum',
    'consultation_conducted' => 'Konsultation durchgeführt',
    'consultation_details' => 'Konsultationsdetails',
    'recommendations' => 'Empfehlungen',
    'notes' => 'Notizen',
    'necessity_test' => 'Notwendigkeitstest',
    'proportionality_test' => 'Verhältnismäßigkeitstest',
    'mitigation_measures' => 'Minderungsmaßnahmen',
    'residual_risk' => 'Restrisiko',
    'breach_date' => 'Datum des Verstoßes',
    'discovery_date' => 'Datum der Entdeckung',
    'breach_type' => 'Art des Verstoßes',
    'causes' => 'Ursachen',
    'measures_taken' => 'Ergriffene Maßnahmen',
    'notified_authority' => 'Behörde benachrichtigt',
    'notification_date' => 'Benachrichtigungsdatum',
    'notified_affected' => 'Betroffene informiert',
    'company_name' => 'Firmenname',
    'contact_person' => 'Ansprechpartner',
    'email' => 'E-Mail',
    'phone' => 'Telefon',
    'address' => 'Adresse',
    'service_provided' => 'Erbrachte Dienstleistung',
    'agreement_signed' => 'Vertrag unterzeichnet',
    'agreement_date' => 'Vertragsdatum',
    'expiry_date' => 'Ablaufdatum',
    'compliance_status' => 'Compliance-Status',
    'save' => 'Speichern',
    'cancel' => 'Abbrechen',
    'add' => 'Hinzufügen',
    'close' => 'Schließen',
    'language' => 'Sprache',
    'full_report' => 'Vollständiger Bericht',
    'backup' => 'Backup',
    'zip_backup' => 'ZIP-Backup',
    'statistics' => 'Statistiken',
    'no_records' => 'Keine Datensätze gefunden',
    'showing' => 'Zeige',
    'of' => 'von',
    'yes' => 'Ja',
    'no' => 'Nein',
    'unknown' => 'Unbekannt',
    'not_required' => 'Nicht erforderlich',
    'in_progress' => 'In Bearbeitung',
    'completed' => 'Abgeschlossen',
    'approved' => 'Genehmigt',
    'draft' => 'Entwurf',
    'open' => 'Offen',
    'investigating' => 'In Untersuchung',
    'contained' => 'Eingedämmt',
    'resolved' => 'Gelöst',
    'closed' => 'Geschlossen',
    'compliant' => 'Konform',
    'non_compliant' => 'Nicht konform',
    'review_needed' => 'Überprüfung erforderlich',
    'low' => 'Niedrig',
    'medium' => 'Mittel',
    'high' => 'Hoch',
    'confidentiality' => 'Vertraulichkeit',
    'integrity' => 'Integrität',
    'availability' => 'Verfügbarkeit',
    'mixed' => 'Gemischt',
    'contract' => 'Vertrag',
    'consent' => 'Einwilligung',
    'legal_obligation' => 'Rechtliche Verpflichtung',
    'legitimate_interests' => 'Berechtigte Interessen',
    'vital_interests' => 'Lebenswichtige Interessen',
    'public_task' => 'Öffentliche Aufgabe',
    'technical' => 'Technisch',
    'organizational' => 'Organisatorisch',
    'human_error' => 'Menschlicher Fehler',
    'external' => 'Extern',
    'systematic_monitoring' => 'Systematische Überwachung',
    'sensitive_data' => 'Sensible Daten',
    'other' => 'Andere',
    'administration' => 'Verwaltung',
    'hr' => 'Personal',
    'finance' => 'Finanzen',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Betrieb',
    'pending' => 'Ausstehend',
    'rejected' => 'Abgelehnt',
    'planned' => 'Geplant',
    'donations' => 'Spenden',
    'create_dpia' => 'DSFA erstellen',
    'create_dpia_from_gdpr' => 'DSFA aus DSGVO erstellen',
    'click_create_dpia_for_gdpr' => 'Klicken Sie auf "DSFA erstellen" für einen DSGVO-Datensatz, der eine DSFA erfordert:',
    'new_gdpr_record' => 'Neuer DSGVO-Datensatz',
    'edit_gdpr_record' => 'DSGVO-Datensatz bearbeiten',
    'new_dpia' => 'Neue DSFA',
    'edit_dpia' => 'DSFA bearbeiten',
    'new_breach' => 'Neue Datenpanne',
    'edit_breach' => 'Datenpanne bearbeiten',
    'new_third_party' => 'Neuer Dritter',
    'edit_third_party' => 'Dritten bearbeiten',
    'record' => 'Datensatz',
    'page' => 'Seite',
    'generated' => 'Generiert',
    'successfully_added' => 'erfolgreich hinzugefügt',
    'successfully_updated' => 'erfolgreich aktualisiert',
    'unsaved_changes_confirm' => 'Es gibt nicht gespeicherte Änderungen. Sind Sie sicher, dass Sie abbrechen möchten?',
    'select_or_type_below' => 'Wählen oder geben Sie unten ein',
    'or_type_custom_retention_period' => 'Oder geben Sie eine eigene Aufbewahrungsfrist ein',
    'or_type_custom_safeguards' => 'Oder geben Sie eigene Garantien ein (durch Kommas getrennt)',
    'or_type_custom_measures' => 'Oder geben Sie eigene Maßnahmen ein (durch Kommas getrennt)',
    'hold_ctrl_to_select_multiple' => 'Halten Sie Strg (Windows) oder Cmd (Mac) gedrückt, um mehrere auszuwählen',
    'custom_mitigation_measures' => 'Eigene Minderungsmaßnahmen (durch Kommas getrennt)',
    'custom_measures_taken' => 'Eigene ergriffene Maßnahmen (durch Kommas getrennt)',
    'custom_measures_placeholder' => 'z.B. Eigene Maßnahme 1, Eigene Maßnahme 2',
    'gdpr_record_id' => 'DSGVO-Datensatz-ID',
    'gdpr_record' => 'DSGVO-Datensatz',
    'dpia_for_gdpr' => 'DSFA für DSGVO',
    'dpia_exists_for_gdpr' => 'Eine DSFA existiert bereits für DSGVO',
    'for_gdpr_record' => 'für DSGVO-Datensatz',
    'only_one_dpia_allowed' => 'Nur eine DSFA ist pro DSGVO-Datensatz erlaubt.',
    'risk_distribution' => 'Risikoverteilung',
    'gdpr_compliance_overview' => 'DSGVO-Compliance-Übersicht',
    'inactive_draft' => 'Inaktiv / Entwurf',
    'collected_from_records' => 'Aus Datensätzen gesammelt',
    'measure' => 'Maßnahme',
    'source' => 'Quelle',
    'configuration' => 'Konfiguration',
    'no_technical_measures' => 'Keine technischen Maßnahmen gefunden',
    'no_organizational_measures' => 'Keine organisatorischen Maßnahmen gefunden',
    'total_gdpr_records' => 'DSGVO-Datensätze insgesamt',
    'dpia_in_progress' => 'DSFA in Bearbeitung',
    'total_breaches' => 'Datenpannen insgesamt',
    'open_breaches' => 'Offene Datenpannen',
    'total_third_parties' => 'Dritte insgesamt',
    'compliant_third_parties' => 'Konforme Dritte',
    'dpia_coverage' => 'DSFA-Abdeckung',
    'gdpr_with_dpia_required' => 'DSGVO mit DSFA erforderlich',
    'dpia_completion_rate' => 'DSFA-Abschlussquote',
    'category' => 'Kategorie',
    'overview' => 'Übersicht',
    'per_category' => 'Pro Kategorie',
    'total_risk' => 'Gesamtrisiko',
    'completion_rate' => 'Abschlussquote',
    'record_type' => 'Datensatztyp',
    'print_report_title' => 'Compliance-Bericht',
    'generated_on' => 'Generiert am',
    'or_type_custom_department' => 'Oder eine eigene Abteilung eingeben',
    'or_type_custom_name' => 'Oder einen Namen eingeben',
    'or_type_custom_risk_origin' => 'Oder eine eigene Risikoquelle eingeben',
    'or_type_custom_status' => 'Oder einen eigenen Status eingeben',
    'or_type_custom_approval' => 'Oder einen eigenen Genehmigungsstatus eingeben',
    'or_type_custom_consultation' => 'Oder einen eigenen Wert eingeben',
    'or_type_custom_compliance_status' => 'Oder einen eigenen Compliance-Status eingeben',
    'or_type_custom_breach_type' => 'Oder eine eigene Art der Datenpanne eingeben',
    'logout' => 'Abmelden',
    'logout_confirm' => 'Möchten Sie sich von dieser Sitzung abmelden?',
    'value' => 'Wert',
    'edit_measure' => 'Maßnahme bearbeiten',
    'current_measure' => 'Aktuelle Maßnahme',
    'new_measure_name' => 'Neuer Maßnahmenname',
    'measure_renamed_success' => 'Maßnahme wurde überall, wo sie verwendet wird, erfolgreich umbenannt.',
    'measure_rename_warning' => 'Dies benennt die Maßnahme in jedem DSGVO-, DSFA- und Datenpannen-Datensatz um, in dem sie verwendet wird.',
    'measure_deleted_success' => 'Maßnahme wurde überall, wo sie verwendet wurde, erfolgreich gelöscht.',
    'confirm_delete_measure' => 'Möchten Sie diese Maßnahme wirklich löschen? Sie wird aus jedem DSGVO-, DSFA- und Datenpannen-Datensatz entfernt, in dem sie verwendet wird. Dies kann nicht rückgängig gemacht werden.',
    'responsible' => 'Verantwortlich',
    'responsible_placeholder' => 'Wer ist für diese Maßnahme verantwortlich?',
    'unassigned' => 'Nicht zugewiesen',
    'value_renamed_success' => 'Wert wurde überall, wo er verwendet wird, erfolgreich umbenannt.',
    'value_deleted_success' => 'Wert wurde überall, wo er verwendet wurde, erfolgreich entfernt.',
    'edit_value' => 'Wert bearbeiten',
    'delete_value' => 'Wert löschen',
    'current_value' => 'Aktueller Wert',
    'new_value' => 'Neuer Wert',
    'value_rename_warning' => 'Das Umbenennen aktualisiert diesen Wert überall, wo er derzeit verwendet wird.',
    'value_delete_warning' => 'Das Löschen entfernt diesen Wert aus jedem Datensatz, in dem er derzeit verwendet wird. Dies kann nicht rückgängig gemacht werden.',
    'confirm_delete_value' => 'Diesen Wert überall löschen, wo er verwendet wird? Dies kann nicht rückgängig gemacht werden.',
    'used_in' => 'Verwendet in',
    'not_currently_used' => 'Derzeit nicht verwendet',
    'no_values' => 'Keine Werte gefunden',
    'not_started' => 'Nicht begonnen',
    'safeguard_scc' => 'Standardvertragsklauseln (SCC)',
    'safeguard_bcr' => 'Verbindliche Unternehmensregelungen (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (nicht mehr gültig)',
    'safeguard_adequacy_decision' => 'Angemessenheitsbeschluss der Europäischen Kommission',
    'safeguard_consent' => 'Ausdrückliche Einwilligung der betroffenen Person',
    'safeguard_model_contracts' => 'Musterverträge',
    'safeguard_certification' => 'Zertifizierungsmechanismen',
    'safeguard_codes_of_conduct' => 'Verhaltensregeln',
    'safeguard_dpia' => 'Datenschutz-Folgenabschätzung (DSFA)',
    'safeguard_tia' => 'Transfer Impact Assessment (TIA)',
    'inactive' => 'Inaktiv',
];

// ==================== SPANISH ====================
$translations['es'] = [
    'app_title' => 'Registro RGPD',
    'company_subtitle' => 'Privacidad y Cumplimiento',
    'dashboard' => 'Panel de control',
    'gdpr' => 'RGPD',
    'dpia' => 'EIPD',
    'breaches' => 'Violaciones de datos',
    'breach' => 'Violación de datos',
    'third_parties' => 'Terceros',
    'third_party' => 'Tercero',
    'measures' => 'Medidas',
    'reporting' => 'Informes',
    'total' => 'Total',
    'active' => 'Activo',
    'high_risk' => 'Alto riesgo',
    'dpia_required' => 'EIPD requerida',
    'dpia_completed' => 'EIPD completada',
    'new' => 'Nuevo',
    'export_json' => 'Exportar JSON',
    'search' => 'Buscar...',
    'search_company' => 'Buscar empresa...',
    'filter' => 'Filtrar',
    'clear' => 'Limpiar',
    'risk' => 'Riesgo',
    'risk_level' => 'Nivel de riesgo',
    'status' => 'Estado',
    'retention_period' => 'Período de retención',
    'actions' => 'Acciones',
    'view' => 'Ver',
    'edit' => 'Editar',
    'delete' => 'Eliminar',
    'print' => 'Imprimir',
    'confirm_delete' => '¿Está seguro de que desea eliminar este registro? Esta acción no se puede deshacer.',
    'processing_activity' => 'Actividad de tratamiento',
    'purpose' => 'Finalidad',
    'data_subjects' => 'Interesados',
    'personal_data' => 'Datos personales',
    'recipients' => 'Destinatarios',
    'legal_basis' => 'Base legal',
    'legitimate_interest' => 'Interés legítimo',
    'department' => 'Departamento',
    'international_transfer' => 'Transferencia internacional',
    'to_country' => 'Al país',
    'we_are_processor' => 'Somos encargados del tratamiento',
    'processing_agreement_third_party' => 'Acuerdo de tratamiento con terceros',
    'technical_measures' => 'Medidas técnicas',
    'organizational_measures' => 'Medidas organizativas',
    'safeguards' => 'Garantías',
    'review_date' => 'Fecha de revisión',
    'controller' => 'Responsable del tratamiento',
    'joint_controller' => 'Corresponsable del tratamiento',
    'dpo' => 'Delegado de Protección de Datos',
    'representative' => 'Representante',
    'name' => 'Nombre',
    'contact' => 'Contacto',
    'title' => 'Título',
    'description' => 'Descripción',
    'risk_origin' => 'Origen del riesgo',
    'affected_subjects' => 'Interesados afectados',
    'management_approval' => 'Aprobación de la dirección',
    'approved_by' => 'Aprobado por',
    'approval_date' => 'Fecha de aprobación',
    'consultation_conducted' => 'Consulta realizada',
    'consultation_details' => 'Detalles de la consulta',
    'recommendations' => 'Recomendaciones',
    'notes' => 'Notas',
    'necessity_test' => 'Prueba de necesidad',
    'proportionality_test' => 'Prueba de proporcionalidad',
    'mitigation_measures' => 'Medidas de mitigación',
    'residual_risk' => 'Riesgo residual',
    'breach_date' => 'Fecha de la violación',
    'discovery_date' => 'Fecha de descubrimiento',
    'breach_type' => 'Tipo de violación',
    'causes' => 'Causas',
    'measures_taken' => 'Medidas tomadas',
    'notified_authority' => 'Autoridad notificada',
    'notification_date' => 'Fecha de notificación',
    'notified_affected' => 'Interesados notificados',
    'company_name' => 'Nombre de la empresa',
    'contact_person' => 'Persona de contacto',
    'email' => 'Correo electrónico',
    'phone' => 'Teléfono',
    'address' => 'Dirección',
    'service_provided' => 'Servicio prestado',
    'agreement_signed' => 'Acuerdo firmado',
    'agreement_date' => 'Fecha del acuerdo',
    'expiry_date' => 'Fecha de vencimiento',
    'compliance_status' => 'Estado de cumplimiento',
    'save' => 'Guardar',
    'cancel' => 'Cancelar',
    'add' => 'Añadir',
    'close' => 'Cerrar',
    'language' => 'Idioma',
    'full_report' => 'Informe completo',
    'backup' => 'Copia de seguridad',
    'zip_backup' => 'Copia de seguridad ZIP',
    'statistics' => 'Estadísticas',
    'no_records' => 'No se encontraron registros',
    'showing' => 'Mostrando',
    'of' => 'de',
    'yes' => 'Sí',
    'no' => 'No',
    'unknown' => 'Desconocido',
    'not_required' => 'No requerido',
    'in_progress' => 'En progreso',
    'completed' => 'Completado',
    'approved' => 'Aprobado',
    'draft' => 'Borrador',
    'open' => 'Abierto',
    'investigating' => 'En investigación',
    'contained' => 'Contenido',
    'resolved' => 'Resuelto',
    'closed' => 'Cerrado',
    'compliant' => 'Cumple',
    'non_compliant' => 'No cumple',
    'review_needed' => 'Revisión necesaria',
    'low' => 'Bajo',
    'medium' => 'Medio',
    'high' => 'Alto',
    'confidentiality' => 'Confidencialidad',
    'integrity' => 'Integridad',
    'availability' => 'Disponibilidad',
    'mixed' => 'Mixto',
    'contract' => 'Contrato',
    'consent' => 'Consentimiento',
    'legal_obligation' => 'Obligación legal',
    'legitimate_interests' => 'Intereses legítimos',
    'vital_interests' => 'Intereses vitales',
    'public_task' => 'Tarea pública',
    'technical' => 'Técnico',
    'organizational' => 'Organizativo',
    'human_error' => 'Error humano',
    'external' => 'Externo',
    'systematic_monitoring' => 'Monitoreo sistemático',
    'sensitive_data' => 'Datos sensibles',
    'other' => 'Otro',
    'administration' => 'Administración',
    'hr' => 'RRHH',
    'finance' => 'Finanzas',
    'marketing' => 'Marketing',
    'it' => 'TI',
    'operations' => 'Operaciones',
    'pending' => 'Pendiente',
    'rejected' => 'Rechazado',
    'planned' => 'Planificado',
    'donations' => 'Donaciones',
    'create_dpia' => 'Crear EIPD',
    'create_dpia_from_gdpr' => 'Crear EIPD desde RGPD',
    'click_create_dpia_for_gdpr' => 'Haga clic en "Crear EIPD" para un registro RGPD que requiera una EIPD:',
    'new_gdpr_record' => 'Nuevo registro RGPD',
    'edit_gdpr_record' => 'Editar registro RGPD',
    'new_dpia' => 'Nueva EIPD',
    'edit_dpia' => 'Editar EIPD',
    'new_breach' => 'Nueva violación de datos',
    'edit_breach' => 'Editar violación de datos',
    'new_third_party' => 'Nuevo tercero',
    'edit_third_party' => 'Editar tercero',
    'record' => 'Registro',
    'page' => 'Página',
    'generated' => 'Generado',
    'successfully_added' => 'añadido con éxito',
    'successfully_updated' => 'actualizado con éxito',
    'unsaved_changes_confirm' => 'Hay cambios sin guardar. ¿Está seguro de que desea cancelar?',
    'select_or_type_below' => 'Seleccione o escriba a continuación',
    'or_type_custom_retention_period' => 'O escriba un período de retención personalizado',
    'or_type_custom_safeguards' => 'O escriba garantías personalizadas (separadas por comas)',
    'or_type_custom_measures' => 'O escriba medidas personalizadas (separadas por comas)',
    'hold_ctrl_to_select_multiple' => 'Mantenga Ctrl (Windows) o Cmd (Mac) para seleccionar varios',
    'custom_mitigation_measures' => 'Medidas de mitigación personalizadas (separadas por comas)',
    'custom_measures_taken' => 'Medidas tomadas personalizadas (separadas por comas)',
    'custom_measures_placeholder' => 'Ej. Medida personalizada 1, Medida personalizada 2',
    'gdpr_record_id' => 'ID de registro RGPD',
    'gdpr_record' => 'Registro RGPD',
    'dpia_for_gdpr' => 'EIPD para RGPD',
    'dpia_exists_for_gdpr' => 'Ya existe una EIPD para RGPD',
    'for_gdpr_record' => 'para registro RGPD',
    'only_one_dpia_allowed' => 'Solo se permite una EIPD por registro RGPD.',
    'risk_distribution' => 'Distribución de riesgos',
    'gdpr_compliance_overview' => 'Resumen de cumplimiento RGPD',
    'inactive_draft' => 'Inactivo / Borrador',
    'collected_from_records' => 'Recopilado de registros',
    'measure' => 'Medida',
    'source' => 'Fuente',
    'configuration' => 'Configuración',
    'no_technical_measures' => 'No se encontraron medidas técnicas',
    'no_organizational_measures' => 'No se encontraron medidas organizativas',
    'total_gdpr_records' => 'Total de registros RGPD',
    'dpia_in_progress' => 'EIPD en progreso',
    'total_breaches' => 'Total de violaciones',
    'open_breaches' => 'Violaciones abiertas',
    'total_third_parties' => 'Total de terceros',
    'compliant_third_parties' => 'Terceros conformes',
    'dpia_coverage' => 'Cobertura de EIPD',
    'gdpr_with_dpia_required' => 'RGPD con EIPD requerida',
    'dpia_completion_rate' => 'Tasa de finalización de EIPD',
    'category' => 'Categoría',
    'overview' => 'Resumen',
    'per_category' => 'Por categoría',
    'total_risk' => 'Riesgo total',
    'completion_rate' => 'Tasa de finalización',
    'record_type' => 'Tipo de registro',
    'print_report_title' => 'Informe de cumplimiento',
    'generated_on' => 'Generado el',
    'or_type_custom_department' => 'O escriba un departamento personalizado',
    'or_type_custom_name' => 'O escriba un nombre',
    'or_type_custom_risk_origin' => 'O escriba un origen de riesgo personalizado',
    'or_type_custom_status' => 'O escriba un estado personalizado',
    'or_type_custom_approval' => 'O escriba un estado de aprobación personalizado',
    'or_type_custom_consultation' => 'O escriba un valor personalizado',
    'or_type_custom_compliance_status' => 'O escriba un estado de cumplimiento personalizado',
    'or_type_custom_breach_type' => 'O escriba un tipo de violación personalizado',
    'logout' => 'Cerrar sesión',
    'logout_confirm' => '¿Cerrar sesión en este dispositivo?',
    'value' => 'Valor',
    'edit_measure' => 'Editar medida',
    'current_measure' => 'Medida actual',
    'new_measure_name' => 'Nuevo nombre de la medida',
    'measure_renamed_success' => 'Medida renombrada correctamente en todos los lugares donde se utiliza.',
    'measure_rename_warning' => 'Esto renombra la medida en todos los registros de RGPD, EIPD y violaciones de datos donde se utiliza.',
    'measure_deleted_success' => 'Medida eliminada correctamente en todos los lugares donde se utilizaba.',
    'confirm_delete_measure' => '¿Está seguro de que desea eliminar esta medida? Se eliminará de todos los registros de RGPD, EIPD y violaciones de datos donde se utilice. Esta acción no se puede deshacer.',
    'responsible' => 'Responsable',
    'responsible_placeholder' => '¿Quién es responsable de esta medida?',
    'unassigned' => 'Sin asignar',
    'value_renamed_success' => 'Valor renombrado correctamente en todos los lugares donde se utiliza.',
    'value_deleted_success' => 'Valor eliminado correctamente en todos los lugares donde se utilizaba.',
    'edit_value' => 'Editar valor',
    'delete_value' => 'Eliminar valor',
    'current_value' => 'Valor actual',
    'new_value' => 'Nuevo valor',
    'value_rename_warning' => 'Al cambiar el nombre se actualiza este valor en todos los lugares donde se utiliza actualmente.',
    'value_delete_warning' => 'Al eliminarlo se borrará este valor de todos los registros donde se utiliza actualmente. Esta acción no se puede deshacer.',
    'confirm_delete_value' => '¿Eliminar este valor en todos los lugares donde se utiliza? Esta acción no se puede deshacer.',
    'used_in' => 'Utilizado en',
    'not_currently_used' => 'No se utiliza actualmente',
    'no_values' => 'No se encontraron valores',
    'not_started' => 'No iniciado',
    'safeguard_scc' => 'Cláusulas contractuales tipo (CCT)',
    'safeguard_bcr' => 'Normas corporativas vinculantes (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (ya no es válido)',
    'safeguard_adequacy_decision' => 'Decisión de adecuación de la Comisión Europea',
    'safeguard_consent' => 'Consentimiento específico del interesado',
    'safeguard_model_contracts' => 'Contratos modelo',
    'safeguard_certification' => 'Mecanismos de certificación',
    'safeguard_codes_of_conduct' => 'Códigos de conducta',
    'safeguard_dpia' => 'Evaluación de impacto relativa a la protección de datos (EIPD)',
    'safeguard_tia' => 'Evaluación de impacto de la transferencia internacional de datos (TIA)',
    'inactive' => 'Inactivo',
];

// ==================== ITALIAN ====================
$translations['it'] = [
    'app_title' => 'Registro GDPR',
    'company_subtitle' => 'Privacy & Conformità',
    'dashboard' => 'Dashboard',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Violazioni dei dati',
    'breach' => 'Violazione dei dati',
    'third_parties' => 'Terze parti',
    'third_party' => 'Terza parte',
    'measures' => 'Misure',
    'reporting' => 'Reportistica',
    'total' => 'Totale',
    'active' => 'Attivo',
    'high_risk' => 'Alto rischio',
    'dpia_required' => 'DPIA richiesta',
    'dpia_completed' => 'DPIA completata',
    'new' => 'Nuovo',
    'export_json' => 'Esporta JSON',
    'search' => 'Cerca...',
    'search_company' => 'Cerca azienda...',
    'filter' => 'Filtra',
    'clear' => 'Cancella',
    'risk' => 'Rischio',
    'risk_level' => 'Livello di rischio',
    'status' => 'Stato',
    'retention_period' => 'Periodo di conservazione',
    'actions' => 'Azioni',
    'view' => 'Visualizza',
    'edit' => 'Modifica',
    'delete' => 'Elimina',
    'print' => 'Stampa',
    'confirm_delete' => 'Sei sicuro di voler eliminare questo record? Questa azione non può essere annullata.',
    'processing_activity' => 'Attività di trattamento',
    'purpose' => 'Finalità',
    'data_subjects' => 'Interessati',
    'personal_data' => 'Dati personali',
    'recipients' => 'Destinatari',
    'legal_basis' => 'Base giuridica',
    'legitimate_interest' => 'Interesse legittimo',
    'department' => 'Dipartimento',
    'international_transfer' => 'Trasferimento internazionale',
    'to_country' => 'Verso il paese',
    'we_are_processor' => 'Siamo responsabili del trattamento',
    'processing_agreement_third_party' => 'Accordo di trattamento con terze parti',
    'technical_measures' => 'Misure tecniche',
    'organizational_measures' => 'Misure organizzative',
    'safeguards' => 'Garanzie',
    'review_date' => 'Data di revisione',
    'controller' => 'Titolare del trattamento',
    'joint_controller' => 'Contitolare del trattamento',
    'dpo' => 'Responsabile della protezione dei dati',
    'representative' => 'Rappresentante',
    'name' => 'Nome',
    'contact' => 'Contatto',
    'title' => 'Titolo',
    'description' => 'Descrizione',
    'risk_origin' => 'Origine del rischio',
    'affected_subjects' => 'Interessati coinvolti',
    'management_approval' => 'Approvazione della direzione',
    'approved_by' => 'Approvato da',
    'approval_date' => 'Data di approvazione',
    'consultation_conducted' => 'Consultazione effettuata',
    'consultation_details' => 'Dettagli della consultazione',
    'recommendations' => 'Raccomandazioni',
    'notes' => 'Note',
    'necessity_test' => 'Test di necessità',
    'proportionality_test' => 'Test di proporzionalità',
    'mitigation_measures' => 'Misure di mitigazione',
    'residual_risk' => 'Rischio residuo',
    'breach_date' => 'Data della violazione',
    'discovery_date' => 'Data di scoperta',
    'breach_type' => 'Tipo di violazione',
    'causes' => 'Cause',
    'measures_taken' => 'Misure adottate',
    'notified_authority' => 'Autorità notificata',
    'notification_date' => 'Data di notifica',
    'notified_affected' => 'Interessati informati',
    'company_name' => 'Nome dell\'azienda',
    'contact_person' => 'Persona di contatto',
    'email' => 'Email',
    'phone' => 'Telefono',
    'address' => 'Indirizzo',
    'service_provided' => 'Servizio fornito',
    'agreement_signed' => 'Accordo firmato',
    'agreement_date' => 'Data dell\'accordo',
    'expiry_date' => 'Data di scadenza',
    'compliance_status' => 'Stato di conformità',
    'save' => 'Salva',
    'cancel' => 'Annulla',
    'add' => 'Aggiungi',
    'close' => 'Chiudi',
    'language' => 'Lingua',
    'full_report' => 'Rapporto completo',
    'backup' => 'Backup',
    'zip_backup' => 'Backup ZIP',
    'statistics' => 'Statistiche',
    'no_records' => 'Nessun record trovato',
    'showing' => 'Visualizzazione di',
    'of' => 'di',
    'yes' => 'Sì',
    'no' => 'No',
    'unknown' => 'Sconosciuto',
    'not_required' => 'Non richiesto',
    'in_progress' => 'In corso',
    'completed' => 'Completato',
    'approved' => 'Approvato',
    'draft' => 'Bozza',
    'open' => 'Aperto',
    'investigating' => 'In indagine',
    'contained' => 'Contenuto',
    'resolved' => 'Risolto',
    'closed' => 'Chiuso',
    'compliant' => 'Conforme',
    'non_compliant' => 'Non conforme',
    'review_needed' => 'Revisione necessaria',
    'low' => 'Basso',
    'medium' => 'Medio',
    'high' => 'Alto',
    'confidentiality' => 'Riservatezza',
    'integrity' => 'Integrità',
    'availability' => 'Disponibilità',
    'mixed' => 'Misto',
    'contract' => 'Contratto',
    'consent' => 'Consenso',
    'legal_obligation' => 'Obbligo legale',
    'legitimate_interests' => 'Interessi legittimi',
    'vital_interests' => 'Interessi vitali',
    'public_task' => 'Compito di interesse pubblico',
    'technical' => 'Tecnico',
    'organizational' => 'Organizzativo',
    'human_error' => 'Errore umano',
    'external' => 'Esterno',
    'systematic_monitoring' => 'Monitoraggio sistematico',
    'sensitive_data' => 'Dati sensibili',
    'other' => 'Altro',
    'administration' => 'Amministrazione',
    'hr' => 'HR',
    'finance' => 'Finanza',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Operazioni',
    'pending' => 'In attesa',
    'rejected' => 'Respinto',
    'planned' => 'Pianificato',
    'donations' => 'Donazioni',
    'create_dpia' => 'Crea DPIA',
    'create_dpia_from_gdpr' => 'Crea DPIA da GDPR',
    'click_create_dpia_for_gdpr' => 'Fai clic su "Crea DPIA" per un record GDPR che richiede una DPIA:',
    'new_gdpr_record' => 'Nuovo record GDPR',
    'edit_gdpr_record' => 'Modifica record GDPR',
    'new_dpia' => 'Nuova DPIA',
    'edit_dpia' => 'Modifica DPIA',
    'new_breach' => 'Nuova violazione dei dati',
    'edit_breach' => 'Modifica violazione dei dati',
    'new_third_party' => 'Nuova terza parte',
    'edit_third_party' => 'Modifica terza parte',
    'record' => 'Record',
    'page' => 'Pagina',
    'generated' => 'Generato',
    'successfully_added' => 'aggiunto con successo',
    'successfully_updated' => 'aggiornato con successo',
    'unsaved_changes_confirm' => 'Ci sono modifiche non salvate. Sei sicuro di voler annullare?',
    'select_or_type_below' => 'Seleziona o digita qui sotto',
    'or_type_custom_retention_period' => 'O digita un periodo di conservazione personalizzato',
    'or_type_custom_safeguards' => 'O digita garanzie personalizzate (separate da virgole)',
    'or_type_custom_measures' => 'O digita misure personalizzate (separate da virgole)',
    'hold_ctrl_to_select_multiple' => 'Tieni premuto Ctrl (Windows) o Cmd (Mac) per selezionare più elementi',
    'custom_mitigation_measures' => 'Misure di mitigazione personalizzate (separate da virgole)',
    'custom_measures_taken' => 'Misure adottate personalizzate (separate da virgole)',
    'custom_measures_placeholder' => 'Es. Misura personalizzata 1, Misura personalizzata 2',
    'gdpr_record_id' => 'ID record GDPR',
    'gdpr_record' => 'Record GDPR',
    'dpia_for_gdpr' => 'DPIA per GDPR',
    'dpia_exists_for_gdpr' => 'Esiste già una DPIA per GDPR',
    'for_gdpr_record' => 'per record GDPR',
    'only_one_dpia_allowed' => 'È consentita una sola DPIA per record GDPR.',
    'risk_distribution' => 'Distribuzione del rischio',
    'gdpr_compliance_overview' => 'Panoramica conformità GDPR',
    'inactive_draft' => 'Inattivo / Bozza',
    'collected_from_records' => 'Raccolto dai record',
    'measure' => 'Misura',
    'source' => 'Fonte',
    'configuration' => 'Configurazione',
    'no_technical_measures' => 'Nessuna misura tecnica trovata',
    'no_organizational_measures' => 'Nessuna misura organizzativa trovata',
    'total_gdpr_records' => 'Totale record GDPR',
    'dpia_in_progress' => 'DPIA in corso',
    'total_breaches' => 'Totale violazioni',
    'open_breaches' => 'Violazioni aperte',
    'total_third_parties' => 'Totale terze parti',
    'compliant_third_parties' => 'Terze parti conformi',
    'dpia_coverage' => 'Copertura DPIA',
    'gdpr_with_dpia_required' => 'GDPR con DPIA richiesta',
    'dpia_completion_rate' => 'Tasso di completamento DPIA',
    'category' => 'Categoria',
    'overview' => 'Panoramica',
    'per_category' => 'Per categoria',
    'total_risk' => 'Rischio totale',
    'completion_rate' => 'Tasso di completamento',
    'record_type' => 'Tipo di record',
    'print_report_title' => 'Rapporto di conformità',
    'generated_on' => 'Generato il',
    'or_type_custom_department' => 'Oppure digita un reparto personalizzato',
    'or_type_custom_name' => 'Oppure digita un nome',
    'or_type_custom_risk_origin' => 'Oppure digita un\'origine del rischio personalizzata',
    'or_type_custom_status' => 'Oppure digita uno stato personalizzato',
    'or_type_custom_approval' => 'Oppure digita uno stato di approvazione personalizzato',
    'or_type_custom_consultation' => 'Oppure digita un valore personalizzato',
    'or_type_custom_compliance_status' => 'Oppure digita uno stato di conformità personalizzato',
    'or_type_custom_breach_type' => 'Oppure digita un tipo di violazione personalizzato',
    'logout' => 'Esci',
    'logout_confirm' => 'Vuoi uscire da questa sessione?',
    'value' => 'Valore',
    'edit_measure' => 'Modifica misura',
    'current_measure' => 'Misura attuale',
    'new_measure_name' => 'Nuovo nome della misura',
    'measure_renamed_success' => 'Misura rinominata correttamente ovunque venga utilizzata.',
    'measure_rename_warning' => 'Questo rinomina la misura in ogni record GDPR, DPIA e violazione dei dati in cui viene utilizzata.',
    'measure_deleted_success' => 'Misura eliminata correttamente ovunque fosse utilizzata.',
    'confirm_delete_measure' => 'Sei sicuro di voler eliminare questa misura? Verrà rimossa da ogni record GDPR, DPIA e violazione dei dati in cui viene utilizzata. Questa azione non può essere annullata.',
    'responsible' => 'Responsabile',
    'responsible_placeholder' => 'Chi è responsabile di questa misura?',
    'unassigned' => 'Non assegnato',
    'value_renamed_success' => 'Valore rinominato correttamente ovunque venga utilizzato.',
    'value_deleted_success' => 'Valore rimosso correttamente ovunque fosse utilizzato.',
    'edit_value' => 'Modifica valore',
    'delete_value' => 'Elimina valore',
    'current_value' => 'Valore attuale',
    'new_value' => 'Nuovo valore',
    'value_rename_warning' => 'La rinomina aggiorna questo valore ovunque venga attualmente utilizzato.',
    'value_delete_warning' => 'L\'eliminazione rimuove questo valore da ogni record in cui è attualmente utilizzato. Questa azione non può essere annullata.',
    'confirm_delete_value' => 'Eliminare questo valore ovunque venga utilizzato? Questa azione non può essere annullata.',
    'used_in' => 'Utilizzato in',
    'not_currently_used' => 'Non attualmente utilizzato',
    'no_values' => 'Nessun valore trovato',
    'not_started' => 'Non iniziato',
    'safeguard_scc' => 'Clausole contrattuali standard (SCC)',
    'safeguard_bcr' => 'Norme vincolanti d\'impresa (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (non più valido)',
    'safeguard_adequacy_decision' => 'Decisione di adeguatezza della Commissione europea',
    'safeguard_consent' => 'Consenso specifico dell\'interessato',
    'safeguard_model_contracts' => 'Contratti tipo',
    'safeguard_certification' => 'Meccanismi di certificazione',
    'safeguard_codes_of_conduct' => 'Codici di condotta',
    'safeguard_dpia' => 'Valutazione d\'impatto sulla protezione dei dati (DPIA)',
    'safeguard_tia' => 'Valutazione d\'impatto del trasferimento internazionale dei dati (TIA)',
    'inactive' => 'Inattivo',
];

// ==================== PORTUGUESE ====================
$translations['pt'] = [
    'app_title' => 'Registo RGPD',
    'company_subtitle' => 'Privacidade e Conformidade',
    'dashboard' => 'Painel de controlo',
    'gdpr' => 'RGPD',
    'dpia' => 'AIPD',
    'breaches' => 'Violações de dados',
    'breach' => 'Violação de dados',
    'third_parties' => 'Terceiros',
    'third_party' => 'Terceiro',
    'measures' => 'Medidas',
    'reporting' => 'Relatórios',
    'total' => 'Total',
    'active' => 'Ativo',
    'high_risk' => 'Alto risco',
    'dpia_required' => 'AIPD necessária',
    'dpia_completed' => 'AIPD concluída',
    'new' => 'Novo',
    'export_json' => 'Exportar JSON',
    'search' => 'Pesquisar...',
    'search_company' => 'Pesquisar empresa...',
    'filter' => 'Filtrar',
    'clear' => 'Limpar',
    'risk' => 'Risco',
    'risk_level' => 'Nível de risco',
    'status' => 'Estado',
    'retention_period' => 'Período de retenção',
    'actions' => 'Ações',
    'view' => 'Ver',
    'edit' => 'Editar',
    'delete' => 'Eliminar',
    'print' => 'Imprimir',
    'confirm_delete' => 'Tem certeza de que deseja eliminar este registo? Esta ação não pode ser desfeita.',
    'processing_activity' => 'Atividade de tratamento',
    'purpose' => 'Finalidade',
    'data_subjects' => 'Titulares de dados',
    'personal_data' => 'Dados pessoais',
    'recipients' => 'Destinatários',
    'legal_basis' => 'Base legal',
    'legitimate_interest' => 'Interesse legítimo',
    'department' => 'Departamento',
    'international_transfer' => 'Transferência internacional',
    'to_country' => 'Para o país',
    'we_are_processor' => 'Somos subcontratantes',
    'processing_agreement_third_party' => 'Acordo de tratamento com terceiros',
    'technical_measures' => 'Medidas técnicas',
    'organizational_measures' => 'Medidas organizacionais',
    'safeguards' => 'Garantias',
    'review_date' => 'Data de revisão',
    'controller' => 'Responsável pelo tratamento',
    'joint_controller' => 'Corresponsável pelo tratamento',
    'dpo' => 'Encarregado de Proteção de Dados',
    'representative' => 'Representante',
    'name' => 'Nome',
    'contact' => 'Contacto',
    'title' => 'Título',
    'description' => 'Descrição',
    'risk_origin' => 'Origem do risco',
    'affected_subjects' => 'Titulares afetados',
    'management_approval' => 'Aprovação da gestão',
    'approved_by' => 'Aprovado por',
    'approval_date' => 'Data de aprovação',
    'consultation_conducted' => 'Consulta realizada',
    'consultation_details' => 'Detalhes da consulta',
    'recommendations' => 'Recomendações',
    'notes' => 'Notas',
    'necessity_test' => 'Teste de necessidade',
    'proportionality_test' => 'Teste de proporcionalidade',
    'mitigation_measures' => 'Medidas de mitigação',
    'residual_risk' => 'Risco residual',
    'breach_date' => 'Data da violação',
    'discovery_date' => 'Data da descoberta',
    'breach_type' => 'Tipo de violação',
    'causes' => 'Causas',
    'measures_taken' => 'Medidas tomadas',
    'notified_authority' => 'Autoridade notificada',
    'notification_date' => 'Data de notificação',
    'notified_affected' => 'Titulares notificados',
    'company_name' => 'Nome da empresa',
    'contact_person' => 'Pessoa de contacto',
    'email' => 'E-mail',
    'phone' => 'Telefone',
    'address' => 'Morada',
    'service_provided' => 'Serviço prestado',
    'agreement_signed' => 'Acordo assinado',
    'agreement_date' => 'Data do acordo',
    'expiry_date' => 'Data de expiração',
    'compliance_status' => 'Estado de conformidade',
    'save' => 'Guardar',
    'cancel' => 'Cancelar',
    'add' => 'Adicionar',
    'close' => 'Fechar',
    'language' => 'Idioma',
    'full_report' => 'Relatório completo',
    'backup' => 'Cópia de segurança',
    'zip_backup' => 'Cópia de segurança ZIP',
    'statistics' => 'Estatísticas',
    'no_records' => 'Nenhum registo encontrado',
    'showing' => 'A mostrar',
    'of' => 'de',
    'yes' => 'Sim',
    'no' => 'Não',
    'unknown' => 'Desconhecido',
    'not_required' => 'Não necessário',
    'in_progress' => 'Em curso',
    'completed' => 'Concluído',
    'approved' => 'Aprovado',
    'draft' => 'Rascunho',
    'open' => 'Aberto',
    'investigating' => 'Em investigação',
    'contained' => 'Contido',
    'resolved' => 'Resolvido',
    'closed' => 'Fechado',
    'compliant' => 'Conforme',
    'non_compliant' => 'Não conforme',
    'review_needed' => 'Revisão necessária',
    'low' => 'Baixo',
    'medium' => 'Médio',
    'high' => 'Alto',
    'confidentiality' => 'Confidencialidade',
    'integrity' => 'Integridade',
    'availability' => 'Disponibilidade',
    'mixed' => 'Misto',
    'contract' => 'Contrato',
    'consent' => 'Consentimento',
    'legal_obligation' => 'Obrigação legal',
    'legitimate_interests' => 'Interesses legítimos',
    'vital_interests' => 'Interesses vitais',
    'public_task' => 'Tarefa pública',
    'technical' => 'Técnico',
    'organizational' => 'Organizacional',
    'human_error' => 'Erro humano',
    'external' => 'Externo',
    'systematic_monitoring' => 'Monitorização sistemática',
    'sensitive_data' => 'Dados sensíveis',
    'other' => 'Outro',
    'administration' => 'Administração',
    'hr' => 'RH',
    'finance' => 'Finanças',
    'marketing' => 'Marketing',
    'it' => 'TI',
    'operations' => 'Operações',
    'pending' => 'Pendente',
    'rejected' => 'Rejeitado',
    'planned' => 'Planeado',
    'donations' => 'Doações',
    'create_dpia' => 'Criar AIPD',
    'create_dpia_from_gdpr' => 'Criar AIPD a partir do RGPD',
    'click_create_dpia_for_gdpr' => 'Clique em "Criar AIPD" para um registo RGPD que necessita de uma AIPD:',
    'new_gdpr_record' => 'Novo registo RGPD',
    'edit_gdpr_record' => 'Editar registo RGPD',
    'new_dpia' => 'Nova AIPD',
    'edit_dpia' => 'Editar AIPD',
    'new_breach' => 'Nova violação de dados',
    'edit_breach' => 'Editar violação de dados',
    'new_third_party' => 'Novo terceiro',
    'edit_third_party' => 'Editar terceiro',
    'record' => 'Registo',
    'page' => 'Página',
    'generated' => 'Gerado',
    'successfully_added' => 'adicionado com sucesso',
    'successfully_updated' => 'atualizado com sucesso',
    'unsaved_changes_confirm' => 'Existem alterações não guardadas. Tem certeza de que deseja cancelar?',
    'select_or_type_below' => 'Selecione ou digite abaixo',
    'or_type_custom_retention_period' => 'Ou digite um período de retenção personalizado',
    'or_type_custom_safeguards' => 'Ou digite garantias personalizadas (separadas por vírgulas)',
    'or_type_custom_measures' => 'Ou digite medidas personalizadas (separadas por vírgulas)',
    'hold_ctrl_to_select_multiple' => 'Mantenha Ctrl (Windows) ou Cmd (Mac) para selecionar vários',
    'custom_mitigation_measures' => 'Medidas de mitigação personalizadas (separadas por vírgulas)',
    'custom_measures_taken' => 'Medidas tomadas personalizadas (separadas por vírgulas)',
    'custom_measures_placeholder' => 'Ex. Medida personalizada 1, Medida personalizada 2',
    'gdpr_record_id' => 'ID do registo RGPD',
    'gdpr_record' => 'Registo RGPD',
    'dpia_for_gdpr' => 'AIPD para RGPD',
    'dpia_exists_for_gdpr' => 'Já existe uma AIPD para RGPD',
    'for_gdpr_record' => 'para registo RGPD',
    'only_one_dpia_allowed' => 'Apenas uma AIPD é permitida por registo RGPD.',
    'risk_distribution' => 'Distribuição de risco',
    'gdpr_compliance_overview' => 'Visão geral da conformidade RGPD',
    'inactive_draft' => 'Inativo / Rascunho',
    'collected_from_records' => 'Recolhido de registos',
    'measure' => 'Medida',
    'source' => 'Fonte',
    'configuration' => 'Configuração',
    'no_technical_measures' => 'Nenhuma medida técnica encontrada',
    'no_organizational_measures' => 'Nenhuma medida organizacional encontrada',
    'total_gdpr_records' => 'Total de registos RGPD',
    'dpia_in_progress' => 'AIPD em curso',
    'total_breaches' => 'Total de violações',
    'open_breaches' => 'Violações abertas',
    'total_third_parties' => 'Total de terceiros',
    'compliant_third_parties' => 'Terceiros conformes',
    'dpia_coverage' => 'Cobertura AIPD',
    'gdpr_with_dpia_required' => 'RGPD com AIPD necessária',
    'dpia_completion_rate' => 'Taxa de conclusão AIPD',
    'category' => 'Categoria',
    'overview' => 'Visão geral',
    'per_category' => 'Por categoria',
    'total_risk' => 'Risco total',
    'completion_rate' => 'Taxa de conclusão',
    'record_type' => 'Tipo de registo',
    'print_report_title' => 'Relatório de conformidade',
    'generated_on' => 'Gerado em',
    'or_type_custom_department' => 'Ou digite um departamento personalizado',
    'or_type_custom_name' => 'Ou digite um nome',
    'or_type_custom_risk_origin' => 'Ou digite uma origem de risco personalizada',
    'or_type_custom_status' => 'Ou digite um estado personalizado',
    'or_type_custom_approval' => 'Ou digite um estado de aprovação personalizado',
    'or_type_custom_consultation' => 'Ou digite um valor personalizado',
    'or_type_custom_compliance_status' => 'Ou digite um estado de conformidade personalizado',
    'or_type_custom_breach_type' => 'Ou digite um tipo de violação personalizado',
    'logout' => 'Terminar sessão',
    'logout_confirm' => 'Terminar esta sessão?',
    'value' => 'Valor',
    'edit_measure' => 'Editar medida',
    'current_measure' => 'Medida atual',
    'new_measure_name' => 'Novo nome da medida',
    'measure_renamed_success' => 'Medida renomeada com sucesso em todos os locais onde é utilizada.',
    'measure_rename_warning' => 'Isto renomeia a medida em todos os registos de RGPD, AIPD e violações de dados onde é utilizada.',
    'measure_deleted_success' => 'Medida eliminada com sucesso em todos os locais onde era utilizada.',
    'confirm_delete_measure' => 'Tem certeza de que deseja eliminar esta medida? Será removida de todos os registos de RGPD, AIPD e violações de dados onde é utilizada. Esta ação não pode ser desfeita.',
    'responsible' => 'Responsável',
    'responsible_placeholder' => 'Quem é responsável por esta medida?',
    'unassigned' => 'Não atribuído',
    'value_renamed_success' => 'Valor renomeado com sucesso em todos os locais onde é utilizado.',
    'value_deleted_success' => 'Valor removido com sucesso em todos os locais onde era utilizado.',
    'edit_value' => 'Editar valor',
    'delete_value' => 'Eliminar valor',
    'current_value' => 'Valor atual',
    'new_value' => 'Novo valor',
    'value_rename_warning' => 'Ao renomear, este valor é atualizado em todos os locais onde é atualmente utilizado.',
    'value_delete_warning' => 'Ao eliminar, este valor é removido de todos os registos onde é atualmente utilizado. Esta ação não pode ser desfeita.',
    'confirm_delete_value' => 'Eliminar este valor em todos os locais onde é utilizado? Esta ação não pode ser desfeita.',
    'used_in' => 'Utilizado em',
    'not_currently_used' => 'Não utilizado atualmente',
    'no_values' => 'Nenhum valor encontrado',
    'not_started' => 'Não iniciado',
    'safeguard_scc' => 'Cláusulas contratuais-tipo (CCT)',
    'safeguard_bcr' => 'Normas vinculativas da empresa (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (já não é válido)',
    'safeguard_adequacy_decision' => 'Decisão de adequação da Comissão Europeia',
    'safeguard_consent' => 'Consentimento específico do titular dos dados',
    'safeguard_model_contracts' => 'Contratos-modelo',
    'safeguard_certification' => 'Mecanismos de certificação',
    'safeguard_codes_of_conduct' => 'Códigos de conduta',
    'safeguard_dpia' => 'Avaliação de impacto sobre a proteção de dados (AIPD)',
    'safeguard_tia' => 'Avaliação de impacto da transferência internacional de dados (TIA)',
    'inactive' => 'Inativo',
];

// ==================== RUSSIAN ====================
$translations['ru'] = [
    'app_title' => 'Реестр GDPR',
    'company_subtitle' => 'Конфиденциальность и соответствие',
    'dashboard' => 'Панель управления',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Утечки данных',
    'breach' => 'Утечка данных',
    'third_parties' => 'Третьи стороны',
    'third_party' => 'Третья сторона',
    'measures' => 'Меры',
    'reporting' => 'Отчетность',
    'total' => 'Всего',
    'active' => 'Активно',
    'high_risk' => 'Высокий риск',
    'dpia_required' => 'Требуется DPIA',
    'dpia_completed' => 'DPIA завершена',
    'new' => 'Новый',
    'export_json' => 'Экспорт JSON',
    'search' => 'Поиск...',
    'search_company' => 'Поиск компании...',
    'filter' => 'Фильтр',
    'clear' => 'Очистить',
    'risk' => 'Риск',
    'risk_level' => 'Уровень риска',
    'status' => 'Статус',
    'retention_period' => 'Срок хранения',
    'actions' => 'Действия',
    'view' => 'Просмотр',
    'edit' => 'Редактировать',
    'delete' => 'Удалить',
    'print' => 'Печать',
    'confirm_delete' => 'Вы уверены, что хотите удалить эту запись? Это действие нельзя отменить.',
    'processing_activity' => 'Операция обработки',
    'purpose' => 'Цель',
    'data_subjects' => 'Субъекты данных',
    'personal_data' => 'Персональные данные',
    'recipients' => 'Получатели',
    'legal_basis' => 'Правовое основание',
    'legitimate_interest' => 'Законный интерес',
    'department' => 'Отдел',
    'international_transfer' => 'Международная передача',
    'to_country' => 'В страну',
    'we_are_processor' => 'Мы являемся обработчиком',
    'processing_agreement_third_party' => 'Соглашение об обработке с третьей стороной',
    'technical_measures' => 'Технические меры',
    'organizational_measures' => 'Организационные меры',
    'safeguards' => 'Гарантии',
    'review_date' => 'Дата проверки',
    'controller' => 'Контролер',
    'joint_controller' => 'Совместный контролер',
    'dpo' => 'Защитник данных',
    'representative' => 'Представитель',
    'name' => 'Имя',
    'contact' => 'Контакт',
    'title' => 'Название',
    'description' => 'Описание',
    'risk_origin' => 'Источник риска',
    'affected_subjects' => 'Затронутые субъекты',
    'management_approval' => 'Утверждение руководством',
    'approved_by' => 'Утверждено',
    'approval_date' => 'Дата утверждения',
    'consultation_conducted' => 'Проведена консультация',
    'consultation_details' => 'Детали консультации',
    'recommendations' => 'Рекомендации',
    'notes' => 'Заметки',
    'necessity_test' => 'Тест необходимости',
    'proportionality_test' => 'Тест пропорциональности',
    'mitigation_measures' => 'Меры по снижению рисков',
    'residual_risk' => 'Остаточный риск',
    'breach_date' => 'Дата утечки',
    'discovery_date' => 'Дата обнаружения',
    'breach_type' => 'Тип утечки',
    'causes' => 'Причины',
    'measures_taken' => 'Принятые меры',
    'notified_authority' => 'Уведомлен орган',
    'notification_date' => 'Дата уведомления',
    'notified_affected' => 'Уведомлены затронутые лица',
    'company_name' => 'Название компании',
    'contact_person' => 'Контактное лицо',
    'email' => 'Эл. почта',
    'phone' => 'Телефон',
    'address' => 'Адрес',
    'service_provided' => 'Предоставляемая услуга',
    'agreement_signed' => 'Соглашение подписано',
    'agreement_date' => 'Дата соглашения',
    'expiry_date' => 'Дата истечения срока',
    'compliance_status' => 'Статус соответствия',
    'save' => 'Сохранить',
    'cancel' => 'Отмена',
    'add' => 'Добавить',
    'close' => 'Закрыть',
    'language' => 'Язык',
    'full_report' => 'Полный отчет',
    'backup' => 'Резервная копия',
    'zip_backup' => 'ZIP-резервная копия',
    'statistics' => 'Статистика',
    'no_records' => 'Записи не найдены',
    'showing' => 'Показано',
    'of' => 'из',
    'yes' => 'Да',
    'no' => 'Нет',
    'unknown' => 'Неизвестно',
    'not_required' => 'Не требуется',
    'in_progress' => 'В процессе',
    'completed' => 'Завершено',
    'approved' => 'Утверждено',
    'draft' => 'Черновик',
    'open' => 'Открыто',
    'investigating' => 'Расследование',
    'contained' => 'Сдерживается',
    'resolved' => 'Решено',
    'closed' => 'Закрыто',
    'compliant' => 'Соответствует',
    'non_compliant' => 'Не соответствует',
    'review_needed' => 'Требуется проверка',
    'low' => 'Низкий',
    'medium' => 'Средний',
    'high' => 'Высокий',
    'confidentiality' => 'Конфиденциальность',
    'integrity' => 'Целостность',
    'availability' => 'Доступность',
    'mixed' => 'Смешанный',
    'contract' => 'Контракт',
    'consent' => 'Согласие',
    'legal_obligation' => 'Законное обязательство',
    'legitimate_interests' => 'Законные интересы',
    'vital_interests' => 'Жизненно важные интересы',
    'public_task' => 'Публичная задача',
    'technical' => 'Технический',
    'organizational' => 'Организационный',
    'human_error' => 'Человеческая ошибка',
    'external' => 'Внешний',
    'systematic_monitoring' => 'Систематический мониторинг',
    'sensitive_data' => 'Конфиденциальные данные',
    'other' => 'Другое',
    'administration' => 'Администрация',
    'hr' => 'Отдел кадров',
    'finance' => 'Финансы',
    'marketing' => 'Маркетинг',
    'it' => 'ИТ',
    'operations' => 'Операции',
    'pending' => 'В ожидании',
    'rejected' => 'Отклонено',
    'planned' => 'Запланировано',
    'donations' => 'Пожертвования',
    'create_dpia' => 'Создать DPIA',
    'create_dpia_from_gdpr' => 'Создать DPIA из GDPR',
    'click_create_dpia_for_gdpr' => 'Нажмите "Создать DPIA" для записи GDPR, требующей DPIA:',
    'new_gdpr_record' => 'Новая запись GDPR',
    'edit_gdpr_record' => 'Редактировать запись GDPR',
    'new_dpia' => 'Новая DPIA',
    'edit_dpia' => 'Редактировать DPIA',
    'new_breach' => 'Новая утечка данных',
    'edit_breach' => 'Редактировать утечку данных',
    'new_third_party' => 'Новая третья сторона',
    'edit_third_party' => 'Редактировать третью сторону',
    'record' => 'Запись',
    'page' => 'Страница',
    'generated' => 'Создано',
    'successfully_added' => 'успешно добавлено',
    'successfully_updated' => 'успешно обновлено',
    'unsaved_changes_confirm' => 'Есть несохраненные изменения. Вы уверены, что хотите отменить?',
    'select_or_type_below' => 'Выберите или введите ниже',
    'or_type_custom_retention_period' => 'Или введите свой срок хранения',
    'or_type_custom_safeguards' => 'Или введите свои гарантии (через запятую)',
    'or_type_custom_measures' => 'Или введите свои меры (через запятую)',
    'hold_ctrl_to_select_multiple' => 'Удерживайте Ctrl (Windows) или Cmd (Mac) для выбора нескольких',
    'custom_mitigation_measures' => 'Собственные меры по снижению рисков (через запятую)',
    'custom_measures_taken' => 'Собственные принятые меры (через запятую)',
    'custom_measures_placeholder' => 'Напр. Собственная мера 1, Собственная мера 2',
    'gdpr_record_id' => 'ID записи GDPR',
    'gdpr_record' => 'Запись GDPR',
    'dpia_for_gdpr' => 'DPIA для GDPR',
    'dpia_exists_for_gdpr' => 'DPIA уже существует для GDPR',
    'for_gdpr_record' => 'для записи GDPR',
    'only_one_dpia_allowed' => 'Разрешена только одна DPIA на запись GDPR.',
    'risk_distribution' => 'Распределение рисков',
    'gdpr_compliance_overview' => 'Обзор соответствия GDPR',
    'inactive_draft' => 'Неактивно / Черновик',
    'collected_from_records' => 'Собрано из записей',
    'measure' => 'Мера',
    'source' => 'Источник',
    'configuration' => 'Конфигурация',
    'no_technical_measures' => 'Технические меры не найдены',
    'no_organizational_measures' => 'Организационные меры не найдены',
    'total_gdpr_records' => 'Всего записей GDPR',
    'dpia_in_progress' => 'DPIA в процессе',
    'total_breaches' => 'Всего утечек',
    'open_breaches' => 'Открытые утечки',
    'total_third_parties' => 'Всего третьих сторон',
    'compliant_third_parties' => 'Соответствующие третьи стороны',
    'dpia_coverage' => 'Покрытие DPIA',
    'gdpr_with_dpia_required' => 'GDPR с требуемой DPIA',
    'dpia_completion_rate' => 'Уровень завершения DPIA',
    'category' => 'Категория',
    'overview' => 'Обзор',
    'per_category' => 'По категориям',
    'total_risk' => 'Общий риск',
    'completion_rate' => 'Уровень завершения',
    'record_type' => 'Тип записи',
    'print_report_title' => 'Отчет о соответствии',
    'generated_on' => 'Создано',
    'or_type_custom_department' => 'Или введите свой отдел',
    'or_type_custom_name' => 'Или введите имя',
    'or_type_custom_risk_origin' => 'Или введите свой источник риска',
    'or_type_custom_status' => 'Или введите свой статус',
    'or_type_custom_approval' => 'Или введите свой статус утверждения',
    'or_type_custom_consultation' => 'Или введите свое значение',
    'or_type_custom_compliance_status' => 'Или введите свой статус соответствия',
    'or_type_custom_breach_type' => 'Или введите свой тип утечки',
    'logout' => 'Выйти',
    'logout_confirm' => 'Выйти из этого сеанса?',
    'value' => 'Значение',
    'edit_measure' => 'Редактировать меру',
    'current_measure' => 'Текущая мера',
    'new_measure_name' => 'Новое название меры',
    'measure_renamed_success' => 'Мера успешно переименована везде, где она используется.',
    'measure_rename_warning' => 'Это переименует меру во всех записях GDPR, DPIA и утечек данных, где она используется.',
    'measure_deleted_success' => 'Мера успешно удалена везде, где она использовалась.',
    'confirm_delete_measure' => 'Вы уверены, что хотите удалить эту меру? Она будет удалена из всех записей GDPR, DPIA и утечек данных, где она используется. Это действие нельзя отменить.',
    'responsible' => 'Ответственный',
    'responsible_placeholder' => 'Кто отвечает за эту меру?',
    'unassigned' => 'Не назначено',
    'value_renamed_success' => 'Значение успешно переименовано везде, где оно используется.',
    'value_deleted_success' => 'Значение успешно удалено везде, где оно использовалось.',
    'edit_value' => 'Редактировать значение',
    'delete_value' => 'Удалить значение',
    'current_value' => 'Текущее значение',
    'new_value' => 'Новое значение',
    'value_rename_warning' => 'Переименование обновит это значение везде, где оно используется в настоящее время.',
    'value_delete_warning' => 'Удаление очистит это значение во всех записях, где оно используется в настоящее время. Это действие нельзя отменить.',
    'confirm_delete_value' => 'Удалить это значение везде, где оно используется? Это действие нельзя отменить.',
    'used_in' => 'Используется в',
    'not_currently_used' => 'В настоящее время не используется',
    'no_values' => 'Значения не найдены',
    'not_started' => 'Не начато',
    'safeguard_scc' => 'Стандартные договорные положения (SCC)',
    'safeguard_bcr' => 'Обязательные корпоративные правила (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (больше не действует)',
    'safeguard_adequacy_decision' => 'Решение Европейской комиссии об адекватности',
    'safeguard_consent' => 'Особое согласие субъекта данных',
    'safeguard_model_contracts' => 'Типовые договоры',
    'safeguard_certification' => 'Механизмы сертификации',
    'safeguard_codes_of_conduct' => 'Кодексы поведения',
    'safeguard_dpia' => 'Оценка воздействия на защиту данных (DPIA)',
    'safeguard_tia' => 'Оценка воздействия международной передачи данных (TIA)',
    'inactive' => 'Неактивно',
];

// ==================== CHINESE ====================
$translations['zh'] = [
    'app_title' => 'GDPR登记册',
    'company_subtitle' => '隐私与合规',
    'dashboard' => '仪表板',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => '数据泄露',
    'breach' => '数据泄露',
    'third_parties' => '第三方',
    'third_party' => '第三方',
    'measures' => '措施',
    'reporting' => '报告',
    'total' => '总计',
    'active' => '活跃',
    'high_risk' => '高风险',
    'dpia_required' => '需要DPIA',
    'dpia_completed' => 'DPIA已完成',
    'new' => '新建',
    'export_json' => '导出JSON',
    'search' => '搜索...',
    'search_company' => '搜索公司...',
    'filter' => '筛选',
    'clear' => '清除',
    'risk' => '风险',
    'risk_level' => '风险级别',
    'status' => '状态',
    'retention_period' => '保留期限',
    'actions' => '操作',
    'view' => '查看',
    'edit' => '编辑',
    'delete' => '删除',
    'print' => '打印',
    'confirm_delete' => '您确定要删除此记录吗？此操作无法撤销。',
    'processing_activity' => '处理活动',
    'purpose' => '目的',
    'data_subjects' => '数据主体',
    'personal_data' => '个人数据',
    'recipients' => '接收者',
    'legal_basis' => '法律依据',
    'legitimate_interest' => '合法利益',
    'department' => '部门',
    'international_transfer' => '国际传输',
    'to_country' => '到国家',
    'we_are_processor' => '我们是处理者',
    'processing_agreement_third_party' => '与第三方的处理协议',
    'technical_measures' => '技术措施',
    'organizational_measures' => '组织措施',
    'safeguards' => '保障措施',
    'review_date' => '审查日期',
    'controller' => '控制者',
    'joint_controller' => '联合控制者',
    'dpo' => '数据保护官',
    'representative' => '代表',
    'name' => '姓名',
    'contact' => '联系方式',
    'title' => '标题',
    'description' => '描述',
    'risk_origin' => '风险来源',
    'affected_subjects' => '受影响的主体',
    'management_approval' => '管理层批准',
    'approved_by' => '批准人',
    'approval_date' => '批准日期',
    'consultation_conducted' => '已进行咨询',
    'consultation_details' => '咨询详情',
    'recommendations' => '建议',
    'notes' => '备注',
    'necessity_test' => '必要性测试',
    'proportionality_test' => '相称性测试',
    'mitigation_measures' => '缓解措施',
    'residual_risk' => '剩余风险',
    'breach_date' => '泄露日期',
    'discovery_date' => '发现日期',
    'breach_type' => '泄露类型',
    'causes' => '原因',
    'measures_taken' => '已采取措施',
    'notified_authority' => '已通知当局',
    'notification_date' => '通知日期',
    'notified_affected' => '已通知受影响人员',
    'company_name' => '公司名称',
    'contact_person' => '联系人',
    'email' => '电子邮件',
    'phone' => '电话',
    'address' => '地址',
    'service_provided' => '提供的服务',
    'agreement_signed' => '已签署协议',
    'agreement_date' => '协议日期',
    'expiry_date' => '到期日期',
    'compliance_status' => '合规状态',
    'save' => '保存',
    'cancel' => '取消',
    'add' => '添加',
    'close' => '关闭',
    'language' => '语言',
    'full_report' => '完整报告',
    'backup' => '备份',
    'zip_backup' => 'ZIP备份',
    'statistics' => '统计信息',
    'no_records' => '未找到记录',
    'showing' => '显示',
    'of' => '共',
    'yes' => '是',
    'no' => '否',
    'unknown' => '未知',
    'not_required' => '不需要',
    'in_progress' => '进行中',
    'completed' => '已完成',
    'approved' => '已批准',
    'draft' => '草稿',
    'open' => '开放',
    'investigating' => '调查中',
    'contained' => '已控制',
    'resolved' => '已解决',
    'closed' => '已关闭',
    'compliant' => '合规',
    'non_compliant' => '不合规',
    'review_needed' => '需要审查',
    'low' => '低',
    'medium' => '中',
    'high' => '高',
    'confidentiality' => '机密性',
    'integrity' => '完整性',
    'availability' => '可用性',
    'mixed' => '混合',
    'contract' => '合同',
    'consent' => '同意',
    'legal_obligation' => '法律义务',
    'legitimate_interests' => '合法利益',
    'vital_interests' => '重大利益',
    'public_task' => '公共任务',
    'technical' => '技术',
    'organizational' => '组织',
    'human_error' => '人为错误',
    'external' => '外部',
    'systematic_monitoring' => '系统监控',
    'sensitive_data' => '敏感数据',
    'other' => '其他',
    'administration' => '行政管理',
    'hr' => '人力资源',
    'finance' => '财务',
    'marketing' => '营销',
    'it' => '信息技术',
    'operations' => '运营',
    'pending' => '待处理',
    'rejected' => '已拒绝',
    'planned' => '已计划',
    'donations' => '捐赠',
    'create_dpia' => '创建DPIA',
    'create_dpia_from_gdpr' => '从GDPR创建DPIA',
    'click_create_dpia_for_gdpr' => '点击"创建DPIA"为需要DPIA的GDPR记录：',
    'new_gdpr_record' => '新GDPR记录',
    'edit_gdpr_record' => '编辑GDPR记录',
    'new_dpia' => '新DPIA',
    'edit_dpia' => '编辑DPIA',
    'new_breach' => '新数据泄露',
    'edit_breach' => '编辑数据泄露',
    'new_third_party' => '新第三方',
    'edit_third_party' => '编辑第三方',
    'record' => '记录',
    'page' => '页',
    'generated' => '生成于',
    'successfully_added' => '成功添加',
    'successfully_updated' => '成功更新',
    'unsaved_changes_confirm' => '有未保存的更改。您确定要取消吗？',
    'select_or_type_below' => '选择或在下方输入',
    'or_type_custom_retention_period' => '或输入自定义保留期限',
    'or_type_custom_safeguards' => '或输入自定义保障措施（逗号分隔）',
    'or_type_custom_measures' => '或输入自定义措施（逗号分隔）',
    'hold_ctrl_to_select_multiple' => '按住Ctrl（Windows）或Cmd（Mac）以选择多个',
    'custom_mitigation_measures' => '自定义缓解措施（逗号分隔）',
    'custom_measures_taken' => '自定义已采取措施（逗号分隔）',
    'custom_measures_placeholder' => '例如：自定义措施1，自定义措施2',
    'gdpr_record_id' => 'GDPR记录ID',
    'gdpr_record' => 'GDPR记录',
    'dpia_for_gdpr' => '为GDPR的DPIA',
    'dpia_exists_for_gdpr' => 'GDPR已存在DPIA',
    'for_gdpr_record' => '为GDPR记录',
    'only_one_dpia_allowed' => '每个GDPR记录只允许一个DPIA。',
    'risk_distribution' => '风险分布',
    'gdpr_compliance_overview' => 'GDPR合规概览',
    'inactive_draft' => '非活跃/草稿',
    'collected_from_records' => '从记录中收集',
    'measure' => '措施',
    'source' => '来源',
    'configuration' => '配置',
    'no_technical_measures' => '未找到技术措施',
    'no_organizational_measures' => '未找到组织措施',
    'total_gdpr_records' => 'GDPR记录总数',
    'dpia_in_progress' => '进行中的DPIA',
    'total_breaches' => '数据泄露总数',
    'open_breaches' => '未解决的数据泄露',
    'total_third_parties' => '第三方总数',
    'compliant_third_parties' => '合规的第三方',
    'dpia_coverage' => 'DPIA覆盖率',
    'gdpr_with_dpia_required' => '需要DPIA的GDPR',
    'dpia_completion_rate' => 'DPIA完成率',
    'category' => '类别',
    'overview' => '概览',
    'per_category' => '按类别',
    'total_risk' => '总风险',
    'completion_rate' => '完成率',
    'record_type' => '记录类型',
    'print_report_title' => '合规报告',
    'generated_on' => '生成于',
    'or_type_custom_department' => '或输入自定义部门',
    'or_type_custom_name' => '或输入姓名',
    'or_type_custom_risk_origin' => '或输入自定义风险来源',
    'or_type_custom_status' => '或输入自定义状态',
    'or_type_custom_approval' => '或输入自定义审批状态',
    'or_type_custom_consultation' => '或输入自定义值',
    'or_type_custom_compliance_status' => '或输入自定义合规状态',
    'or_type_custom_breach_type' => '或输入自定义泄露类型',
    'logout' => '退出登录',
    'logout_confirm' => '要退出此会话吗？',
    'value' => '值',
    'edit_measure' => '编辑措施',
    'current_measure' => '当前措施',
    'new_measure_name' => '新措施名称',
    'measure_renamed_success' => '措施已在所有使用位置成功重命名。',
    'measure_rename_warning' => '此操作将在使用该措施的所有 GDPR、DPIA 和数据泄露记录中重命名该措施。',
    'measure_deleted_success' => '措施已在所有使用位置成功删除。',
    'confirm_delete_measure' => '确定要删除此措施吗？它将从使用它的所有 GDPR、DPIA 和数据泄露记录中删除。此操作无法撤销。',
    'responsible' => '负责人',
    'responsible_placeholder' => '谁负责此措施？',
    'unassigned' => '未分配',
    'value_renamed_success' => '值已在所有使用位置成功重命名。',
    'value_deleted_success' => '值已在所有使用位置成功删除。',
    'edit_value' => '编辑值',
    'delete_value' => '删除值',
    'current_value' => '当前值',
    'new_value' => '新值',
    'value_rename_warning' => '重命名将更新当前使用该值的所有位置。',
    'value_delete_warning' => '删除将清除当前使用该值的所有记录中的此值。此操作无法撤销。',
    'confirm_delete_value' => '要在所有使用位置删除此值吗？此操作无法撤销。',
    'used_in' => '使用于',
    'not_currently_used' => '当前未使用',
    'no_values' => '未找到任何值',
    'not_started' => '未开始',
    'safeguard_scc' => '标准合同条款（SCC）',
    'safeguard_bcr' => '有约束力的公司规则（BCR）',
    'safeguard_privacy_shield' => '隐私盾（已失效）',
    'safeguard_adequacy_decision' => '欧盟委员会充分性决定',
    'safeguard_consent' => '数据主体的特别同意',
    'safeguard_model_contracts' => '示范合同',
    'safeguard_certification' => '认证机制',
    'safeguard_codes_of_conduct' => '行为准则',
    'safeguard_dpia' => '数据保护影响评估（DPIA）',
    'safeguard_tia' => '国际数据传输影响评估（TIA）',
    'inactive' => '未激活',
];

// ==================== JAPANESE ====================
$translations['ja'] = [
    'app_title' => 'GDPRレジスター',
    'company_subtitle' => 'プライバシーとコンプライアンス',
    'dashboard' => 'ダッシュボード',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'データ漏洩',
    'breach' => 'データ漏洩',
    'third_parties' => '第三者',
    'third_party' => '第三者',
    'measures' => '対策',
    'reporting' => 'レポート',
    'total' => '合計',
    'active' => 'アクティブ',
    'high_risk' => '高リスク',
    'dpia_required' => 'DPIAが必要',
    'dpia_completed' => 'DPIA完了',
    'new' => '新規',
    'export_json' => 'JSONをエクスポート',
    'search' => '検索...',
    'search_company' => '会社を検索...',
    'filter' => 'フィルター',
    'clear' => 'クリア',
    'risk' => 'リスク',
    'risk_level' => 'リスクレベル',
    'status' => 'ステータス',
    'retention_period' => '保持期間',
    'actions' => 'アクション',
    'view' => '表示',
    'edit' => '編集',
    'delete' => '削除',
    'print' => '印刷',
    'confirm_delete' => 'このレコードを削除してもよろしいですか？この操作は元に戻せません。',
    'processing_activity' => '処理活動',
    'purpose' => '目的',
    'data_subjects' => 'データ主体',
    'personal_data' => '個人データ',
    'recipients' => '受取人',
    'legal_basis' => '法的根拠',
    'legitimate_interest' => '正当な利益',
    'department' => '部門',
    'international_transfer' => '国際移転',
    'to_country' => '国へ',
    'we_are_processor' => '処理者です',
    'processing_agreement_third_party' => '第三者との処理契約',
    'technical_measures' => '技術的対策',
    'organizational_measures' => '組織的対策',
    'safeguards' => '保護措置',
    'review_date' => 'レビュー日',
    'controller' => '管理者',
    'joint_controller' => '共同管理者',
    'dpo' => 'データ保護責任者',
    'representative' => '代表者',
    'name' => '名前',
    'contact' => '連絡先',
    'title' => 'タイトル',
    'description' => '説明',
    'risk_origin' => 'リスクの原因',
    'affected_subjects' => '影響を受ける主体',
    'management_approval' => '経営陣の承認',
    'approved_by' => '承認者',
    'approval_date' => '承認日',
    'consultation_conducted' => '協議実施済み',
    'consultation_details' => '協議の詳細',
    'recommendations' => '推奨事項',
    'notes' => 'メモ',
    'necessity_test' => '必要性テスト',
    'proportionality_test' => '比例性テスト',
    'mitigation_measures' => '緩和策',
    'residual_risk' => '残留リスク',
    'breach_date' => '漏洩日',
    'discovery_date' => '発見日',
    'breach_type' => '漏洩タイプ',
    'causes' => '原因',
    'measures_taken' => '講じた対策',
    'notified_authority' => '当局に通知済み',
    'notification_date' => '通知日',
    'notified_affected' => '影響を受ける者に通知済み',
    'company_name' => '会社名',
    'contact_person' => '担当者',
    'email' => 'メール',
    'phone' => '電話',
    'address' => '住所',
    'service_provided' => '提供サービス',
    'agreement_signed' => '契約締結済み',
    'agreement_date' => '契約日',
    'expiry_date' => '有効期限',
    'compliance_status' => 'コンプライアンスステータス',
    'save' => '保存',
    'cancel' => 'キャンセル',
    'add' => '追加',
    'close' => '閉じる',
    'language' => '言語',
    'full_report' => '完全レポート',
    'backup' => 'バックアップ',
    'zip_backup' => 'ZIPバックアップ',
    'statistics' => '統計',
    'no_records' => 'レコードが見つかりません',
    'showing' => '表示中',
    'of' => 'の',
    'yes' => 'はい',
    'no' => 'いいえ',
    'unknown' => '不明',
    'not_required' => '不要',
    'in_progress' => '進行中',
    'completed' => '完了',
    'approved' => '承認済み',
    'draft' => '下書き',
    'open' => 'オープン',
    'investigating' => '調査中',
    'contained' => '封じ込め済み',
    'resolved' => '解決済み',
    'closed' => 'クローズ',
    'compliant' => '準拠',
    'non_compliant' => '非準拠',
    'review_needed' => 'レビューが必要',
    'low' => '低',
    'medium' => '中',
    'high' => '高',
    'confidentiality' => '機密性',
    'integrity' => '完全性',
    'availability' => '可用性',
    'mixed' => '混合',
    'contract' => '契約',
    'consent' => '同意',
    'legal_obligation' => '法的義務',
    'legitimate_interests' => '正当な利益',
    'vital_interests' => '生命に関わる利益',
    'public_task' => '公的任務',
    'technical' => '技術的',
    'organizational' => '組織的',
    'human_error' => '人為的ミス',
    'external' => '外部',
    'systematic_monitoring' => '体系的監視',
    'sensitive_data' => '機微データ',
    'other' => 'その他',
    'administration' => '管理',
    'hr' => '人事',
    'finance' => '財務',
    'marketing' => 'マーケティング',
    'it' => 'IT',
    'operations' => '運用',
    'pending' => '保留中',
    'rejected' => '却下',
    'planned' => '計画済み',
    'donations' => '寄付',
    'create_dpia' => 'DPIAを作成',
    'create_dpia_from_gdpr' => 'GDPRからDPIAを作成',
    'click_create_dpia_for_gdpr' => 'DPIAが必要なGDPRレコードの「DPIAを作成」をクリックしてください：',
    'new_gdpr_record' => '新規GDPRレコード',
    'edit_gdpr_record' => 'GDPRレコードを編集',
    'new_dpia' => '新規DPIA',
    'edit_dpia' => 'DPIAを編集',
    'new_breach' => '新規データ漏洩',
    'edit_breach' => 'データ漏洩を編集',
    'new_third_party' => '新規第三者',
    'edit_third_party' => '第三者を編集',
    'record' => 'レコード',
    'page' => 'ページ',
    'generated' => '生成日時',
    'successfully_added' => '正常に追加されました',
    'successfully_updated' => '正常に更新されました',
    'unsaved_changes_confirm' => '保存されていない変更があります。キャンセルしてもよろしいですか？',
    'select_or_type_below' => '以下から選択または入力',
    'or_type_custom_retention_period' => 'またはカスタム保持期間を入力',
    'or_type_custom_safeguards' => 'またはカスタム保護措置を入力（カンマ区切り）',
    'or_type_custom_measures' => 'またはカスタム対策を入力（カンマ区切り）',
    'hold_ctrl_to_select_multiple' => 'Ctrl（Windows）またはCmd（Mac）を押しながら複数選択',
    'custom_mitigation_measures' => 'カスタム緩和策（カンマ区切り）',
    'custom_measures_taken' => 'カスタム講じた対策（カンマ区切り）',
    'custom_measures_placeholder' => '例：カスタム対策1、カスタム対策2',
    'gdpr_record_id' => 'GDPRレコードID',
    'gdpr_record' => 'GDPRレコード',
    'dpia_for_gdpr' => 'GDPRのDPIA',
    'dpia_exists_for_gdpr' => 'GDPRのDPIAは既に存在します',
    'for_gdpr_record' => 'GDPRレコード用',
    'only_one_dpia_allowed' => 'GDPRレコードごとに1つのDPIAのみ許可されます。',
    'risk_distribution' => 'リスク分布',
    'gdpr_compliance_overview' => 'GDPRコンプライアンス概要',
    'inactive_draft' => '非アクティブ/下書き',
    'collected_from_records' => 'レコードから収集',
    'measure' => '対策',
    'source' => 'ソース',
    'configuration' => '設定',
    'no_technical_measures' => '技術的対策が見つかりません',
    'no_organizational_measures' => '組織的対策が見つかりません',
    'total_gdpr_records' => 'GDPRレコード合計',
    'dpia_in_progress' => '進行中のDPIA',
    'total_breaches' => 'データ漏洩合計',
    'open_breaches' => '未解決のデータ漏洩',
    'total_third_parties' => '第三者の合計',
    'compliant_third_parties' => '準拠している第三者',
    'dpia_coverage' => 'DPIAカバレッジ',
    'gdpr_with_dpia_required' => 'DPIAが必要なGDPR',
    'dpia_completion_rate' => 'DPIA完了率',
    'category' => 'カテゴリ',
    'overview' => '概要',
    'per_category' => 'カテゴリ別',
    'total_risk' => '総合リスク',
    'completion_rate' => '完了率',
    'record_type' => 'レコードタイプ',
    'print_report_title' => 'コンプライアンスレポート',
    'generated_on' => '生成日時',
    'or_type_custom_department' => 'またはカスタム部署を入力',
    'or_type_custom_name' => 'または名前を入力',
    'or_type_custom_risk_origin' => 'またはカスタムのリスク原因を入力',
    'or_type_custom_status' => 'またはカスタムステータスを入力',
    'or_type_custom_approval' => 'またはカスタムの承認ステータスを入力',
    'or_type_custom_consultation' => 'またはカスタム値を入力',
    'or_type_custom_compliance_status' => 'またはカスタムのコンプライアンスステータスを入力',
    'or_type_custom_breach_type' => 'またはカスタムの漏洩タイプを入力',
    'logout' => 'ログアウト',
    'logout_confirm' => 'このセッションからログアウトしますか？',
    'value' => '値',
    'edit_measure' => '対策を編集',
    'current_measure' => '現在の対策',
    'new_measure_name' => '新しい対策名',
    'measure_renamed_success' => '対策が使用されているすべての箇所で名前が変更されました。',
    'measure_rename_warning' => 'この操作により、この対策が使用されているすべてのGDPR、DPIA、データ漏洩の記録で名前が変更されます。',
    'measure_deleted_success' => '対策が使用されていたすべての箇所から削除されました。',
    'confirm_delete_measure' => 'この対策を削除してもよろしいですか？この対策が使用されているすべてのGDPR、DPIA、データ漏洩の記録から削除されます。この操作は元に戻せません。',
    'responsible' => '担当者',
    'responsible_placeholder' => 'この対策の担当者は誰ですか？',
    'unassigned' => '未割り当て',
    'value_renamed_success' => '値が使用されているすべての箇所で名前が変更されました。',
    'value_deleted_success' => '値が使用されていたすべての箇所から削除されました。',
    'edit_value' => '値を編集',
    'delete_value' => '値を削除',
    'current_value' => '現在の値',
    'new_value' => '新しい値',
    'value_rename_warning' => '名前を変更すると、現在この値が使用されているすべての箇所が更新されます。',
    'value_delete_warning' => '削除すると、現在この値が使用されているすべての記録からこの値が消去されます。この操作は元に戻せません。',
    'confirm_delete_value' => 'この値が使用されているすべての箇所で削除しますか？この操作は元に戻せません。',
    'used_in' => '使用箇所',
    'not_currently_used' => '現在使用されていません',
    'no_values' => '値が見つかりません',
    'not_started' => '未着手',
    'safeguard_scc' => '標準契約条項（SCC）',
    'safeguard_bcr' => '拘束的企業準則（BCR）',
    'safeguard_privacy_shield' => 'プライバシーシールド（現在は無効）',
    'safeguard_adequacy_decision' => '欧州委員会の十分性認定',
    'safeguard_consent' => 'データ主体の個別の同意',
    'safeguard_model_contracts' => 'モデル契約',
    'safeguard_certification' => '認証制度',
    'safeguard_codes_of_conduct' => '行動規範',
    'safeguard_dpia' => 'データ保護影響評価（DPIA）',
    'safeguard_tia' => '国際データ移転影響評価（TIA）',
    'inactive' => '非アクティブ',
];

// ==================== KOREAN ====================
$translations['ko'] = [
    'app_title' => 'GDPR 등록부',
    'company_subtitle' => '개인정보 보호 및 규정 준수',
    'dashboard' => '대시보드',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => '데이터 유출',
    'breach' => '데이터 유출',
    'third_parties' => '제3자',
    'third_party' => '제3자',
    'measures' => '조치',
    'reporting' => '보고',
    'total' => '전체',
    'active' => '활성',
    'high_risk' => '고위험',
    'dpia_required' => 'DPIA 필요',
    'dpia_completed' => 'DPIA 완료',
    'new' => '새로 만들기',
    'export_json' => 'JSON 내보내기',
    'search' => '검색...',
    'search_company' => '회사 검색...',
    'filter' => '필터',
    'clear' => '지우기',
    'risk' => '위험',
    'risk_level' => '위험 수준',
    'status' => '상태',
    'retention_period' => '보존 기간',
    'actions' => '작업',
    'view' => '보기',
    'edit' => '편집',
    'delete' => '삭제',
    'print' => '인쇄',
    'confirm_delete' => '이 레코드를 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.',
    'processing_activity' => '처리 활동',
    'purpose' => '목적',
    'data_subjects' => '데이터 주체',
    'personal_data' => '개인 데이터',
    'recipients' => '수신자',
    'legal_basis' => '법적 근거',
    'legitimate_interest' => '정당한 이익',
    'department' => '부서',
    'international_transfer' => '국제 이전',
    'to_country' => '국가로',
    'we_are_processor' => '처리자입니다',
    'processing_agreement_third_party' => '제3자와의 처리 계약',
    'technical_measures' => '기술적 조치',
    'organizational_measures' => '조직적 조치',
    'safeguards' => '보호 조치',
    'review_date' => '검토 날짜',
    'controller' => '관리자',
    'joint_controller' => '공동 관리자',
    'dpo' => '데이터 보호 책임자',
    'representative' => '대표자',
    'name' => '이름',
    'contact' => '연락처',
    'title' => '제목',
    'description' => '설명',
    'risk_origin' => '위험 원인',
    'affected_subjects' => '영향을 받는 주체',
    'management_approval' => '경영진 승인',
    'approved_by' => '승인자',
    'approval_date' => '승인 날짜',
    'consultation_conducted' => '협의 수행됨',
    'consultation_details' => '협의 세부사항',
    'recommendations' => '권장사항',
    'notes' => '메모',
    'necessity_test' => '필요성 테스트',
    'proportionality_test' => '비례성 테스트',
    'mitigation_measures' => '완화 조치',
    'residual_risk' => '잔여 위험',
    'breach_date' => '유출 날짜',
    'discovery_date' => '발견 날짜',
    'breach_type' => '유출 유형',
    'causes' => '원인',
    'measures_taken' => '취한 조치',
    'notified_authority' => '당국에 통보됨',
    'notification_date' => '통보 날짜',
    'notified_affected' => '영향받은 자에게 통보됨',
    'company_name' => '회사명',
    'contact_person' => '담당자',
    'email' => '이메일',
    'phone' => '전화',
    'address' => '주소',
    'service_provided' => '제공 서비스',
    'agreement_signed' => '계약 체결됨',
    'agreement_date' => '계약 날짜',
    'expiry_date' => '만료 날짜',
    'compliance_status' => '규정 준수 상태',
    'save' => '저장',
    'cancel' => '취소',
    'add' => '추가',
    'close' => '닫기',
    'language' => '언어',
    'full_report' => '전체 보고서',
    'backup' => '백업',
    'zip_backup' => 'ZIP 백업',
    'statistics' => '통계',
    'no_records' => '레코드를 찾을 수 없음',
    'showing' => '표시 중',
    'of' => '의',
    'yes' => '예',
    'no' => '아니오',
    'unknown' => '알 수 없음',
    'not_required' => '필요하지 않음',
    'in_progress' => '진행 중',
    'completed' => '완료됨',
    'approved' => '승인됨',
    'draft' => '초안',
    'open' => '열림',
    'investigating' => '조사 중',
    'contained' => '통제됨',
    'resolved' => '해결됨',
    'closed' => '종료됨',
    'compliant' => '준수',
    'non_compliant' => '비준수',
    'review_needed' => '검토 필요',
    'low' => '낮음',
    'medium' => '중간',
    'high' => '높음',
    'confidentiality' => '기밀성',
    'integrity' => '무결성',
    'availability' => '가용성',
    'mixed' => '혼합',
    'contract' => '계약',
    'consent' => '동의',
    'legal_obligation' => '법적 의무',
    'legitimate_interests' => '정당한 이익',
    'vital_interests' => '중요한 이익',
    'public_task' => '공공 업무',
    'technical' => '기술적',
    'organizational' => '조직적',
    'human_error' => '인적 오류',
    'external' => '외부',
    'systematic_monitoring' => '체계적 모니터링',
    'sensitive_data' => '민감 데이터',
    'other' => '기타',
    'administration' => '행정',
    'hr' => '인사',
    'finance' => '재무',
    'marketing' => '마케팅',
    'it' => 'IT',
    'operations' => '운영',
    'pending' => '보류 중',
    'rejected' => '거부됨',
    'planned' => '계획됨',
    'donations' => '기부',
    'create_dpia' => 'DPIA 생성',
    'create_dpia_from_gdpr' => 'GDPR에서 DPIA 생성',
    'click_create_dpia_for_gdpr' => 'DPIA가 필요한 GDPR 레코드에 대해 "DPIA 생성"을 클릭하세요:',
    'new_gdpr_record' => '새 GDPR 레코드',
    'edit_gdpr_record' => 'GDPR 레코드 편집',
    'new_dpia' => '새 DPIA',
    'edit_dpia' => 'DPIA 편집',
    'new_breach' => '새 데이터 유출',
    'edit_breach' => '데이터 유출 편집',
    'new_third_party' => '새 제3자',
    'edit_third_party' => '제3자 편집',
    'record' => '레코드',
    'page' => '페이지',
    'generated' => '생성됨',
    'successfully_added' => '성공적으로 추가됨',
    'successfully_updated' => '성공적으로 업데이트됨',
    'unsaved_changes_confirm' => '저장되지 않은 변경사항이 있습니다. 취소하시겠습니까?',
    'select_or_type_below' => '선택하거나 아래에 입력하세요',
    'or_type_custom_retention_period' => '또는 사용자 정의 보존 기간 입력',
    'or_type_custom_safeguards' => '또는 사용자 정의 보호 조치 입력 (쉼표로 구분)',
    'or_type_custom_measures' => '또는 사용자 정의 조치 입력 (쉼표로 구분)',
    'hold_ctrl_to_select_multiple' => 'Ctrl(Windows) 또는 Cmd(Mac)을 눌러 여러 항목 선택',
    'custom_mitigation_measures' => '사용자 정의 완화 조치 (쉼표로 구분)',
    'custom_measures_taken' => '사용자 정의 취한 조치 (쉼표로 구분)',
    'custom_measures_placeholder' => '예: 사용자 정의 조치 1, 사용자 정의 조치 2',
    'gdpr_record_id' => 'GDPR 레코드 ID',
    'gdpr_record' => 'GDPR 레코드',
    'dpia_for_gdpr' => 'GDPR용 DPIA',
    'dpia_exists_for_gdpr' => 'GDPR에 대한 DPIA가 이미 존재합니다',
    'for_gdpr_record' => 'GDPR 레코드용',
    'only_one_dpia_allowed' => 'GDPR 레코드당 하나의 DPIA만 허용됩니다.',
    'risk_distribution' => '위험 분포',
    'gdpr_compliance_overview' => 'GDPR 규정 준수 개요',
    'inactive_draft' => '비활성 / 초안',
    'collected_from_records' => '레코드에서 수집됨',
    'measure' => '조치',
    'source' => '출처',
    'configuration' => '구성',
    'no_technical_measures' => '기술적 조치를 찾을 수 없음',
    'no_organizational_measures' => '조직적 조치를 찾을 수 없음',
    'total_gdpr_records' => 'GDPR 레코드 총계',
    'dpia_in_progress' => '진행 중인 DPIA',
    'total_breaches' => '데이터 유출 총계',
    'open_breaches' => '미해결 데이터 유출',
    'total_third_parties' => '제3자 총계',
    'compliant_third_parties' => '준수하는 제3자',
    'dpia_coverage' => 'DPIA 적용 범위',
    'gdpr_with_dpia_required' => 'DPIA가 필요한 GDPR',
    'dpia_completion_rate' => 'DPIA 완료율',
    'category' => '카테고리',
    'overview' => '개요',
    'per_category' => '카테고리별',
    'total_risk' => '총 위험',
    'completion_rate' => '완료율',
    'record_type' => '레코드 유형',
    'print_report_title' => '규정 준수 보고서',
    'generated_on' => '생성됨',
    'or_type_custom_department' => '또는 사용자 지정 부서 입력',
    'or_type_custom_name' => '또는 이름 입력',
    'or_type_custom_risk_origin' => '또는 사용자 지정 위험 원인 입력',
    'or_type_custom_status' => '또는 사용자 지정 상태 입력',
    'or_type_custom_approval' => '또는 사용자 지정 승인 상태 입력',
    'or_type_custom_consultation' => '또는 사용자 지정 값 입력',
    'or_type_custom_compliance_status' => '또는 사용자 지정 준수 상태 입력',
    'or_type_custom_breach_type' => '또는 사용자 지정 유출 유형 입력',
    'logout' => '로그아웃',
    'logout_confirm' => '이 세션에서 로그아웃하시겠습니까?',
    'value' => '값',
    'edit_measure' => '조치 편집',
    'current_measure' => '현재 조치',
    'new_measure_name' => '새 조치 이름',
    'measure_renamed_success' => '조치가 사용되는 모든 위치에서 이름이 성공적으로 변경되었습니다.',
    'measure_rename_warning' => '이 작업은 해당 조치가 사용되는 모든 GDPR, DPIA 및 데이터 유출 기록에서 조치 이름을 변경합니다.',
    'measure_deleted_success' => '조치가 사용되었던 모든 위치에서 성공적으로 삭제되었습니다.',
    'confirm_delete_measure' => '이 조치를 삭제하시겠습니까? 이 조치가 사용되는 모든 GDPR, DPIA 및 데이터 유출 기록에서 제거됩니다. 이 작업은 되돌릴 수 없습니다.',
    'responsible' => '담당자',
    'responsible_placeholder' => '이 조치의 담당자는 누구입니까?',
    'unassigned' => '미지정',
    'value_renamed_success' => '값이 사용되는 모든 위치에서 이름이 성공적으로 변경되었습니다.',
    'value_deleted_success' => '값이 사용되었던 모든 위치에서 성공적으로 삭제되었습니다.',
    'edit_value' => '값 편집',
    'delete_value' => '값 삭제',
    'current_value' => '현재 값',
    'new_value' => '새 값',
    'value_rename_warning' => '이름을 변경하면 현재 이 값이 사용되는 모든 위치가 업데이트됩니다.',
    'value_delete_warning' => '삭제하면 현재 이 값이 사용되는 모든 기록에서 이 값이 지워집니다. 이 작업은 되돌릴 수 없습니다.',
    'confirm_delete_value' => '이 값이 사용되는 모든 위치에서 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.',
    'used_in' => '사용 위치',
    'not_currently_used' => '현재 사용되지 않음',
    'no_values' => '값을 찾을 수 없습니다',
    'not_started' => '시작 안 함',
    'safeguard_scc' => '표준계약조항(SCC)',
    'safeguard_bcr' => '구속력 있는 기업 규칙(BCR)',
    'safeguard_privacy_shield' => '프라이버시 실드(더 이상 유효하지 않음)',
    'safeguard_adequacy_decision' => '유럽위원회의 적정성 결정',
    'safeguard_consent' => '정보주체의 특별 동의',
    'safeguard_model_contracts' => '표준 계약서',
    'safeguard_certification' => '인증 메커니즘',
    'safeguard_codes_of_conduct' => '행동강령',
    'safeguard_dpia' => '개인정보 영향평가(DPIA)',
    'safeguard_tia' => '국제 데이터 이전 영향평가(TIA)',
    'inactive' => '비활성',
];

// ==================== ARABIC ====================
$translations['ar'] = [
    'app_title' => 'سجل اللائحة العامة',
    'company_subtitle' => 'الخصوصية والامتثال',
    'dashboard' => 'لوحة القيادة',
    'gdpr' => 'اللائحة العامة',
    'dpia' => 'تقييم تأثير حماية البيانات',
    'breaches' => 'انتهاكات البيانات',
    'breach' => 'انتهاك البيانات',
    'third_parties' => 'الأطراف الثالثة',
    'third_party' => 'طرف ثالث',
    'measures' => 'الإجراءات',
    'reporting' => 'التقارير',
    'total' => 'المجموع',
    'active' => 'نشط',
    'high_risk' => 'مخاطر عالية',
    'dpia_required' => 'تقييم تأثير حماية البيانات مطلوب',
    'dpia_completed' => 'تقييم تأثير حماية البيانات مكتمل',
    'new' => 'جديد',
    'export_json' => 'تصدير JSON',
    'search' => 'بحث...',
    'search_company' => 'بحث عن شركة...',
    'filter' => 'تصفية',
    'clear' => 'مسح',
    'risk' => 'مخاطر',
    'risk_level' => 'مستوى المخاطر',
    'status' => 'الحالة',
    'retention_period' => 'فترة الاحتفاظ',
    'actions' => 'إجراءات',
    'view' => 'عرض',
    'edit' => 'تعديل',
    'delete' => 'حذف',
    'print' => 'طباعة',
    'confirm_delete' => 'هل أنت متأكد من حذف هذا السجل؟ لا يمكن التراجع عن هذا الإجراء.',
    'processing_activity' => 'نشاط المعالجة',
    'purpose' => 'الغرض',
    'data_subjects' => 'أصحاب البيانات',
    'personal_data' => 'البيانات الشخصية',
    'recipients' => 'المستلمون',
    'legal_basis' => 'الأساس القانوني',
    'legitimate_interest' => 'المصلحة المشروعة',
    'department' => 'القسم',
    'international_transfer' => 'النقل الدولي',
    'to_country' => 'إلى الدولة',
    'we_are_processor' => 'نحن معالج',
    'processing_agreement_third_party' => 'اتفاقية المعالجة مع طرف ثالث',
    'technical_measures' => 'إجراءات تقنية',
    'organizational_measures' => 'إجراءات تنظيمية',
    'safeguards' => 'ضمانات',
    'review_date' => 'تاريخ المراجعة',
    'controller' => 'المراقب',
    'joint_controller' => 'المراقب المشترك',
    'dpo' => 'مسؤول حماية البيانات',
    'representative' => 'الممثل',
    'name' => 'الاسم',
    'contact' => 'جهة الاتصال',
    'title' => 'العنوان',
    'description' => 'الوصف',
    'risk_origin' => 'أصل المخاطر',
    'affected_subjects' => 'الأطراف المتأثرة',
    'management_approval' => 'موافقة الإدارة',
    'approved_by' => 'تمت الموافقة من قبل',
    'approval_date' => 'تاريخ الموافقة',
    'consultation_conducted' => 'تم إجراء التشاور',
    'consultation_details' => 'تفاصيل التشاور',
    'recommendations' => 'التوصيات',
    'notes' => 'ملاحظات',
    'necessity_test' => 'اختبار الضرورة',
    'proportionality_test' => 'اختبار التناسب',
    'mitigation_measures' => 'إجراءات التخفيف',
    'residual_risk' => 'المخاطر المتبقية',
    'breach_date' => 'تاريخ الانتهاك',
    'discovery_date' => 'تاريخ الاكتشاف',
    'breach_type' => 'نوع الانتهاك',
    'causes' => 'الأسباب',
    'measures_taken' => 'الإجراءات المتخذة',
    'notified_authority' => 'تم إخطار السلطة',
    'notification_date' => 'تاريخ الإخطار',
    'notified_affected' => 'تم إخطار المتأثرين',
    'company_name' => 'اسم الشركة',
    'contact_person' => 'شخص الاتصال',
    'email' => 'البريد الإلكتروني',
    'phone' => 'الهاتف',
    'address' => 'العنوان',
    'service_provided' => 'الخدمة المقدمة',
    'agreement_signed' => 'تم توقيع الاتفاقية',
    'agreement_date' => 'تاريخ الاتفاقية',
    'expiry_date' => 'تاريخ الانتهاء',
    'compliance_status' => 'حالة الامتثال',
    'save' => 'حفظ',
    'cancel' => 'إلغاء',
    'add' => 'إضافة',
    'close' => 'إغلاق',
    'language' => 'اللغة',
    'full_report' => 'تقرير كامل',
    'backup' => 'نسخ احتياطي',
    'zip_backup' => 'نسخ احتياطي مضغوط',
    'statistics' => 'إحصائيات',
    'no_records' => 'لم يتم العثور على سجلات',
    'showing' => 'عرض',
    'of' => 'من',
    'yes' => 'نعم',
    'no' => 'لا',
    'unknown' => 'غير معروف',
    'not_required' => 'غير مطلوب',
    'in_progress' => 'قيد التنفيذ',
    'completed' => 'مكتمل',
    'approved' => 'موافق عليه',
    'draft' => 'مسودة',
    'open' => 'مفتوح',
    'investigating' => 'قيد التحقيق',
    'contained' => 'محصور',
    'resolved' => 'تم الحل',
    'closed' => 'مغلق',
    'compliant' => 'متوافق',
    'non_compliant' => 'غير متوافق',
    'review_needed' => 'مراجعة مطلوبة',
    'low' => 'منخفض',
    'medium' => 'متوسط',
    'high' => 'مرتفع',
    'confidentiality' => 'السرية',
    'integrity' => 'النزاهة',
    'availability' => 'التوفر',
    'mixed' => 'مختلط',
    'contract' => 'عقد',
    'consent' => 'موافقة',
    'legal_obligation' => 'التزام قانوني',
    'legitimate_interests' => 'مصالح مشروعة',
    'vital_interests' => 'مصالح حيوية',
    'public_task' => 'مهمة عامة',
    'technical' => 'تقني',
    'organizational' => 'تنظيمي',
    'human_error' => 'خطأ بشري',
    'external' => 'خارجي',
    'systematic_monitoring' => 'مراقبة منهجية',
    'sensitive_data' => 'بيانات حساسة',
    'other' => 'أخرى',
    'administration' => 'الإدارة',
    'hr' => 'الموارد البشرية',
    'finance' => 'المالية',
    'marketing' => 'التسويق',
    'it' => 'تكنولوجيا المعلومات',
    'operations' => 'العمليات',
    'pending' => 'معلق',
    'rejected' => 'مرفوض',
    'planned' => 'مخطط',
    'donations' => 'التبرعات',
    'create_dpia' => 'إنشاء تقييم تأثير حماية البيانات',
    'create_dpia_from_gdpr' => 'إنشاء تقييم تأثير حماية البيانات من اللائحة العامة',
    'click_create_dpia_for_gdpr' => 'انقر على "إنشاء تقييم تأثير حماية البيانات" لسجل اللائحة العامة الذي يتطلب تقييم تأثير حماية البيانات:',
    'new_gdpr_record' => 'سجل لائحة عامة جديد',
    'edit_gdpr_record' => 'تعديل سجل اللائحة العامة',
    'new_dpia' => 'تقييم تأثير حماية بيانات جديد',
    'edit_dpia' => 'تعديل تقييم تأثير حماية البيانات',
    'new_breach' => 'انتهاك بيانات جديد',
    'edit_breach' => 'تعديل انتهاك البيانات',
    'new_third_party' => 'طرف ثالث جديد',
    'edit_third_party' => 'تعديل طرف ثالث',
    'record' => 'سجل',
    'page' => 'صفحة',
    'generated' => 'تم الإنشاء',
    'successfully_added' => 'تمت الإضافة بنجاح',
    'successfully_updated' => 'تم التحديث بنجاح',
    'unsaved_changes_confirm' => 'هناك تغييرات غير محفوظة. هل أنت متأكد من الإلغاء؟',
    'select_or_type_below' => 'اختر أو اكتب أدناه',
    'or_type_custom_retention_period' => 'أو اكتب فترة احتفاظ مخصصة',
    'or_type_custom_safeguards' => 'أو اكتب ضمانات مخصصة (مفصولة بفواصل)',
    'or_type_custom_measures' => 'أو اكتب إجراءات مخصصة (مفصولة بفواصل)',
    'hold_ctrl_to_select_multiple' => 'اضغط مع الاستمرار على Ctrl (ويندوز) أو Cmd (ماك) لتحديد متعدد',
    'custom_mitigation_measures' => 'إجراءات تخفيف مخصصة (مفصولة بفواصل)',
    'custom_measures_taken' => 'إجراءات متخذة مخصصة (مفصولة بفواصل)',
    'custom_measures_placeholder' => 'مثال: إجراء مخصص 1، إجراء مخصص 2',
    'gdpr_record_id' => 'معرف سجل اللائحة العامة',
    'gdpr_record' => 'سجل اللائحة العامة',
    'dpia_for_gdpr' => 'تقييم تأثير حماية البيانات للائحة العامة',
    'dpia_exists_for_gdpr' => 'يوجد بالفعل تقييم تأثير حماية البيانات للائحة العامة',
    'for_gdpr_record' => 'لسجل اللائحة العامة',
    'only_one_dpia_allowed' => 'يسمح بتقييم تأثير حماية بيانات واحد فقط لكل سجل لائحة عامة.',
    'risk_distribution' => 'توزيع المخاطر',
    'gdpr_compliance_overview' => 'نظرة عامة على الامتثال للائحة العامة',
    'inactive_draft' => 'غير نشط / مسودة',
    'collected_from_records' => 'تم جمعها من السجلات',
    'measure' => 'إجراء',
    'source' => 'المصدر',
    'configuration' => 'التكوين',
    'no_technical_measures' => 'لم يتم العثور على إجراءات تقنية',
    'no_organizational_measures' => 'لم يتم العثور على إجراءات تنظيمية',
    'total_gdpr_records' => 'إجمالي سجلات اللائحة العامة',
    'dpia_in_progress' => 'تقييم تأثير حماية البيانات قيد التنفيذ',
    'total_breaches' => 'إجمالي الانتهاكات',
    'open_breaches' => 'انتهاكات مفتوحة',
    'total_third_parties' => 'إجمالي الأطراف الثالثة',
    'compliant_third_parties' => 'أطراف ثالثة متوافقة',
    'dpia_coverage' => 'تغطية تقييم تأثير حماية البيانات',
    'gdpr_with_dpia_required' => 'اللائحة العامة مع تقييم تأثير حماية البيانات المطلوب',
    'dpia_completion_rate' => 'معدل إكمال تقييم تأثير حماية البيانات',
    'category' => 'الفئة',
    'overview' => 'نظرة عامة',
    'per_category' => 'حسب الفئة',
    'total_risk' => 'المخاطر الإجمالية',
    'completion_rate' => 'معدل الإكمال',
    'record_type' => 'نوع السجل',
    'print_report_title' => 'تقرير الامتثال',
    'generated_on' => 'تم الإنشاء في',
    'or_type_custom_department' => 'أو اكتب قسمًا مخصصًا',
    'or_type_custom_name' => 'أو اكتب اسمًا',
    'or_type_custom_risk_origin' => 'أو اكتب مصدر خطر مخصص',
    'or_type_custom_status' => 'أو اكتب حالة مخصصة',
    'or_type_custom_approval' => 'أو اكتب حالة موافقة مخصصة',
    'or_type_custom_consultation' => 'أو اكتب قيمة مخصصة',
    'or_type_custom_compliance_status' => 'أو اكتب حالة امتثال مخصصة',
    'or_type_custom_breach_type' => 'أو اكتب نوع انتهاك مخصص',
    'logout' => 'تسجيل الخروج',
    'logout_confirm' => 'هل تريد تسجيل الخروج من هذه الجلسة؟',
    'value' => 'القيمة',
    'edit_measure' => 'تعديل الإجراء',
    'current_measure' => 'الإجراء الحالي',
    'new_measure_name' => 'اسم الإجراء الجديد',
    'measure_renamed_success' => 'تمت إعادة تسمية الإجراء بنجاح في كل مكان يُستخدم فيه.',
    'measure_rename_warning' => 'سيؤدي هذا إلى إعادة تسمية الإجراء في كل سجل من سجلات اللائحة العامة وتقييم تأثير حماية البيانات وانتهاكات البيانات التي يُستخدم فيها.',
    'measure_deleted_success' => 'تم حذف الإجراء بنجاح من كل مكان كان يُستخدم فيه.',
    'confirm_delete_measure' => 'هل أنت متأكد من حذف هذا الإجراء؟ سيتم إزالته من كل سجل من سجلات اللائحة العامة وتقييم تأثير حماية البيانات وانتهاكات البيانات التي يُستخدم فيها. لا يمكن التراجع عن هذا الإجراء.',
    'responsible' => 'المسؤول',
    'responsible_placeholder' => 'من المسؤول عن هذا الإجراء؟',
    'unassigned' => 'غير معيّن',
    'value_renamed_success' => 'تمت إعادة تسمية القيمة بنجاح في كل مكان تُستخدم فيه.',
    'value_deleted_success' => 'تمت إزالة القيمة بنجاح من كل مكان كانت تُستخدم فيه.',
    'edit_value' => 'تعديل القيمة',
    'delete_value' => 'حذف القيمة',
    'current_value' => 'القيمة الحالية',
    'new_value' => 'القيمة الجديدة',
    'value_rename_warning' => 'ستؤدي إعادة التسمية إلى تحديث هذه القيمة في كل مكان تُستخدم فيه حاليًا.',
    'value_delete_warning' => 'سيؤدي الحذف إلى مسح هذه القيمة من كل سجل تُستخدم فيه حاليًا. لا يمكن التراجع عن هذا الإجراء.',
    'confirm_delete_value' => 'هل تريد حذف هذه القيمة من كل مكان تُستخدم فيه؟ لا يمكن التراجع عن هذا الإجراء.',
    'used_in' => 'مستخدمة في',
    'not_currently_used' => 'غير مستخدمة حاليًا',
    'no_values' => 'لم يتم العثور على قيم',
    'not_started' => 'لم يبدأ',
    'safeguard_scc' => 'البنود التعاقدية القياسية (SCC)',
    'safeguard_bcr' => 'القواعد المؤسسية الملزمة (BCR)',
    'safeguard_privacy_shield' => 'درع الخصوصية (لم يعد ساريًا)',
    'safeguard_adequacy_decision' => 'قرار كفاية الحماية الصادر عن المفوضية الأوروبية',
    'safeguard_consent' => 'موافقة محددة من صاحب البيانات',
    'safeguard_model_contracts' => 'العقود النموذجية',
    'safeguard_certification' => 'آليات إصدار الشهادات',
    'safeguard_codes_of_conduct' => 'مدونات السلوك',
    'safeguard_dpia' => 'تقييم تأثير حماية البيانات (DPIA)',
    'safeguard_tia' => 'تقييم تأثير نقل البيانات الدولي (TIA)',
    'inactive' => 'غير نشط',
];

// ==================== HINDI ====================
$translations['hi'] = [
    'app_title' => 'GDPR रजिस्टर',
    'company_subtitle' => 'गोपनीयता और अनुपालन',
    'dashboard' => 'डैशबोर्ड',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'डेटा उल्लंघन',
    'breach' => 'डेटा उल्लंघन',
    'third_parties' => 'तीसरे पक्ष',
    'third_party' => 'तीसरा पक्ष',
    'measures' => 'उपाय',
    'reporting' => 'रिपोर्टिंग',
    'total' => 'कुल',
    'active' => 'सक्रिय',
    'high_risk' => 'उच्च जोखिम',
    'dpia_required' => 'DPIA आवश्यक',
    'dpia_completed' => 'DPIA पूर्ण',
    'new' => 'नया',
    'export_json' => 'JSON निर्यात करें',
    'search' => 'खोजें...',
    'search_company' => 'कंपनी खोजें...',
    'filter' => 'फ़िल्टर',
    'clear' => 'साफ़ करें',
    'risk' => 'जोखिम',
    'risk_level' => 'जोखिम स्तर',
    'status' => 'स्थिति',
    'retention_period' => 'प्रतिधारण अवधि',
    'actions' => 'कार्य',
    'view' => 'देखें',
    'edit' => 'संपादित करें',
    'delete' => 'हटाएं',
    'print' => 'प्रिंट करें',
    'confirm_delete' => 'क्या आप इस रिकॉर्ड को हटाना चाहते हैं? इसे पूर्ववत नहीं किया जा सकता।',
    'processing_activity' => 'प्रसंस्करण गतिविधि',
    'purpose' => 'उद्देश्य',
    'data_subjects' => 'डेटा विषय',
    'personal_data' => 'व्यक्तिगत डेटा',
    'recipients' => 'प्राप्तकर्ता',
    'legal_basis' => 'कानूनी आधार',
    'legitimate_interest' => 'वैध हित',
    'department' => 'विभाग',
    'international_transfer' => 'अंतर्राष्ट्रीय स्थानांतरण',
    'to_country' => 'देश में',
    'we_are_processor' => 'हम प्रोसेसर हैं',
    'processing_agreement_third_party' => 'तीसरे पक्ष के साथ प्रसंस्करण समझौता',
    'technical_measures' => 'तकनीकी उपाय',
    'organizational_measures' => 'संगठनात्मक उपाय',
    'safeguards' => 'सुरक्षा उपाय',
    'review_date' => 'समीक्षा तिथि',
    'controller' => 'नियंत्रक',
    'joint_controller' => 'संयुक्त नियंत्रक',
    'dpo' => 'डेटा संरक्षण अधिकारी',
    'representative' => 'प्रतिनिधि',
    'name' => 'नाम',
    'contact' => 'संपर्क',
    'title' => 'शीर्षक',
    'description' => 'विवरण',
    'risk_origin' => 'जोखिम का कारण',
    'affected_subjects' => 'प्रभावित विषय',
    'management_approval' => 'प्रबंधन अनुमोदन',
    'approved_by' => 'द्वारा अनुमोदित',
    'approval_date' => 'अनुमोदन तिथि',
    'consultation_conducted' => 'परामर्श किया गया',
    'consultation_details' => 'परामर्श विवरण',
    'recommendations' => 'सिफारिशें',
    'notes' => 'नोट्स',
    'necessity_test' => 'आवश्यकता परीक्षण',
    'proportionality_test' => 'समानुपातिकता परीक्षण',
    'mitigation_measures' => 'शमन उपाय',
    'residual_risk' => 'अवशिष्ट जोखिम',
    'breach_date' => 'उल्लंघन तिथि',
    'discovery_date' => 'खोज तिथि',
    'breach_type' => 'उल्लंघन प्रकार',
    'causes' => 'कारण',
    'measures_taken' => 'किए गए उपाय',
    'notified_authority' => 'प्राधिकरण को सूचित किया',
    'notification_date' => 'सूचना तिथि',
    'notified_affected' => 'प्रभावित व्यक्तियों को सूचित किया',
    'company_name' => 'कंपनी का नाम',
    'contact_person' => 'संपर्क व्यक्ति',
    'email' => 'ईमेल',
    'phone' => 'फोन',
    'address' => 'पता',
    'service_provided' => 'प्रदान की गई सेवा',
    'agreement_signed' => 'समझौता हस्ताक्षरित',
    'agreement_date' => 'समझौता तिथि',
    'expiry_date' => 'समाप्ति तिथि',
    'compliance_status' => 'अनुपालन स्थिति',
    'save' => 'सहेजें',
    'cancel' => 'रद्द करें',
    'add' => 'जोड़ें',
    'close' => 'बंद करें',
    'language' => 'भाषा',
    'full_report' => 'पूरी रिपोर्ट',
    'backup' => 'बैकअप',
    'zip_backup' => 'ZIP बैकअप',
    'statistics' => 'आंकड़े',
    'no_records' => 'कोई रिकॉर्ड नहीं मिला',
    'showing' => 'दिखा रहा है',
    'of' => 'का',
    'yes' => 'हाँ',
    'no' => 'नहीं',
    'unknown' => 'अज्ञात',
    'not_required' => 'आवश्यक नहीं',
    'in_progress' => 'प्रगति में',
    'completed' => 'पूर्ण',
    'approved' => 'अनुमोदित',
    'draft' => 'ड्राफ्ट',
    'open' => 'खुला',
    'investigating' => 'जांच में',
    'contained' => 'नियंत्रित',
    'resolved' => 'हल किया गया',
    'closed' => 'बंद',
    'compliant' => 'अनुपालक',
    'non_compliant' => 'गैर-अनुपालक',
    'review_needed' => 'समीक्षा आवश्यक',
    'low' => 'निम्न',
    'medium' => 'मध्यम',
    'high' => 'उच्च',
    'confidentiality' => 'गोपनीयता',
    'integrity' => 'अखंडता',
    'availability' => 'उपलब्धता',
    'mixed' => 'मिश्रित',
    'contract' => 'अनुबंध',
    'consent' => 'सहमति',
    'legal_obligation' => 'कानूनी दायित्व',
    'legitimate_interests' => 'वैध हित',
    'vital_interests' => 'महत्वपूर्ण हित',
    'public_task' => 'सार्वजनिक कार्य',
    'technical' => 'तकनीकी',
    'organizational' => 'संगठनात्मक',
    'human_error' => 'मानवीय त्रुटि',
    'external' => 'बाहरी',
    'systematic_monitoring' => 'व्यवस्थित निगरानी',
    'sensitive_data' => 'संवेदनशील डेटा',
    'other' => 'अन्य',
    'administration' => 'प्रशासन',
    'hr' => 'मानव संसाधन',
    'finance' => 'वित्त',
    'marketing' => 'विपणन',
    'it' => 'आईटी',
    'operations' => 'संचालन',
    'pending' => 'लंबित',
    'rejected' => 'अस्वीकृत',
    'planned' => 'योजनाबद्ध',
    'donations' => 'दान',
    'create_dpia' => 'DPIA बनाएं',
    'create_dpia_from_gdpr' => 'GDPR से DPIA बनाएं',
    'click_create_dpia_for_gdpr' => 'GDPR रिकॉर्ड के लिए "DPIA बनाएं" पर क्लिक करें जिसे DPIA की आवश्यकता है:',
    'new_gdpr_record' => 'नया GDPR रिकॉर्ड',
    'edit_gdpr_record' => 'GDPR रिकॉर्ड संपादित करें',
    'new_dpia' => 'नई DPIA',
    'edit_dpia' => 'DPIA संपादित करें',
    'new_breach' => 'नया डेटा उल्लंघन',
    'edit_breach' => 'डेटा उल्लंघन संपादित करें',
    'new_third_party' => 'नया तीसरा पक्ष',
    'edit_third_party' => 'तीसरा पक्ष संपादित करें',
    'record' => 'रिकॉर्ड',
    'page' => 'पृष्ठ',
    'generated' => 'उत्पन्न',
    'successfully_added' => 'सफलतापूर्वक जोड़ा गया',
    'successfully_updated' => 'सफलतापूर्वक अद्यतन किया गया',
    'unsaved_changes_confirm' => 'असुरक्षित परिवर्तन हैं। क्या आप रद्द करना चाहते हैं?',
    'select_or_type_below' => 'नीचे चुनें या टाइप करें',
    'or_type_custom_retention_period' => 'या कस्टम प्रतिधारण अवधि टाइप करें',
    'or_type_custom_safeguards' => 'या कस्टम सुरक्षा उपाय टाइप करें (अल्पविराम से अलग)',
    'or_type_custom_measures' => 'या कस्टम उपाय टाइप करें (अल्पविराम से अलग)',
    'hold_ctrl_to_select_multiple' => 'एकाधिक चयन के लिए Ctrl (Windows) या Cmd (Mac) दबाए रखें',
    'custom_mitigation_measures' => 'कस्टम शमन उपाय (अल्पविराम से अलग)',
    'custom_measures_taken' => 'कस्टम किए गए उपाय (अल्पविराम से अलग)',
    'custom_measures_placeholder' => 'जैसे: कस्टम उपाय 1, कस्टम उपाय 2',
    'gdpr_record_id' => 'GDPR रिकॉर्ड आईडी',
    'gdpr_record' => 'GDPR रिकॉर्ड',
    'dpia_for_gdpr' => 'GDPR के लिए DPIA',
    'dpia_exists_for_gdpr' => 'GDPR के लिए DPIA पहले से मौजूद है',
    'for_gdpr_record' => 'GDPR रिकॉर्ड के लिए',
    'only_one_dpia_allowed' => 'प्रति GDPR रिकॉर्ड केवल एक DPIA की अनुमति है।',
    'risk_distribution' => 'जोखिम वितरण',
    'gdpr_compliance_overview' => 'GDPR अनुपालन अवलोकन',
    'inactive_draft' => 'निष्क्रिय / ड्राफ्ट',
    'collected_from_records' => 'रिकॉर्ड से एकत्रित',
    'measure' => 'उपाय',
    'source' => 'स्रोत',
    'configuration' => 'विन्यास',
    'no_technical_measures' => 'कोई तकनीकी उपाय नहीं मिला',
    'no_organizational_measures' => 'कोई संगठनात्मक उपाय नहीं मिला',
    'total_gdpr_records' => 'कुल GDPR रिकॉर्ड',
    'dpia_in_progress' => 'प्रगति में DPIA',
    'total_breaches' => 'कुल उल्लंघन',
    'open_breaches' => 'खुले उल्लंघन',
    'total_third_parties' => 'कुल तीसरे पक्ष',
    'compliant_third_parties' => 'अनुपालक तीसरे पक्ष',
    'dpia_coverage' => 'DPIA कवरेज',
    'gdpr_with_dpia_required' => 'DPIA आवश्यक GDPR',
    'dpia_completion_rate' => 'DPIA पूर्णता दर',
    'category' => 'श्रेणी',
    'overview' => 'अवलोकन',
    'per_category' => 'श्रेणी के अनुसार',
    'total_risk' => 'कुल जोखिम',
    'completion_rate' => 'पूर्णता दर',
    'record_type' => 'रिकॉर्ड प्रकार',
    'print_report_title' => 'अनुपालन रिपोर्ट',
    'generated_on' => 'उत्पन्न',
    'or_type_custom_department' => 'या एक कस्टम विभाग टाइप करें',
    'or_type_custom_name' => 'या एक नाम टाइप करें',
    'or_type_custom_risk_origin' => 'या एक कस्टम जोखिम स्रोत टाइप करें',
    'or_type_custom_status' => 'या एक कस्टम स्थिति टाइप करें',
    'or_type_custom_approval' => 'या एक कस्टम अनुमोदन स्थिति टाइप करें',
    'or_type_custom_consultation' => 'या एक कस्टम मान टाइप करें',
    'or_type_custom_compliance_status' => 'या एक कस्टम अनुपालन स्थिति टाइप करें',
    'or_type_custom_breach_type' => 'या एक कस्टम उल्लंघन प्रकार टाइप करें',
    'logout' => 'लॉगआउट',
    'logout_confirm' => 'क्या आप इस सत्र से लॉगआउट करना चाहते हैं?',
    'value' => 'मान',
    'edit_measure' => 'उपाय संपादित करें',
    'current_measure' => 'वर्तमान उपाय',
    'new_measure_name' => 'नया उपाय नाम',
    'measure_renamed_success' => 'उपाय का नाम उन सभी स्थानों पर सफलतापूर्वक बदल दिया गया है जहाँ इसका उपयोग किया जाता है।',
    'measure_rename_warning' => 'यह हर उस GDPR, DPIA और डेटा उल्लंघन रिकॉर्ड में उपाय का नाम बदल देगा जहाँ इसका उपयोग किया जाता है।',
    'measure_deleted_success' => 'उपाय को उन सभी स्थानों से सफलतापूर्वक हटा दिया गया है जहाँ इसका उपयोग किया गया था।',
    'confirm_delete_measure' => 'क्या आप वाकई इस उपाय को हटाना चाहते हैं? यह हर उस GDPR, DPIA और डेटा उल्लंघन रिकॉर्ड से हटा दिया जाएगा जहाँ इसका उपयोग किया जाता है। इसे पूर्ववत नहीं किया जा सकता।',
    'responsible' => 'जिम्मेदार व्यक्ति',
    'responsible_placeholder' => 'इस उपाय के लिए कौन जिम्मेदार है?',
    'unassigned' => 'असाइन नहीं किया गया',
    'value_renamed_success' => 'मान का नाम उन सभी स्थानों पर सफलतापूर्वक बदल दिया गया है जहाँ इसका उपयोग किया जाता है।',
    'value_deleted_success' => 'मान को उन सभी स्थानों से सफलतापूर्वक हटा दिया गया है जहाँ इसका उपयोग किया गया था।',
    'edit_value' => 'मान संपादित करें',
    'delete_value' => 'मान हटाएं',
    'current_value' => 'वर्तमान मान',
    'new_value' => 'नया मान',
    'value_rename_warning' => 'नाम बदलने से यह मान उन सभी स्थानों पर अपडेट हो जाएगा जहाँ इसका वर्तमान में उपयोग किया जाता है।',
    'value_delete_warning' => 'हटाने से यह मान उन सभी रिकॉर्ड से मिट जाएगा जहाँ इसका वर्तमान में उपयोग किया जाता है। इसे पूर्ववत नहीं किया जा सकता।',
    'confirm_delete_value' => 'क्या इस मान को उन सभी स्थानों से हटाना है जहाँ इसका उपयोग किया जाता है? इसे पूर्ववत नहीं किया जा सकता।',
    'used_in' => 'में उपयोग किया गया',
    'not_currently_used' => 'वर्तमान में उपयोग नहीं किया जा रहा',
    'no_values' => 'कोई मान नहीं मिला',
    'not_started' => 'शुरू नहीं हुआ',
    'safeguard_scc' => 'मानक संविदात्मक खंड (SCC)',
    'safeguard_bcr' => 'बाध्यकारी कॉर्पोरेट नियम (BCR)',
    'safeguard_privacy_shield' => 'प्राइवेसी शील्ड (अब मान्य नहीं)',
    'safeguard_adequacy_decision' => 'यूरोपीय आयोग का पर्याप्तता निर्णय',
    'safeguard_consent' => 'डेटा विषय की विशिष्ट सहमति',
    'safeguard_model_contracts' => 'मॉडल अनुबंध',
    'safeguard_certification' => 'प्रमाणन तंत्र',
    'safeguard_codes_of_conduct' => 'आचार संहिता',
    'safeguard_dpia' => 'डेटा सुरक्षा प्रभाव आकलन (DPIA)',
    'safeguard_tia' => 'अंतरराष्ट्रीय डेटा स्थानांतरण प्रभाव आकलन (TIA)',
    'inactive' => 'निष्क्रिय',
];

// ==================== TURKISH ====================
$translations['tr'] = [
    'app_title' => 'KVKK Kayıt',
    'company_subtitle' => 'Gizlilik ve Uyum',
    'dashboard' => 'Panel',
    'gdpr' => 'KVKK',
    'dpia' => 'DPIA',
    'breaches' => 'Veri İhlalleri',
    'breach' => 'Veri İhlali',
    'third_parties' => 'Üçüncü Taraflar',
    'third_party' => 'Üçüncü Taraf',
    'measures' => 'Önlemler',
    'reporting' => 'Raporlama',
    'total' => 'Toplam',
    'active' => 'Aktif',
    'high_risk' => 'Yüksek Risk',
    'dpia_required' => 'DPIA Gerekli',
    'dpia_completed' => 'DPIA Tamamlandı',
    'new' => 'Yeni',
    'export_json' => 'JSON Dışa Aktar',
    'search' => 'Ara...',
    'search_company' => 'Şirket ara...',
    'filter' => 'Filtrele',
    'clear' => 'Temizle',
    'risk' => 'Risk',
    'risk_level' => 'Risk Seviyesi',
    'status' => 'Durum',
    'retention_period' => 'Saklama Süresi',
    'actions' => 'İşlemler',
    'view' => 'Görüntüle',
    'edit' => 'Düzenle',
    'delete' => 'Sil',
    'print' => 'Yazdır',
    'confirm_delete' => 'Bu kaydı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.',
    'processing_activity' => 'İşleme Faaliyeti',
    'purpose' => 'Amaç',
    'data_subjects' => 'Veri Sahipleri',
    'personal_data' => 'Kişisel Veri',
    'recipients' => 'Alıcılar',
    'legal_basis' => 'Yasal Dayanak',
    'legitimate_interest' => 'Meşru Menfaat',
    'department' => 'Departman',
    'international_transfer' => 'Uluslararası Transfer',
    'to_country' => 'Ülkeye',
    'we_are_processor' => 'İşleyiciyiz',
    'processing_agreement_third_party' => 'Üçüncü Taraf ile İşleme Sözleşmesi',
    'technical_measures' => 'Teknik Önlemler',
    'organizational_measures' => 'Organizasyonel Önlemler',
    'safeguards' => 'Güvenceler',
    'review_date' => 'İnceleme Tarihi',
    'controller' => 'Veri Sorumlusu',
    'joint_controller' => 'Ortak Veri Sorumlusu',
    'dpo' => 'Veri Koruma Görevlisi',
    'representative' => 'Temsilci',
    'name' => 'İsim',
    'contact' => 'İletişim',
    'title' => 'Başlık',
    'description' => 'Açıklama',
    'risk_origin' => 'Risk Kaynağı',
    'affected_subjects' => 'Etkilenen Kişiler',
    'management_approval' => 'Yönetim Onayı',
    'approved_by' => 'Onaylayan',
    'approval_date' => 'Onay Tarihi',
    'consultation_conducted' => 'Danışma Yapıldı',
    'consultation_details' => 'Danışma Detayları',
    'recommendations' => 'Tavsiyeler',
    'notes' => 'Notlar',
    'necessity_test' => 'Gereklilik Testi',
    'proportionality_test' => 'Orantılılık Testi',
    'mitigation_measures' => 'Azaltıcı Önlemler',
    'residual_risk' => 'Artık Risk',
    'breach_date' => 'İhlal Tarihi',
    'discovery_date' => 'Keşif Tarihi',
    'breach_type' => 'İhlal Türü',
    'causes' => 'Nedenler',
    'measures_taken' => 'Alınan Önlemler',
    'notified_authority' => 'Yetkili Makama Bildirildi',
    'notification_date' => 'Bildirim Tarihi',
    'notified_affected' => 'Etkilenen Kişilere Bildirildi',
    'company_name' => 'Şirket Adı',
    'contact_person' => 'İletişim Kişisi',
    'email' => 'E-posta',
    'phone' => 'Telefon',
    'address' => 'Adres',
    'service_provided' => 'Sağlanan Hizmet',
    'agreement_signed' => 'Sözleşme İmzalandı',
    'agreement_date' => 'Sözleşme Tarihi',
    'expiry_date' => 'Son Kullanma Tarihi',
    'compliance_status' => 'Uyum Durumu',
    'save' => 'Kaydet',
    'cancel' => 'İptal',
    'add' => 'Ekle',
    'close' => 'Kapat',
    'language' => 'Dil',
    'full_report' => 'Tam Rapor',
    'backup' => 'Yedekleme',
    'zip_backup' => 'ZIP Yedekleme',
    'statistics' => 'İstatistikler',
    'no_records' => 'Kayıt bulunamadı',
    'showing' => 'Gösteriliyor',
    'of' => 'of',
    'yes' => 'Evet',
    'no' => 'Hayır',
    'unknown' => 'Bilinmiyor',
    'not_required' => 'Gerekli Değil',
    'in_progress' => 'Devam Ediyor',
    'completed' => 'Tamamlandı',
    'approved' => 'Onaylandı',
    'draft' => 'Taslak',
    'open' => 'Açık',
    'investigating' => 'Soruşturuluyor',
    'contained' => 'Kontrol Altında',
    'resolved' => 'Çözüldü',
    'closed' => 'Kapalı',
    'compliant' => 'Uyumlu',
    'non_compliant' => 'Uyumsuz',
    'review_needed' => 'İnceleme Gerekli',
    'low' => 'Düşük',
    'medium' => 'Orta',
    'high' => 'Yüksek',
    'confidentiality' => 'Gizlilik',
    'integrity' => 'Bütünlük',
    'availability' => 'Kullanılabilirlik',
    'mixed' => 'Karma',
    'contract' => 'Sözleşme',
    'consent' => 'Rıza',
    'legal_obligation' => 'Yasal Yükümlülük',
    'legitimate_interests' => 'Meşru Menfaatler',
    'vital_interests' => 'Hayati Menfaatler',
    'public_task' => 'Kamu Görevi',
    'technical' => 'Teknik',
    'organizational' => 'Organizasyonel',
    'human_error' => 'İnsan Hatası',
    'external' => 'Dış',
    'systematic_monitoring' => 'Sistematik İzleme',
    'sensitive_data' => 'Hassas Veri',
    'other' => 'Diğer',
    'administration' => 'İdare',
    'hr' => 'İK',
    'finance' => 'Finans',
    'marketing' => 'Pazarlama',
    'it' => 'BT',
    'operations' => 'Operasyonlar',
    'pending' => 'Beklemede',
    'rejected' => 'Reddedildi',
    'planned' => 'Planlandı',
    'donations' => 'Bağışlar',
    'create_dpia' => 'DPIA Oluştur',
    'create_dpia_from_gdpr' => 'KVKK\'dan DPIA Oluştur',
    'click_create_dpia_for_gdpr' => 'DPIA gerektiren bir KVKK kaydı için "DPIA Oluştur"a tıklayın:',
    'new_gdpr_record' => 'Yeni KVKK Kaydı',
    'edit_gdpr_record' => 'KVKK Kaydını Düzenle',
    'new_dpia' => 'Yeni DPIA',
    'edit_dpia' => 'DPIA\'yı Düzenle',
    'new_breach' => 'Yeni Veri İhlali',
    'edit_breach' => 'Veri İhlalini Düzenle',
    'new_third_party' => 'Yeni Üçüncü Taraf',
    'edit_third_party' => 'Üçüncü Tarafı Düzenle',
    'record' => 'Kayıt',
    'page' => 'Sayfa',
    'generated' => 'Oluşturuldu',
    'successfully_added' => 'başarıyla eklendi',
    'successfully_updated' => 'başarıyla güncellendi',
    'unsaved_changes_confirm' => 'Kaydedilmemiş değişiklikler var. İptal etmek istediğinizden emin misiniz?',
    'select_or_type_below' => 'Aşağıdan seçin veya yazın',
    'or_type_custom_retention_period' => 'Veya özel saklama süresi yazın',
    'or_type_custom_safeguards' => 'Veya özel güvenceler yazın (virgülle ayrılmış)',
    'or_type_custom_measures' => 'Veya özel önlemler yazın (virgülle ayrılmış)',
    'hold_ctrl_to_select_multiple' => 'Birden fazla seçmek için Ctrl (Windows) veya Cmd (Mac) basılı tutun',
    'custom_mitigation_measures' => 'Özel azaltıcı önlemler (virgülle ayrılmış)',
    'custom_measures_taken' => 'Özel alınan önlemler (virgülle ayrılmış)',
    'custom_measures_placeholder' => 'Örn: Özel önlem 1, Özel önlem 2',
    'gdpr_record_id' => 'KVKK Kayıt ID\'si',
    'gdpr_record' => 'KVKK Kaydı',
    'dpia_for_gdpr' => 'KVKK için DPIA',
    'dpia_exists_for_gdpr' => 'KVKK için zaten bir DPIA mevcut',
    'for_gdpr_record' => 'KVKK kaydı için',
    'only_one_dpia_allowed' => 'KVKK kaydı başına yalnızca bir DPIA\'ya izin verilir.',
    'risk_distribution' => 'Risk Dağılımı',
    'gdpr_compliance_overview' => 'KVKK Uyum Genel Görünümü',
    'inactive_draft' => 'Pasif / Taslak',
    'collected_from_records' => 'Kayıtlardan toplanan',
    'measure' => 'Önlem',
    'source' => 'Kaynak',
    'configuration' => 'Yapılandırma',
    'no_technical_measures' => 'Teknik önlem bulunamadı',
    'no_organizational_measures' => 'Organizasyonel önlem bulunamadı',
    'total_gdpr_records' => 'Toplam KVKK kaydı',
    'dpia_in_progress' => 'Devam eden DPIA',
    'total_breaches' => 'Toplam ihlal',
    'open_breaches' => 'Açık ihlaller',
    'total_third_parties' => 'Toplam üçüncü taraf',
    'compliant_third_parties' => 'Uyumlu üçüncü taraflar',
    'dpia_coverage' => 'DPIA Kapsamı',
    'gdpr_with_dpia_required' => 'DPIA gerektiren KVKK',
    'dpia_completion_rate' => 'DPIA tamamlama oranı',
    'category' => 'Kategori',
    'overview' => 'Genel Görünüm',
    'per_category' => 'Kategoriye Göre',
    'total_risk' => 'Toplam Risk',
    'completion_rate' => 'Tamamlama Oranı',
    'record_type' => 'Kayıt Türü',
    'print_report_title' => 'Uyum Raporu',
    'generated_on' => 'Oluşturulma Tarihi',
    'or_type_custom_department' => 'Veya özel bir departman yazın',
    'or_type_custom_name' => 'Veya bir isim yazın',
    'or_type_custom_risk_origin' => 'Veya özel bir risk kaynağı yazın',
    'or_type_custom_status' => 'Veya özel bir durum yazın',
    'or_type_custom_approval' => 'Veya özel bir onay durumu yazın',
    'or_type_custom_consultation' => 'Veya özel bir değer yazın',
    'or_type_custom_compliance_status' => 'Veya özel bir uyumluluk durumu yazın',
    'or_type_custom_breach_type' => 'Veya özel bir ihlal türü yazın',
    'logout' => 'Çıkış Yap',
    'logout_confirm' => 'Bu oturumdan çıkış yapmak istiyor musunuz?',
    'value' => 'Değer',
    'edit_measure' => 'Önlemi Düzenle',
    'current_measure' => 'Mevcut Önlem',
    'new_measure_name' => 'Yeni Önlem Adı',
    'measure_renamed_success' => 'Önlem, kullanıldığı her yerde başarıyla yeniden adlandırıldı.',
    'measure_rename_warning' => 'Bu işlem, önlemi kullanıldığı her KVKK, DPIA ve veri ihlali kaydında yeniden adlandırır.',
    'measure_deleted_success' => 'Önlem, kullanıldığı her yerden başarıyla silindi.',
    'confirm_delete_measure' => 'Bu önlemi silmek istediğinizden emin misiniz? Kullanıldığı her KVKK, DPIA ve veri ihlali kaydından kaldırılacaktır. Bu işlem geri alınamaz.',
    'responsible' => 'Sorumlu',
    'responsible_placeholder' => 'Bu önlemden kim sorumlu?',
    'unassigned' => 'Atanmamış',
    'value_renamed_success' => 'Değer, kullanıldığı her yerde başarıyla yeniden adlandırıldı.',
    'value_deleted_success' => 'Değer, kullanıldığı her yerden başarıyla kaldırıldı.',
    'edit_value' => 'Değeri düzenle',
    'delete_value' => 'Değeri sil',
    'current_value' => 'Mevcut değer',
    'new_value' => 'Yeni değer',
    'value_rename_warning' => 'Yeniden adlandırma, bu değerin şu anda kullanıldığı her yeri günceller.',
    'value_delete_warning' => 'Silme işlemi, bu değeri şu anda kullanıldığı her kayıttan temizler. Bu işlem geri alınamaz.',
    'confirm_delete_value' => 'Bu değer kullanıldığı her yerden silinsin mi? Bu işlem geri alınamaz.',
    'used_in' => 'Kullanıldığı yer',
    'not_currently_used' => 'Şu anda kullanılmıyor',
    'no_values' => 'Değer bulunamadı',
    'not_started' => 'Başlamadı',
    'safeguard_scc' => 'Standart Sözleşme Hükümleri (SCC)',
    'safeguard_bcr' => 'Bağlayıcı Şirket Kuralları (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (artık geçerli değil)',
    'safeguard_adequacy_decision' => 'Avrupa Komisyonu Yeterlilik Kararı',
    'safeguard_consent' => 'Veri sahibinin özel rızası',
    'safeguard_model_contracts' => 'Model sözleşmeler',
    'safeguard_certification' => 'Sertifikasyon mekanizmaları',
    'safeguard_codes_of_conduct' => 'Davranış kuralları',
    'safeguard_dpia' => 'Veri Koruma Etki Değerlendirmesi (DPIA)',
    'safeguard_tia' => 'Uluslararası Veri Aktarımı Etki Değerlendirmesi (TIA)',
    'inactive' => 'Pasif',
];

// ==================== POLISH ====================
$translations['pl'] = [
    'app_title' => 'Rejestr RODO',
    'company_subtitle' => 'Prywatność i zgodność',
    'dashboard' => 'Panel',
    'gdpr' => 'RODO',
    'dpia' => 'DPIA',
    'breaches' => 'Naruszenia danych',
    'breach' => 'Naruszenie danych',
    'third_parties' => 'Strony trzecie',
    'third_party' => 'Strona trzecia',
    'measures' => 'Środki',
    'reporting' => 'Raportowanie',
    'total' => 'Razem',
    'active' => 'Aktywny',
    'high_risk' => 'Wysokie ryzyko',
    'dpia_required' => 'Wymagana DPIA',
    'dpia_completed' => 'DPIA zakończona',
    'new' => 'Nowy',
    'export_json' => 'Eksportuj JSON',
    'search' => 'Szukaj...',
    'search_company' => 'Szukaj firmy...',
    'filter' => 'Filtruj',
    'clear' => 'Wyczyść',
    'risk' => 'Ryzyko',
    'risk_level' => 'Poziom ryzyka',
    'status' => 'Status',
    'retention_period' => 'Okres przechowywania',
    'actions' => 'Akcje',
    'view' => 'Wyświetl',
    'edit' => 'Edytuj',
    'delete' => 'Usuń',
    'print' => 'Drukuj',
    'confirm_delete' => 'Czy na pewno chcesz usunąć ten rekord? Tej operacji nie można cofnąć.',
    'processing_activity' => 'Czynność przetwarzania',
    'purpose' => 'Cel',
    'data_subjects' => 'Osoby, których dane dotyczą',
    'personal_data' => 'Dane osobowe',
    'recipients' => 'Odbiorcy',
    'legal_basis' => 'Podstawa prawna',
    'legitimate_interest' => 'Prawnie uzasadniony interes',
    'department' => 'Departament',
    'international_transfer' => 'Transfer międzynarodowy',
    'to_country' => 'Do kraju',
    'we_are_processor' => 'Jesteśmy podmiotem przetwarzającym',
    'processing_agreement_third_party' => 'Umowa powierzenia przetwarzania z stroną trzecią',
    'technical_measures' => 'Środki techniczne',
    'organizational_measures' => 'Środki organizacyjne',
    'safeguards' => 'Gwarancje',
    'review_date' => 'Data przeglądu',
    'controller' => 'Administrator',
    'joint_controller' => 'Współadministrator',
    'dpo' => 'Inspektor Ochrony Danych',
    'representative' => 'Przedstawiciel',
    'name' => 'Nazwa',
    'contact' => 'Kontakt',
    'title' => 'Tytuł',
    'description' => 'Opis',
    'risk_origin' => 'Źródło ryzyka',
    'affected_subjects' => 'Osoby dotknięte',
    'management_approval' => 'Zatwierdzenie zarządu',
    'approved_by' => 'Zatwierdzony przez',
    'approval_date' => 'Data zatwierdzenia',
    'consultation_conducted' => 'Przeprowadzono konsultację',
    'consultation_details' => 'Szczegóły konsultacji',
    'recommendations' => 'Zalecenia',
    'notes' => 'Uwagi',
    'necessity_test' => 'Test konieczności',
    'proportionality_test' => 'Test proporcjonalności',
    'mitigation_measures' => 'Środki ograniczające',
    'residual_risk' => 'Ryzyko rezydualne',
    'breach_date' => 'Data naruszenia',
    'discovery_date' => 'Data wykrycia',
    'breach_type' => 'Rodzaj naruszenia',
    'causes' => 'Przyczyny',
    'measures_taken' => 'Podjęte środki',
    'notified_authority' => 'Powiadomiono organ',
    'notification_date' => 'Data powiadomienia',
    'notified_affected' => 'Powiadomiono osoby dotknięte',
    'company_name' => 'Nazwa firmy',
    'contact_person' => 'Osoba kontaktowa',
    'email' => 'E-mail',
    'phone' => 'Telefon',
    'address' => 'Adres',
    'service_provided' => 'Świadczona usługa',
    'agreement_signed' => 'Podpisano umowę',
    'agreement_date' => 'Data umowy',
    'expiry_date' => 'Data wygaśnięcia',
    'compliance_status' => 'Status zgodności',
    'save' => 'Zapisz',
    'cancel' => 'Anuluj',
    'add' => 'Dodaj',
    'close' => 'Zamknij',
    'language' => 'Język',
    'full_report' => 'Pełny raport',
    'backup' => 'Kopia zapasowa',
    'zip_backup' => 'Kopia zapasowa ZIP',
    'statistics' => 'Statystyki',
    'no_records' => 'Nie znaleziono rekordów',
    'showing' => 'Wyświetlanie',
    'of' => 'z',
    'yes' => 'Tak',
    'no' => 'Nie',
    'unknown' => 'Nieznany',
    'not_required' => 'Niewymagane',
    'in_progress' => 'W trakcie',
    'completed' => 'Zakończone',
    'approved' => 'Zatwierdzone',
    'draft' => 'Szkic',
    'open' => 'Otwarty',
    'investigating' => 'W dochodzeniu',
    'contained' => 'Ograniczone',
    'resolved' => 'Rozwiązany',
    'closed' => 'Zamknięty',
    'compliant' => 'Zgodny',
    'non_compliant' => 'Niezgodny',
    'review_needed' => 'Wymagany przegląd',
    'low' => 'Niski',
    'medium' => 'Średni',
    'high' => 'Wysoki',
    'confidentiality' => 'Poufność',
    'integrity' => 'Integralność',
    'availability' => 'Dostępność',
    'mixed' => 'Mieszany',
    'contract' => 'Umowa',
    'consent' => 'Zgoda',
    'legal_obligation' => 'Obowiązek prawny',
    'legitimate_interests' => 'Prawnie uzasadnione interesy',
    'vital_interests' => 'Żywotne interesy',
    'public_task' => 'Zadanie publiczne',
    'technical' => 'Techniczny',
    'organizational' => 'Organizacyjny',
    'human_error' => 'Błąd ludzki',
    'external' => 'Zewnętrzny',
    'systematic_monitoring' => 'Systematyczny monitoring',
    'sensitive_data' => 'Dane wrażliwe',
    'other' => 'Inne',
    'administration' => 'Administracja',
    'hr' => 'HR',
    'finance' => 'Finanse',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Operacje',
    'pending' => 'Oczekujący',
    'rejected' => 'Odrzucony',
    'planned' => 'Zaplanowany',
    'donations' => 'Darowizny',
    'create_dpia' => 'Utwórz DPIA',
    'create_dpia_from_gdpr' => 'Utwórz DPIA z RODO',
    'click_create_dpia_for_gdpr' => 'Kliknij "Utwórz DPIA" dla rekordu RODO, który wymaga DPIA:',
    'new_gdpr_record' => 'Nowy rekord RODO',
    'edit_gdpr_record' => 'Edytuj rekord RODO',
    'new_dpia' => 'Nowa DPIA',
    'edit_dpia' => 'Edytuj DPIA',
    'new_breach' => 'Nowe naruszenie danych',
    'edit_breach' => 'Edytuj naruszenie danych',
    'new_third_party' => 'Nowa strona trzecia',
    'edit_third_party' => 'Edytuj stronę trzecią',
    'record' => 'Rekord',
    'page' => 'Strona',
    'generated' => 'Wygenerowano',
    'successfully_added' => 'pomyślnie dodano',
    'successfully_updated' => 'pomyślnie zaktualizowano',
    'unsaved_changes_confirm' => 'Istnieją niezapisane zmiany. Czy na pewno chcesz anulować?',
    'select_or_type_below' => 'Wybierz lub wpisz poniżej',
    'or_type_custom_retention_period' => 'Lub wpisz niestandardowy okres przechowywania',
    'or_type_custom_safeguards' => 'Lub wpisz niestandardowe gwarancje (oddzielone przecinkami)',
    'or_type_custom_measures' => 'Lub wpisz niestandardowe środki (oddzielone przecinkami)',
    'hold_ctrl_to_select_multiple' => 'Przytrzymaj Ctrl (Windows) lub Cmd (Mac), aby wybrać wiele',
    'custom_mitigation_measures' => 'Niestandardowe środki ograniczające (oddzielone przecinkami)',
    'custom_measures_taken' => 'Niestandardowe podjęte środki (oddzielone przecinkami)',
    'custom_measures_placeholder' => 'Np. Środek niestandardowy 1, Środek niestandardowy 2',
    'gdpr_record_id' => 'ID rekordu RODO',
    'gdpr_record' => 'Rekord RODO',
    'dpia_for_gdpr' => 'DPIA dla RODO',
    'dpia_exists_for_gdpr' => 'DPIA już istnieje dla RODO',
    'for_gdpr_record' => 'dla rekordu RODO',
    'only_one_dpia_allowed' => 'Tylko jedna DPIA jest dozwolona na rekord RODO.',
    'risk_distribution' => 'Rozkład ryzyka',
    'gdpr_compliance_overview' => 'Przegląd zgodności z RODO',
    'inactive_draft' => 'Nieaktywny / Szkic',
    'collected_from_records' => 'Zebrane z rekordów',
    'measure' => 'Środek',
    'source' => 'Źródło',
    'configuration' => 'Konfiguracja',
    'no_technical_measures' => 'Nie znaleziono środków technicznych',
    'no_organizational_measures' => 'Nie znaleziono środków organizacyjnych',
    'total_gdpr_records' => 'Łączna liczba rekordów RODO',
    'dpia_in_progress' => 'DPIA w trakcie',
    'total_breaches' => 'Łączna liczba naruszeń',
    'open_breaches' => 'Otwarte naruszenia',
    'total_third_parties' => 'Łączna liczba stron trzecich',
    'compliant_third_parties' => 'Zgodne strony trzecie',
    'dpia_coverage' => 'Pokrycie DPIA',
    'gdpr_with_dpia_required' => 'RODO z wymaganą DPIA',
    'dpia_completion_rate' => 'Wskaźnik ukończenia DPIA',
    'category' => 'Kategoria',
    'overview' => 'Przegląd',
    'per_category' => 'Według kategorii',
    'total_risk' => 'Całkowite ryzyko',
    'completion_rate' => 'Wskaźnik ukończenia',
    'record_type' => 'Typ rekordu',
    'print_report_title' => 'Raport zgodności',
    'generated_on' => 'Wygenerowano',
    'or_type_custom_department' => 'Lub wpisz własny dział',
    'or_type_custom_name' => 'Lub wpisz nazwę',
    'or_type_custom_risk_origin' => 'Lub wpisz własne źródło ryzyka',
    'or_type_custom_status' => 'Lub wpisz własny status',
    'or_type_custom_approval' => 'Lub wpisz własny status zatwierdzenia',
    'or_type_custom_consultation' => 'Lub wpisz własną wartość',
    'or_type_custom_compliance_status' => 'Lub wpisz własny status zgodności',
    'or_type_custom_breach_type' => 'Lub wpisz własny typ naruszenia',
    'logout' => 'Wyloguj się',
    'logout_confirm' => 'Czy chcesz wylogować się z tej sesji?',
    'value' => 'Wartość',
    'edit_measure' => 'Edytuj środek',
    'current_measure' => 'Bieżący środek',
    'new_measure_name' => 'Nowa nazwa środka',
    'measure_renamed_success' => 'Środek został pomyślnie zmieniony wszędzie tam, gdzie jest używany.',
    'measure_rename_warning' => 'Spowoduje to zmianę nazwy środka we wszystkich rekordach RODO, DPIA i naruszeń danych, w których jest używany.',
    'measure_deleted_success' => 'Środek został pomyślnie usunięty wszędzie tam, gdzie był używany.',
    'confirm_delete_measure' => 'Czy na pewno chcesz usunąć ten środek? Zostanie on usunięty ze wszystkich rekordów RODO, DPIA i naruszeń danych, w których jest używany. Tej operacji nie można cofnąć.',
    'responsible' => 'Odpowiedzialny',
    'responsible_placeholder' => 'Kto jest odpowiedzialny za ten środek?',
    'unassigned' => 'Nieprzypisany',
    'value_renamed_success' => 'Wartość została pomyślnie zmieniona wszędzie tam, gdzie jest używana.',
    'value_deleted_success' => 'Wartość została pomyślnie usunięta wszędzie tam, gdzie była używana.',
    'edit_value' => 'Edytuj wartość',
    'delete_value' => 'Usuń wartość',
    'current_value' => 'Bieżąca wartość',
    'new_value' => 'Nowa wartość',
    'value_rename_warning' => 'Zmiana nazwy zaktualizuje tę wartość wszędzie tam, gdzie jest obecnie używana.',
    'value_delete_warning' => 'Usunięcie wyczyści tę wartość we wszystkich rekordach, w których jest obecnie używana. Tej operacji nie można cofnąć.',
    'confirm_delete_value' => 'Usunąć tę wartość wszędzie tam, gdzie jest używana? Tej operacji nie można cofnąć.',
    'used_in' => 'Używane w',
    'not_currently_used' => 'Obecnie nieużywane',
    'no_values' => 'Nie znaleziono wartości',
    'not_started' => 'Nie rozpoczęto',
    'safeguard_scc' => 'Standardowe klauzule umowne (SCC)',
    'safeguard_bcr' => 'Wiążące reguły korporacyjne (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (już nieważne)',
    'safeguard_adequacy_decision' => 'Decyzja Komisji Europejskiej o adekwatności',
    'safeguard_consent' => 'Wyraźna zgoda osoby, której dane dotyczą',
    'safeguard_model_contracts' => 'Umowy standardowe',
    'safeguard_certification' => 'Mechanizmy certyfikacji',
    'safeguard_codes_of_conduct' => 'Kodeksy postępowania',
    'safeguard_dpia' => 'Ocena skutków dla ochrony danych (DPIA)',
    'safeguard_tia' => 'Ocena skutków międzynarodowego transferu danych (TIA)',
    'inactive' => 'Nieaktywny',
];

// ==================== UKRAINIAN ====================
$translations['uk'] = [
    'app_title' => 'Реєстр GDPR',
    'company_subtitle' => 'Конфіденційність та відповідність',
    'dashboard' => 'Панель керування',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Витоки даних',
    'breach' => 'Витік даних',
    'third_parties' => 'Треті сторони',
    'third_party' => 'Третя сторона',
    'measures' => 'Заходи',
    'reporting' => 'Звітність',
    'total' => 'Всього',
    'active' => 'Активний',
    'high_risk' => 'Високий ризик',
    'dpia_required' => 'Потрібна DPIA',
    'dpia_completed' => 'DPIA завершена',
    'new' => 'Новий',
    'export_json' => 'Експорт JSON',
    'search' => 'Пошук...',
    'search_company' => 'Пошук компанії...',
    'filter' => 'Фільтр',
    'clear' => 'Очистити',
    'risk' => 'Ризик',
    'risk_level' => 'Рівень ризику',
    'status' => 'Статус',
    'retention_period' => 'Термін зберігання',
    'actions' => 'Дії',
    'view' => 'Переглянути',
    'edit' => 'Редагувати',
    'delete' => 'Видалити',
    'print' => 'Друк',
    'confirm_delete' => 'Ви впевнені, що хочете видалити цей запис? Цю дію не можна скасувати.',
    'processing_activity' => 'Операція обробки',
    'purpose' => 'Мета',
    'data_subjects' => 'Суб\'єкти даних',
    'personal_data' => 'Персональні дані',
    'recipients' => 'Отримувачі',
    'legal_basis' => 'Правова підстава',
    'legitimate_interest' => 'Законний інтерес',
    'department' => 'Відділ',
    'international_transfer' => 'Міжнародна передача',
    'to_country' => 'До країни',
    'we_are_processor' => 'Ми обробник',
    'processing_agreement_third_party' => 'Угода про обробку з третьою стороною',
    'technical_measures' => 'Технічні заходи',
    'organizational_measures' => 'Організаційні заходи',
    'safeguards' => 'Гарантії',
    'review_date' => 'Дата перевірки',
    'controller' => 'Контролер',
    'joint_controller' => 'Спільний контролер',
    'dpo' => 'Уповноважений із захисту даних',
    'representative' => 'Представник',
    'name' => 'Ім\'я',
    'contact' => 'Контакт',
    'title' => 'Назва',
    'description' => 'Опис',
    'risk_origin' => 'Джерело ризику',
    'affected_subjects' => 'Постраждалі суб\'єкти',
    'management_approval' => 'Схвалення керівництва',
    'approved_by' => 'Схвалено',
    'approval_date' => 'Дата схвалення',
    'consultation_conducted' => 'Проведено консультацію',
    'consultation_details' => 'Деталі консультації',
    'recommendations' => 'Рекомендації',
    'notes' => 'Примітки',
    'necessity_test' => 'Тест необхідності',
    'proportionality_test' => 'Тест пропорційності',
    'mitigation_measures' => 'Заходи зменшення ризиків',
    'residual_risk' => 'Залишковий ризик',
    'breach_date' => 'Дата витоку',
    'discovery_date' => 'Дата виявлення',
    'breach_type' => 'Тип витоку',
    'causes' => 'Причини',
    'measures_taken' => 'Вжиті заходи',
    'notified_authority' => 'Повідомлено орган',
    'notification_date' => 'Дата повідомлення',
    'notified_affected' => 'Повідомлено постраждалих осіб',
    'company_name' => 'Назва компанії',
    'contact_person' => 'Контактна особа',
    'email' => 'Електронна пошта',
    'phone' => 'Телефон',
    'address' => 'Адреса',
    'service_provided' => 'Надана послуга',
    'agreement_signed' => 'Угоду підписано',
    'agreement_date' => 'Дата угоди',
    'expiry_date' => 'Дата закінчення строку',
    'compliance_status' => 'Статус відповідності',
    'save' => 'Зберегти',
    'cancel' => 'Скасувати',
    'add' => 'Додати',
    'close' => 'Закрити',
    'language' => 'Мова',
    'full_report' => 'Повний звіт',
    'backup' => 'Резервна копія',
    'zip_backup' => 'ZIP-резервна копія',
    'statistics' => 'Статистика',
    'no_records' => 'Записи не знайдено',
    'showing' => 'Показано',
    'of' => 'з',
    'yes' => 'Так',
    'no' => 'Ні',
    'unknown' => 'Невідомо',
    'not_required' => 'Не потрібно',
    'in_progress' => 'В процесі',
    'completed' => 'Завершено',
    'approved' => 'Схвалено',
    'draft' => 'Чернетка',
    'open' => 'Відкрито',
    'investigating' => 'Розслідується',
    'contained' => 'Стримується',
    'resolved' => 'Вирішено',
    'closed' => 'Закрито',
    'compliant' => 'Відповідає',
    'non_compliant' => 'Не відповідає',
    'review_needed' => 'Потрібна перевірка',
    'low' => 'Низький',
    'medium' => 'Середній',
    'high' => 'Високий',
    'confidentiality' => 'Конфіденційність',
    'integrity' => 'Цілісність',
    'availability' => 'Доступність',
    'mixed' => 'Змішаний',
    'contract' => 'Договір',
    'consent' => 'Згода',
    'legal_obligation' => 'Законне зобов\'язання',
    'legitimate_interests' => 'Законні інтереси',
    'vital_interests' => 'Життєво важливі інтереси',
    'public_task' => 'Публічне завдання',
    'technical' => 'Технічний',
    'organizational' => 'Організаційний',
    'human_error' => 'Людська помилка',
    'external' => 'Зовнішній',
    'systematic_monitoring' => 'Систематичний моніторинг',
    'sensitive_data' => 'Чутливі дані',
    'other' => 'Інше',
    'administration' => 'Адміністрація',
    'hr' => 'Кадри',
    'finance' => 'Фінанси',
    'marketing' => 'Маркетинг',
    'it' => 'ІТ',
    'operations' => 'Операції',
    'pending' => 'В очікуванні',
    'rejected' => 'Відхилено',
    'planned' => 'Заплановано',
    'donations' => 'Пожертви',
    'create_dpia' => 'Створити DPIA',
    'create_dpia_from_gdpr' => 'Створити DPIA з GDPR',
    'click_create_dpia_for_gdpr' => 'Натисніть "Створити DPIA" для запису GDPR, який потребує DPIA:',
    'new_gdpr_record' => 'Новий запис GDPR',
    'edit_gdpr_record' => 'Редагувати запис GDPR',
    'new_dpia' => 'Нова DPIA',
    'edit_dpia' => 'Редагувати DPIA',
    'new_breach' => 'Новий витік даних',
    'edit_breach' => 'Редагувати витік даних',
    'new_third_party' => 'Нова третя сторона',
    'edit_third_party' => 'Редагувати третю сторону',
    'record' => 'Запис',
    'page' => 'Сторінка',
    'generated' => 'Створено',
    'successfully_added' => 'успішно додано',
    'successfully_updated' => 'успішно оновлено',
    'unsaved_changes_confirm' => 'Є незбережені зміни. Ви впевнені, що хочете скасувати?',
    'select_or_type_below' => 'Виберіть або введіть нижче',
    'or_type_custom_retention_period' => 'Або введіть свій термін зберігання',
    'or_type_custom_safeguards' => 'Або введіть свої гарантії (через кому)',
    'or_type_custom_measures' => 'Або введіть свої заходи (через кому)',
    'hold_ctrl_to_select_multiple' => 'Утримуйте Ctrl (Windows) або Cmd (Mac) для вибору кількох',
    'custom_mitigation_measures' => 'Власні заходи зменшення ризиків (через кому)',
    'custom_measures_taken' => 'Власні вжиті заходи (через кому)',
    'custom_measures_placeholder' => 'Напр. Власний захід 1, Власний захід 2',
    'gdpr_record_id' => 'ID запису GDPR',
    'gdpr_record' => 'Запис GDPR',
    'dpia_for_gdpr' => 'DPIA для GDPR',
    'dpia_exists_for_gdpr' => 'DPIA вже існує для GDPR',
    'for_gdpr_record' => 'для запису GDPR',
    'only_one_dpia_allowed' => 'Дозволено лише одну DPIA на запис GDPR.',
    'risk_distribution' => 'Розподіл ризиків',
    'gdpr_compliance_overview' => 'Огляд відповідності GDPR',
    'inactive_draft' => 'Неактивний / Чернетка',
    'collected_from_records' => 'Зібрано з записів',
    'measure' => 'Захід',
    'source' => 'Джерело',
    'configuration' => 'Конфігурація',
    'no_technical_measures' => 'Технічні заходи не знайдено',
    'no_organizational_measures' => 'Організаційні заходи не знайдено',
    'total_gdpr_records' => 'Всього записів GDPR',
    'dpia_in_progress' => 'DPIA в процесі',
    'total_breaches' => 'Всього витоків',
    'open_breaches' => 'Відкриті витоки',
    'total_third_parties' => 'Всього третіх сторін',
    'compliant_third_parties' => 'Відповідні треті сторони',
    'dpia_coverage' => 'Покриття DPIA',
    'gdpr_with_dpia_required' => 'GDPR з потрібною DPIA',
    'dpia_completion_rate' => 'Рівень завершення DPIA',
    'category' => 'Категорія',
    'overview' => 'Огляд',
    'per_category' => 'За категоріями',
    'total_risk' => 'Загальний ризик',
    'completion_rate' => 'Рівень завершення',
    'record_type' => 'Тип запису',
    'print_report_title' => 'Звіт про відповідність',
    'generated_on' => 'Створено',
    'or_type_custom_department' => 'Або введіть власний відділ',
    'or_type_custom_name' => 'Або введіть ім’я',
    'or_type_custom_risk_origin' => 'Або введіть власне джерело ризику',
    'or_type_custom_status' => 'Або введіть власний статус',
    'or_type_custom_approval' => 'Або введіть власний статус затвердження',
    'or_type_custom_consultation' => 'Або введіть власне значення',
    'or_type_custom_compliance_status' => 'Або введіть власний статус відповідності',
    'or_type_custom_breach_type' => 'Або введіть власний тип витоку',
    'logout' => 'Вийти',
    'logout_confirm' => 'Вийти з цього сеансу?',
    'value' => 'Значення',
    'edit_measure' => 'Редагувати захід',
    'current_measure' => 'Поточний захід',
    'new_measure_name' => 'Нова назва заходу',
    'measure_renamed_success' => 'Захід успішно перейменовано скрізь, де він використовується.',
    'measure_rename_warning' => 'Це перейменує захід у всіх записах GDPR, DPIA та витоків даних, де він використовується.',
    'measure_deleted_success' => 'Захід успішно видалено скрізь, де він використовувався.',
    'confirm_delete_measure' => 'Ви впевнені, що хочете видалити цей захід? Його буде видалено з усіх записів GDPR, DPIA та витоків даних, де він використовується. Цю дію не можна скасувати.',
    'responsible' => 'Відповідальний',
    'responsible_placeholder' => 'Хто відповідає за цей захід?',
    'unassigned' => 'Не призначено',
    'value_renamed_success' => 'Значення успішно перейменовано скрізь, де воно використовується.',
    'value_deleted_success' => 'Значення успішно видалено скрізь, де воно використовувалося.',
    'edit_value' => 'Редагувати значення',
    'delete_value' => 'Видалити значення',
    'current_value' => 'Поточне значення',
    'new_value' => 'Нове значення',
    'value_rename_warning' => 'Перейменування оновить це значення скрізь, де воно наразі використовується.',
    'value_delete_warning' => 'Видалення очистить це значення в усіх записах, де воно наразі використовується. Цю дію не можна скасувати.',
    'confirm_delete_value' => 'Видалити це значення скрізь, де воно використовується? Цю дію не можна скасувати.',
    'used_in' => 'Використовується в',
    'not_currently_used' => 'Наразі не використовується',
    'no_values' => 'Значень не знайдено',
    'not_started' => 'Не розпочато',
    'safeguard_scc' => 'Стандартні договірні положення (SCC)',
    'safeguard_bcr' => 'Обов\'язкові корпоративні правила (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (більше не діє)',
    'safeguard_adequacy_decision' => 'Рішення Європейської комісії про адекватність',
    'safeguard_consent' => 'Особлива згода суб\'єкта даних',
    'safeguard_model_contracts' => 'Типові договори',
    'safeguard_certification' => 'Механізми сертифікації',
    'safeguard_codes_of_conduct' => 'Кодекси поведінки',
    'safeguard_dpia' => 'Оцінка впливу на захист даних (DPIA)',
    'safeguard_tia' => 'Оцінка впливу міжнародної передачі даних (TIA)',
    'inactive' => 'Неактивний',
];

// ==================== SWEDISH ====================
$translations['sv'] = [
    'app_title' => 'GDPR-register',
    'company_subtitle' => 'Integritet och efterlevnad',
    'dashboard' => 'Instrumentpanel',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Dataintrång',
    'breach' => 'Dataintrång',
    'third_parties' => 'Tredje parter',
    'third_party' => 'Tredje part',
    'measures' => 'Åtgärder',
    'reporting' => 'Rapportering',
    'total' => 'Totalt',
    'active' => 'Aktiv',
    'high_risk' => 'Hög risk',
    'dpia_required' => 'DPIA krävs',
    'dpia_completed' => 'DPIA slutförd',
    'new' => 'Ny',
    'export_json' => 'Exportera JSON',
    'search' => 'Sök...',
    'search_company' => 'Sök företag...',
    'filter' => 'Filtrera',
    'clear' => 'Rensa',
    'risk' => 'Risk',
    'risk_level' => 'Risknivå',
    'status' => 'Status',
    'retention_period' => 'Lagringstid',
    'actions' => 'Åtgärder',
    'view' => 'Visa',
    'edit' => 'Redigera',
    'delete' => 'Ta bort',
    'print' => 'Skriv ut',
    'confirm_delete' => 'Är du säker på att du vill ta bort den här posten? Detta kan inte ångras.',
    'processing_activity' => 'Behandlingsaktivitet',
    'purpose' => 'Syfte',
    'data_subjects' => 'Registrerade',
    'personal_data' => 'Personuppgifter',
    'recipients' => 'Mottagare',
    'legal_basis' => 'Rättslig grund',
    'legitimate_interest' => 'Berättigat intresse',
    'department' => 'Avdelning',
    'international_transfer' => 'Internationell överföring',
    'to_country' => 'Till land',
    'we_are_processor' => 'Vi är personuppgiftsbiträde',
    'processing_agreement_third_party' => 'Personuppgiftsbiträdesavtal med tredje part',
    'technical_measures' => 'Tekniska åtgärder',
    'organizational_measures' => 'Organisatoriska åtgärder',
    'safeguards' => 'Skyddsåtgärder',
    'review_date' => 'Granskningsdatum',
    'controller' => 'Personuppgiftsansvarig',
    'joint_controller' => 'Gemensamt personuppgiftsansvarig',
    'dpo' => 'Dataskyddsombud',
    'representative' => 'Representant',
    'name' => 'Namn',
    'contact' => 'Kontakt',
    'title' => 'Titel',
    'description' => 'Beskrivning',
    'risk_origin' => 'Riskursprung',
    'affected_subjects' => 'Berörda registrerade',
    'management_approval' => 'Ledningens godkännande',
    'approved_by' => 'Godkänd av',
    'approval_date' => 'Godkännandedatum',
    'consultation_conducted' => 'Samråd genomfört',
    'consultation_details' => 'Samrådsdetaljer',
    'recommendations' => 'Rekommendationer',
    'notes' => 'Anteckningar',
    'necessity_test' => 'Nödvändighetstest',
    'proportionality_test' => 'Proportionalitetstest',
    'mitigation_measures' => 'Begränsande åtgärder',
    'residual_risk' => 'Kvarvarande risk',
    'breach_date' => 'Datum för intrång',
    'discovery_date' => 'Upptäcktsdatum',
    'breach_type' => 'Typ av intrång',
    'causes' => 'Orsaker',
    'measures_taken' => 'Vidtagna åtgärder',
    'notified_authority' => 'Underrättat tillsynsmyndighet',
    'notification_date' => 'Underrättelsedatum',
    'notified_affected' => 'Underrättat berörda personer',
    'company_name' => 'Företagsnamn',
    'contact_person' => 'Kontaktperson',
    'email' => 'E-post',
    'phone' => 'Telefon',
    'address' => 'Adress',
    'service_provided' => 'Tillhandahållen tjänst',
    'agreement_signed' => 'Avtal undertecknat',
    'agreement_date' => 'Avtalsdatum',
    'expiry_date' => 'Utgångsdatum',
    'compliance_status' => 'Efterlevnadsstatus',
    'save' => 'Spara',
    'cancel' => 'Avbryt',
    'add' => 'Lägg till',
    'close' => 'Stäng',
    'language' => 'Språk',
    'full_report' => 'Fullständig rapport',
    'backup' => 'Säkerhetskopia',
    'zip_backup' => 'ZIP-säkerhetskopia',
    'statistics' => 'Statistik',
    'no_records' => 'Inga poster hittades',
    'showing' => 'Visar',
    'of' => 'av',
    'yes' => 'Ja',
    'no' => 'Nej',
    'unknown' => 'Okänd',
    'not_required' => 'Ej nödvändig',
    'in_progress' => 'Pågående',
    'completed' => 'Slutförd',
    'approved' => 'Godkänd',
    'draft' => 'Utkast',
    'open' => 'Öppen',
    'investigating' => 'Utreder',
    'contained' => 'Begränsad',
    'resolved' => 'Löst',
    'closed' => 'Stängd',
    'compliant' => 'Följer',
    'non_compliant' => 'Följer inte',
    'review_needed' => 'Granskning behövs',
    'low' => 'Låg',
    'medium' => 'Medel',
    'high' => 'Hög',
    'confidentiality' => 'Konfidentialitet',
    'integrity' => 'Integritet',
    'availability' => 'Tillgänglighet',
    'mixed' => 'Blandad',
    'contract' => 'Avtal',
    'consent' => 'Samtycke',
    'legal_obligation' => 'Rättslig skyldighet',
    'legitimate_interests' => 'Berättigade intressen',
    'vital_interests' => 'Vitala intressen',
    'public_task' => 'Offentlig uppgift',
    'technical' => 'Teknisk',
    'organizational' => 'Organisatorisk',
    'human_error' => 'Mänskligt fel',
    'external' => 'Extern',
    'systematic_monitoring' => 'Systematisk övervakning',
    'sensitive_data' => 'Känsliga uppgifter',
    'other' => 'Annat',
    'administration' => 'Administration',
    'hr' => 'HR',
    'finance' => 'Ekonomi',
    'marketing' => 'Marknadsföring',
    'it' => 'IT',
    'operations' => 'Verksamhet',
    'pending' => 'Väntande',
    'rejected' => 'Avvisad',
    'planned' => 'Planerad',
    'donations' => 'Donationer',
    'create_dpia' => 'Skapa DPIA',
    'create_dpia_from_gdpr' => 'Skapa DPIA från GDPR',
    'click_create_dpia_for_gdpr' => 'Klicka på "Skapa DPIA" för en GDPR-post som kräver en DPIA:',
    'new_gdpr_record' => 'Ny GDPR-post',
    'edit_gdpr_record' => 'Redigera GDPR-post',
    'new_dpia' => 'Ny DPIA',
    'edit_dpia' => 'Redigera DPIA',
    'new_breach' => 'Nytt dataintrång',
    'edit_breach' => 'Redigera dataintrång',
    'new_third_party' => 'Ny tredje part',
    'edit_third_party' => 'Redigera tredje part',
    'record' => 'Post',
    'page' => 'Sida',
    'generated' => 'Genererad',
    'successfully_added' => 'har lagts till',
    'successfully_updated' => 'har uppdaterats',
    'unsaved_changes_confirm' => 'Det finns osparade ändringar. Är du säker på att du vill avbryta?',
    'select_or_type_below' => 'Välj eller skriv nedan',
    'or_type_custom_retention_period' => 'Eller ange anpassad lagringstid',
    'or_type_custom_safeguards' => 'Eller ange anpassade skyddsåtgärder (komma-separerade)',
    'or_type_custom_measures' => 'Eller ange anpassade åtgärder (komma-separerade)',
    'hold_ctrl_to_select_multiple' => 'Håll Ctrl (Windows) eller Cmd (Mac) för att välja flera',
    'custom_mitigation_measures' => 'Anpassade begränsande åtgärder (komma-separerade)',
    'custom_measures_taken' => 'Anpassade vidtagna åtgärder (komma-separerade)',
    'custom_measures_placeholder' => 'T.ex. Anpassad åtgärd 1, Anpassad åtgärd 2',
    'gdpr_record_id' => 'GDPR-post-ID',
    'gdpr_record' => 'GDPR-post',
    'dpia_for_gdpr' => 'DPIA för GDPR',
    'dpia_exists_for_gdpr' => 'En DPIA finns redan för GDPR',
    'for_gdpr_record' => 'för GDPR-post',
    'only_one_dpia_allowed' => 'Endast en DPIA tillåts per GDPR-post.',
    'risk_distribution' => 'Riskfördelning',
    'gdpr_compliance_overview' => 'Översikt över GDPR-efterlevnad',
    'inactive_draft' => 'Inaktiv / Utkast',
    'collected_from_records' => 'Insamlat från poster',
    'measure' => 'Åtgärd',
    'source' => 'Källa',
    'configuration' => 'Konfiguration',
    'no_technical_measures' => 'Inga tekniska åtgärder hittades',
    'no_organizational_measures' => 'Inga organisatoriska åtgärder hittades',
    'total_gdpr_records' => 'Totalt antal GDPR-poster',
    'dpia_in_progress' => 'DPIA pågående',
    'total_breaches' => 'Totalt antal intrång',
    'open_breaches' => 'Öppna intrång',
    'total_third_parties' => 'Totalt antal tredje parter',
    'compliant_third_parties' => 'Följsamma tredje parter',
    'dpia_coverage' => 'DPIA-täckning',
    'gdpr_with_dpia_required' => 'GDPR med krävd DPIA',
    'dpia_completion_rate' => 'DPIA-slutförandegrad',
    'category' => 'Kategori',
    'overview' => 'Översikt',
    'per_category' => 'Per kategori',
    'total_risk' => 'Total risk',
    'completion_rate' => 'Slutförandegrad',
    'record_type' => 'Posttyp',
    'print_report_title' => 'Efterlevnadsrapport',
    'generated_on' => 'Genererad',
    'or_type_custom_department' => 'Eller skriv en egen avdelning',
    'or_type_custom_name' => 'Eller skriv ett namn',
    'or_type_custom_risk_origin' => 'Eller skriv ett eget riskursprung',
    'or_type_custom_status' => 'Eller skriv en egen status',
    'or_type_custom_approval' => 'Eller skriv en egen godkännandestatus',
    'or_type_custom_consultation' => 'Eller skriv ett eget värde',
    'or_type_custom_compliance_status' => 'Eller skriv en egen efterlevnadsstatus',
    'or_type_custom_breach_type' => 'Eller skriv en egen typ av intrång',
    'logout' => 'Logga ut',
    'logout_confirm' => 'Vill du logga ut från den här sessionen?',
    'value' => 'Värde',
    'edit_measure' => 'Redigera åtgärd',
    'current_measure' => 'Nuvarande åtgärd',
    'new_measure_name' => 'Nytt åtgärdsnamn',
    'measure_renamed_success' => 'Åtgärden har bytt namn i alla poster där den används.',
    'measure_rename_warning' => 'Detta byter namn på åtgärden i alla GDPR-, DPIA- och dataintrångsposter där den används.',
    'measure_deleted_success' => 'Åtgärden har tagits bort överallt där den användes.',
    'confirm_delete_measure' => 'Är du säker på att du vill ta bort den här åtgärden? Den tas bort från alla GDPR-, DPIA- och dataintrångsposter där den används. Detta kan inte ångras.',
    'responsible' => 'Ansvarig',
    'responsible_placeholder' => 'Vem är ansvarig för den här åtgärden?',
    'unassigned' => 'Ej tilldelad',
    'value_renamed_success' => 'Värdet har bytt namn överallt där det används.',
    'value_deleted_success' => 'Värdet har tagits bort överallt där det användes.',
    'edit_value' => 'Redigera värde',
    'delete_value' => 'Ta bort värde',
    'current_value' => 'Nuvarande värde',
    'new_value' => 'Nytt värde',
    'value_rename_warning' => 'Namnbytet uppdaterar det här värdet överallt där det används just nu.',
    'value_delete_warning' => 'Borttagning rensar det här värdet från alla poster där det används just nu. Detta kan inte ångras.',
    'confirm_delete_value' => 'Ta bort det här värdet överallt där det används? Detta kan inte ångras.',
    'used_in' => 'Används i',
    'not_currently_used' => 'Används inte för närvarande',
    'no_values' => 'Inga värden hittades',
    'not_started' => 'Inte påbörjad',
    'safeguard_scc' => 'Standardavtalsklausuler (SCC)',
    'safeguard_bcr' => 'Bindande företagsbestämmelser (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (inte längre giltigt)',
    'safeguard_adequacy_decision' => 'Europeiska kommissionens beslut om adekvat skyddsnivå',
    'safeguard_consent' => 'Specifikt samtycke från den registrerade',
    'safeguard_model_contracts' => 'Modellavtal',
    'safeguard_certification' => 'Certifieringsmekanismer',
    'safeguard_codes_of_conduct' => 'Uppförandekoder',
    'safeguard_dpia' => 'Konsekvensbedömning avseende dataskydd (DPIA)',
    'safeguard_tia' => 'Konsekvensbedömning för internationell dataöverföring (TIA)',
    'inactive' => 'Inaktiv',
];

// ==================== NORWEGIAN ====================
$translations['no'] = [
    'app_title' => 'GDPR-register',
    'company_subtitle' => 'Personvern og samsvar',
    'dashboard' => 'Dashbord',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Databrudd',
    'breach' => 'Databrudd',
    'third_parties' => 'Tredjeparter',
    'third_party' => 'Tredjepart',
    'measures' => 'Tiltak',
    'reporting' => 'Rapportering',
    'total' => 'Totalt',
    'active' => 'Aktiv',
    'high_risk' => 'Høy risiko',
    'dpia_required' => 'DPIA kreves',
    'dpia_completed' => 'DPIA fullført',
    'new' => 'Ny',
    'export_json' => 'Eksporter JSON',
    'search' => 'Søk...',
    'search_company' => 'Søk etter selskap...',
    'filter' => 'Filter',
    'clear' => 'Tøm',
    'risk' => 'Risiko',
    'risk_level' => 'Risikonivå',
    'status' => 'Status',
    'retention_period' => 'Lagringsperiode',
    'actions' => 'Handlinger',
    'view' => 'Vis',
    'edit' => 'Rediger',
    'delete' => 'Slett',
    'print' => 'Skriv ut',
    'confirm_delete' => 'Er du sikker på at du vil slette denne oppføringen? Dette kan ikke angres.',
    'processing_activity' => 'Behandlingsaktivitet',
    'purpose' => 'Formål',
    'data_subjects' => 'Registrerte',
    'personal_data' => 'Personopplysninger',
    'recipients' => 'Mottakere',
    'legal_basis' => 'Rettslig grunnlag',
    'legitimate_interest' => 'Berettiget interesse',
    'department' => 'Avdeling',
    'international_transfer' => 'Internasjonal overføring',
    'to_country' => 'Til land',
    'we_are_processor' => 'Vi er behandler',
    'processing_agreement_third_party' => 'Behandlingsavtale med tredjepart',
    'technical_measures' => 'Tekniske tiltak',
    'organizational_measures' => 'Organisatoriske tiltak',
    'safeguards' => 'Sikkerhetstiltak',
    'review_date' => 'Gjennomgangsdato',
    'controller' => 'Behandlingsansvarlig',
    'joint_controller' => 'Felles behandlingsansvarlig',
    'dpo' => 'Personvernombud',
    'representative' => 'Representant',
    'name' => 'Navn',
    'contact' => 'Kontakt',
    'title' => 'Tittel',
    'description' => 'Beskrivelse',
    'risk_origin' => 'Risikoopprinnelse',
    'affected_subjects' => 'Berørte registrerte',
    'management_approval' => 'Ledelsesgodkjenning',
    'approved_by' => 'Godkjent av',
    'approval_date' => 'Godkjenningsdato',
    'consultation_conducted' => 'Konsultasjon gjennomført',
    'consultation_details' => 'Konsultasjonsdetaljer',
    'recommendations' => 'Anbefalinger',
    'notes' => 'Notater',
    'necessity_test' => 'Nødvendighetstest',
    'proportionality_test' => 'Proporsjonalitetstest',
    'mitigation_measures' => 'Begrensende tiltak',
    'residual_risk' => 'Restrisiko',
    'breach_date' => 'Dato for brudd',
    'discovery_date' => 'Oppdagelsesdato',
    'breach_type' => 'Type brudd',
    'causes' => 'Årsaker',
    'measures_taken' => 'Tiltak iverksatt',
    'notified_authority' => 'Varslet tilsynsmyndighet',
    'notification_date' => 'Varslingsdato',
    'notified_affected' => 'Varslet berørte personer',
    'company_name' => 'Selskapsnavn',
    'contact_person' => 'Kontaktperson',
    'email' => 'E-post',
    'phone' => 'Telefon',
    'address' => 'Adresse',
    'service_provided' => 'Tjeneste levert',
    'agreement_signed' => 'Avtale signert',
    'agreement_date' => 'Avtaledato',
    'expiry_date' => 'Utløpsdato',
    'compliance_status' => 'Samsvarsstatus',
    'save' => 'Lagre',
    'cancel' => 'Avbryt',
    'add' => 'Legg til',
    'close' => 'Lukk',
    'language' => 'Språk',
    'full_report' => 'Fullstendig rapport',
    'backup' => 'Sikkerhetskopi',
    'zip_backup' => 'ZIP-sikkerhetskopi',
    'statistics' => 'Statistikk',
    'no_records' => 'Ingen oppføringer funnet',
    'showing' => 'Viser',
    'of' => 'av',
    'yes' => 'Ja',
    'no' => 'Nei',
    'unknown' => 'Ukjent',
    'not_required' => 'Ikke nødvendig',
    'in_progress' => 'Pågående',
    'completed' => 'Fullført',
    'approved' => 'Godkjent',
    'draft' => 'Utkast',
    'open' => 'Åpen',
    'investigating' => 'Etterforsker',
    'contained' => 'Inneholdt',
    'resolved' => 'Løst',
    'closed' => 'Lukket',
    'compliant' => 'Samsvarer',
    'non_compliant' => 'Samsvarer ikke',
    'review_needed' => 'Gjennomgang nødvendig',
    'low' => 'Lav',
    'medium' => 'Middels',
    'high' => 'Høy',
    'confidentiality' => 'Konfidensialitet',
    'integrity' => 'Integritet',
    'availability' => 'Tilgjengelighet',
    'mixed' => 'Blandet',
    'contract' => 'Kontrakt',
    'consent' => 'Samtykke',
    'legal_obligation' => 'Rettslig forpliktelse',
    'legitimate_interests' => 'Berettigede interesser',
    'vital_interests' => 'Vitale interesser',
    'public_task' => 'Offentlig oppgave',
    'technical' => 'Teknisk',
    'organizational' => 'Organisatorisk',
    'human_error' => 'Menneskelig feil',
    'external' => 'Ekstern',
    'systematic_monitoring' => 'Systematisk overvåking',
    'sensitive_data' => 'Sensitive data',
    'other' => 'Annet',
    'administration' => 'Administrasjon',
    'hr' => 'HR',
    'finance' => 'Finans',
    'marketing' => 'Markedsføring',
    'it' => 'IT',
    'operations' => 'Drift',
    'pending' => 'Venter',
    'rejected' => 'Avvist',
    'planned' => 'Planlagt',
    'donations' => 'Donasjoner',
    'create_dpia' => 'Opprett DPIA',
    'create_dpia_from_gdpr' => 'Opprett DPIA fra GDPR',
    'click_create_dpia_for_gdpr' => 'Klikk "Opprett DPIA" for en GDPR-oppføring som krever en DPIA:',
    'new_gdpr_record' => 'Ny GDPR-oppføring',
    'edit_gdpr_record' => 'Rediger GDPR-oppføring',
    'new_dpia' => 'Ny DPIA',
    'edit_dpia' => 'Rediger DPIA',
    'new_breach' => 'Nytt databrudd',
    'edit_breach' => 'Rediger databrudd',
    'new_third_party' => 'Ny tredjepart',
    'edit_third_party' => 'Rediger tredjepart',
    'record' => 'Oppføring',
    'page' => 'Side',
    'generated' => 'Generert',
    'successfully_added' => 'lagt til',
    'successfully_updated' => 'oppdatert',
    'unsaved_changes_confirm' => 'Det er ulagrede endringer. Er du sikker på at du vil avbryte?',
    'select_or_type_below' => 'Velg eller skriv nedenfor',
    'or_type_custom_retention_period' => 'Eller skriv egendefinert lagringsperiode',
    'or_type_custom_safeguards' => 'Eller skriv egendefinerte sikkerhetstiltak (kommaseparert)',
    'or_type_custom_measures' => 'Eller skriv egendefinerte tiltak (kommaseparert)',
    'hold_ctrl_to_select_multiple' => 'Hold Ctrl (Windows) eller Cmd (Mac) for å velge flere',
    'custom_mitigation_measures' => 'Egendefinerte begrensende tiltak (kommaseparert)',
    'custom_measures_taken' => 'Egendefinerte iverksatte tiltak (kommaseparert)',
    'custom_measures_placeholder' => 'F.eks. Egendefinert tiltak 1, Egendefinert tiltak 2',
    'gdpr_record_id' => 'GDPR-oppførings-ID',
    'gdpr_record' => 'GDPR-oppføring',
    'dpia_for_gdpr' => 'DPIA for GDPR',
    'dpia_exists_for_gdpr' => 'En DPIA finnes allerede for GDPR',
    'for_gdpr_record' => 'for GDPR-oppføring',
    'only_one_dpia_allowed' => 'Bare én DPIA er tillatt per GDPR-oppføring.',
    'risk_distribution' => 'Risikofordeling',
    'gdpr_compliance_overview' => 'GDPR-samsvarsoversikt',
    'inactive_draft' => 'Inaktiv / Utkast',
    'collected_from_records' => 'Samlet fra oppføringer',
    'measure' => 'Tiltak',
    'source' => 'Kilde',
    'configuration' => 'Konfigurasjon',
    'no_technical_measures' => 'Ingen tekniske tiltak funnet',
    'no_organizational_measures' => 'Ingen organisatoriske tiltak funnet',
    'total_gdpr_records' => 'Totalt antall GDPR-oppføringer',
    'dpia_in_progress' => 'DPIA pågår',
    'total_breaches' => 'Totalt antall databrudd',
    'open_breaches' => 'Åpne databrudd',
    'total_third_parties' => 'Totalt antall tredjeparter',
    'compliant_third_parties' => 'Samsvarende tredjeparter',
    'dpia_coverage' => 'DPIA-dekning',
    'gdpr_with_dpia_required' => 'GDPR med DPIA kreves',
    'dpia_completion_rate' => 'DPIA-fullføringsrate',
    'category' => 'Kategori',
    'overview' => 'Oversikt',
    'per_category' => 'Per kategori',
    'total_risk' => 'Total risiko',
    'completion_rate' => 'Fullføringsrate',
    'record_type' => 'Oppføringstype',
    'print_report_title' => 'Samsvarsrapport',
    'generated_on' => 'Generert',
    'or_type_custom_department' => 'Eller skriv inn en egen avdeling',
    'or_type_custom_name' => 'Eller skriv inn et navn',
    'or_type_custom_risk_origin' => 'Eller skriv inn en egen risikokilde',
    'or_type_custom_status' => 'Eller skriv inn en egen status',
    'or_type_custom_approval' => 'Eller skriv inn en egen godkjenningsstatus',
    'or_type_custom_consultation' => 'Eller skriv inn en egen verdi',
    'or_type_custom_compliance_status' => 'Eller skriv inn en egen samsvarsstatus',
    'or_type_custom_breach_type' => 'Eller skriv inn en egen bruddtype',
    'logout' => 'Logg ut',
    'logout_confirm' => 'Vil du logge ut av denne økten?',
    'value' => 'Verdi',
    'edit_measure' => 'Rediger tiltak',
    'current_measure' => 'Gjeldende tiltak',
    'new_measure_name' => 'Nytt tiltaksnavn',
    'measure_renamed_success' => 'Tiltaket er omdøpt overalt hvor det brukes.',
    'measure_rename_warning' => 'Dette omdøper tiltaket i alle GDPR-, DPIA- og databruddsposter der det brukes.',
    'measure_deleted_success' => 'Tiltaket er slettet overalt hvor det ble brukt.',
    'confirm_delete_measure' => 'Er du sikker på at du vil slette dette tiltaket? Det fjernes fra alle GDPR-, DPIA- og databruddsposter der det brukes. Dette kan ikke angres.',
    'responsible' => 'Ansvarlig',
    'responsible_placeholder' => 'Hvem er ansvarlig for dette tiltaket?',
    'unassigned' => 'Ikke tildelt',
    'value_renamed_success' => 'Verdien er omdøpt overalt hvor den brukes.',
    'value_deleted_success' => 'Verdien er fjernet overalt hvor den ble brukt.',
    'edit_value' => 'Rediger verdi',
    'delete_value' => 'Slett verdi',
    'current_value' => 'Gjeldende verdi',
    'new_value' => 'Ny verdi',
    'value_rename_warning' => 'Omdøping oppdaterer denne verdien overalt hvor den brukes nå.',
    'value_delete_warning' => 'Sletting fjerner denne verdien fra alle poster der den brukes nå. Dette kan ikke angres.',
    'confirm_delete_value' => 'Slette denne verdien overalt hvor den brukes? Dette kan ikke angres.',
    'used_in' => 'Brukt i',
    'not_currently_used' => 'Ikke i bruk for øyeblikket',
    'no_values' => 'Ingen verdier funnet',
    'not_started' => 'Ikke startet',
    'safeguard_scc' => 'Standard avtaleklausuler (SCC)',
    'safeguard_bcr' => 'Bindende virksomhetsregler (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (ikke lenger gyldig)',
    'safeguard_adequacy_decision' => 'EU-kommisjonens beslutning om tilstrekkelig beskyttelsesnivå',
    'safeguard_consent' => 'Spesifikt samtykke fra den registrerte',
    'safeguard_model_contracts' => 'Modellkontrakter',
    'safeguard_certification' => 'Sertifiseringsmekanismer',
    'safeguard_codes_of_conduct' => 'Atferdskodekser',
    'safeguard_dpia' => 'Personvernkonsekvensvurdering (DPIA)',
    'safeguard_tia' => 'Konsekvensvurdering for internasjonal dataoverføring (TIA)',
    'inactive' => 'Inaktiv',
];

// ==================== DANISH ====================
$translations['da'] = [
    'app_title' => 'GDPR-register',
    'company_subtitle' => 'Privatliv og overholdelse',
    'dashboard' => 'Dashboard',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Databrud',
    'breach' => 'Databrud',
    'third_parties' => 'Tredjeparter',
    'third_party' => 'Tredjepart',
    'measures' => 'Foranstaltninger',
    'reporting' => 'Rapportering',
    'total' => 'I alt',
    'active' => 'Aktiv',
    'high_risk' => 'Høj risiko',
    'dpia_required' => 'DPIA kræves',
    'dpia_completed' => 'DPIA fuldført',
    'new' => 'Ny',
    'export_json' => 'Eksporter JSON',
    'search' => 'Søg...',
    'search_company' => 'Søg efter virksomhed...',
    'filter' => 'Filter',
    'clear' => 'Ryd',
    'risk' => 'Risiko',
    'risk_level' => 'Risikoniveau',
    'status' => 'Status',
    'retention_period' => 'Opbevaringsperiode',
    'actions' => 'Handlinger',
    'view' => 'Vis',
    'edit' => 'Rediger',
    'delete' => 'Slet',
    'print' => 'Print',
    'confirm_delete' => 'Er du sikker på, at du vil slette denne post? Dette kan ikke fortrydes.',
    'processing_activity' => 'Behandlingsaktivitet',
    'purpose' => 'Formål',
    'data_subjects' => 'Registrerede',
    'personal_data' => 'Personoplysninger',
    'recipients' => 'Modtagere',
    'legal_basis' => 'Retsgrundlag',
    'legitimate_interest' => 'Berettiget interesse',
    'department' => 'Afdeling',
    'international_transfer' => 'International overførsel',
    'to_country' => 'Til land',
    'we_are_processor' => 'Vi er databehandler',
    'processing_agreement_third_party' => 'Databehandleraftale med tredjepart',
    'technical_measures' => 'Tekniske foranstaltninger',
    'organizational_measures' => 'Organisatoriske foranstaltninger',
    'safeguards' => 'Sikkerhedsforanstaltninger',
    'review_date' => 'Gennemsynsdato',
    'controller' => 'Dataansvarlig',
    'joint_controller' => 'Fælles dataansvarlig',
    'dpo' => 'Databeskyttelsesrådgiver',
    'representative' => 'Repræsentant',
    'name' => 'Navn',
    'contact' => 'Kontakt',
    'title' => 'Titel',
    'description' => 'Beskrivelse',
    'risk_origin' => 'Risikoopprindelse',
    'affected_subjects' => 'Berørte registrerede',
    'management_approval' => 'Ledelsesgodkendelse',
    'approved_by' => 'Godkendt af',
    'approval_date' => 'Godkendelsesdato',
    'consultation_conducted' => 'Konsultation gennemført',
    'consultation_details' => 'Konsultationsdetaljer',
    'recommendations' => 'Anbefalinger',
    'notes' => 'Noter',
    'necessity_test' => 'Nødvendighedstest',
    'proportionality_test' => 'Proportionalitetstest',
    'mitigation_measures' => 'Afbødende foranstaltninger',
    'residual_risk' => 'Restrisiko',
    'breach_date' => 'Dato for brud',
    'discovery_date' => 'Opdagelsesdato',
    'breach_type' => 'Type brud',
    'causes' => 'Årsager',
    'measures_taken' => 'Iværksatte foranstaltninger',
    'notified_authority' => 'Underrettet tilsynsmyndighed',
    'notification_date' => 'Underretningsdato',
    'notified_affected' => 'Underrettet berørte personer',
    'company_name' => 'Virksomhedsnavn',
    'contact_person' => 'Kontaktperson',
    'email' => 'E-mail',
    'phone' => 'Telefon',
    'address' => 'Adresse',
    'service_provided' => 'Ydet service',
    'agreement_signed' => 'Aftale underskrevet',
    'agreement_date' => 'Aftaledato',
    'expiry_date' => 'Udløbsdato',
    'compliance_status' => 'Overholdelsesstatus',
    'save' => 'Gem',
    'cancel' => 'Annuller',
    'add' => 'Tilføj',
    'close' => 'Luk',
    'language' => 'Sprog',
    'full_report' => 'Fuldstændig rapport',
    'backup' => 'Backup',
    'zip_backup' => 'ZIP-backup',
    'statistics' => 'Statistik',
    'no_records' => 'Ingen poster fundet',
    'showing' => 'Viser',
    'of' => 'af',
    'yes' => 'Ja',
    'no' => 'Nej',
    'unknown' => 'Ukendt',
    'not_required' => 'Ikke påkrævet',
    'in_progress' => 'I gang',
    'completed' => 'Fuldført',
    'approved' => 'Godkendt',
    'draft' => 'Udkast',
    'open' => 'Åben',
    'investigating' => 'Undersøger',
    'contained' => 'Inddæmmet',
    'resolved' => 'Løst',
    'closed' => 'Lukket',
    'compliant' => 'Overholder',
    'non_compliant' => 'Overholder ikke',
    'review_needed' => 'Gennemsyn nødvendigt',
    'low' => 'Lav',
    'medium' => 'Mellem',
    'high' => 'Høj',
    'confidentiality' => 'Fortrolighed',
    'integrity' => 'Integritet',
    'availability' => 'Tilgængelighed',
    'mixed' => 'Blandet',
    'contract' => 'Kontrakt',
    'consent' => 'Samtykke',
    'legal_obligation' => 'Retlig forpligtelse',
    'legitimate_interests' => 'Berettigede interesser',
    'vital_interests' => 'Vitale interesser',
    'public_task' => 'Offentlig opgave',
    'technical' => 'Teknisk',
    'organizational' => 'Organisatorisk',
    'human_error' => 'Menneskelig fejl',
    'external' => 'Ekstern',
    'systematic_monitoring' => 'Systematisk overvågning',
    'sensitive_data' => 'Følsomme data',
    'other' => 'Andet',
    'administration' => 'Administration',
    'hr' => 'HR',
    'finance' => 'Finans',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Drift',
    'pending' => 'Afventer',
    'rejected' => 'Afvist',
    'planned' => 'Planlagt',
    'donations' => 'Donationer',
    'create_dpia' => 'Opret DPIA',
    'create_dpia_from_gdpr' => 'Opret DPIA fra GDPR',
    'click_create_dpia_for_gdpr' => 'Klik på "Opret DPIA" for en GDPR-post, der kræver en DPIA:',
    'new_gdpr_record' => 'Ny GDPR-post',
    'edit_gdpr_record' => 'Rediger GDPR-post',
    'new_dpia' => 'Ny DPIA',
    'edit_dpia' => 'Rediger DPIA',
    'new_breach' => 'Nyt databrud',
    'edit_breach' => 'Rediger databrud',
    'new_third_party' => 'Ny tredjepart',
    'edit_third_party' => 'Rediger tredjepart',
    'record' => 'Post',
    'page' => 'Side',
    'generated' => 'Genereret',
    'successfully_added' => 'tilføjet',
    'successfully_updated' => 'opdateret',
    'unsaved_changes_confirm' => 'Der er ikke-gemte ændringer. Er du sikker på, at du vil annullere?',
    'select_or_type_below' => 'Vælg eller skriv nedenfor',
    'or_type_custom_retention_period' => 'Eller skriv brugerdefineret opbevaringsperiode',
    'or_type_custom_safeguards' => 'Eller skriv brugerdefinerede sikkerhedsforanstaltninger (kommasepareret)',
    'or_type_custom_measures' => 'Eller skriv brugerdefinerede foranstaltninger (kommasepareret)',
    'hold_ctrl_to_select_multiple' => 'Hold Ctrl (Windows) eller Cmd (Mac) for at vælge flere',
    'custom_mitigation_measures' => 'Brugerdefinerede afbødende foranstaltninger (kommasepareret)',
    'custom_measures_taken' => 'Brugerdefinerede iværksatte foranstaltninger (kommasepareret)',
    'custom_measures_placeholder' => 'F.eks. Brugerdefineret foranstaltning 1, Brugerdefineret foranstaltning 2',
    'gdpr_record_id' => 'GDPR-post-ID',
    'gdpr_record' => 'GDPR-post',
    'dpia_for_gdpr' => 'DPIA for GDPR',
    'dpia_exists_for_gdpr' => 'En DPIA findes allerede for GDPR',
    'for_gdpr_record' => 'for GDPR-post',
    'only_one_dpia_allowed' => 'Kun én DPIA er tilladt pr. GDPR-post.',
    'risk_distribution' => 'Risikofordeling',
    'gdpr_compliance_overview' => 'GDPR-overholdelsesoversigt',
    'inactive_draft' => 'Inaktiv / Udkast',
    'collected_from_records' => 'Indsamlet fra poster',
    'measure' => 'Foranstaltning',
    'source' => 'Kilde',
    'configuration' => 'Konfiguration',
    'no_technical_measures' => 'Ingen tekniske foranstaltninger fundet',
    'no_organizational_measures' => 'Ingen organisatoriske foranstaltninger fundet',
    'total_gdpr_records' => 'GDPR-poster i alt',
    'dpia_in_progress' => 'DPIA i gang',
    'total_breaches' => 'Databrud i alt',
    'open_breaches' => 'Åbne databrud',
    'total_third_parties' => 'Tredjeparter i alt',
    'compliant_third_parties' => 'Overholdende tredjeparter',
    'dpia_coverage' => 'DPIA-dækning',
    'gdpr_with_dpia_required' => 'GDPR med DPIA påkrævet',
    'dpia_completion_rate' => 'DPIA-gennemførelsesrate',
    'category' => 'Kategori',
    'overview' => 'Oversigt',
    'per_category' => 'Per kategori',
    'total_risk' => 'Total risiko',
    'completion_rate' => 'Gennemførelsesrate',
    'record_type' => 'Posttype',
    'print_report_title' => 'Overholdelsesrapport',
    'generated_on' => 'Genereret',
    'or_type_custom_department' => 'Eller indtast en brugerdefineret afdeling',
    'or_type_custom_name' => 'Eller indtast et navn',
    'or_type_custom_risk_origin' => 'Eller indtast en brugerdefineret risikokilde',
    'or_type_custom_status' => 'Eller indtast en brugerdefineret status',
    'or_type_custom_approval' => 'Eller indtast en brugerdefineret godkendelsesstatus',
    'or_type_custom_consultation' => 'Eller indtast en brugerdefineret værdi',
    'or_type_custom_compliance_status' => 'Eller indtast en brugerdefineret overholdelsesstatus',
    'or_type_custom_breach_type' => 'Eller indtast en brugerdefineret bruddtype',
    'logout' => 'Log ud',
    'logout_confirm' => 'Vil du logge ud af denne session?',
    'value' => 'Værdi',
    'edit_measure' => 'Rediger foranstaltning',
    'current_measure' => 'Nuværende foranstaltning',
    'new_measure_name' => 'Nyt navn til foranstaltning',
    'measure_renamed_success' => 'Foranstaltningen er omdøbt overalt, hvor den bruges.',
    'measure_rename_warning' => 'Dette omdøber foranstaltningen i alle GDPR-, DPIA- og databrudsposter, hvor den bruges.',
    'measure_deleted_success' => 'Foranstaltningen er slettet overalt, hvor den blev brugt.',
    'confirm_delete_measure' => 'Er du sikker på, at du vil slette denne foranstaltning? Den fjernes fra alle GDPR-, DPIA- og databrudsposter, hvor den bruges. Dette kan ikke fortrydes.',
    'responsible' => 'Ansvarlig',
    'responsible_placeholder' => 'Hvem er ansvarlig for denne foranstaltning?',
    'unassigned' => 'Ikke tildelt',
    'value_renamed_success' => 'Værdien er omdøbt overalt, hvor den bruges.',
    'value_deleted_success' => 'Værdien er fjernet overalt, hvor den blev brugt.',
    'edit_value' => 'Rediger værdi',
    'delete_value' => 'Slet værdi',
    'current_value' => 'Nuværende værdi',
    'new_value' => 'Ny værdi',
    'value_rename_warning' => 'Omdøbning opdaterer denne værdi overalt, hvor den bruges i øjeblikket.',
    'value_delete_warning' => 'Sletning fjerner denne værdi fra alle poster, hvor den bruges i øjeblikket. Dette kan ikke fortrydes.',
    'confirm_delete_value' => 'Vil du slette denne værdi overalt, hvor den bruges? Dette kan ikke fortrydes.',
    'used_in' => 'Bruges i',
    'not_currently_used' => 'Bruges ikke i øjeblikket',
    'no_values' => 'Ingen værdier fundet',
    'not_started' => 'Ikke startet',
    'safeguard_scc' => 'Standardkontraktbestemmelser (SCC)',
    'safeguard_bcr' => 'Bindende virksomhedsregler (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (ikke længere gyldig)',
    'safeguard_adequacy_decision' => 'Europa-Kommissionens afgørelse om tilstrækkeligheden af beskyttelsesniveauet',
    'safeguard_consent' => 'Specifikt samtykke fra den registrerede',
    'safeguard_model_contracts' => 'Standardkontrakter',
    'safeguard_certification' => 'Certificeringsmekanismer',
    'safeguard_codes_of_conduct' => 'Adfærdskodekser',
    'safeguard_dpia' => 'Konsekvensanalyse vedrørende databeskyttelse (DPIA)',
    'safeguard_tia' => 'Konsekvensanalyse for international dataoverførsel (TIA)',
    'inactive' => 'Inaktiv',
];

// ==================== FINNISH ====================
$translations['fi'] = [
    'app_title' => 'GDPR-rekisteri',
    'company_subtitle' => 'Tietosuoja ja vaatimustenmukaisuus',
    'dashboard' => 'Kojelauta',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Tietoturvaloukkaukset',
    'breach' => 'Tietoturvaloukkaus',
    'third_parties' => 'Kolmannet osapuolet',
    'third_party' => 'Kolmas osapuoli',
    'measures' => 'Toimenpiteet',
    'reporting' => 'Raportointi',
    'total' => 'Yhteensä',
    'active' => 'Aktiivinen',
    'high_risk' => 'Korkea riski',
    'dpia_required' => 'DPIA vaaditaan',
    'dpia_completed' => 'DPIA valmis',
    'new' => 'Uusi',
    'export_json' => 'Vie JSON',
    'search' => 'Hae...',
    'search_company' => 'Hae yritystä...',
    'filter' => 'Suodata',
    'clear' => 'Tyhjennä',
    'risk' => 'Riski',
    'risk_level' => 'Riskitaso',
    'status' => 'Tila',
    'retention_period' => 'Säilytysaika',
    'actions' => 'Toiminnot',
    'view' => 'Näytä',
    'edit' => 'Muokkaa',
    'delete' => 'Poista',
    'print' => 'Tulosta',
    'confirm_delete' => 'Oletko varma, että haluat poistaa tämän tietueen? Tätä ei voi peruuttaa.',
    'processing_activity' => 'Käsittelytoiminta',
    'purpose' => 'Tarkoitus',
    'data_subjects' => 'Rekisteröidyt',
    'personal_data' => 'Henkilötiedot',
    'recipients' => 'Vastaanottajat',
    'legal_basis' => 'Oikeusperuste',
    'legitimate_interest' => 'Oikeutettu etu',
    'department' => 'Osasto',
    'international_transfer' => 'Kansainvälinen siirto',
    'to_country' => 'Maihin',
    'we_are_processor' => 'Olemme henkilötietojen käsittelijä',
    'processing_agreement_third_party' => 'Henkilötietojen käsittelysopimus kolmannen osapuolen kanssa',
    'technical_measures' => 'Tekniset toimenpiteet',
    'organizational_measures' => 'Organisatoriset toimenpiteet',
    'safeguards' => 'Suojatoimet',
    'review_date' => 'Tarkastuspäivä',
    'controller' => 'Rekisterinpitäjä',
    'joint_controller' => 'Yhteinen rekisterinpitäjä',
    'dpo' => 'Tietosuojavastaava',
    'representative' => 'Edustaja',
    'name' => 'Nimi',
    'contact' => 'Yhteystiedot',
    'title' => 'Otsikko',
    'description' => 'Kuvaus',
    'risk_origin' => 'Riskin alkuperä',
    'affected_subjects' => 'Vaikutetut rekisteröidyt',
    'management_approval' => 'Johdon hyväksyntä',
    'approved_by' => 'Hyväksynyt',
    'approval_date' => 'Hyväksymispäivä',
    'consultation_conducted' => 'Konsultointi suoritettu',
    'consultation_details' => 'Konsultoinnin tiedot',
    'recommendations' => 'Suositukset',
    'notes' => 'Muistiinpanot',
    'necessity_test' => 'Tarpeellisuustesti',
    'proportionality_test' => 'Suhteellisuustesti',
    'mitigation_measures' => 'Lieventävät toimenpiteet',
    'residual_risk' => 'Jäännösriski',
    'breach_date' => 'Loukkauksen päivämäärä',
    'discovery_date' => 'Havaitsemispäivämäärä',
    'breach_type' => 'Loukkauksen tyyppi',
    'causes' => 'Syy',
    'measures_taken' => 'Toteutetut toimenpiteet',
    'notified_authority' => 'Ilmoitettu viranomaiselle',
    'notification_date' => 'Ilmoituspäivämäärä',
    'notified_affected' => 'Ilmoitettu vaikutetuille',
    'company_name' => 'Yrityksen nimi',
    'contact_person' => 'Yhteyshenkilö',
    'email' => 'Sähköposti',
    'phone' => 'Puhelin',
    'address' => 'Osoite',
    'service_provided' => 'Tarjottu palvelu',
    'agreement_signed' => 'Sopimus allekirjoitettu',
    'agreement_date' => 'Sopimuspäivämäärä',
    'expiry_date' => 'Voimassaolon päättymispäivä',
    'compliance_status' => 'Vaatimustenmukaisuuden tila',
    'save' => 'Tallenna',
    'cancel' => 'Peruuta',
    'add' => 'Lisää',
    'close' => 'Sulje',
    'language' => 'Kieli',
    'full_report' => 'Koko raportti',
    'backup' => 'Varmuuskopio',
    'zip_backup' => 'ZIP-varmuuskopio',
    'statistics' => 'Tilastot',
    'no_records' => 'Tietueita ei löytynyt',
    'showing' => 'Näytetään',
    'of' => '/',
    'yes' => 'Kyllä',
    'no' => 'Ei',
    'unknown' => 'Tuntematon',
    'not_required' => 'Ei vaadita',
    'in_progress' => 'Käynnissä',
    'completed' => 'Valmis',
    'approved' => 'Hyväksytty',
    'draft' => 'Luonnos',
    'open' => 'Avoin',
    'investigating' => 'Tutkitaan',
    'contained' => 'Hallinnassa',
    'resolved' => 'Ratkaistu',
    'closed' => 'Suljettu',
    'compliant' => 'Vaatimustenmukainen',
    'non_compliant' => 'Ei vaatimustenmukainen',
    'review_needed' => 'Tarkistus tarvitaan',
    'low' => 'Matala',
    'medium' => 'Keskitaso',
    'high' => 'Korkea',
    'confidentiality' => 'Luottamuksellisuus',
    'integrity' => 'Eheys',
    'availability' => 'Käytettävyys',
    'mixed' => 'Sekoitettu',
    'contract' => 'Sopimus',
    'consent' => 'Suostumus',
    'legal_obligation' => 'Lakisääteinen velvoite',
    'legitimate_interests' => 'Oikeutetut edut',
    'vital_interests' => 'Elintärkeät edut',
    'public_task' => 'Julkinen tehtävä',
    'technical' => 'Tekninen',
    'organizational' => 'Organisatorinen',
    'human_error' => 'Inhimillinen virhe',
    'external' => 'Ulkoinen',
    'systematic_monitoring' => 'Systemaattinen seuranta',
    'sensitive_data' => 'Arkaluonteiset tiedot',
    'other' => 'Muu',
    'administration' => 'Hallinto',
    'hr' => 'HR',
    'finance' => 'Talous',
    'marketing' => 'Markkinointi',
    'it' => 'IT',
    'operations' => 'Toiminta',
    'pending' => 'Odottaa',
    'rejected' => 'Hylätty',
    'planned' => 'Suunniteltu',
    'donations' => 'Lahjoitukset',
    'create_dpia' => 'Luo DPIA',
    'create_dpia_from_gdpr' => 'Luo DPIA GDPR:stä',
    'click_create_dpia_for_gdpr' => 'Napsauta "Luo DPIA" GDPR-tietueelle, joka vaatii DPIA:n:',
    'new_gdpr_record' => 'Uusi GDPR-tietue',
    'edit_gdpr_record' => 'Muokkaa GDPR-tietuetta',
    'new_dpia' => 'Uusi DPIA',
    'edit_dpia' => 'Muokkaa DPIA:ta',
    'new_breach' => 'Uusi tietoturvaloukkaus',
    'edit_breach' => 'Muokkaa tietoturvaloukkausta',
    'new_third_party' => 'Uusi kolmas osapuoli',
    'edit_third_party' => 'Muokkaa kolmatta osapuolta',
    'record' => 'Tietue',
    'page' => 'Sivu',
    'generated' => 'Luotu',
    'successfully_added' => 'lisättiin onnistuneesti',
    'successfully_updated' => 'päivitettiin onnistuneesti',
    'unsaved_changes_confirm' => 'Tallentamattomia muutoksia on. Oletko varma, että haluat peruuttaa?',
    'select_or_type_below' => 'Valitse tai kirjoita alle',
    'or_type_custom_retention_period' => 'Tai kirjoita mukautettu säilytysaika',
    'or_type_custom_safeguards' => 'Tai kirjoita mukautetut suojatoimet (pilkuilla erotettuna)',
    'or_type_custom_measures' => 'Tai kirjoita mukautetut toimenpiteet (pilkuilla erotettuna)',
    'hold_ctrl_to_select_multiple' => 'Pidä Ctrl (Windows) tai Cmd (Mac) painettuna valitaksesi useita',
    'custom_mitigation_measures' => 'Mukautetut lieventävät toimenpiteet (pilkuilla erotettuna)',
    'custom_measures_taken' => 'Mukautetut toteutetut toimenpiteet (pilkuilla erotettuna)',
    'custom_measures_placeholder' => 'Esim. Mukautettu toimenpide 1, Mukautettu toimenpide 2',
    'gdpr_record_id' => 'GDPR-tietueen ID',
    'gdpr_record' => 'GDPR-tietue',
    'dpia_for_gdpr' => 'DPIA GDPR:lle',
    'dpia_exists_for_gdpr' => 'DPIA on jo olemassa GDPR:lle',
    'for_gdpr_record' => 'GDPR-tietueelle',
    'only_one_dpia_allowed' => 'Vain yksi DPIA on sallittu GDPR-tietuetta kohti.',
    'risk_distribution' => 'Riskijakauma',
    'gdpr_compliance_overview' => 'GDPR-vaatimustenmukaisuuden yleiskatsaus',
    'inactive_draft' => 'Epäaktiivinen / Luonnos',
    'collected_from_records' => 'Kerätty tietueista',
    'measure' => 'Toimenpide',
    'source' => 'Lähde',
    'configuration' => 'Asetukset',
    'no_technical_measures' => 'Teknisiä toimenpiteitä ei löytynyt',
    'no_organizational_measures' => 'Organisatorisia toimenpiteitä ei löytynyt',
    'total_gdpr_records' => 'GDPR-tietueita yhteensä',
    'dpia_in_progress' => 'DPIA käynnissä',
    'total_breaches' => 'Tietoturvaloukkauksia yhteensä',
    'open_breaches' => 'Avoimet tietoturvaloukkaukset',
    'total_third_parties' => 'Kolmannet osapuolet yhteensä',
    'compliant_third_parties' => 'Vaatimustenmukaiset kolmannet osapuolet',
    'dpia_coverage' => 'DPIA-kattavuus',
    'gdpr_with_dpia_required' => 'GDPR, jossa DPIA vaaditaan',
    'dpia_completion_rate' => 'DPIA:n valmistumisaste',
    'category' => 'Kategoria',
    'overview' => 'Yleiskatsaus',
    'per_category' => 'Kategoriaittain',
    'total_risk' => 'Kokonaisriski',
    'completion_rate' => 'Valmistumisaste',
    'record_type' => 'Tietuetyyppi',
    'print_report_title' => 'Vaatimustenmukaisuusraportti',
    'generated_on' => 'Luotu',
    'or_type_custom_department' => 'Tai kirjoita oma osasto',
    'or_type_custom_name' => 'Tai kirjoita nimi',
    'or_type_custom_risk_origin' => 'Tai kirjoita oma riskin alkuperä',
    'or_type_custom_status' => 'Tai kirjoita oma tila',
    'or_type_custom_approval' => 'Tai kirjoita oma hyväksyntätila',
    'or_type_custom_consultation' => 'Tai kirjoita oma arvo',
    'or_type_custom_compliance_status' => 'Tai kirjoita oma vaatimustenmukaisuustila',
    'or_type_custom_breach_type' => 'Tai kirjoita oma tietoturvaloukkauksen tyyppi',
    'logout' => 'Kirjaudu ulos',
    'logout_confirm' => 'Haluatko kirjautua ulos tästä istunnosta?',
    'value' => 'Arvo',
    'edit_measure' => 'Muokkaa toimenpidettä',
    'current_measure' => 'Nykyinen toimenpide',
    'new_measure_name' => 'Uusi toimenpiteen nimi',
    'measure_renamed_success' => 'Toimenpide nimettiin onnistuneesti uudelleen kaikkialla, missä sitä käytetään.',
    'measure_rename_warning' => 'Tämä nimeää toimenpiteen uudelleen jokaisessa GDPR-, DPIA- ja tietoturvaloukkaustietueessa, jossa sitä käytetään.',
    'measure_deleted_success' => 'Toimenpide poistettiin onnistuneesti kaikkialta, missä sitä käytettiin.',
    'confirm_delete_measure' => 'Haluatko varmasti poistaa tämän toimenpiteen? Se poistetaan jokaisesta GDPR-, DPIA- ja tietoturvaloukkaustietueesta, jossa sitä käytetään. Tätä ei voi peruuttaa.',
    'responsible' => 'Vastuuhenkilö',
    'responsible_placeholder' => 'Kuka on vastuussa tästä toimenpiteestä?',
    'unassigned' => 'Ei määritetty',
    'value_renamed_success' => 'Arvo nimettiin onnistuneesti uudelleen kaikkialla, missä sitä käytetään.',
    'value_deleted_success' => 'Arvo poistettiin onnistuneesti kaikkialta, missä sitä käytettiin.',
    'edit_value' => 'Muokkaa arvoa',
    'delete_value' => 'Poista arvo',
    'current_value' => 'Nykyinen arvo',
    'new_value' => 'Uusi arvo',
    'value_rename_warning' => 'Uudelleennimeäminen päivittää tämän arvon kaikkialla, missä sitä tällä hetkellä käytetään.',
    'value_delete_warning' => 'Poistaminen tyhjentää tämän arvon kaikista tietueista, joissa sitä tällä hetkellä käytetään. Tätä ei voi peruuttaa.',
    'confirm_delete_value' => 'Poistetaanko tämä arvo kaikkialta, missä sitä käytetään? Tätä ei voi peruuttaa.',
    'used_in' => 'Käytössä kohteessa',
    'not_currently_used' => 'Ei tällä hetkellä käytössä',
    'no_values' => 'Arvoja ei löytynyt',
    'not_started' => 'Ei aloitettu',
    'safeguard_scc' => 'Vakiosopimuslausekkeet (SCC)',
    'safeguard_bcr' => 'Sitovat yrityssäännöt (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (ei enää voimassa)',
    'safeguard_adequacy_decision' => 'Euroopan komission tietosuojan riittävyyttä koskeva päätös',
    'safeguard_consent' => 'Rekisteröidyn erityinen suostumus',
    'safeguard_model_contracts' => 'Mallisopimukset',
    'safeguard_certification' => 'Sertifiointimekanismit',
    'safeguard_codes_of_conduct' => 'Käytännesäännöt',
    'safeguard_dpia' => 'Tietosuojaa koskeva vaikutustenarviointi (DPIA)',
    'safeguard_tia' => 'Kansainvälisen tiedonsiirron vaikutustenarviointi (TIA)',
    'inactive' => 'Ei aktiivinen',
];

// ==================== INDONESIAN ====================
$translations['id'] = [
    'app_title' => 'Register GDPR',
    'company_subtitle' => 'Privasi & Kepatuhan',
    'dashboard' => 'Dasbor',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Pelanggaran Data',
    'breach' => 'Pelanggaran Data',
    'third_parties' => 'Pihak Ketiga',
    'third_party' => 'Pihak Ketiga',
    'measures' => 'Tindakan',
    'reporting' => 'Pelaporan',
    'total' => 'Total',
    'active' => 'Aktif',
    'high_risk' => 'Risiko Tinggi',
    'dpia_required' => 'DPIA Diperlukan',
    'dpia_completed' => 'DPIA Selesai',
    'new' => 'Baru',
    'export_json' => 'Ekspor JSON',
    'search' => 'Cari...',
    'search_company' => 'Cari perusahaan...',
    'filter' => 'Filter',
    'clear' => 'Bersihkan',
    'risk' => 'Risiko',
    'risk_level' => 'Tingkat Risiko',
    'status' => 'Status',
    'retention_period' => 'Periode Retensi',
    'actions' => 'Tindakan',
    'view' => 'Lihat',
    'edit' => 'Edit',
    'delete' => 'Hapus',
    'print' => 'Cetak',
    'confirm_delete' => 'Apakah Anda yakin ingin menghapus catatan ini? Tindakan ini tidak dapat dibatalkan.',
    'processing_activity' => 'Aktivitas Pemrosesan',
    'purpose' => 'Tujuan',
    'data_subjects' => 'Subjek Data',
    'personal_data' => 'Data Pribadi',
    'recipients' => 'Penerima',
    'legal_basis' => 'Dasar Hukum',
    'legitimate_interest' => 'Kepentingan Sah',
    'department' => 'Departemen',
    'or_type_custom_department' => 'Atau ketik departemen khusus',
    'or_type_custom_name' => 'Atau ketik nama',
    'or_type_custom_risk_origin' => 'Atau ketik asal risiko khusus',
    'or_type_custom_status' => 'Atau ketik status khusus',
    'or_type_custom_approval' => 'Atau ketik status persetujuan khusus',
    'or_type_custom_consultation' => 'Atau ketik nilai khusus',
    'or_type_custom_compliance_status' => 'Atau ketik status kepatuhan khusus',
    'or_type_custom_breach_type' => 'Atau ketik jenis pelanggaran khusus',
    'international_transfer' => 'Transfer Internasional',
    'to_country' => 'Ke Negara',
    'we_are_processor' => 'Kami adalah Prosesor',
    'processing_agreement_third_party' => 'Perjanjian Pemrosesan dengan Pihak Ketiga',
    'technical_measures' => 'Tindakan Teknis',
    'organizational_measures' => 'Tindakan Organisasi',
    'safeguards' => 'Perlindungan',
    'review_date' => 'Tanggal Peninjauan',
    'controller' => 'Pengendali',
    'joint_controller' => 'Pengendali Bersama',
    'dpo' => 'DPO',
    'representative' => 'Perwakilan',
    'name' => 'Nama',
    'contact' => 'Kontak',
    'title' => 'Judul',
    'description' => 'Deskripsi',
    'risk_origin' => 'Asal Risiko',
    'affected_subjects' => 'Subjek Terdampak',
    'management_approval' => 'Persetujuan Manajemen',
    'approved_by' => 'Disetujui Oleh',
    'approval_date' => 'Tanggal Persetujuan',
    'consultation_conducted' => 'Konsultasi Dilakukan',
    'consultation_details' => 'Detail Konsultasi',
    'recommendations' => 'Rekomendasi',
    'notes' => 'Catatan',
    'necessity_test' => 'Uji Kebutuhan',
    'proportionality_test' => 'Uji Proporsionalitas',
    'mitigation_measures' => 'Tindakan Mitigasi',
    'residual_risk' => 'Risiko Residual',
    'breach_date' => 'Tanggal Pelanggaran',
    'discovery_date' => 'Tanggal Penemuan',
    'breach_type' => 'Jenis Pelanggaran',
    'causes' => 'Penyebab',
    'measures_taken' => 'Tindakan yang Diambil',
    'notified_authority' => 'Otoritas Diberitahu',
    'notification_date' => 'Tanggal Pemberitahuan',
    'notified_affected' => 'Pihak Terdampak Diberitahu',
    'company_name' => 'Nama Perusahaan',
    'contact_person' => 'Orang Kontak',
    'email' => 'Email',
    'phone' => 'Telepon',
    'address' => 'Alamat',
    'service_provided' => 'Layanan yang Diberikan',
    'agreement_signed' => 'Perjanjian Ditandatangani',
    'agreement_date' => 'Tanggal Perjanjian',
    'expiry_date' => 'Tanggal Kedaluwarsa',
    'compliance_status' => 'Status Kepatuhan',
    'save' => 'Simpan',
    'cancel' => 'Batal',
    'add' => 'Tambah',
    'close' => 'Tutup',
    'language' => 'Bahasa',
    'logout' => 'Keluar',
    'logout_confirm' => 'Keluar dari sesi ini?',
    'full_report' => 'Laporan Lengkap',
    'backup' => 'Cadangan',
    'zip_backup' => 'Cadangan ZIP',
    'statistics' => 'Statistik',
    'no_records' => 'Tidak ada catatan ditemukan',
    'showing' => 'Menampilkan',
    'of' => 'dari',
    'yes' => 'Ya',
    'no' => 'Tidak',
    'unknown' => 'Tidak Diketahui',
    'not_required' => 'Tidak Diperlukan',
    'in_progress' => 'Sedang Berlangsung',
    'completed' => 'Selesai',
    'approved' => 'Disetujui',
    'draft' => 'Draf',
    'open' => 'Terbuka',
    'investigating' => 'Sedang Diselidiki',
    'contained' => 'Terkendali',
    'resolved' => 'Terselesaikan',
    'closed' => 'Ditutup',
    'compliant' => 'Patuh',
    'non_compliant' => 'Tidak Patuh',
    'review_needed' => 'Perlu Ditinjau',
    'low' => 'Rendah',
    'medium' => 'Sedang',
    'high' => 'Tinggi',
    'confidentiality' => 'Kerahasiaan',
    'integrity' => 'Integritas',
    'availability' => 'Ketersediaan',
    'mixed' => 'Campuran',
    'contract' => 'Kontrak',
    'consent' => 'Persetujuan',
    'legal_obligation' => 'Kewajiban Hukum',
    'legitimate_interests' => 'Kepentingan Sah',
    'vital_interests' => 'Kepentingan Vital',
    'public_task' => 'Tugas Publik',
    'technical' => 'Teknis',
    'organizational' => 'Organisasi',
    'human_error' => 'Kesalahan Manusia',
    'external' => 'Eksternal',
    'systematic_monitoring' => 'Pemantauan Sistematis',
    'sensitive_data' => 'Data Sensitif',
    'other' => 'Lainnya',
    'administration' => 'Administrasi',
    'hr' => 'SDM',
    'finance' => 'Keuangan',
    'marketing' => 'Pemasaran',
    'it' => 'TI',
    'operations' => 'Operasi',
    'pending' => 'Tertunda',
    'rejected' => 'Ditolak',
    'planned' => 'Direncanakan',
    'donations' => 'Donasi',
    'create_dpia' => 'Buat DPIA',
    'create_dpia_from_gdpr' => 'Buat DPIA dari GDPR',
    'click_create_dpia_for_gdpr' => 'Klik "Buat DPIA" untuk catatan GDPR yang memerlukan DPIA:',
    'new_gdpr_record' => 'Catatan GDPR Baru',
    'edit_gdpr_record' => 'Edit Catatan GDPR',
    'new_dpia' => 'DPIA Baru',
    'edit_dpia' => 'Edit DPIA',
    'new_breach' => 'Pelanggaran Data Baru',
    'edit_breach' => 'Edit Pelanggaran Data',
    'new_third_party' => 'Pihak Ketiga Baru',
    'edit_third_party' => 'Edit Pihak Ketiga',
    'record' => 'Catatan',
    'page' => 'Halaman',
    'generated' => 'Dibuat',
    'successfully_added' => 'berhasil ditambahkan',
    'successfully_updated' => 'berhasil diperbarui',
    'unsaved_changes_confirm' => 'Ada perubahan yang belum disimpan. Apakah Anda yakin ingin membatalkan?',
    'select_or_type_below' => 'Pilih atau ketik di bawah',
    'or_type_custom_retention_period' => 'Atau ketik periode retensi khusus',
    'or_type_custom_safeguards' => 'Atau ketik perlindungan khusus (dipisahkan titik koma)',
    'or_type_custom_measures' => 'Atau ketik tindakan khusus (dipisahkan titik koma)',
    'hold_ctrl_to_select_multiple' => 'Tahan Ctrl (Windows) atau Cmd (Mac) untuk memilih beberapa',
    'custom_mitigation_measures' => 'Tindakan mitigasi khusus (dipisahkan titik koma)',
    'custom_measures_taken' => 'Tindakan khusus yang diambil (dipisahkan titik koma)',
    'custom_measures_placeholder' => 'mis. Tindakan khusus 1; Tindakan khusus 2',
    'gdpr_record_id' => 'ID Catatan GDPR',
    'gdpr_record' => 'Catatan GDPR',
    'dpia_for_gdpr' => 'DPIA untuk GDPR',
    'dpia_exists_for_gdpr' => 'DPIA sudah ada untuk GDPR',
    'for_gdpr_record' => 'untuk catatan GDPR',
    'only_one_dpia_allowed' => 'Hanya satu DPIA yang diizinkan per catatan GDPR.',
    'risk_distribution' => 'Distribusi Risiko',
    'gdpr_compliance_overview' => 'Ikhtisar Kepatuhan GDPR',
    'inactive_draft' => 'Tidak Aktif / Draf',
    'collected_from_records' => 'Dikumpulkan dari catatan',
    'measure' => 'Tindakan',
    'value' => 'Nilai',
    'source' => 'Sumber',
    'configuration' => 'Konfigurasi',
    'no_technical_measures' => 'Tidak ada tindakan teknis ditemukan',
    'no_organizational_measures' => 'Tidak ada tindakan organisasi ditemukan',
    'edit_measure' => 'Edit Tindakan',
    'current_measure' => 'Tindakan Saat Ini',
    'new_measure_name' => 'Nama Tindakan Baru',
    'measure_renamed_success' => 'Tindakan berhasil diganti nama di semua tempat penggunaannya.',
    'measure_rename_warning' => 'Ini akan mengganti nama tindakan di setiap catatan GDPR, DPIA, dan Pelanggaran Data tempat tindakan tersebut digunakan.',
    'measure_deleted_success' => 'Tindakan berhasil dihapus dari semua tempat penggunaannya.',
    'confirm_delete_measure' => 'Apakah Anda yakin ingin menghapus tindakan ini? Tindakan ini akan dihapus dari setiap catatan GDPR, DPIA, dan Pelanggaran Data tempat tindakan tersebut digunakan. Tindakan ini tidak dapat dibatalkan.',
    'responsible' => 'Penanggung Jawab',
    'responsible_placeholder' => 'Siapa yang bertanggung jawab atas tindakan ini?',
    'unassigned' => 'Belum Ditugaskan',
    'value_renamed_success' => 'Nilai berhasil diganti nama di semua tempat penggunaannya.',
    'value_deleted_success' => 'Nilai berhasil dihapus dari semua tempat penggunaannya.',
    'edit_value' => 'Edit nilai',
    'delete_value' => 'Hapus nilai',
    'current_value' => 'Nilai saat ini',
    'new_value' => 'Nilai baru',
    'value_rename_warning' => 'Mengganti nama akan memperbarui nilai ini di semua tempat yang saat ini menggunakannya.',
    'value_delete_warning' => 'Menghapus akan menghilangkan nilai ini dari setiap catatan yang saat ini menggunakannya. Tindakan ini tidak dapat dibatalkan.',
    'confirm_delete_value' => 'Hapus nilai ini di semua tempat penggunaannya? Tindakan ini tidak dapat dibatalkan.',
    'used_in' => 'Digunakan di',
    'not_currently_used' => 'Saat ini tidak digunakan',
    'no_values' => 'Tidak ada nilai ditemukan',
    'total_gdpr_records' => 'Total catatan GDPR',
    'dpia_in_progress' => 'DPIA sedang berlangsung',
    'total_breaches' => 'Total pelanggaran',
    'open_breaches' => 'Pelanggaran terbuka',
    'total_third_parties' => 'Total pihak ketiga',
    'compliant_third_parties' => 'Pihak ketiga yang patuh',
    'dpia_coverage' => 'Cakupan DPIA',
    'gdpr_with_dpia_required' => 'GDPR yang memerlukan DPIA',
    'dpia_completion_rate' => 'Tingkat penyelesaian DPIA',
    'category' => 'Kategori',
    'overview' => 'Ikhtisar',
    'per_category' => 'Per Kategori',
    'total_risk' => 'Total Risiko',
    'completion_rate' => 'Tingkat Penyelesaian',
    'record_type' => 'Jenis Catatan',
    'print_report_title' => 'Laporan Kepatuhan',
    'generated_on' => 'Dibuat pada',
    'not_started' => 'Belum dimulai',
    'safeguard_scc' => 'Klausul Kontrak Standar (SCC)',
    'safeguard_bcr' => 'Aturan Perusahaan yang Mengikat (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (tidak lagi berlaku)',
    'safeguard_adequacy_decision' => 'Keputusan Kecukupan Komisi Eropa',
    'safeguard_consent' => 'Persetujuan khusus dari subjek data',
    'safeguard_model_contracts' => 'Kontrak model',
    'safeguard_certification' => 'Mekanisme sertifikasi',
    'safeguard_codes_of_conduct' => 'Kode etik',
    'safeguard_dpia' => 'Penilaian Dampak Perlindungan Data (DPIA)',
    'safeguard_tia' => 'Penilaian Dampak Transfer Data Internasional (TIA)',
    'inactive' => 'Tidak aktif',
];

// ==================== VIETNAMESE ====================
$translations['vi'] = [
    'app_title' => 'Sổ đăng ký GDPR',
    'company_subtitle' => 'Quyền riêng tư & Tuân thủ',
    'dashboard' => 'Bảng điều khiển',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Vi phạm dữ liệu',
    'breach' => 'Vi phạm dữ liệu',
    'third_parties' => 'Bên thứ ba',
    'third_party' => 'Bên thứ ba',
    'measures' => 'Biện pháp',
    'reporting' => 'Báo cáo',
    'total' => 'Tổng',
    'active' => 'Đang hoạt động',
    'high_risk' => 'Rủi ro cao',
    'dpia_required' => 'Yêu cầu DPIA',
    'dpia_completed' => 'DPIA đã hoàn thành',
    'new' => 'Mới',
    'export_json' => 'Xuất JSON',
    'search' => 'Tìm kiếm...',
    'search_company' => 'Tìm công ty...',
    'filter' => 'Bộ lọc',
    'clear' => 'Xóa',
    'risk' => 'Rủi ro',
    'risk_level' => 'Mức độ rủi ro',
    'status' => 'Trạng thái',
    'retention_period' => 'Thời gian lưu trữ',
    'actions' => 'Hành động',
    'view' => 'Xem',
    'edit' => 'Sửa',
    'delete' => 'Xóa',
    'print' => 'In',
    'confirm_delete' => 'Bạn có chắc chắn muốn xóa bản ghi này không? Hành động này không thể hoàn tác.',
    'processing_activity' => 'Hoạt động xử lý',
    'purpose' => 'Mục đích',
    'data_subjects' => 'Chủ thể dữ liệu',
    'personal_data' => 'Dữ liệu cá nhân',
    'recipients' => 'Người nhận',
    'legal_basis' => 'Cơ sở pháp lý',
    'legitimate_interest' => 'Lợi ích hợp pháp',
    'department' => 'Phòng ban',
    'or_type_custom_department' => 'Hoặc nhập phòng ban tùy chỉnh',
    'or_type_custom_name' => 'Hoặc nhập tên',
    'or_type_custom_risk_origin' => 'Hoặc nhập nguồn gốc rủi ro tùy chỉnh',
    'or_type_custom_status' => 'Hoặc nhập trạng thái tùy chỉnh',
    'or_type_custom_approval' => 'Hoặc nhập trạng thái phê duyệt tùy chỉnh',
    'or_type_custom_consultation' => 'Hoặc nhập giá trị tùy chỉnh',
    'or_type_custom_compliance_status' => 'Hoặc nhập trạng thái tuân thủ tùy chỉnh',
    'or_type_custom_breach_type' => 'Hoặc nhập loại vi phạm tùy chỉnh',
    'international_transfer' => 'Chuyển giao quốc tế',
    'to_country' => 'Đến quốc gia',
    'we_are_processor' => 'Chúng tôi là bên xử lý',
    'processing_agreement_third_party' => 'Thỏa thuận xử lý với bên thứ ba',
    'technical_measures' => 'Biện pháp kỹ thuật',
    'organizational_measures' => 'Biện pháp tổ chức',
    'safeguards' => 'Biện pháp bảo vệ',
    'review_date' => 'Ngày xem xét',
    'controller' => 'Bên kiểm soát',
    'joint_controller' => 'Bên kiểm soát chung',
    'dpo' => 'DPO',
    'representative' => 'Đại diện',
    'name' => 'Tên',
    'contact' => 'Liên hệ',
    'title' => 'Tiêu đề',
    'description' => 'Mô tả',
    'risk_origin' => 'Nguồn gốc rủi ro',
    'affected_subjects' => 'Chủ thể bị ảnh hưởng',
    'management_approval' => 'Phê duyệt của ban quản lý',
    'approved_by' => 'Được phê duyệt bởi',
    'approval_date' => 'Ngày phê duyệt',
    'consultation_conducted' => 'Đã tham vấn',
    'consultation_details' => 'Chi tiết tham vấn',
    'recommendations' => 'Khuyến nghị',
    'notes' => 'Ghi chú',
    'necessity_test' => 'Kiểm tra tính cần thiết',
    'proportionality_test' => 'Kiểm tra tính tương xứng',
    'mitigation_measures' => 'Biện pháp giảm thiểu',
    'residual_risk' => 'Rủi ro còn lại',
    'breach_date' => 'Ngày xảy ra vi phạm',
    'discovery_date' => 'Ngày phát hiện',
    'breach_type' => 'Loại vi phạm',
    'causes' => 'Nguyên nhân',
    'measures_taken' => 'Biện pháp đã thực hiện',
    'notified_authority' => 'Đã thông báo cơ quan chức năng',
    'notification_date' => 'Ngày thông báo',
    'notified_affected' => 'Đã thông báo cho người bị ảnh hưởng',
    'company_name' => 'Tên công ty',
    'contact_person' => 'Người liên hệ',
    'email' => 'Email',
    'phone' => 'Điện thoại',
    'address' => 'Địa chỉ',
    'service_provided' => 'Dịch vụ cung cấp',
    'agreement_signed' => 'Đã ký thỏa thuận',
    'agreement_date' => 'Ngày thỏa thuận',
    'expiry_date' => 'Ngày hết hạn',
    'compliance_status' => 'Trạng thái tuân thủ',
    'save' => 'Lưu',
    'cancel' => 'Hủy',
    'add' => 'Thêm',
    'close' => 'Đóng',
    'language' => 'Ngôn ngữ',
    'logout' => 'Đăng xuất',
    'logout_confirm' => 'Đăng xuất khỏi phiên này?',
    'full_report' => 'Báo cáo đầy đủ',
    'backup' => 'Sao lưu',
    'zip_backup' => 'Sao lưu ZIP',
    'statistics' => 'Thống kê',
    'no_records' => 'Không tìm thấy bản ghi nào',
    'showing' => 'Hiển thị',
    'of' => 'trong số',
    'yes' => 'Có',
    'no' => 'Không',
    'unknown' => 'Không xác định',
    'not_required' => 'Không yêu cầu',
    'in_progress' => 'Đang tiến hành',
    'completed' => 'Đã hoàn thành',
    'approved' => 'Đã phê duyệt',
    'draft' => 'Bản nháp',
    'open' => 'Đang mở',
    'investigating' => 'Đang điều tra',
    'contained' => 'Đã kiểm soát',
    'resolved' => 'Đã giải quyết',
    'closed' => 'Đã đóng',
    'compliant' => 'Tuân thủ',
    'non_compliant' => 'Không tuân thủ',
    'review_needed' => 'Cần xem xét',
    'low' => 'Thấp',
    'medium' => 'Trung bình',
    'high' => 'Cao',
    'confidentiality' => 'Bảo mật',
    'integrity' => 'Toàn vẹn',
    'availability' => 'Tính sẵn sàng',
    'mixed' => 'Hỗn hợp',
    'contract' => 'Hợp đồng',
    'consent' => 'Sự đồng ý',
    'legal_obligation' => 'Nghĩa vụ pháp lý',
    'legitimate_interests' => 'Lợi ích hợp pháp',
    'vital_interests' => 'Lợi ích thiết yếu',
    'public_task' => 'Nhiệm vụ công',
    'technical' => 'Kỹ thuật',
    'organizational' => 'Tổ chức',
    'human_error' => 'Lỗi con người',
    'external' => 'Bên ngoài',
    'systematic_monitoring' => 'Giám sát có hệ thống',
    'sensitive_data' => 'Dữ liệu nhạy cảm',
    'other' => 'Khác',
    'administration' => 'Hành chính',
    'hr' => 'Nhân sự',
    'finance' => 'Tài chính',
    'marketing' => 'Marketing',
    'it' => 'CNTT',
    'operations' => 'Vận hành',
    'pending' => 'Đang chờ',
    'rejected' => 'Bị từ chối',
    'planned' => 'Đã lên kế hoạch',
    'donations' => 'Quyên góp',
    'create_dpia' => 'Tạo DPIA',
    'create_dpia_from_gdpr' => 'Tạo DPIA từ GDPR',
    'click_create_dpia_for_gdpr' => 'Nhấp "Tạo DPIA" cho bản ghi GDPR yêu cầu DPIA:',
    'new_gdpr_record' => 'Bản ghi GDPR mới',
    'edit_gdpr_record' => 'Sửa bản ghi GDPR',
    'new_dpia' => 'DPIA mới',
    'edit_dpia' => 'Sửa DPIA',
    'new_breach' => 'Vi phạm dữ liệu mới',
    'edit_breach' => 'Sửa vi phạm dữ liệu',
    'new_third_party' => 'Bên thứ ba mới',
    'edit_third_party' => 'Sửa bên thứ ba',
    'record' => 'Bản ghi',
    'page' => 'Trang',
    'generated' => 'Đã tạo',
    'successfully_added' => 'đã thêm thành công',
    'successfully_updated' => 'đã cập nhật thành công',
    'unsaved_changes_confirm' => 'Có thay đổi chưa được lưu. Bạn có chắc chắn muốn hủy không?',
    'select_or_type_below' => 'Chọn hoặc nhập bên dưới',
    'or_type_custom_retention_period' => 'Hoặc nhập thời gian lưu trữ tùy chỉnh',
    'or_type_custom_safeguards' => 'Hoặc nhập biện pháp bảo vệ tùy chỉnh (phân tách bằng dấu chấm phẩy)',
    'or_type_custom_measures' => 'Hoặc nhập biện pháp tùy chỉnh (phân tách bằng dấu chấm phẩy)',
    'hold_ctrl_to_select_multiple' => 'Giữ Ctrl (Windows) hoặc Cmd (Mac) để chọn nhiều mục',
    'custom_mitigation_measures' => 'Biện pháp giảm thiểu tùy chỉnh (phân tách bằng dấu chấm phẩy)',
    'custom_measures_taken' => 'Biện pháp tùy chỉnh đã thực hiện (phân tách bằng dấu chấm phẩy)',
    'custom_measures_placeholder' => 'ví dụ: Biện pháp tùy chỉnh 1; Biện pháp tùy chỉnh 2',
    'gdpr_record_id' => 'ID bản ghi GDPR',
    'gdpr_record' => 'Bản ghi GDPR',
    'dpia_for_gdpr' => 'DPIA cho GDPR',
    'dpia_exists_for_gdpr' => 'Đã tồn tại DPIA cho GDPR',
    'for_gdpr_record' => 'cho bản ghi GDPR',
    'only_one_dpia_allowed' => 'Chỉ được phép một DPIA cho mỗi bản ghi GDPR.',
    'risk_distribution' => 'Phân bố rủi ro',
    'gdpr_compliance_overview' => 'Tổng quan tuân thủ GDPR',
    'inactive_draft' => 'Không hoạt động / Bản nháp',
    'collected_from_records' => 'Thu thập từ các bản ghi',
    'measure' => 'Biện pháp',
    'value' => 'Giá trị',
    'source' => 'Nguồn',
    'configuration' => 'Cấu hình',
    'no_technical_measures' => 'Không tìm thấy biện pháp kỹ thuật nào',
    'no_organizational_measures' => 'Không tìm thấy biện pháp tổ chức nào',
    'edit_measure' => 'Sửa biện pháp',
    'current_measure' => 'Biện pháp hiện tại',
    'new_measure_name' => 'Tên biện pháp mới',
    'measure_renamed_success' => 'Đã đổi tên biện pháp thành công ở mọi nơi được sử dụng.',
    'measure_rename_warning' => 'Thao tác này sẽ đổi tên biện pháp trong mọi bản ghi GDPR, DPIA và vi phạm dữ liệu có sử dụng biện pháp đó.',
    'measure_deleted_success' => 'Đã xóa biện pháp thành công ở mọi nơi từng được sử dụng.',
    'confirm_delete_measure' => 'Bạn có chắc chắn muốn xóa biện pháp này không? Biện pháp sẽ bị xóa khỏi mọi bản ghi GDPR, DPIA và vi phạm dữ liệu có sử dụng nó. Hành động này không thể hoàn tác.',
    'responsible' => 'Người chịu trách nhiệm',
    'responsible_placeholder' => 'Ai chịu trách nhiệm về biện pháp này?',
    'unassigned' => 'Chưa phân công',
    'value_renamed_success' => 'Đã đổi tên giá trị thành công ở mọi nơi được sử dụng.',
    'value_deleted_success' => 'Đã xóa giá trị thành công ở mọi nơi từng được sử dụng.',
    'edit_value' => 'Sửa giá trị',
    'delete_value' => 'Xóa giá trị',
    'current_value' => 'Giá trị hiện tại',
    'new_value' => 'Giá trị mới',
    'value_rename_warning' => 'Việc đổi tên sẽ cập nhật giá trị này ở mọi nơi hiện đang được sử dụng.',
    'value_delete_warning' => 'Việc xóa sẽ xóa giá trị này khỏi mọi bản ghi hiện đang sử dụng nó. Hành động này không thể hoàn tác.',
    'confirm_delete_value' => 'Xóa giá trị này ở mọi nơi được sử dụng? Hành động này không thể hoàn tác.',
    'used_in' => 'Được sử dụng trong',
    'not_currently_used' => 'Hiện không được sử dụng',
    'no_values' => 'Không tìm thấy giá trị nào',
    'total_gdpr_records' => 'Tổng số bản ghi GDPR',
    'dpia_in_progress' => 'DPIA đang tiến hành',
    'total_breaches' => 'Tổng số vi phạm',
    'open_breaches' => 'Vi phạm đang mở',
    'total_third_parties' => 'Tổng số bên thứ ba',
    'compliant_third_parties' => 'Bên thứ ba tuân thủ',
    'dpia_coverage' => 'Phạm vi DPIA',
    'gdpr_with_dpia_required' => 'GDPR yêu cầu DPIA',
    'dpia_completion_rate' => 'Tỷ lệ hoàn thành DPIA',
    'category' => 'Danh mục',
    'overview' => 'Tổng quan',
    'per_category' => 'Theo danh mục',
    'total_risk' => 'Tổng rủi ro',
    'completion_rate' => 'Tỷ lệ hoàn thành',
    'record_type' => 'Loại bản ghi',
    'print_report_title' => 'Báo cáo tuân thủ',
    'generated_on' => 'Được tạo vào',
    'not_started' => 'Chưa bắt đầu',
    'safeguard_scc' => 'Điều khoản hợp đồng tiêu chuẩn (SCC)',
    'safeguard_bcr' => 'Quy tắc doanh nghiệp ràng buộc (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (không còn hiệu lực)',
    'safeguard_adequacy_decision' => 'Quyết định về mức độ đầy đủ của Ủy ban Châu Âu',
    'safeguard_consent' => 'Sự đồng ý cụ thể của chủ thể dữ liệu',
    'safeguard_model_contracts' => 'Hợp đồng mẫu',
    'safeguard_certification' => 'Cơ chế chứng nhận',
    'safeguard_codes_of_conduct' => 'Quy tắc ứng xử',
    'safeguard_dpia' => 'Đánh giá tác động bảo vệ dữ liệu (DPIA)',
    'safeguard_tia' => 'Đánh giá tác động chuyển giao dữ liệu quốc tế (TIA)',
    'inactive' => 'Không hoạt động',
];

// ==================== THAI ====================
$translations['th'] = [
    'app_title' => 'ทะเบียน GDPR',
    'company_subtitle' => 'ความเป็นส่วนตัวและการปฏิบัติตามข้อกำหนด',
    'dashboard' => 'แดชบอร์ด',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'การละเมิดข้อมูล',
    'breach' => 'การละเมิดข้อมูล',
    'third_parties' => 'บุคคลที่สาม',
    'third_party' => 'บุคคลที่สาม',
    'measures' => 'มาตรการ',
    'reporting' => 'การรายงาน',
    'total' => 'ทั้งหมด',
    'active' => 'ใช้งานอยู่',
    'high_risk' => 'ความเสี่ยงสูง',
    'dpia_required' => 'ต้องทำ DPIA',
    'dpia_completed' => 'DPIA เสร็จสมบูรณ์',
    'new' => 'ใหม่',
    'export_json' => 'ส่งออก JSON',
    'search' => 'ค้นหา...',
    'search_company' => 'ค้นหาบริษัท...',
    'filter' => 'ตัวกรอง',
    'clear' => 'ล้าง',
    'risk' => 'ความเสี่ยง',
    'risk_level' => 'ระดับความเสี่ยง',
    'status' => 'สถานะ',
    'retention_period' => 'ระยะเวลาการเก็บรักษา',
    'actions' => 'การดำเนินการ',
    'view' => 'ดู',
    'edit' => 'แก้ไข',
    'delete' => 'ลบ',
    'print' => 'พิมพ์',
    'confirm_delete' => 'คุณแน่ใจหรือไม่ว่าต้องการลบบันทึกนี้? การกระทำนี้ไม่สามารถยกเลิกได้',
    'processing_activity' => 'กิจกรรมการประมวลผล',
    'purpose' => 'วัตถุประสงค์',
    'data_subjects' => 'เจ้าของข้อมูล',
    'personal_data' => 'ข้อมูลส่วนบุคคล',
    'recipients' => 'ผู้รับข้อมูล',
    'legal_basis' => 'ฐานทางกฎหมาย',
    'legitimate_interest' => 'ประโยชน์อันชอบด้วยกฎหมาย',
    'department' => 'แผนก',
    'or_type_custom_department' => 'หรือพิมพ์แผนกที่กำหนดเอง',
    'or_type_custom_name' => 'หรือพิมพ์ชื่อ',
    'or_type_custom_risk_origin' => 'หรือพิมพ์แหล่งที่มาความเสี่ยงที่กำหนดเอง',
    'or_type_custom_status' => 'หรือพิมพ์สถานะที่กำหนดเอง',
    'or_type_custom_approval' => 'หรือพิมพ์สถานะการอนุมัติที่กำหนดเอง',
    'or_type_custom_consultation' => 'หรือพิมพ์ค่าที่กำหนดเอง',
    'or_type_custom_compliance_status' => 'หรือพิมพ์สถานะการปฏิบัติตามที่กำหนดเอง',
    'or_type_custom_breach_type' => 'หรือพิมพ์ประเภทการละเมิดที่กำหนดเอง',
    'international_transfer' => 'การโอนข้อมูลระหว่างประเทศ',
    'to_country' => 'ไปยังประเทศ',
    'we_are_processor' => 'เราเป็นผู้ประมวลผล',
    'processing_agreement_third_party' => 'ข้อตกลงการประมวลผลกับบุคคลที่สาม',
    'technical_measures' => 'มาตรการทางเทคนิค',
    'organizational_measures' => 'มาตรการขององค์กร',
    'safeguards' => 'มาตรการป้องกัน',
    'review_date' => 'วันที่ทบทวน',
    'controller' => 'ผู้ควบคุมข้อมูล',
    'joint_controller' => 'ผู้ควบคุมข้อมูลร่วม',
    'dpo' => 'DPO',
    'representative' => 'ตัวแทน',
    'name' => 'ชื่อ',
    'contact' => 'ติดต่อ',
    'title' => 'ชื่อเรื่อง',
    'description' => 'คำอธิบาย',
    'risk_origin' => 'แหล่งที่มาความเสี่ยง',
    'affected_subjects' => 'เจ้าของข้อมูลที่ได้รับผลกระทบ',
    'management_approval' => 'การอนุมัติจากฝ่ายบริหาร',
    'approved_by' => 'อนุมัติโดย',
    'approval_date' => 'วันที่อนุมัติ',
    'consultation_conducted' => 'ดำเนินการปรึกษาแล้ว',
    'consultation_details' => 'รายละเอียดการปรึกษา',
    'recommendations' => 'ข้อเสนอแนะ',
    'notes' => 'บันทึกเพิ่มเติม',
    'necessity_test' => 'การทดสอบความจำเป็น',
    'proportionality_test' => 'การทดสอบความได้สัดส่วน',
    'mitigation_measures' => 'มาตรการบรรเทา',
    'residual_risk' => 'ความเสี่ยงคงเหลือ',
    'breach_date' => 'วันที่เกิดการละเมิด',
    'discovery_date' => 'วันที่ตรวจพบ',
    'breach_type' => 'ประเภทการละเมิด',
    'causes' => 'สาเหตุ',
    'measures_taken' => 'มาตรการที่ดำเนินการ',
    'notified_authority' => 'แจ้งหน่วยงานกำกับดูแลแล้ว',
    'notification_date' => 'วันที่แจ้งเตือน',
    'notified_affected' => 'แจ้งผู้ได้รับผลกระทบแล้ว',
    'company_name' => 'ชื่อบริษัท',
    'contact_person' => 'บุคคลที่ติดต่อ',
    'email' => 'อีเมล',
    'phone' => 'โทรศัพท์',
    'address' => 'ที่อยู่',
    'service_provided' => 'บริการที่ให้',
    'agreement_signed' => 'ลงนามข้อตกลงแล้ว',
    'agreement_date' => 'วันที่ทำข้อตกลง',
    'expiry_date' => 'วันหมดอายุ',
    'compliance_status' => 'สถานะการปฏิบัติตาม',
    'save' => 'บันทึก',
    'cancel' => 'ยกเลิก',
    'add' => 'เพิ่ม',
    'close' => 'ปิด',
    'language' => 'ภาษา',
    'logout' => 'ออกจากระบบ',
    'logout_confirm' => 'ออกจากเซสชันนี้หรือไม่?',
    'full_report' => 'รายงานฉบับเต็ม',
    'backup' => 'สำรองข้อมูล',
    'zip_backup' => 'สำรองข้อมูล ZIP',
    'statistics' => 'สถิติ',
    'no_records' => 'ไม่พบบันทึก',
    'showing' => 'กำลังแสดง',
    'of' => 'จาก',
    'yes' => 'ใช่',
    'no' => 'ไม่',
    'unknown' => 'ไม่ทราบ',
    'not_required' => 'ไม่จำเป็น',
    'in_progress' => 'กำลังดำเนินการ',
    'completed' => 'เสร็จสมบูรณ์',
    'approved' => 'อนุมัติแล้ว',
    'draft' => 'ฉบับร่าง',
    'open' => 'เปิด',
    'investigating' => 'กำลังตรวจสอบ',
    'contained' => 'ควบคุมได้แล้ว',
    'resolved' => 'แก้ไขแล้ว',
    'closed' => 'ปิดแล้ว',
    'compliant' => 'ปฏิบัติตาม',
    'non_compliant' => 'ไม่ปฏิบัติตาม',
    'review_needed' => 'ต้องทบทวน',
    'low' => 'ต่ำ',
    'medium' => 'ปานกลาง',
    'high' => 'สูง',
    'confidentiality' => 'การรักษาความลับ',
    'integrity' => 'ความถูกต้องครบถ้วน',
    'availability' => 'ความพร้อมใช้งาน',
    'mixed' => 'ผสม',
    'contract' => 'สัญญา',
    'consent' => 'ความยินยอม',
    'legal_obligation' => 'ข้อผูกพันทางกฎหมาย',
    'legitimate_interests' => 'ประโยชน์อันชอบด้วยกฎหมาย',
    'vital_interests' => 'ประโยชน์สำคัญต่อชีวิต',
    'public_task' => 'ภารกิจสาธารณะ',
    'technical' => 'ด้านเทคนิค',
    'organizational' => 'ด้านองค์กร',
    'human_error' => 'ความผิดพลาดของมนุษย์',
    'external' => 'ภายนอก',
    'systematic_monitoring' => 'การติดตามอย่างเป็นระบบ',
    'sensitive_data' => 'ข้อมูลอ่อนไหว',
    'other' => 'อื่นๆ',
    'administration' => 'ธุรการ',
    'hr' => 'ทรัพยากรบุคคล',
    'finance' => 'การเงิน',
    'marketing' => 'การตลาด',
    'it' => 'ไอที',
    'operations' => 'ปฏิบัติการ',
    'pending' => 'รอดำเนินการ',
    'rejected' => 'ถูกปฏิเสธ',
    'planned' => 'วางแผนไว้',
    'donations' => 'การบริจาค',
    'create_dpia' => 'สร้าง DPIA',
    'create_dpia_from_gdpr' => 'สร้าง DPIA จาก GDPR',
    'click_create_dpia_for_gdpr' => 'คลิก "สร้าง DPIA" สำหรับบันทึก GDPR ที่ต้องทำ DPIA:',
    'new_gdpr_record' => 'บันทึก GDPR ใหม่',
    'edit_gdpr_record' => 'แก้ไขบันทึก GDPR',
    'new_dpia' => 'DPIA ใหม่',
    'edit_dpia' => 'แก้ไข DPIA',
    'new_breach' => 'การละเมิดข้อมูลใหม่',
    'edit_breach' => 'แก้ไขการละเมิดข้อมูล',
    'new_third_party' => 'บุคคลที่สามใหม่',
    'edit_third_party' => 'แก้ไขบุคคลที่สาม',
    'record' => 'บันทึก',
    'page' => 'หน้า',
    'generated' => 'สร้างเมื่อ',
    'successfully_added' => 'เพิ่มสำเร็จ',
    'successfully_updated' => 'อัปเดตสำเร็จ',
    'unsaved_changes_confirm' => 'มีการเปลี่ยนแปลงที่ยังไม่ได้บันทึก คุณแน่ใจหรือไม่ว่าต้องการยกเลิก?',
    'select_or_type_below' => 'เลือกหรือพิมพ์ด้านล่าง',
    'or_type_custom_retention_period' => 'หรือพิมพ์ระยะเวลาการเก็บรักษาที่กำหนดเอง',
    'or_type_custom_safeguards' => 'หรือพิมพ์มาตรการป้องกันที่กำหนดเอง (คั่นด้วยเครื่องหมายเซมิโคลอน)',
    'or_type_custom_measures' => 'หรือพิมพ์มาตรการที่กำหนดเอง (คั่นด้วยเครื่องหมายเซมิโคลอน)',
    'hold_ctrl_to_select_multiple' => 'กด Ctrl (Windows) หรือ Cmd (Mac) ค้างไว้เพื่อเลือกหลายรายการ',
    'custom_mitigation_measures' => 'มาตรการบรรเทาที่กำหนดเอง (คั่นด้วยเครื่องหมายเซมิโคลอน)',
    'custom_measures_taken' => 'มาตรการที่กำหนดเองที่ดำเนินการ (คั่นด้วยเครื่องหมายเซมิโคลอน)',
    'custom_measures_placeholder' => 'เช่น มาตรการที่กำหนดเอง 1; มาตรการที่กำหนดเอง 2',
    'gdpr_record_id' => 'รหัสบันทึก GDPR',
    'gdpr_record' => 'บันทึก GDPR',
    'dpia_for_gdpr' => 'DPIA สำหรับ GDPR',
    'dpia_exists_for_gdpr' => 'มี DPIA อยู่แล้วสำหรับ GDPR',
    'for_gdpr_record' => 'สำหรับบันทึก GDPR',
    'only_one_dpia_allowed' => 'อนุญาตให้มี DPIA ได้เพียงหนึ่งรายการต่อบันทึก GDPR หนึ่งรายการ',
    'risk_distribution' => 'การกระจายความเสี่ยง',
    'gdpr_compliance_overview' => 'ภาพรวมการปฏิบัติตาม GDPR',
    'inactive_draft' => 'ไม่ใช้งาน / ฉบับร่าง',
    'collected_from_records' => 'รวบรวมจากบันทึก',
    'measure' => 'มาตรการ',
    'value' => 'ค่า',
    'source' => 'แหล่งที่มา',
    'configuration' => 'การกำหนดค่า',
    'no_technical_measures' => 'ไม่พบมาตรการทางเทคนิค',
    'no_organizational_measures' => 'ไม่พบมาตรการขององค์กร',
    'edit_measure' => 'แก้ไขมาตรการ',
    'current_measure' => 'มาตรการปัจจุบัน',
    'new_measure_name' => 'ชื่อมาตรการใหม่',
    'measure_renamed_success' => 'เปลี่ยนชื่อมาตรการสำเร็จในทุกที่ที่ใช้งาน',
    'measure_rename_warning' => 'การดำเนินการนี้จะเปลี่ยนชื่อมาตรการในทุกบันทึก GDPR, DPIA และการละเมิดข้อมูลที่ใช้มาตรการนี้',
    'measure_deleted_success' => 'ลบมาตรการสำเร็จในทุกที่ที่เคยใช้งาน',
    'confirm_delete_measure' => 'คุณแน่ใจหรือไม่ว่าต้องการลบมาตรการนี้? มาตรการนี้จะถูกลบออกจากทุกบันทึก GDPR, DPIA และการละเมิดข้อมูลที่ใช้มาตรการนี้ การกระทำนี้ไม่สามารถยกเลิกได้',
    'responsible' => 'ผู้รับผิดชอบ',
    'responsible_placeholder' => 'ใครเป็นผู้รับผิดชอบมาตรการนี้?',
    'unassigned' => 'ยังไม่ได้มอบหมาย',
    'value_renamed_success' => 'เปลี่ยนชื่อค่าสำเร็จในทุกที่ที่ใช้งาน',
    'value_deleted_success' => 'ลบค่าสำเร็จในทุกที่ที่เคยใช้งาน',
    'edit_value' => 'แก้ไขค่า',
    'delete_value' => 'ลบค่า',
    'current_value' => 'ค่าปัจจุบัน',
    'new_value' => 'ค่าใหม่',
    'value_rename_warning' => 'การเปลี่ยนชื่อจะอัปเดตค่านี้ในทุกที่ที่กำลังใช้งานอยู่',
    'value_delete_warning' => 'การลบจะล้างค่านี้ออกจากทุกบันทึกที่กำลังใช้งานอยู่ การกระทำนี้ไม่สามารถยกเลิกได้',
    'confirm_delete_value' => 'ลบค่านี้ในทุกที่ที่ใช้งานหรือไม่? การกระทำนี้ไม่สามารถยกเลิกได้',
    'used_in' => 'ใช้งานใน',
    'not_currently_used' => 'ไม่ได้ใช้งานในขณะนี้',
    'no_values' => 'ไม่พบค่า',
    'total_gdpr_records' => 'จำนวนบันทึก GDPR ทั้งหมด',
    'dpia_in_progress' => 'DPIA ที่กำลังดำเนินการ',
    'total_breaches' => 'จำนวนการละเมิดทั้งหมด',
    'open_breaches' => 'การละเมิดที่ยังเปิดอยู่',
    'total_third_parties' => 'จำนวนบุคคลที่สามทั้งหมด',
    'compliant_third_parties' => 'บุคคลที่สามที่ปฏิบัติตาม',
    'dpia_coverage' => 'ความครอบคลุมของ DPIA',
    'gdpr_with_dpia_required' => 'GDPR ที่ต้องทำ DPIA',
    'dpia_completion_rate' => 'อัตราความสำเร็จของ DPIA',
    'category' => 'หมวดหมู่',
    'overview' => 'ภาพรวม',
    'per_category' => 'แยกตามหมวดหมู่',
    'total_risk' => 'ความเสี่ยงทั้งหมด',
    'completion_rate' => 'อัตราความสำเร็จ',
    'record_type' => 'ประเภทบันทึก',
    'print_report_title' => 'รายงานการปฏิบัติตามข้อกำหนด',
    'generated_on' => 'สร้างเมื่อ',
    'not_started' => 'ยังไม่เริ่ม',
    'safeguard_scc' => 'ข้อกำหนดสัญญามาตรฐาน (SCC)',
    'safeguard_bcr' => 'กฎเกณฑ์บริษัทที่มีผลผูกพัน (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (ไม่มีผลบังคับใช้อีกต่อไป)',
    'safeguard_adequacy_decision' => 'คำวินิจฉัยความเพียงพอของคณะกรรมาธิการยุโรป',
    'safeguard_consent' => 'ความยินยอมเฉพาะจากเจ้าของข้อมูล',
    'safeguard_model_contracts' => 'สัญญาตัวอย่าง',
    'safeguard_certification' => 'กลไกการรับรอง',
    'safeguard_codes_of_conduct' => 'จรรยาบรรณ',
    'safeguard_dpia' => 'การประเมินผลกระทบด้านการคุ้มครองข้อมูล (DPIA)',
    'safeguard_tia' => 'การประเมินผลกระทบการโอนข้อมูลระหว่างประเทศ (TIA)',
    'inactive' => 'ไม่ใช้งาน',
];

// ==================== PERSIAN ====================
$translations['fa'] = [
    'app_title' => 'ثبت GDPR',
    'company_subtitle' => 'حریم خصوصی و انطباق',
    'dashboard' => 'داشبورد',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'نقض داده',
    'breach' => 'نقض داده',
    'third_parties' => 'اشخاص ثالث',
    'third_party' => 'شخص ثالث',
    'measures' => 'اقدامات',
    'reporting' => 'گزارش‌دهی',
    'total' => 'مجموع',
    'active' => 'فعال',
    'high_risk' => 'ریسک بالا',
    'dpia_required' => 'نیاز به DPIA',
    'dpia_completed' => 'DPIA تکمیل شد',
    'new' => 'جدید',
    'export_json' => 'خروجی JSON',
    'search' => 'جستجو...',
    'search_company' => 'جستجوی شرکت...',
    'filter' => 'فیلتر',
    'clear' => 'پاک کردن',
    'risk' => 'ریسک',
    'risk_level' => 'سطح ریسک',
    'status' => 'وضعیت',
    'retention_period' => 'دوره نگهداری',
    'actions' => 'عملیات',
    'view' => 'مشاهده',
    'edit' => 'ویرایش',
    'delete' => 'حذف',
    'print' => 'چاپ',
    'confirm_delete' => 'آیا مطمئن هستید که می‌خواهید این رکورد را حذف کنید؟ این عمل قابل بازگشت نیست.',
    'processing_activity' => 'فعالیت پردازش',
    'purpose' => 'هدف',
    'data_subjects' => 'موضوعات داده',
    'personal_data' => 'داده شخصی',
    'recipients' => 'دریافت‌کنندگان',
    'legal_basis' => 'مبنای قانونی',
    'legitimate_interest' => 'منافع مشروع',
    'department' => 'بخش',
    'or_type_custom_department' => 'یا یک بخش سفارشی وارد کنید',
    'or_type_custom_name' => 'یا یک نام وارد کنید',
    'or_type_custom_risk_origin' => 'یا منشأ ریسک سفارشی وارد کنید',
    'or_type_custom_status' => 'یا وضعیت سفارشی وارد کنید',
    'or_type_custom_approval' => 'یا وضعیت تأیید سفارشی وارد کنید',
    'or_type_custom_consultation' => 'یا مقدار سفارشی وارد کنید',
    'or_type_custom_compliance_status' => 'یا وضعیت انطباق سفارشی وارد کنید',
    'or_type_custom_breach_type' => 'یا نوع نقض سفارشی وارد کنید',
    'international_transfer' => 'انتقال بین‌المللی',
    'to_country' => 'به کشور',
    'we_are_processor' => 'ما پردازشگر هستیم',
    'processing_agreement_third_party' => 'توافق‌نامه پردازش با شخص ثالث',
    'technical_measures' => 'اقدامات فنی',
    'organizational_measures' => 'اقدامات سازمانی',
    'safeguards' => 'تدابیر حفاظتی',
    'review_date' => 'تاریخ بازبینی',
    'controller' => 'کنترل‌کننده',
    'joint_controller' => 'کنترل‌کننده مشترک',
    'dpo' => 'DPO',
    'representative' => 'نماینده',
    'name' => 'نام',
    'contact' => 'تماس',
    'title' => 'عنوان',
    'description' => 'توضیحات',
    'risk_origin' => 'منشأ ریسک',
    'affected_subjects' => 'موضوعات تحت تأثیر',
    'management_approval' => 'تأیید مدیریت',
    'approved_by' => 'تأیید شده توسط',
    'approval_date' => 'تاریخ تأیید',
    'consultation_conducted' => 'مشاوره انجام شد',
    'consultation_details' => 'جزئیات مشاوره',
    'recommendations' => 'توصیه‌ها',
    'notes' => 'یادداشت‌ها',
    'necessity_test' => 'آزمون ضرورت',
    'proportionality_test' => 'آزمون تناسب',
    'mitigation_measures' => 'اقدامات کاهش‌دهنده',
    'residual_risk' => 'ریسک باقی‌مانده',
    'breach_date' => 'تاریخ نقض',
    'discovery_date' => 'تاریخ کشف',
    'breach_type' => 'نوع نقض',
    'causes' => 'علل',
    'measures_taken' => 'اقدامات انجام‌شده',
    'notified_authority' => 'مقام مسئول مطلع شد',
    'notification_date' => 'تاریخ اطلاع‌رسانی',
    'notified_affected' => 'افراد تحت تأثیر مطلع شدند',
    'company_name' => 'نام شرکت',
    'contact_person' => 'شخص تماس',
    'email' => 'ایمیل',
    'phone' => 'تلفن',
    'address' => 'آدرس',
    'service_provided' => 'خدمات ارائه‌شده',
    'agreement_signed' => 'توافق‌نامه امضا شد',
    'agreement_date' => 'تاریخ توافق‌نامه',
    'expiry_date' => 'تاریخ انقضا',
    'compliance_status' => 'وضعیت انطباق',
    'save' => 'ذخیره',
    'cancel' => 'لغو',
    'add' => 'افزودن',
    'close' => 'بستن',
    'language' => 'زبان',
    'logout' => 'خروج',
    'logout_confirm' => 'از این جلسه خارج شوید؟',
    'full_report' => 'گزارش کامل',
    'backup' => 'پشتیبان‌گیری',
    'zip_backup' => 'پشتیبان ZIP',
    'statistics' => 'آمار',
    'no_records' => 'رکوردی یافت نشد',
    'showing' => 'نمایش',
    'of' => 'از',
    'yes' => 'بله',
    'no' => 'خیر',
    'unknown' => 'نامشخص',
    'not_required' => 'مورد نیاز نیست',
    'in_progress' => 'در حال انجام',
    'completed' => 'تکمیل شده',
    'approved' => 'تأیید شده',
    'draft' => 'پیش‌نویس',
    'open' => 'باز',
    'investigating' => 'در حال بررسی',
    'contained' => 'مهار شده',
    'resolved' => 'حل شده',
    'closed' => 'بسته شده',
    'compliant' => 'منطبق',
    'non_compliant' => 'غیرمنطبق',
    'review_needed' => 'نیاز به بازبینی',
    'low' => 'کم',
    'medium' => 'متوسط',
    'high' => 'زیاد',
    'confidentiality' => 'محرمانگی',
    'integrity' => 'یکپارچگی',
    'availability' => 'دسترس‌پذیری',
    'mixed' => 'ترکیبی',
    'contract' => 'قرارداد',
    'consent' => 'رضایت',
    'legal_obligation' => 'تعهد قانونی',
    'legitimate_interests' => 'منافع مشروع',
    'vital_interests' => 'منافع حیاتی',
    'public_task' => 'وظیفه عمومی',
    'technical' => 'فنی',
    'organizational' => 'سازمانی',
    'human_error' => 'خطای انسانی',
    'external' => 'خارجی',
    'systematic_monitoring' => 'نظارت سیستماتیک',
    'sensitive_data' => 'داده حساس',
    'other' => 'سایر',
    'administration' => 'اداری',
    'hr' => 'منابع انسانی',
    'finance' => 'مالی',
    'marketing' => 'بازاریابی',
    'it' => 'فناوری اطلاعات',
    'operations' => 'عملیات',
    'pending' => 'در انتظار',
    'rejected' => 'رد شده',
    'planned' => 'برنامه‌ریزی‌شده',
    'donations' => 'کمک‌های مالی',
    'create_dpia' => 'ایجاد DPIA',
    'create_dpia_from_gdpr' => 'ایجاد DPIA از GDPR',
    'click_create_dpia_for_gdpr' => 'برای رکورد GDPR که به DPIA نیاز دارد روی «ایجاد DPIA» کلیک کنید:',
    'new_gdpr_record' => 'رکورد جدید GDPR',
    'edit_gdpr_record' => 'ویرایش رکورد GDPR',
    'new_dpia' => 'DPIA جدید',
    'edit_dpia' => 'ویرایش DPIA',
    'new_breach' => 'نقض داده جدید',
    'edit_breach' => 'ویرایش نقض داده',
    'new_third_party' => 'شخص ثالث جدید',
    'edit_third_party' => 'ویرایش شخص ثالث',
    'record' => 'رکورد',
    'page' => 'صفحه',
    'generated' => 'تولید شد',
    'successfully_added' => 'با موفقیت اضافه شد',
    'successfully_updated' => 'با موفقیت به‌روزرسانی شد',
    'unsaved_changes_confirm' => 'تغییرات ذخیره‌نشده‌ای وجود دارد. آیا مطمئن هستید که می‌خواهید لغو کنید؟',
    'select_or_type_below' => 'انتخاب کنید یا در زیر تایپ کنید',
    'or_type_custom_retention_period' => 'یا دوره نگهداری سفارشی وارد کنید',
    'or_type_custom_safeguards' => 'یا تدابیر حفاظتی سفارشی وارد کنید (با نقطه‌ویرگول جدا شود)',
    'or_type_custom_measures' => 'یا اقدامات سفارشی وارد کنید (با نقطه‌ویرگول جدا شود)',
    'hold_ctrl_to_select_multiple' => 'برای انتخاب چندگانه، Ctrl (ویندوز) یا Cmd (مک) را نگه دارید',
    'custom_mitigation_measures' => 'اقدامات کاهش‌دهنده سفارشی (با نقطه‌ویرگول جدا شود)',
    'custom_measures_taken' => 'اقدامات سفارشی انجام‌شده (با نقطه‌ویرگول جدا شود)',
    'custom_measures_placeholder' => 'مثلاً: اقدام سفارشی ۱؛ اقدام سفارشی ۲',
    'gdpr_record_id' => 'شناسه رکورد GDPR',
    'gdpr_record' => 'رکورد GDPR',
    'dpia_for_gdpr' => 'DPIA برای GDPR',
    'dpia_exists_for_gdpr' => 'یک DPIA از قبل برای GDPR وجود دارد',
    'for_gdpr_record' => 'برای رکورد GDPR',
    'only_one_dpia_allowed' => 'فقط یک DPIA برای هر رکورد GDPR مجاز است.',
    'risk_distribution' => 'توزیع ریسک',
    'gdpr_compliance_overview' => 'نمای کلی انطباق GDPR',
    'inactive_draft' => 'غیرفعال / پیش‌نویس',
    'collected_from_records' => 'جمع‌آوری‌شده از رکوردها',
    'measure' => 'اقدام',
    'value' => 'مقدار',
    'source' => 'منبع',
    'configuration' => 'پیکربندی',
    'no_technical_measures' => 'هیچ اقدام فنی یافت نشد',
    'no_organizational_measures' => 'هیچ اقدام سازمانی یافت نشد',
    'edit_measure' => 'ویرایش اقدام',
    'current_measure' => 'اقدام فعلی',
    'new_measure_name' => 'نام اقدام جدید',
    'measure_renamed_success' => 'نام اقدام با موفقیت در همه جای استفاده تغییر یافت.',
    'measure_rename_warning' => 'این کار نام اقدام را در تمام رکوردهای GDPR، DPIA و نقض داده که در آن استفاده شده تغییر می‌دهد.',
    'measure_deleted_success' => 'اقدام با موفقیت از همه جای استفاده حذف شد.',
    'confirm_delete_measure' => 'آیا مطمئن هستید که می‌خواهید این اقدام را حذف کنید؟ این اقدام از تمام رکوردهای GDPR، DPIA و نقض داده که در آن استفاده شده حذف خواهد شد. این عمل قابل بازگشت نیست.',
    'responsible' => 'مسئول',
    'responsible_placeholder' => 'چه کسی مسئول این اقدام است؟',
    'unassigned' => 'تخصیص‌نیافته',
    'value_renamed_success' => 'نام مقدار با موفقیت در همه جای استفاده تغییر یافت.',
    'value_deleted_success' => 'مقدار با موفقیت از همه جای استفاده حذف شد.',
    'edit_value' => 'ویرایش مقدار',
    'delete_value' => 'حذف مقدار',
    'current_value' => 'مقدار فعلی',
    'new_value' => 'مقدار جدید',
    'value_rename_warning' => 'تغییر نام، این مقدار را در همه جایی که در حال حاضر استفاده می‌شود به‌روزرسانی می‌کند.',
    'value_delete_warning' => 'حذف، این مقدار را از تمام رکوردهایی که در حال حاضر استفاده می‌شود پاک می‌کند. این عمل قابل بازگشت نیست.',
    'confirm_delete_value' => 'این مقدار در همه جای استفاده حذف شود؟ این عمل قابل بازگشت نیست.',
    'used_in' => 'استفاده‌شده در',
    'not_currently_used' => 'در حال حاضر استفاده نمی‌شود',
    'no_values' => 'هیچ مقداری یافت نشد',
    'total_gdpr_records' => 'مجموع رکوردهای GDPR',
    'dpia_in_progress' => 'DPIA در حال انجام',
    'total_breaches' => 'مجموع نقض‌ها',
    'open_breaches' => 'نقض‌های باز',
    'total_third_parties' => 'مجموع اشخاص ثالث',
    'compliant_third_parties' => 'اشخاص ثالث منطبق',
    'dpia_coverage' => 'پوشش DPIA',
    'gdpr_with_dpia_required' => 'GDPR با نیاز به DPIA',
    'dpia_completion_rate' => 'نرخ تکمیل DPIA',
    'category' => 'دسته‌بندی',
    'overview' => 'نمای کلی',
    'per_category' => 'بر اساس دسته‌بندی',
    'total_risk' => 'مجموع ریسک',
    'completion_rate' => 'نرخ تکمیل',
    'record_type' => 'نوع رکورد',
    'print_report_title' => 'گزارش انطباق',
    'generated_on' => 'تولید شده در',
    'not_started' => 'شروع نشده',
    'safeguard_scc' => 'بندهای قراردادی استاندارد (SCC)',
    'safeguard_bcr' => 'قوانین الزام‌آور شرکتی (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (دیگر معتبر نیست)',
    'safeguard_adequacy_decision' => 'تصمیم کفایت کمیسیون اروپا',
    'safeguard_consent' => 'رضایت خاص از موضوع داده',
    'safeguard_model_contracts' => 'قراردادهای نمونه',
    'safeguard_certification' => 'مکانیزم‌های صدور گواهینامه',
    'safeguard_codes_of_conduct' => 'آیین‌نامه‌های رفتاری',
    'safeguard_dpia' => 'ارزیابی تأثیر حفاظت از داده (DPIA)',
    'safeguard_tia' => 'ارزیابی تأثیر انتقال بین‌المللی داده (TIA)',
    'inactive' => 'غیرفعال',
];

// ==================== HEBREW ====================
$translations['he'] = [
    'app_title' => 'מרשם GDPR',
    'company_subtitle' => 'פרטיות ותאימות',
    'dashboard' => 'לוח בקרה',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'הפרות מידע',
    'breach' => 'הפרת מידע',
    'third_parties' => 'צדדים שלישיים',
    'third_party' => 'צד שלישי',
    'measures' => 'אמצעים',
    'reporting' => 'דיווח',
    'total' => 'סך הכול',
    'active' => 'פעיל',
    'high_risk' => 'סיכון גבוה',
    'dpia_required' => 'נדרש DPIA',
    'dpia_completed' => 'DPIA הושלם',
    'new' => 'חדש',
    'export_json' => 'ייצוא JSON',
    'search' => 'חיפוש...',
    'search_company' => 'חיפוש חברה...',
    'filter' => 'סינון',
    'clear' => 'נקה',
    'risk' => 'סיכון',
    'risk_level' => 'רמת סיכון',
    'status' => 'סטטוס',
    'retention_period' => 'תקופת שמירה',
    'actions' => 'פעולות',
    'view' => 'צפייה',
    'edit' => 'עריכה',
    'delete' => 'מחיקה',
    'print' => 'הדפסה',
    'confirm_delete' => 'האם אתה בטוח שברצונך למחוק רשומה זו? לא ניתן לבטל פעולה זו.',
    'processing_activity' => 'פעילות עיבוד',
    'purpose' => 'מטרה',
    'data_subjects' => 'נושאי מידע',
    'personal_data' => 'מידע אישי',
    'recipients' => 'נמענים',
    'legal_basis' => 'בסיס משפטי',
    'legitimate_interest' => 'אינטרס לגיטימי',
    'department' => 'מחלקה',
    'or_type_custom_department' => 'או הזן מחלקה מותאמת אישית',
    'or_type_custom_name' => 'או הזן שם',
    'or_type_custom_risk_origin' => 'או הזן מקור סיכון מותאם אישית',
    'or_type_custom_status' => 'או הזן סטטוס מותאם אישית',
    'or_type_custom_approval' => 'או הזן סטטוס אישור מותאם אישית',
    'or_type_custom_consultation' => 'או הזן ערך מותאם אישית',
    'or_type_custom_compliance_status' => 'או הזן סטטוס תאימות מותאם אישית',
    'or_type_custom_breach_type' => 'או הזן סוג הפרה מותאם אישית',
    'international_transfer' => 'העברה בינלאומית',
    'to_country' => 'למדינה',
    'we_are_processor' => 'אנחנו המעבד',
    'processing_agreement_third_party' => 'הסכם עיבוד עם צד שלישי',
    'technical_measures' => 'אמצעים טכניים',
    'organizational_measures' => 'אמצעים ארגוניים',
    'safeguards' => 'אמצעי הגנה',
    'review_date' => 'תאריך בדיקה',
    'controller' => 'מבקר',
    'joint_controller' => 'מבקר משותף',
    'dpo' => 'DPO',
    'representative' => 'נציג',
    'name' => 'שם',
    'contact' => 'איש קשר',
    'title' => 'כותרת',
    'description' => 'תיאור',
    'risk_origin' => 'מקור הסיכון',
    'affected_subjects' => 'נושאים מושפעים',
    'management_approval' => 'אישור הנהלה',
    'approved_by' => 'אושר על ידי',
    'approval_date' => 'תאריך אישור',
    'consultation_conducted' => 'התייעצות בוצעה',
    'consultation_details' => 'פרטי התייעצות',
    'recommendations' => 'המלצות',
    'notes' => 'הערות',
    'necessity_test' => 'מבחן הכרחיות',
    'proportionality_test' => 'מבחן מידתיות',
    'mitigation_measures' => 'אמצעי מיתון',
    'residual_risk' => 'סיכון שיורי',
    'breach_date' => 'תאריך ההפרה',
    'discovery_date' => 'תאריך הגילוי',
    'breach_type' => 'סוג ההפרה',
    'causes' => 'גורמים',
    'measures_taken' => 'אמצעים שננקטו',
    'notified_authority' => 'הרשות עודכנה',
    'notification_date' => 'תאריך ההודעה',
    'notified_affected' => 'הנפגעים עודכנו',
    'company_name' => 'שם החברה',
    'contact_person' => 'איש קשר',
    'email' => 'דוא"ל',
    'phone' => 'טלפון',
    'address' => 'כתובת',
    'service_provided' => 'שירות שניתן',
    'agreement_signed' => 'ההסכם נחתם',
    'agreement_date' => 'תאריך ההסכם',
    'expiry_date' => 'תאריך תפוגה',
    'compliance_status' => 'סטטוס תאימות',
    'save' => 'שמור',
    'cancel' => 'ביטול',
    'add' => 'הוסף',
    'close' => 'סגור',
    'language' => 'שפה',
    'logout' => 'התנתקות',
    'logout_confirm' => 'להתנתק מהפעלה זו?',
    'full_report' => 'דוח מלא',
    'backup' => 'גיבוי',
    'zip_backup' => 'גיבוי ZIP',
    'statistics' => 'סטטיסטיקה',
    'no_records' => 'לא נמצאו רשומות',
    'showing' => 'מציג',
    'of' => 'מתוך',
    'yes' => 'כן',
    'no' => 'לא',
    'unknown' => 'לא ידוע',
    'not_required' => 'לא נדרש',
    'in_progress' => 'בתהליך',
    'completed' => 'הושלם',
    'approved' => 'אושר',
    'draft' => 'טיוטה',
    'open' => 'פתוח',
    'investigating' => 'בבדיקה',
    'contained' => 'הוכל',
    'resolved' => 'נפתר',
    'closed' => 'סגור',
    'compliant' => 'תואם',
    'non_compliant' => 'לא תואם',
    'review_needed' => 'נדרשת בדיקה',
    'low' => 'נמוך',
    'medium' => 'בינוני',
    'high' => 'גבוה',
    'confidentiality' => 'סודיות',
    'integrity' => 'שלמות',
    'availability' => 'זמינות',
    'mixed' => 'מעורב',
    'contract' => 'חוזה',
    'consent' => 'הסכמה',
    'legal_obligation' => 'חובה חוקית',
    'legitimate_interests' => 'אינטרסים לגיטימיים',
    'vital_interests' => 'אינטרסים חיוניים',
    'public_task' => 'משימה ציבורית',
    'technical' => 'טכני',
    'organizational' => 'ארגוני',
    'human_error' => 'טעות אנוש',
    'external' => 'חיצוני',
    'systematic_monitoring' => 'ניטור שיטתי',
    'sensitive_data' => 'מידע רגיש',
    'other' => 'אחר',
    'administration' => 'מנהלה',
    'hr' => 'משאבי אנוש',
    'finance' => 'כספים',
    'marketing' => 'שיווק',
    'it' => 'מחשוב',
    'operations' => 'תפעול',
    'pending' => 'ממתין',
    'rejected' => 'נדחה',
    'planned' => 'מתוכנן',
    'donations' => 'תרומות',
    'create_dpia' => 'צור DPIA',
    'create_dpia_from_gdpr' => 'צור DPIA מ-GDPR',
    'click_create_dpia_for_gdpr' => 'לחץ על "צור DPIA" עבור רשומת GDPR הדורשת DPIA:',
    'new_gdpr_record' => 'רשומת GDPR חדשה',
    'edit_gdpr_record' => 'עריכת רשומת GDPR',
    'new_dpia' => 'DPIA חדש',
    'edit_dpia' => 'עריכת DPIA',
    'new_breach' => 'הפרת מידע חדשה',
    'edit_breach' => 'עריכת הפרת מידע',
    'new_third_party' => 'צד שלישי חדש',
    'edit_third_party' => 'עריכת צד שלישי',
    'record' => 'רשומה',
    'page' => 'עמוד',
    'generated' => 'נוצר',
    'successfully_added' => 'נוסף בהצלחה',
    'successfully_updated' => 'עודכן בהצלחה',
    'unsaved_changes_confirm' => 'ישנם שינויים שלא נשמרו. האם אתה בטוח שברצונך לבטל?',
    'select_or_type_below' => 'בחר או הקלד למטה',
    'or_type_custom_retention_period' => 'או הזן תקופת שמירה מותאמת אישית',
    'or_type_custom_safeguards' => 'או הזן אמצעי הגנה מותאמים אישית (מופרדים בנקודה־פסיק)',
    'or_type_custom_measures' => 'או הזן אמצעים מותאמים אישית (מופרדים בנקודה־פסיק)',
    'hold_ctrl_to_select_multiple' => 'החזק Ctrl (Windows) או Cmd (Mac) לבחירה מרובה',
    'custom_mitigation_measures' => 'אמצעי מיתון מותאמים אישית (מופרדים בנקודה־פסיק)',
    'custom_measures_taken' => 'אמצעים מותאמים אישית שננקטו (מופרדים בנקודה־פסיק)',
    'custom_measures_placeholder' => 'לדוגמה: אמצעי מותאם 1; אמצעי מותאם 2',
    'gdpr_record_id' => 'מזהה רשומת GDPR',
    'gdpr_record' => 'רשומת GDPR',
    'dpia_for_gdpr' => 'DPIA עבור GDPR',
    'dpia_exists_for_gdpr' => 'כבר קיים DPIA עבור GDPR',
    'for_gdpr_record' => 'עבור רשומת GDPR',
    'only_one_dpia_allowed' => 'מותר רק DPIA אחד לכל רשומת GDPR.',
    'risk_distribution' => 'התפלגות סיכונים',
    'gdpr_compliance_overview' => 'סקירת תאימות GDPR',
    'inactive_draft' => 'לא פעיל / טיוטה',
    'collected_from_records' => 'נאסף מרשומות',
    'measure' => 'אמצעי',
    'value' => 'ערך',
    'source' => 'מקור',
    'configuration' => 'תצורה',
    'no_technical_measures' => 'לא נמצאו אמצעים טכניים',
    'no_organizational_measures' => 'לא נמצאו אמצעים ארגוניים',
    'edit_measure' => 'עריכת אמצעי',
    'current_measure' => 'אמצעי נוכחי',
    'new_measure_name' => 'שם אמצעי חדש',
    'measure_renamed_success' => 'שם האמצעי שונה בהצלחה בכל מקום שבו הוא נמצא בשימוש.',
    'measure_rename_warning' => 'פעולה זו תשנה את שם האמצעי בכל רשומת GDPR, DPIA והפרת מידע שבה הוא נמצא בשימוש.',
    'measure_deleted_success' => 'האמצעי נמחק בהצלחה מכל מקום שבו היה בשימוש.',
    'confirm_delete_measure' => 'האם אתה בטוח שברצונך למחוק אמצעי זה? הוא יוסר מכל רשומת GDPR, DPIA והפרת מידע שבה הוא נמצא בשימוש. לא ניתן לבטל פעולה זו.',
    'responsible' => 'אחראי',
    'responsible_placeholder' => 'מי אחראי על אמצעי זה?',
    'unassigned' => 'לא משויך',
    'value_renamed_success' => 'שם הערך שונה בהצלחה בכל מקום שבו הוא נמצא בשימוש.',
    'value_deleted_success' => 'הערך הוסר בהצלחה מכל מקום שבו היה בשימוש.',
    'edit_value' => 'עריכת ערך',
    'delete_value' => 'מחיקת ערך',
    'current_value' => 'ערך נוכחי',
    'new_value' => 'ערך חדש',
    'value_rename_warning' => 'שינוי השם יעדכן ערך זה בכל מקום שבו הוא נמצא כרגע בשימוש.',
    'value_delete_warning' => 'המחיקה תנקה ערך זה מכל רשומה שבה הוא נמצא כרגע בשימוש. לא ניתן לבטל פעולה זו.',
    'confirm_delete_value' => 'למחוק ערך זה בכל מקום שבו הוא נמצא בשימוש? לא ניתן לבטל פעולה זו.',
    'used_in' => 'בשימוש ב',
    'not_currently_used' => 'לא נמצא כרגע בשימוש',
    'no_values' => 'לא נמצאו ערכים',
    'total_gdpr_records' => 'סך רשומות GDPR',
    'dpia_in_progress' => 'DPIA בתהליך',
    'total_breaches' => 'סך ההפרות',
    'open_breaches' => 'הפרות פתוחות',
    'total_third_parties' => 'סך הצדדים השלישיים',
    'compliant_third_parties' => 'צדדים שלישיים תואמים',
    'dpia_coverage' => 'כיסוי DPIA',
    'gdpr_with_dpia_required' => 'רשומות GDPR הדורשות DPIA',
    'dpia_completion_rate' => 'שיעור השלמת DPIA',
    'category' => 'קטגוריה',
    'overview' => 'סקירה כללית',
    'per_category' => 'לפי קטגוריה',
    'total_risk' => 'סיכון כולל',
    'completion_rate' => 'שיעור השלמה',
    'record_type' => 'סוג רשומה',
    'print_report_title' => 'דוח תאימות',
    'generated_on' => 'נוצר בתאריך',
    'not_started' => 'טרם החל',
    'safeguard_scc' => 'סעיפים חוזיים סטנדרטיים (SCC)',
    'safeguard_bcr' => 'כללים תאגידיים מחייבים (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (אינו תקף עוד)',
    'safeguard_adequacy_decision' => 'החלטת הלימות של הנציבות האירופית',
    'safeguard_consent' => 'הסכמה ספציפית של נושא המידע',
    'safeguard_model_contracts' => 'חוזי מודל',
    'safeguard_certification' => 'מנגנוני הסמכה',
    'safeguard_codes_of_conduct' => 'קודי התנהגות',
    'safeguard_dpia' => 'הערכת השפעה על הגנת מידע (DPIA)',
    'safeguard_tia' => 'הערכת השפעת העברת מידע בינלאומית (TIA)',
    'inactive' => 'לא פעיל',
];

// ==================== GREEK ====================
$translations['el'] = [
    'app_title' => 'Μητρώο GDPR',
    'company_subtitle' => 'Απόρρητο & Συμμόρφωση',
    'dashboard' => 'Πίνακας ελέγχου',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Παραβιάσεις Δεδομένων',
    'breach' => 'Παραβίαση Δεδομένων',
    'third_parties' => 'Τρίτα Μέρη',
    'third_party' => 'Τρίτο Μέρος',
    'measures' => 'Μέτρα',
    'reporting' => 'Αναφορές',
    'total' => 'Σύνολο',
    'active' => 'Ενεργό',
    'high_risk' => 'Υψηλός Κίνδυνος',
    'dpia_required' => 'Απαιτείται DPIA',
    'dpia_completed' => 'DPIA Ολοκληρώθηκε',
    'new' => 'Νέο',
    'export_json' => 'Εξαγωγή JSON',
    'search' => 'Αναζήτηση...',
    'search_company' => 'Αναζήτηση εταιρείας...',
    'filter' => 'Φίλτρο',
    'clear' => 'Καθαρισμός',
    'risk' => 'Κίνδυνος',
    'risk_level' => 'Επίπεδο Κινδύνου',
    'status' => 'Κατάσταση',
    'retention_period' => 'Περίοδος Διατήρησης',
    'actions' => 'Ενέργειες',
    'view' => 'Προβολή',
    'edit' => 'Επεξεργασία',
    'delete' => 'Διαγραφή',
    'print' => 'Εκτύπωση',
    'confirm_delete' => 'Είστε βέβαιοι ότι θέλετε να διαγράψετε αυτήν την εγγραφή; Αυτή η ενέργεια δεν μπορεί να αναιρεθεί.',
    'processing_activity' => 'Δραστηριότητα Επεξεργασίας',
    'purpose' => 'Σκοπός',
    'data_subjects' => 'Υποκείμενα Δεδομένων',
    'personal_data' => 'Προσωπικά Δεδομένα',
    'recipients' => 'Αποδέκτες',
    'legal_basis' => 'Νομική Βάση',
    'legitimate_interest' => 'Έννομο Συμφέρον',
    'department' => 'Τμήμα',
    'or_type_custom_department' => 'Ή πληκτρολογήστε προσαρμοσμένο τμήμα',
    'or_type_custom_name' => 'Ή πληκτρολογήστε όνομα',
    'or_type_custom_risk_origin' => 'Ή πληκτρολογήστε προσαρμοσμένη προέλευση κινδύνου',
    'or_type_custom_status' => 'Ή πληκτρολογήστε προσαρμοσμένη κατάσταση',
    'or_type_custom_approval' => 'Ή πληκτρολογήστε προσαρμοσμένη κατάσταση έγκρισης',
    'or_type_custom_consultation' => 'Ή πληκτρολογήστε προσαρμοσμένη τιμή',
    'or_type_custom_compliance_status' => 'Ή πληκτρολογήστε προσαρμοσμένη κατάσταση συμμόρφωσης',
    'or_type_custom_breach_type' => 'Ή πληκτρολογήστε προσαρμοσμένο τύπο παραβίασης',
    'international_transfer' => 'Διεθνής Διαβίβαση',
    'to_country' => 'Προς Χώρα',
    'we_are_processor' => 'Είμαστε Εκτελών την Επεξεργασία',
    'processing_agreement_third_party' => 'Συμφωνία Επεξεργασίας με Τρίτο Μέρος',
    'technical_measures' => 'Τεχνικά Μέτρα',
    'organizational_measures' => 'Οργανωτικά Μέτρα',
    'safeguards' => 'Διασφαλίσεις',
    'review_date' => 'Ημερομηνία Αναθεώρησης',
    'controller' => 'Υπεύθυνος Επεξεργασίας',
    'joint_controller' => 'Από Κοινού Υπεύθυνος Επεξεργασίας',
    'dpo' => 'DPO',
    'representative' => 'Εκπρόσωπος',
    'name' => 'Όνομα',
    'contact' => 'Επικοινωνία',
    'title' => 'Τίτλος',
    'description' => 'Περιγραφή',
    'risk_origin' => 'Προέλευση Κινδύνου',
    'affected_subjects' => 'Επηρεαζόμενα Υποκείμενα',
    'management_approval' => 'Έγκριση Διοίκησης',
    'approved_by' => 'Εγκρίθηκε Από',
    'approval_date' => 'Ημερομηνία Έγκρισης',
    'consultation_conducted' => 'Διαβούλευση Πραγματοποιήθηκε',
    'consultation_details' => 'Λεπτομέρειες Διαβούλευσης',
    'recommendations' => 'Συστάσεις',
    'notes' => 'Σημειώσεις',
    'necessity_test' => 'Δοκιμή Αναγκαιότητας',
    'proportionality_test' => 'Δοκιμή Αναλογικότητας',
    'mitigation_measures' => 'Μέτρα Μετριασμού',
    'residual_risk' => 'Υπολειπόμενος Κίνδυνος',
    'breach_date' => 'Ημερομηνία Παραβίασης',
    'discovery_date' => 'Ημερομηνία Ανακάλυψης',
    'breach_type' => 'Τύπος Παραβίασης',
    'causes' => 'Αιτίες',
    'measures_taken' => 'Μέτρα που Ελήφθησαν',
    'notified_authority' => 'Ενημερώθηκε η Αρχή',
    'notification_date' => 'Ημερομηνία Ειδοποίησης',
    'notified_affected' => 'Ενημερώθηκαν οι Θιγόμενοι',
    'company_name' => 'Επωνυμία Εταιρείας',
    'contact_person' => 'Πρόσωπο Επικοινωνίας',
    'email' => 'Email',
    'phone' => 'Τηλέφωνο',
    'address' => 'Διεύθυνση',
    'service_provided' => 'Παρεχόμενη Υπηρεσία',
    'agreement_signed' => 'Η Συμφωνία Υπογράφηκε',
    'agreement_date' => 'Ημερομηνία Συμφωνίας',
    'expiry_date' => 'Ημερομηνία Λήξης',
    'compliance_status' => 'Κατάσταση Συμμόρφωσης',
    'save' => 'Αποθήκευση',
    'cancel' => 'Ακύρωση',
    'add' => 'Προσθήκη',
    'close' => 'Κλείσιμο',
    'language' => 'Γλώσσα',
    'logout' => 'Αποσύνδεση',
    'logout_confirm' => 'Αποσύνδεση από αυτήν τη συνεδρία;',
    'full_report' => 'Πλήρης Αναφορά',
    'backup' => 'Αντίγραφο Ασφαλείας',
    'zip_backup' => 'Αντίγραφο ZIP',
    'statistics' => 'Στατιστικά',
    'no_records' => 'Δεν βρέθηκαν εγγραφές',
    'showing' => 'Εμφάνιση',
    'of' => 'από',
    'yes' => 'Ναι',
    'no' => 'Όχι',
    'unknown' => 'Άγνωστο',
    'not_required' => 'Δεν Απαιτείται',
    'in_progress' => 'Σε Εξέλιξη',
    'completed' => 'Ολοκληρώθηκε',
    'approved' => 'Εγκρίθηκε',
    'draft' => 'Πρόχειρο',
    'open' => 'Ανοιχτό',
    'investigating' => 'Υπό Διερεύνηση',
    'contained' => 'Περιορίστηκε',
    'resolved' => 'Επιλύθηκε',
    'closed' => 'Κλειστό',
    'compliant' => 'Συμμορφούμενο',
    'non_compliant' => 'Μη Συμμορφούμενο',
    'review_needed' => 'Απαιτείται Αναθεώρηση',
    'low' => 'Χαμηλός',
    'medium' => 'Μεσαίος',
    'high' => 'Υψηλός',
    'confidentiality' => 'Εμπιστευτικότητα',
    'integrity' => 'Ακεραιότητα',
    'availability' => 'Διαθεσιμότητα',
    'mixed' => 'Μικτό',
    'contract' => 'Σύμβαση',
    'consent' => 'Συγκατάθεση',
    'legal_obligation' => 'Νομική Υποχρέωση',
    'legitimate_interests' => 'Έννομα Συμφέροντα',
    'vital_interests' => 'Ζωτικά Συμφέροντα',
    'public_task' => 'Δημόσιο Καθήκον',
    'technical' => 'Τεχνικό',
    'organizational' => 'Οργανωτικό',
    'human_error' => 'Ανθρώπινο Λάθος',
    'external' => 'Εξωτερικό',
    'systematic_monitoring' => 'Συστηματική Παρακολούθηση',
    'sensitive_data' => 'Ευαίσθητα Δεδομένα',
    'other' => 'Άλλο',
    'administration' => 'Διοίκηση',
    'hr' => 'Ανθρώπινο Δυναμικό',
    'finance' => 'Οικονομικά',
    'marketing' => 'Μάρκετινγκ',
    'it' => 'Πληροφορική',
    'operations' => 'Λειτουργίες',
    'pending' => 'Εκκρεμεί',
    'rejected' => 'Απορρίφθηκε',
    'planned' => 'Προγραμματισμένο',
    'donations' => 'Δωρεές',
    'create_dpia' => 'Δημιουργία DPIA',
    'create_dpia_from_gdpr' => 'Δημιουργία DPIA από GDPR',
    'click_create_dpia_for_gdpr' => 'Κάντε κλικ στο "Δημιουργία DPIA" για μια εγγραφή GDPR που απαιτεί DPIA:',
    'new_gdpr_record' => 'Νέα Εγγραφή GDPR',
    'edit_gdpr_record' => 'Επεξεργασία Εγγραφής GDPR',
    'new_dpia' => 'Νέο DPIA',
    'edit_dpia' => 'Επεξεργασία DPIA',
    'new_breach' => 'Νέα Παραβίαση Δεδομένων',
    'edit_breach' => 'Επεξεργασία Παραβίασης Δεδομένων',
    'new_third_party' => 'Νέο Τρίτο Μέρος',
    'edit_third_party' => 'Επεξεργασία Τρίτου Μέρους',
    'record' => 'Εγγραφή',
    'page' => 'Σελίδα',
    'generated' => 'Δημιουργήθηκε',
    'successfully_added' => 'προστέθηκε με επιτυχία',
    'successfully_updated' => 'ενημερώθηκε με επιτυχία',
    'unsaved_changes_confirm' => 'Υπάρχουν μη αποθηκευμένες αλλαγές. Είστε βέβαιοι ότι θέλετε να ακυρώσετε;',
    'select_or_type_below' => 'Επιλέξτε ή πληκτρολογήστε παρακάτω',
    'or_type_custom_retention_period' => 'Ή πληκτρολογήστε προσαρμοσμένη περίοδο διατήρησης',
    'or_type_custom_safeguards' => 'Ή πληκτρολογήστε προσαρμοσμένες διασφαλίσεις (χωρισμένες με ερωτηματικό)',
    'or_type_custom_measures' => 'Ή πληκτρολογήστε προσαρμοσμένα μέτρα (χωρισμένα με ερωτηματικό)',
    'hold_ctrl_to_select_multiple' => 'Κρατήστε πατημένο το Ctrl (Windows) ή Cmd (Mac) για πολλαπλή επιλογή',
    'custom_mitigation_measures' => 'Προσαρμοσμένα μέτρα μετριασμού (χωρισμένα με ερωτηματικό)',
    'custom_measures_taken' => 'Προσαρμοσμένα μέτρα που ελήφθησαν (χωρισμένα με ερωτηματικό)',
    'custom_measures_placeholder' => 'π.χ. Προσαρμοσμένο μέτρο 1· Προσαρμοσμένο μέτρο 2',
    'gdpr_record_id' => 'Αναγνωριστικό Εγγραφής GDPR',
    'gdpr_record' => 'Εγγραφή GDPR',
    'dpia_for_gdpr' => 'DPIA για GDPR',
    'dpia_exists_for_gdpr' => 'Υπάρχει ήδη DPIA για το GDPR',
    'for_gdpr_record' => 'για την εγγραφή GDPR',
    'only_one_dpia_allowed' => 'Επιτρέπεται μόνο ένα DPIA ανά εγγραφή GDPR.',
    'risk_distribution' => 'Κατανομή Κινδύνου',
    'gdpr_compliance_overview' => 'Επισκόπηση Συμμόρφωσης GDPR',
    'inactive_draft' => 'Ανενεργό / Πρόχειρο',
    'collected_from_records' => 'Συλλέχθηκε από εγγραφές',
    'measure' => 'Μέτρο',
    'value' => 'Τιμή',
    'source' => 'Πηγή',
    'configuration' => 'Διαμόρφωση',
    'no_technical_measures' => 'Δεν βρέθηκαν τεχνικά μέτρα',
    'no_organizational_measures' => 'Δεν βρέθηκαν οργανωτικά μέτρα',
    'edit_measure' => 'Επεξεργασία Μέτρου',
    'current_measure' => 'Τρέχον Μέτρο',
    'new_measure_name' => 'Νέο Όνομα Μέτρου',
    'measure_renamed_success' => 'Η μετονομασία του μέτρου ολοκληρώθηκε με επιτυχία παντού όπου χρησιμοποιείται.',
    'measure_rename_warning' => 'Αυτό θα μετονομάσει το μέτρο σε κάθε εγγραφή GDPR, DPIA και Παραβίασης Δεδομένων όπου χρησιμοποιείται.',
    'measure_deleted_success' => 'Το μέτρο διαγράφηκε με επιτυχία από παντού όπου χρησιμοποιούνταν.',
    'confirm_delete_measure' => 'Είστε βέβαιοι ότι θέλετε να διαγράψετε αυτό το μέτρο; Θα αφαιρεθεί από κάθε εγγραφή GDPR, DPIA και Παραβίασης Δεδομένων όπου χρησιμοποιείται. Αυτή η ενέργεια δεν μπορεί να αναιρεθεί.',
    'responsible' => 'Υπεύθυνος',
    'responsible_placeholder' => 'Ποιος είναι υπεύθυνος για αυτό το μέτρο;',
    'unassigned' => 'Μη Ανατεθειμένο',
    'value_renamed_success' => 'Η μετονομασία της τιμής ολοκληρώθηκε με επιτυχία παντού όπου χρησιμοποιείται.',
    'value_deleted_success' => 'Η τιμή διαγράφηκε με επιτυχία από παντού όπου χρησιμοποιούνταν.',
    'edit_value' => 'Επεξεργασία τιμής',
    'delete_value' => 'Διαγραφή τιμής',
    'current_value' => 'Τρέχουσα τιμή',
    'new_value' => 'Νέα τιμή',
    'value_rename_warning' => 'Η μετονομασία θα ενημερώσει αυτήν την τιμή παντού όπου χρησιμοποιείται αυτήν τη στιγμή.',
    'value_delete_warning' => 'Η διαγραφή θα αφαιρέσει αυτήν την τιμή από κάθε εγγραφή όπου χρησιμοποιείται αυτήν τη στιγμή. Αυτή η ενέργεια δεν μπορεί να αναιρεθεί.',
    'confirm_delete_value' => 'Διαγραφή αυτής της τιμής παντού όπου χρησιμοποιείται; Αυτή η ενέργεια δεν μπορεί να αναιρεθεί.',
    'used_in' => 'Χρησιμοποιείται σε',
    'not_currently_used' => 'Δεν χρησιμοποιείται αυτήν τη στιγμή',
    'no_values' => 'Δεν βρέθηκαν τιμές',
    'total_gdpr_records' => 'Σύνολο εγγραφών GDPR',
    'dpia_in_progress' => 'DPIA σε εξέλιξη',
    'total_breaches' => 'Σύνολο παραβιάσεων',
    'open_breaches' => 'Ανοιχτές παραβιάσεις',
    'total_third_parties' => 'Σύνολο τρίτων μερών',
    'compliant_third_parties' => 'Συμμορφούμενα τρίτα μέρη',
    'dpia_coverage' => 'Κάλυψη DPIA',
    'gdpr_with_dpia_required' => 'GDPR με απαίτηση DPIA',
    'dpia_completion_rate' => 'Ποσοστό ολοκλήρωσης DPIA',
    'category' => 'Κατηγορία',
    'overview' => 'Επισκόπηση',
    'per_category' => 'Ανά Κατηγορία',
    'total_risk' => 'Συνολικός Κίνδυνος',
    'completion_rate' => 'Ποσοστό Ολοκλήρωσης',
    'record_type' => 'Τύπος Εγγραφής',
    'print_report_title' => 'Αναφορά Συμμόρφωσης',
    'generated_on' => 'Δημιουργήθηκε στις',
    'not_started' => 'Δεν Έχει Ξεκινήσει',
    'safeguard_scc' => 'Τυποποιημένες Συμβατικές Ρήτρες (SCC)',
    'safeguard_bcr' => 'Δεσμευτικοί Εταιρικοί Κανόνες (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (δεν ισχύει πλέον)',
    'safeguard_adequacy_decision' => 'Απόφαση Επάρκειας της Ευρωπαϊκής Επιτροπής',
    'safeguard_consent' => 'Ειδική συγκατάθεση του υποκειμένου δεδομένων',
    'safeguard_model_contracts' => 'Πρότυπες συμβάσεις',
    'safeguard_certification' => 'Μηχανισμοί πιστοποίησης',
    'safeguard_codes_of_conduct' => 'Κώδικες δεοντολογίας',
    'safeguard_dpia' => 'Εκτίμηση Αντικτύπου στην Προστασία Δεδομένων (DPIA)',
    'safeguard_tia' => 'Εκτίμηση Αντικτύπου Διεθνούς Διαβίβασης Δεδομένων (TIA)',
    'inactive' => 'Ανενεργό',
];

// ==================== CZECH ====================
$translations['cs'] = [
    'app_title' => 'Registr GDPR',
    'company_subtitle' => 'Ochrana soukromí a compliance',
    'dashboard' => 'Přehled',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Úniky dat',
    'breach' => 'Únik dat',
    'third_parties' => 'Třetí strany',
    'third_party' => 'Třetí strana',
    'measures' => 'Opatření',
    'reporting' => 'Reporting',
    'total' => 'Celkem',
    'active' => 'Aktivní',
    'high_risk' => 'Vysoké riziko',
    'dpia_required' => 'Vyžadováno DPIA',
    'dpia_completed' => 'DPIA dokončeno',
    'new' => 'Nový',
    'export_json' => 'Export JSON',
    'search' => 'Hledat...',
    'search_company' => 'Hledat společnost...',
    'filter' => 'Filtr',
    'clear' => 'Vymazat',
    'risk' => 'Riziko',
    'risk_level' => 'Úroveň rizika',
    'status' => 'Stav',
    'retention_period' => 'Doba uchovávání',
    'actions' => 'Akce',
    'view' => 'Zobrazit',
    'edit' => 'Upravit',
    'delete' => 'Smazat',
    'print' => 'Tisk',
    'confirm_delete' => 'Opravdu chcete smazat tento záznam? Tuto akci nelze vrátit zpět.',
    'processing_activity' => 'Činnost zpracování',
    'purpose' => 'Účel',
    'data_subjects' => 'Subjekty údajů',
    'personal_data' => 'Osobní údaje',
    'recipients' => 'Příjemci',
    'legal_basis' => 'Právní základ',
    'legitimate_interest' => 'Oprávněný zájem',
    'department' => 'Oddělení',
    'or_type_custom_department' => 'Nebo zadejte vlastní oddělení',
    'or_type_custom_name' => 'Nebo zadejte jméno',
    'or_type_custom_risk_origin' => 'Nebo zadejte vlastní zdroj rizika',
    'or_type_custom_status' => 'Nebo zadejte vlastní stav',
    'or_type_custom_approval' => 'Nebo zadejte vlastní stav schválení',
    'or_type_custom_consultation' => 'Nebo zadejte vlastní hodnotu',
    'or_type_custom_compliance_status' => 'Nebo zadejte vlastní stav shody',
    'or_type_custom_breach_type' => 'Nebo zadejte vlastní typ úniku',
    'international_transfer' => 'Mezinárodní přenos',
    'to_country' => 'Do země',
    'we_are_processor' => 'Jsme zpracovatel',
    'processing_agreement_third_party' => 'Smlouva o zpracování s třetí stranou',
    'technical_measures' => 'Technická opatření',
    'organizational_measures' => 'Organizační opatření',
    'safeguards' => 'Záruky',
    'review_date' => 'Datum revize',
    'controller' => 'Správce',
    'joint_controller' => 'Společný správce',
    'dpo' => 'DPO',
    'representative' => 'Zástupce',
    'name' => 'Jméno',
    'contact' => 'Kontakt',
    'title' => 'Název',
    'description' => 'Popis',
    'risk_origin' => 'Zdroj rizika',
    'affected_subjects' => 'Dotčené subjekty',
    'management_approval' => 'Schválení vedením',
    'approved_by' => 'Schválil',
    'approval_date' => 'Datum schválení',
    'consultation_conducted' => 'Konzultace provedena',
    'consultation_details' => 'Detaily konzultace',
    'recommendations' => 'Doporučení',
    'notes' => 'Poznámky',
    'necessity_test' => 'Test nezbytnosti',
    'proportionality_test' => 'Test proporcionality',
    'mitigation_measures' => 'Zmírňující opatření',
    'residual_risk' => 'Zbytkové riziko',
    'breach_date' => 'Datum úniku',
    'discovery_date' => 'Datum zjištění',
    'breach_type' => 'Typ úniku',
    'causes' => 'Příčiny',
    'measures_taken' => 'Přijatá opatření',
    'notified_authority' => 'Úřad informován',
    'notification_date' => 'Datum oznámení',
    'notified_affected' => 'Dotčené osoby informovány',
    'company_name' => 'Název společnosti',
    'contact_person' => 'Kontaktní osoba',
    'email' => 'E-mail',
    'phone' => 'Telefon',
    'address' => 'Adresa',
    'service_provided' => 'Poskytovaná služba',
    'agreement_signed' => 'Smlouva podepsána',
    'agreement_date' => 'Datum smlouvy',
    'expiry_date' => 'Datum vypršení',
    'compliance_status' => 'Stav shody',
    'save' => 'Uložit',
    'cancel' => 'Zrušit',
    'add' => 'Přidat',
    'close' => 'Zavřít',
    'language' => 'Jazyk',
    'logout' => 'Odhlásit se',
    'logout_confirm' => 'Odhlásit se z této relace?',
    'full_report' => 'Úplná zpráva',
    'backup' => 'Záloha',
    'zip_backup' => 'ZIP záloha',
    'statistics' => 'Statistiky',
    'no_records' => 'Nebyly nalezeny žádné záznamy',
    'showing' => 'Zobrazeno',
    'of' => 'z',
    'yes' => 'Ano',
    'no' => 'Ne',
    'unknown' => 'Neznámé',
    'not_required' => 'Nevyžadováno',
    'in_progress' => 'Probíhá',
    'completed' => 'Dokončeno',
    'approved' => 'Schváleno',
    'draft' => 'Koncept',
    'open' => 'Otevřené',
    'investigating' => 'Vyšetřuje se',
    'contained' => 'Zvládnuto',
    'resolved' => 'Vyřešeno',
    'closed' => 'Uzavřeno',
    'compliant' => 'V souladu',
    'non_compliant' => 'Není v souladu',
    'review_needed' => 'Nutná revize',
    'low' => 'Nízké',
    'medium' => 'Střední',
    'high' => 'Vysoké',
    'confidentiality' => 'Důvěrnost',
    'integrity' => 'Integrita',
    'availability' => 'Dostupnost',
    'mixed' => 'Smíšené',
    'contract' => 'Smlouva',
    'consent' => 'Souhlas',
    'legal_obligation' => 'Zákonná povinnost',
    'legitimate_interests' => 'Oprávněné zájmy',
    'vital_interests' => 'Životně důležité zájmy',
    'public_task' => 'Veřejný úkol',
    'technical' => 'Technické',
    'organizational' => 'Organizační',
    'human_error' => 'Lidská chyba',
    'external' => 'Externí',
    'systematic_monitoring' => 'Systematické monitorování',
    'sensitive_data' => 'Citlivé údaje',
    'other' => 'Jiné',
    'administration' => 'Administrativa',
    'hr' => 'Lidské zdroje',
    'finance' => 'Finance',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Provoz',
    'pending' => 'Čeká se',
    'rejected' => 'Zamítnuto',
    'planned' => 'Plánováno',
    'donations' => 'Dary',
    'create_dpia' => 'Vytvořit DPIA',
    'create_dpia_from_gdpr' => 'Vytvořit DPIA z GDPR',
    'click_create_dpia_for_gdpr' => 'Klikněte na "Vytvořit DPIA" pro záznam GDPR, který vyžaduje DPIA:',
    'new_gdpr_record' => 'Nový záznam GDPR',
    'edit_gdpr_record' => 'Upravit záznam GDPR',
    'new_dpia' => 'Nové DPIA',
    'edit_dpia' => 'Upravit DPIA',
    'new_breach' => 'Nový únik dat',
    'edit_breach' => 'Upravit únik dat',
    'new_third_party' => 'Nová třetí strana',
    'edit_third_party' => 'Upravit třetí stranu',
    'record' => 'Záznam',
    'page' => 'Stránka',
    'generated' => 'Vygenerováno',
    'successfully_added' => 'úspěšně přidáno',
    'successfully_updated' => 'úspěšně aktualizováno',
    'unsaved_changes_confirm' => 'Existují neuložené změny. Opravdu chcete zrušit?',
    'select_or_type_below' => 'Vyberte nebo napište níže',
    'or_type_custom_retention_period' => 'Nebo zadejte vlastní dobu uchovávání',
    'or_type_custom_safeguards' => 'Nebo zadejte vlastní záruky (oddělené středníkem)',
    'or_type_custom_measures' => 'Nebo zadejte vlastní opatření (oddělené středníkem)',
    'hold_ctrl_to_select_multiple' => 'Podržte Ctrl (Windows) nebo Cmd (Mac) pro výběr více položek',
    'custom_mitigation_measures' => 'Vlastní zmírňující opatření (oddělené středníkem)',
    'custom_measures_taken' => 'Vlastní přijatá opatření (oddělené středníkem)',
    'custom_measures_placeholder' => 'např. vlastní opatření 1; vlastní opatření 2',
    'gdpr_record_id' => 'ID záznamu GDPR',
    'gdpr_record' => 'Záznam GDPR',
    'dpia_for_gdpr' => 'DPIA pro GDPR',
    'dpia_exists_for_gdpr' => 'Pro tento GDPR již DPIA existuje',
    'for_gdpr_record' => 'pro záznam GDPR',
    'only_one_dpia_allowed' => 'Pro každý záznam GDPR je povoleno pouze jedno DPIA.',
    'risk_distribution' => 'Rozložení rizik',
    'gdpr_compliance_overview' => 'Přehled shody GDPR',
    'inactive_draft' => 'Neaktivní / Koncept',
    'collected_from_records' => 'Shromážděno ze záznamů',
    'measure' => 'Opatření',
    'value' => 'Hodnota',
    'source' => 'Zdroj',
    'configuration' => 'Konfigurace',
    'no_technical_measures' => 'Nebyla nalezena žádná technická opatření',
    'no_organizational_measures' => 'Nebyla nalezena žádná organizační opatření',
    'edit_measure' => 'Upravit opatření',
    'current_measure' => 'Aktuální opatření',
    'new_measure_name' => 'Nový název opatření',
    'measure_renamed_success' => 'Opatření bylo úspěšně přejmenováno všude, kde se používá.',
    'measure_rename_warning' => 'Tímto se přejmenuje opatření ve všech záznamech GDPR, DPIA a úniku dat, kde se používá.',
    'measure_deleted_success' => 'Opatření bylo úspěšně odstraněno ze všech míst, kde bylo použito.',
    'confirm_delete_measure' => 'Opravdu chcete smazat toto opatření? Bude odstraněno ze všech záznamů GDPR, DPIA a úniku dat, kde se používá. Tuto akci nelze vrátit zpět.',
    'responsible' => 'Odpovědná osoba',
    'responsible_placeholder' => 'Kdo je odpovědný za toto opatření?',
    'unassigned' => 'Nepřiřazeno',
    'value_renamed_success' => 'Hodnota byla úspěšně přejmenována všude, kde se používá.',
    'value_deleted_success' => 'Hodnota byla úspěšně odstraněna ze všech míst, kde byla použita.',
    'edit_value' => 'Upravit hodnotu',
    'delete_value' => 'Smazat hodnotu',
    'current_value' => 'Aktuální hodnota',
    'new_value' => 'Nová hodnota',
    'value_rename_warning' => 'Přejmenování aktualizuje tuto hodnotu všude, kde se aktuálně používá.',
    'value_delete_warning' => 'Smazání odstraní tuto hodnotu ze všech záznamů, kde se aktuálně používá. Tuto akci nelze vrátit zpět.',
    'confirm_delete_value' => 'Smazat tuto hodnotu všude, kde se používá? Tuto akci nelze vrátit zpět.',
    'used_in' => 'Použito v',
    'not_currently_used' => 'Aktuálně se nepoužívá',
    'no_values' => 'Nebyly nalezeny žádné hodnoty',
    'total_gdpr_records' => 'Celkový počet záznamů GDPR',
    'dpia_in_progress' => 'DPIA probíhá',
    'total_breaches' => 'Celkový počet úniků',
    'open_breaches' => 'Otevřené úniky',
    'total_third_parties' => 'Celkový počet třetích stran',
    'compliant_third_parties' => 'Třetí strany v souladu',
    'dpia_coverage' => 'Pokrytí DPIA',
    'gdpr_with_dpia_required' => 'GDPR vyžadující DPIA',
    'dpia_completion_rate' => 'Míra dokončení DPIA',
    'category' => 'Kategorie',
    'overview' => 'Přehled',
    'per_category' => 'Podle kategorie',
    'total_risk' => 'Celkové riziko',
    'completion_rate' => 'Míra dokončení',
    'record_type' => 'Typ záznamu',
    'print_report_title' => 'Zpráva o shodě',
    'generated_on' => 'Vygenerováno dne',
    'not_started' => 'Nezahájeno',
    'safeguard_scc' => 'Standardní smluvní doložky (SCC)',
    'safeguard_bcr' => 'Závazná podniková pravidla (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (již neplatí)',
    'safeguard_adequacy_decision' => 'Rozhodnutí Evropské komise o odpovídající ochraně',
    'safeguard_consent' => 'Konkrétní souhlas subjektu údajů',
    'safeguard_model_contracts' => 'Vzorové smlouvy',
    'safeguard_certification' => 'Certifikační mechanismy',
    'safeguard_codes_of_conduct' => 'Kodexy chování',
    'safeguard_dpia' => 'Posouzení vlivu na ochranu osobních údajů (DPIA)',
    'safeguard_tia' => 'Posouzení dopadu mezinárodního přenosu údajů (TIA)',
    'inactive' => 'Neaktivní',
];

// ==================== ROMANIAN ====================
$translations['ro'] = [
    'app_title' => 'Registru GDPR',
    'company_subtitle' => 'Confidențialitate și Conformitate',
    'dashboard' => 'Panou de bord',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Încălcări de Date',
    'breach' => 'Încălcare de Date',
    'third_parties' => 'Terți',
    'third_party' => 'Terț',
    'measures' => 'Măsuri',
    'reporting' => 'Raportare',
    'total' => 'Total',
    'active' => 'Activ',
    'high_risk' => 'Risc Ridicat',
    'dpia_required' => 'DPIA Necesară',
    'dpia_completed' => 'DPIA Finalizată',
    'new' => 'Nou',
    'export_json' => 'Export JSON',
    'search' => 'Căutare...',
    'search_company' => 'Căutare companie...',
    'filter' => 'Filtru',
    'clear' => 'Șterge',
    'risk' => 'Risc',
    'risk_level' => 'Nivel de Risc',
    'status' => 'Stare',
    'retention_period' => 'Perioadă de Retenție',
    'actions' => 'Acțiuni',
    'view' => 'Vizualizare',
    'edit' => 'Editare',
    'delete' => 'Ștergere',
    'print' => 'Printare',
    'confirm_delete' => 'Sigur doriți să ștergeți această înregistrare? Această acțiune nu poate fi anulată.',
    'processing_activity' => 'Activitate de Prelucrare',
    'purpose' => 'Scop',
    'data_subjects' => 'Persoane Vizate',
    'personal_data' => 'Date Personale',
    'recipients' => 'Destinatari',
    'legal_basis' => 'Temei Juridic',
    'legitimate_interest' => 'Interes Legitim',
    'department' => 'Departament',
    'or_type_custom_department' => 'Sau introduceți un departament personalizat',
    'or_type_custom_name' => 'Sau introduceți un nume',
    'or_type_custom_risk_origin' => 'Sau introduceți o origine a riscului personalizată',
    'or_type_custom_status' => 'Sau introduceți o stare personalizată',
    'or_type_custom_approval' => 'Sau introduceți o stare de aprobare personalizată',
    'or_type_custom_consultation' => 'Sau introduceți o valoare personalizată',
    'or_type_custom_compliance_status' => 'Sau introduceți o stare de conformitate personalizată',
    'or_type_custom_breach_type' => 'Sau introduceți un tip de încălcare personalizat',
    'international_transfer' => 'Transfer Internațional',
    'to_country' => 'Către Țara',
    'we_are_processor' => 'Suntem Persoana Împuternicită',
    'processing_agreement_third_party' => 'Acord de Prelucrare cu Terțul',
    'technical_measures' => 'Măsuri Tehnice',
    'organizational_measures' => 'Măsuri Organizatorice',
    'safeguards' => 'Garanții',
    'review_date' => 'Data Revizuirii',
    'controller' => 'Operator',
    'joint_controller' => 'Operator Asociat',
    'dpo' => 'DPO',
    'representative' => 'Reprezentant',
    'name' => 'Nume',
    'contact' => 'Contact',
    'title' => 'Titlu',
    'description' => 'Descriere',
    'risk_origin' => 'Origine a Riscului',
    'affected_subjects' => 'Persoane Afectate',
    'management_approval' => 'Aprobare Managerială',
    'approved_by' => 'Aprobat de',
    'approval_date' => 'Data Aprobării',
    'consultation_conducted' => 'Consultare Efectuată',
    'consultation_details' => 'Detalii Consultare',
    'recommendations' => 'Recomandări',
    'notes' => 'Note',
    'necessity_test' => 'Test de Necesitate',
    'proportionality_test' => 'Test de Proporționalitate',
    'mitigation_measures' => 'Măsuri de Atenuare',
    'residual_risk' => 'Risc Rezidual',
    'breach_date' => 'Data Încălcării',
    'discovery_date' => 'Data Descoperirii',
    'breach_type' => 'Tip de Încălcare',
    'causes' => 'Cauze',
    'measures_taken' => 'Măsuri Luate',
    'notified_authority' => 'Autoritate Notificată',
    'notification_date' => 'Data Notificării',
    'notified_affected' => 'Persoane Afectate Notificate',
    'company_name' => 'Denumire Companie',
    'contact_person' => 'Persoană de Contact',
    'email' => 'E-mail',
    'phone' => 'Telefon',
    'address' => 'Adresă',
    'service_provided' => 'Serviciu Furnizat',
    'agreement_signed' => 'Acord Semnat',
    'agreement_date' => 'Data Acordului',
    'expiry_date' => 'Data Expirării',
    'compliance_status' => 'Stare de Conformitate',
    'save' => 'Salvare',
    'cancel' => 'Anulare',
    'add' => 'Adăugare',
    'close' => 'Închidere',
    'language' => 'Limbă',
    'logout' => 'Deconectare',
    'logout_confirm' => 'Deconectați-vă din această sesiune?',
    'full_report' => 'Raport Complet',
    'backup' => 'Backup',
    'zip_backup' => 'Backup ZIP',
    'statistics' => 'Statistici',
    'no_records' => 'Nu au fost găsite înregistrări',
    'showing' => 'Se afișează',
    'of' => 'din',
    'yes' => 'Da',
    'no' => 'Nu',
    'unknown' => 'Necunoscut',
    'not_required' => 'Nu este Necesar',
    'in_progress' => 'În Curs',
    'completed' => 'Finalizat',
    'approved' => 'Aprobat',
    'draft' => 'Ciornă',
    'open' => 'Deschis',
    'investigating' => 'În Investigare',
    'contained' => 'Izolat',
    'resolved' => 'Rezolvat',
    'closed' => 'Închis',
    'compliant' => 'Conform',
    'non_compliant' => 'Neconform',
    'review_needed' => 'Necesită Revizuire',
    'low' => 'Scăzut',
    'medium' => 'Mediu',
    'high' => 'Ridicat',
    'confidentiality' => 'Confidențialitate',
    'integrity' => 'Integritate',
    'availability' => 'Disponibilitate',
    'mixed' => 'Mixt',
    'contract' => 'Contract',
    'consent' => 'Consimțământ',
    'legal_obligation' => 'Obligație Legală',
    'legitimate_interests' => 'Interese Legitime',
    'vital_interests' => 'Interese Vitale',
    'public_task' => 'Sarcină Publică',
    'technical' => 'Tehnic',
    'organizational' => 'Organizatoric',
    'human_error' => 'Eroare Umană',
    'external' => 'Extern',
    'systematic_monitoring' => 'Monitorizare Sistematică',
    'sensitive_data' => 'Date Sensibile',
    'other' => 'Altul',
    'administration' => 'Administrație',
    'hr' => 'Resurse Umane',
    'finance' => 'Finanțe',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Operațiuni',
    'pending' => 'În Așteptare',
    'rejected' => 'Respins',
    'planned' => 'Planificat',
    'donations' => 'Donații',
    'create_dpia' => 'Creare DPIA',
    'create_dpia_from_gdpr' => 'Creare DPIA din GDPR',
    'click_create_dpia_for_gdpr' => 'Faceți clic pe „Creare DPIA” pentru o înregistrare GDPR care necesită DPIA:',
    'new_gdpr_record' => 'Înregistrare GDPR Nouă',
    'edit_gdpr_record' => 'Editare Înregistrare GDPR',
    'new_dpia' => 'DPIA Nouă',
    'edit_dpia' => 'Editare DPIA',
    'new_breach' => 'Încălcare de Date Nouă',
    'edit_breach' => 'Editare Încălcare de Date',
    'new_third_party' => 'Terț Nou',
    'edit_third_party' => 'Editare Terț',
    'record' => 'Înregistrare',
    'page' => 'Pagină',
    'generated' => 'Generat',
    'successfully_added' => 'adăugat cu succes',
    'successfully_updated' => 'actualizat cu succes',
    'unsaved_changes_confirm' => 'Există modificări nesalvate. Sigur doriți să anulați?',
    'select_or_type_below' => 'Selectați sau introduceți mai jos',
    'or_type_custom_retention_period' => 'Sau introduceți o perioadă de retenție personalizată',
    'or_type_custom_safeguards' => 'Sau introduceți garanții personalizate (separate prin punct și virgulă)',
    'or_type_custom_measures' => 'Sau introduceți măsuri personalizate (separate prin punct și virgulă)',
    'hold_ctrl_to_select_multiple' => 'Țineți apăsat Ctrl (Windows) sau Cmd (Mac) pentru selecție multiplă',
    'custom_mitigation_measures' => 'Măsuri de atenuare personalizate (separate prin punct și virgulă)',
    'custom_measures_taken' => 'Măsuri personalizate luate (separate prin punct și virgulă)',
    'custom_measures_placeholder' => 'ex. Măsură personalizată 1; Măsură personalizată 2',
    'gdpr_record_id' => 'ID Înregistrare GDPR',
    'gdpr_record' => 'Înregistrare GDPR',
    'dpia_for_gdpr' => 'DPIA pentru GDPR',
    'dpia_exists_for_gdpr' => 'Există deja o DPIA pentru GDPR',
    'for_gdpr_record' => 'pentru înregistrarea GDPR',
    'only_one_dpia_allowed' => 'Este permisă o singură DPIA per înregistrare GDPR.',
    'risk_distribution' => 'Distribuția Riscurilor',
    'gdpr_compliance_overview' => 'Prezentare Generală Conformitate GDPR',
    'inactive_draft' => 'Inactiv / Ciornă',
    'collected_from_records' => 'Colectat din înregistrări',
    'measure' => 'Măsură',
    'value' => 'Valoare',
    'source' => 'Sursă',
    'configuration' => 'Configurație',
    'no_technical_measures' => 'Nu au fost găsite măsuri tehnice',
    'no_organizational_measures' => 'Nu au fost găsite măsuri organizatorice',
    'edit_measure' => 'Editare Măsură',
    'current_measure' => 'Măsură Curentă',
    'new_measure_name' => 'Nume Măsură Nouă',
    'measure_renamed_success' => 'Măsura a fost redenumită cu succes peste tot unde este utilizată.',
    'measure_rename_warning' => 'Aceasta va redenumi măsura în fiecare înregistrare GDPR, DPIA și Încălcare de Date în care este utilizată.',
    'measure_deleted_success' => 'Măsura a fost ștearsă cu succes de peste tot unde a fost utilizată.',
    'confirm_delete_measure' => 'Sigur doriți să ștergeți această măsură? Va fi eliminată din fiecare înregistrare GDPR, DPIA și Încălcare de Date în care este utilizată. Această acțiune nu poate fi anulată.',
    'responsible' => 'Responsabil',
    'responsible_placeholder' => 'Cine este responsabil pentru această măsură?',
    'unassigned' => 'Neatribuit',
    'value_renamed_success' => 'Valoarea a fost redenumită cu succes peste tot unde este utilizată.',
    'value_deleted_success' => 'Valoarea a fost eliminată cu succes de peste tot unde a fost utilizată.',
    'edit_value' => 'Editare valoare',
    'delete_value' => 'Ștergere valoare',
    'current_value' => 'Valoare curentă',
    'new_value' => 'Valoare nouă',
    'value_rename_warning' => 'Redenumirea va actualiza această valoare peste tot unde este utilizată în prezent.',
    'value_delete_warning' => 'Ștergerea va elimina această valoare din fiecare înregistrare în care este utilizată în prezent. Această acțiune nu poate fi anulată.',
    'confirm_delete_value' => 'Ștergeți această valoare peste tot unde este utilizată? Această acțiune nu poate fi anulată.',
    'used_in' => 'Utilizat în',
    'not_currently_used' => 'Nu este utilizat în prezent',
    'no_values' => 'Nu au fost găsite valori',
    'total_gdpr_records' => 'Total înregistrări GDPR',
    'dpia_in_progress' => 'DPIA în curs',
    'total_breaches' => 'Total încălcări',
    'open_breaches' => 'Încălcări deschise',
    'total_third_parties' => 'Total terți',
    'compliant_third_parties' => 'Terți conformi',
    'dpia_coverage' => 'Acoperire DPIA',
    'gdpr_with_dpia_required' => 'GDPR care necesită DPIA',
    'dpia_completion_rate' => 'Rata de finalizare DPIA',
    'category' => 'Categorie',
    'overview' => 'Prezentare Generală',
    'per_category' => 'Pe Categorie',
    'total_risk' => 'Risc Total',
    'completion_rate' => 'Rată de Finalizare',
    'record_type' => 'Tip de Înregistrare',
    'print_report_title' => 'Raport de Conformitate',
    'generated_on' => 'Generat la',
    'not_started' => 'Neînceput',
    'safeguard_scc' => 'Clauze Contractuale Standard (SCC)',
    'safeguard_bcr' => 'Reguli Corporative Obligatorii (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (nu mai este valabil)',
    'safeguard_adequacy_decision' => 'Decizie de Adecvare a Comisiei Europene',
    'safeguard_consent' => 'Consimțământ specific din partea persoanei vizate',
    'safeguard_model_contracts' => 'Contracte-model',
    'safeguard_certification' => 'Mecanisme de certificare',
    'safeguard_codes_of_conduct' => 'Coduri de conduită',
    'safeguard_dpia' => 'Evaluarea Impactului asupra Protecției Datelor (DPIA)',
    'safeguard_tia' => 'Evaluarea Impactului Transferului Internațional de Date (TIA)',
    'inactive' => 'Inactiv',
];

// ==================== HUNGARIAN ====================
$translations['hu'] = [
    'app_title' => 'GDPR Nyilvántartás',
    'company_subtitle' => 'Adatvédelem és megfelelőség',
    'dashboard' => 'Irányítópult',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Adatvédelmi incidensek',
    'breach' => 'Adatvédelmi incidens',
    'third_parties' => 'Harmadik felek',
    'third_party' => 'Harmadik fél',
    'measures' => 'Intézkedések',
    'reporting' => 'Jelentések',
    'total' => 'Összesen',
    'active' => 'Aktív',
    'high_risk' => 'Magas kockázat',
    'dpia_required' => 'DPIA szükséges',
    'dpia_completed' => 'DPIA elkészült',
    'new' => 'Új',
    'export_json' => 'JSON exportálás',
    'search' => 'Keresés...',
    'search_company' => 'Cég keresése...',
    'filter' => 'Szűrő',
    'clear' => 'Törlés',
    'risk' => 'Kockázat',
    'risk_level' => 'Kockázati szint',
    'status' => 'Állapot',
    'retention_period' => 'Megőrzési idő',
    'actions' => 'Műveletek',
    'view' => 'Megtekintés',
    'edit' => 'Szerkesztés',
    'delete' => 'Törlés',
    'print' => 'Nyomtatás',
    'confirm_delete' => 'Biztosan törli ezt a rekordot? Ez a művelet nem vonható vissza.',
    'processing_activity' => 'Adatkezelési tevékenység',
    'purpose' => 'Cél',
    'data_subjects' => 'Érintettek',
    'personal_data' => 'Személyes adatok',
    'recipients' => 'Címzettek',
    'legal_basis' => 'Jogalap',
    'legitimate_interest' => 'Jogos érdek',
    'department' => 'Osztály',
    'or_type_custom_department' => 'Vagy adjon meg egyéni osztályt',
    'or_type_custom_name' => 'Vagy adjon meg nevet',
    'or_type_custom_risk_origin' => 'Vagy adjon meg egyéni kockázati forrást',
    'or_type_custom_status' => 'Vagy adjon meg egyéni állapotot',
    'or_type_custom_approval' => 'Vagy adjon meg egyéni jóváhagyási állapotot',
    'or_type_custom_consultation' => 'Vagy adjon meg egyéni értéket',
    'or_type_custom_compliance_status' => 'Vagy adjon meg egyéni megfelelőségi állapotot',
    'or_type_custom_breach_type' => 'Vagy adjon meg egyéni incidenstípust',
    'international_transfer' => 'Nemzetközi adattovábbítás',
    'to_country' => 'Célország',
    'we_are_processor' => 'Mi vagyunk az adatfeldolgozó',
    'processing_agreement_third_party' => 'Adatfeldolgozási megállapodás harmadik féllel',
    'technical_measures' => 'Technikai intézkedések',
    'organizational_measures' => 'Szervezési intézkedések',
    'safeguards' => 'Garanciák',
    'review_date' => 'Felülvizsgálat dátuma',
    'controller' => 'Adatkezelő',
    'joint_controller' => 'Közös adatkezelő',
    'dpo' => 'DPO',
    'representative' => 'Képviselő',
    'name' => 'Név',
    'contact' => 'Kapcsolat',
    'title' => 'Cím',
    'description' => 'Leírás',
    'risk_origin' => 'Kockázat forrása',
    'affected_subjects' => 'Érintett személyek',
    'management_approval' => 'Vezetői jóváhagyás',
    'approved_by' => 'Jóváhagyta',
    'approval_date' => 'Jóváhagyás dátuma',
    'consultation_conducted' => 'Konzultáció megtörtént',
    'consultation_details' => 'Konzultáció részletei',
    'recommendations' => 'Ajánlások',
    'notes' => 'Megjegyzések',
    'necessity_test' => 'Szükségességi teszt',
    'proportionality_test' => 'Arányossági teszt',
    'mitigation_measures' => 'Kockázatcsökkentő intézkedések',
    'residual_risk' => 'Maradványkockázat',
    'breach_date' => 'Incidens dátuma',
    'discovery_date' => 'Felfedezés dátuma',
    'breach_type' => 'Incidens típusa',
    'causes' => 'Okok',
    'measures_taken' => 'Megtett intézkedések',
    'notified_authority' => 'Hatóság értesítve',
    'notification_date' => 'Értesítés dátuma',
    'notified_affected' => 'Érintettek értesítve',
    'company_name' => 'Cégnév',
    'contact_person' => 'Kapcsolattartó',
    'email' => 'E-mail',
    'phone' => 'Telefon',
    'address' => 'Cím',
    'service_provided' => 'Nyújtott szolgáltatás',
    'agreement_signed' => 'Megállapodás aláírva',
    'agreement_date' => 'Megállapodás dátuma',
    'expiry_date' => 'Lejárat dátuma',
    'compliance_status' => 'Megfelelőségi állapot',
    'save' => 'Mentés',
    'cancel' => 'Mégse',
    'add' => 'Hozzáadás',
    'close' => 'Bezárás',
    'language' => 'Nyelv',
    'logout' => 'Kijelentkezés',
    'logout_confirm' => 'Kijelentkezik ebből a munkamenetből?',
    'full_report' => 'Teljes jelentés',
    'backup' => 'Biztonsági mentés',
    'zip_backup' => 'ZIP mentés',
    'statistics' => 'Statisztikák',
    'no_records' => 'Nem található rekord',
    'showing' => 'Megjelenítve',
    'of' => '/',
    'yes' => 'Igen',
    'no' => 'Nem',
    'unknown' => 'Ismeretlen',
    'not_required' => 'Nem szükséges',
    'in_progress' => 'Folyamatban',
    'completed' => 'Befejezve',
    'approved' => 'Jóváhagyva',
    'draft' => 'Tervezet',
    'open' => 'Nyitott',
    'investigating' => 'Kivizsgálás alatt',
    'contained' => 'Elhárítva',
    'resolved' => 'Megoldva',
    'closed' => 'Lezárva',
    'compliant' => 'Megfelelő',
    'non_compliant' => 'Nem megfelelő',
    'review_needed' => 'Felülvizsgálat szükséges',
    'low' => 'Alacsony',
    'medium' => 'Közepes',
    'high' => 'Magas',
    'confidentiality' => 'Bizalmasság',
    'integrity' => 'Sértetlenség',
    'availability' => 'Rendelkezésre állás',
    'mixed' => 'Vegyes',
    'contract' => 'Szerződés',
    'consent' => 'Hozzájárulás',
    'legal_obligation' => 'Jogi kötelezettség',
    'legitimate_interests' => 'Jogos érdekek',
    'vital_interests' => 'Létfontosságú érdekek',
    'public_task' => 'Közfeladat',
    'technical' => 'Technikai',
    'organizational' => 'Szervezési',
    'human_error' => 'Emberi hiba',
    'external' => 'Külső',
    'systematic_monitoring' => 'Rendszeres megfigyelés',
    'sensitive_data' => 'Különleges adatok',
    'other' => 'Egyéb',
    'administration' => 'Adminisztráció',
    'hr' => 'HR',
    'finance' => 'Pénzügy',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Üzemeltetés',
    'pending' => 'Függőben',
    'rejected' => 'Elutasítva',
    'planned' => 'Tervezett',
    'donations' => 'Adományok',
    'create_dpia' => 'DPIA létrehozása',
    'create_dpia_from_gdpr' => 'DPIA létrehozása GDPR alapján',
    'click_create_dpia_for_gdpr' => 'Kattintson a „DPIA létrehozása” gombra egy DPIA-t igénylő GDPR-rekordhoz:',
    'new_gdpr_record' => 'Új GDPR-rekord',
    'edit_gdpr_record' => 'GDPR-rekord szerkesztése',
    'new_dpia' => 'Új DPIA',
    'edit_dpia' => 'DPIA szerkesztése',
    'new_breach' => 'Új adatvédelmi incidens',
    'edit_breach' => 'Adatvédelmi incidens szerkesztése',
    'new_third_party' => 'Új harmadik fél',
    'edit_third_party' => 'Harmadik fél szerkesztése',
    'record' => 'Rekord',
    'page' => 'Oldal',
    'generated' => 'Létrehozva',
    'successfully_added' => 'sikeresen hozzáadva',
    'successfully_updated' => 'sikeresen frissítve',
    'unsaved_changes_confirm' => 'Vannak nem mentett módosítások. Biztosan mégsem szeretné?',
    'select_or_type_below' => 'Válasszon vagy írjon be alább',
    'or_type_custom_retention_period' => 'Vagy adjon meg egyéni megőrzési időt',
    'or_type_custom_safeguards' => 'Vagy adjon meg egyéni garanciákat (pontosvesszővel elválasztva)',
    'or_type_custom_measures' => 'Vagy adjon meg egyéni intézkedéseket (pontosvesszővel elválasztva)',
    'hold_ctrl_to_select_multiple' => 'Tartsa lenyomva a Ctrl (Windows) vagy Cmd (Mac) billentyűt a többes kijelöléshez',
    'custom_mitigation_measures' => 'Egyéni kockázatcsökkentő intézkedések (pontosvesszővel elválasztva)',
    'custom_measures_taken' => 'Egyéni megtett intézkedések (pontosvesszővel elválasztva)',
    'custom_measures_placeholder' => 'pl. Egyéni intézkedés 1; Egyéni intézkedés 2',
    'gdpr_record_id' => 'GDPR-rekord azonosító',
    'gdpr_record' => 'GDPR-rekord',
    'dpia_for_gdpr' => 'DPIA a GDPR-hez',
    'dpia_exists_for_gdpr' => 'Már létezik DPIA ehhez a GDPR-hez',
    'for_gdpr_record' => 'a GDPR-rekordhoz',
    'only_one_dpia_allowed' => 'GDPR-rekordonként csak egy DPIA engedélyezett.',
    'risk_distribution' => 'Kockázateloszlás',
    'gdpr_compliance_overview' => 'GDPR megfelelőségi áttekintés',
    'inactive_draft' => 'Inaktív / Tervezet',
    'collected_from_records' => 'Rekordokból gyűjtve',
    'measure' => 'Intézkedés',
    'value' => 'Érték',
    'source' => 'Forrás',
    'configuration' => 'Konfiguráció',
    'no_technical_measures' => 'Nem található technikai intézkedés',
    'no_organizational_measures' => 'Nem található szervezési intézkedés',
    'edit_measure' => 'Intézkedés szerkesztése',
    'current_measure' => 'Jelenlegi intézkedés',
    'new_measure_name' => 'Új intézkedés neve',
    'measure_renamed_success' => 'Az intézkedés sikeresen átnevezve mindenhol, ahol használatban van.',
    'measure_rename_warning' => 'Ez átnevezi az intézkedést minden olyan GDPR-, DPIA- és adatvédelmi incidens rekordban, ahol használatban van.',
    'measure_deleted_success' => 'Az intézkedés sikeresen törölve mindenhonnan, ahol használatban volt.',
    'confirm_delete_measure' => 'Biztosan törli ezt az intézkedést? Minden olyan GDPR-, DPIA- és adatvédelmi incidens rekordból eltávolításra kerül, ahol használatban van. Ez a művelet nem vonható vissza.',
    'responsible' => 'Felelős',
    'responsible_placeholder' => 'Ki felelős ezért az intézkedésért?',
    'unassigned' => 'Nincs hozzárendelve',
    'value_renamed_success' => 'Az érték sikeresen átnevezve mindenhol, ahol használatban van.',
    'value_deleted_success' => 'Az érték sikeresen eltávolítva mindenhonnan, ahol használatban volt.',
    'edit_value' => 'Érték szerkesztése',
    'delete_value' => 'Érték törlése',
    'current_value' => 'Jelenlegi érték',
    'new_value' => 'Új érték',
    'value_rename_warning' => 'Az átnevezés frissíti ezt az értéket mindenhol, ahol jelenleg használatban van.',
    'value_delete_warning' => 'A törlés eltávolítja ezt az értéket minden olyan rekordból, ahol jelenleg használatban van. Ez a művelet nem vonható vissza.',
    'confirm_delete_value' => 'Törli ezt az értéket mindenhol, ahol használatban van? Ez a művelet nem vonható vissza.',
    'used_in' => 'Használatban itt',
    'not_currently_used' => 'Jelenleg nincs használatban',
    'no_values' => 'Nem találhatók értékek',
    'total_gdpr_records' => 'GDPR-rekordok összesen',
    'dpia_in_progress' => 'Folyamatban lévő DPIA',
    'total_breaches' => 'Incidensek összesen',
    'open_breaches' => 'Nyitott incidensek',
    'total_third_parties' => 'Harmadik felek összesen',
    'compliant_third_parties' => 'Megfelelő harmadik felek',
    'dpia_coverage' => 'DPIA lefedettség',
    'gdpr_with_dpia_required' => 'DPIA-t igénylő GDPR-ek',
    'dpia_completion_rate' => 'DPIA teljesítési arány',
    'category' => 'Kategória',
    'overview' => 'Áttekintés',
    'per_category' => 'Kategóriánként',
    'total_risk' => 'Teljes kockázat',
    'completion_rate' => 'Teljesítési arány',
    'record_type' => 'Rekord típusa',
    'print_report_title' => 'Megfelelőségi jelentés',
    'generated_on' => 'Létrehozva ekkor',
    'not_started' => 'Nem kezdődött el',
    'safeguard_scc' => 'Általános szerződési feltételek (SCC)',
    'safeguard_bcr' => 'Kötelező erejű vállalati szabályok (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (már nem érvényes)',
    'safeguard_adequacy_decision' => 'Európai Bizottság megfelelőségi határozata',
    'safeguard_consent' => 'Az érintett kifejezett hozzájárulása',
    'safeguard_model_contracts' => 'Mintaszerződések',
    'safeguard_certification' => 'Tanúsítási mechanizmusok',
    'safeguard_codes_of_conduct' => 'Magatartási kódexek',
    'safeguard_dpia' => 'Adatvédelmi hatásvizsgálat (DPIA)',
    'safeguard_tia' => 'Nemzetközi adattovábbítási hatásvizsgálat (TIA)',
    'inactive' => 'Inaktív',
];

// ==================== BULGARIAN ====================
$translations['bg'] = [
    'app_title' => 'Регистър по GDPR',
    'company_subtitle' => 'Поверителност и съответствие',
    'dashboard' => 'Табло',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Нарушения на данни',
    'breach' => 'Нарушение на данни',
    'third_parties' => 'Трети страни',
    'third_party' => 'Трета страна',
    'measures' => 'Мерки',
    'reporting' => 'Отчитане',
    'total' => 'Общо',
    'active' => 'Активен',
    'high_risk' => 'Висок риск',
    'dpia_required' => 'Изисква се DPIA',
    'dpia_completed' => 'DPIA завършена',
    'new' => 'Нов',
    'export_json' => 'Експорт JSON',
    'search' => 'Търсене...',
    'search_company' => 'Търсене на компания...',
    'filter' => 'Филтър',
    'clear' => 'Изчисти',
    'risk' => 'Риск',
    'risk_level' => 'Ниво на риск',
    'status' => 'Статус',
    'retention_period' => 'Период на съхранение',
    'actions' => 'Действия',
    'view' => 'Преглед',
    'edit' => 'Редактиране',
    'delete' => 'Изтриване',
    'print' => 'Печат',
    'confirm_delete' => 'Наистина ли искате да изтриете този запис? Това действие не може да бъде отменено.',
    'processing_activity' => 'Дейност по обработка',
    'purpose' => 'Цел',
    'data_subjects' => 'Субекти на данни',
    'personal_data' => 'Лични данни',
    'recipients' => 'Получатели',
    'legal_basis' => 'Правно основание',
    'legitimate_interest' => 'Законен интерес',
    'department' => 'Отдел',
    'or_type_custom_department' => 'Или въведете персонализиран отдел',
    'or_type_custom_name' => 'Или въведете име',
    'or_type_custom_risk_origin' => 'Или въведете персонализиран източник на риск',
    'or_type_custom_status' => 'Или въведете персонализиран статус',
    'or_type_custom_approval' => 'Или въведете персонализиран статус на одобрение',
    'or_type_custom_consultation' => 'Или въведете персонализирана стойност',
    'or_type_custom_compliance_status' => 'Или въведете персонализиран статус на съответствие',
    'or_type_custom_breach_type' => 'Или въведете персонализиран тип нарушение',
    'international_transfer' => 'Международно предаване',
    'to_country' => 'До държава',
    'we_are_processor' => 'Ние сме обработващ',
    'processing_agreement_third_party' => 'Споразумение за обработка с трета страна',
    'technical_measures' => 'Технически мерки',
    'organizational_measures' => 'Организационни мерки',
    'safeguards' => 'Гаранции',
    'review_date' => 'Дата на преглед',
    'controller' => 'Администратор',
    'joint_controller' => 'Съвместен администратор',
    'dpo' => 'DPO',
    'representative' => 'Представител',
    'name' => 'Име',
    'contact' => 'Контакт',
    'title' => 'Заглавие',
    'description' => 'Описание',
    'risk_origin' => 'Източник на риска',
    'affected_subjects' => 'Засегнати субекти',
    'management_approval' => 'Одобрение от ръководството',
    'approved_by' => 'Одобрено от',
    'approval_date' => 'Дата на одобрение',
    'consultation_conducted' => 'Проведена консултация',
    'consultation_details' => 'Детайли за консултацията',
    'recommendations' => 'Препоръки',
    'notes' => 'Бележки',
    'necessity_test' => 'Тест за необходимост',
    'proportionality_test' => 'Тест за пропорционалност',
    'mitigation_measures' => 'Мерки за смекчаване',
    'residual_risk' => 'Остатъчен риск',
    'breach_date' => 'Дата на нарушението',
    'discovery_date' => 'Дата на откриване',
    'breach_type' => 'Тип нарушение',
    'causes' => 'Причини',
    'measures_taken' => 'Предприети мерки',
    'notified_authority' => 'Уведомен орган',
    'notification_date' => 'Дата на уведомление',
    'notified_affected' => 'Уведомени засегнати лица',
    'company_name' => 'Име на компанията',
    'contact_person' => 'Лице за контакт',
    'email' => 'Имейл',
    'phone' => 'Телефон',
    'address' => 'Адрес',
    'service_provided' => 'Предоставяна услуга',
    'agreement_signed' => 'Споразумение подписано',
    'agreement_date' => 'Дата на споразумението',
    'expiry_date' => 'Дата на изтичане',
    'compliance_status' => 'Статус на съответствие',
    'save' => 'Запази',
    'cancel' => 'Отказ',
    'add' => 'Добави',
    'close' => 'Затвори',
    'language' => 'Език',
    'logout' => 'Изход',
    'logout_confirm' => 'Да излезете от тази сесия?',
    'full_report' => 'Пълен отчет',
    'backup' => 'Резервно копие',
    'zip_backup' => 'ZIP резервно копие',
    'statistics' => 'Статистика',
    'no_records' => 'Не са намерени записи',
    'showing' => 'Показване на',
    'of' => 'от',
    'yes' => 'Да',
    'no' => 'Не',
    'unknown' => 'Неизвестно',
    'not_required' => 'Не се изисква',
    'in_progress' => 'В процес',
    'completed' => 'Завършено',
    'approved' => 'Одобрено',
    'draft' => 'Чернова',
    'open' => 'Отворено',
    'investigating' => 'Разследва се',
    'contained' => 'Овладяно',
    'resolved' => 'Разрешено',
    'closed' => 'Затворено',
    'compliant' => 'Съответстващо',
    'non_compliant' => 'Несъответстващо',
    'review_needed' => 'Необходим преглед',
    'low' => 'Нисък',
    'medium' => 'Среден',
    'high' => 'Висок',
    'confidentiality' => 'Поверителност',
    'integrity' => 'Цялостност',
    'availability' => 'Наличност',
    'mixed' => 'Смесено',
    'contract' => 'Договор',
    'consent' => 'Съгласие',
    'legal_obligation' => 'Правно задължение',
    'legitimate_interests' => 'Законни интереси',
    'vital_interests' => 'Жизненоважни интереси',
    'public_task' => 'Обществена задача',
    'technical' => 'Техническо',
    'organizational' => 'Организационно',
    'human_error' => 'Човешка грешка',
    'external' => 'Външно',
    'systematic_monitoring' => 'Системно наблюдение',
    'sensitive_data' => 'Чувствителни данни',
    'other' => 'Друго',
    'administration' => 'Администрация',
    'hr' => 'Човешки ресурси',
    'finance' => 'Финанси',
    'marketing' => 'Маркетинг',
    'it' => 'ИТ',
    'operations' => 'Операции',
    'pending' => 'В очакване',
    'rejected' => 'Отхвърлено',
    'planned' => 'Планирано',
    'donations' => 'Дарения',
    'create_dpia' => 'Създай DPIA',
    'create_dpia_from_gdpr' => 'Създай DPIA от GDPR',
    'click_create_dpia_for_gdpr' => 'Кликнете „Създай DPIA“ за GDPR запис, който изисква DPIA:',
    'new_gdpr_record' => 'Нов GDPR запис',
    'edit_gdpr_record' => 'Редактиране на GDPR запис',
    'new_dpia' => 'Нова DPIA',
    'edit_dpia' => 'Редактиране на DPIA',
    'new_breach' => 'Ново нарушение на данни',
    'edit_breach' => 'Редактиране на нарушение на данни',
    'new_third_party' => 'Нова трета страна',
    'edit_third_party' => 'Редактиране на трета страна',
    'record' => 'Запис',
    'page' => 'Страница',
    'generated' => 'Генерирано',
    'successfully_added' => 'успешно добавено',
    'successfully_updated' => 'успешно обновено',
    'unsaved_changes_confirm' => 'Има незапазени промени. Наистина ли искате да отмените?',
    'select_or_type_below' => 'Изберете или въведете по-долу',
    'or_type_custom_retention_period' => 'Или въведете персонализиран период на съхранение',
    'or_type_custom_safeguards' => 'Или въведете персонализирани гаранции (разделени с точка и запетая)',
    'or_type_custom_measures' => 'Или въведете персонализирани мерки (разделени с точка и запетая)',
    'hold_ctrl_to_select_multiple' => 'Задръжте Ctrl (Windows) или Cmd (Mac) за множествен избор',
    'custom_mitigation_measures' => 'Персонализирани мерки за смекчаване (разделени с точка и запетая)',
    'custom_measures_taken' => 'Персонализирани предприети мерки (разделени с точка и запетая)',
    'custom_measures_placeholder' => 'напр. Персонализирана мярка 1; Персонализирана мярка 2',
    'gdpr_record_id' => 'ID на GDPR запис',
    'gdpr_record' => 'GDPR запис',
    'dpia_for_gdpr' => 'DPIA за GDPR',
    'dpia_exists_for_gdpr' => 'Вече съществува DPIA за GDPR',
    'for_gdpr_record' => 'за GDPR запис',
    'only_one_dpia_allowed' => 'Разрешена е само една DPIA на GDPR запис.',
    'risk_distribution' => 'Разпределение на риска',
    'gdpr_compliance_overview' => 'Общ преглед на съответствието с GDPR',
    'inactive_draft' => 'Неактивен / Чернова',
    'collected_from_records' => 'Събрано от записи',
    'measure' => 'Мярка',
    'value' => 'Стойност',
    'source' => 'Източник',
    'configuration' => 'Конфигурация',
    'no_technical_measures' => 'Не са намерени технически мерки',
    'no_organizational_measures' => 'Не са намерени организационни мерки',
    'edit_measure' => 'Редактиране на мярка',
    'current_measure' => 'Текуща мярка',
    'new_measure_name' => 'Ново име на мярката',
    'measure_renamed_success' => 'Мярката е преименувана успешно навсякъде, където се използва.',
    'measure_rename_warning' => 'Това ще преименува мярката във всеки GDPR, DPIA и запис за нарушение на данни, където се използва.',
    'measure_deleted_success' => 'Мярката е изтрита успешно навсякъде, където е била използвана.',
    'confirm_delete_measure' => 'Наистина ли искате да изтриете тази мярка? Тя ще бъде премахната от всеки GDPR, DPIA и запис за нарушение на данни, където се използва. Това действие не може да бъде отменено.',
    'responsible' => 'Отговорник',
    'responsible_placeholder' => 'Кой е отговорен за тази мярка?',
    'unassigned' => 'Неназначено',
    'value_renamed_success' => 'Стойността е преименувана успешно навсякъде, където се използва.',
    'value_deleted_success' => 'Стойността е премахната успешно навсякъде, където е била използвана.',
    'edit_value' => 'Редактиране на стойност',
    'delete_value' => 'Изтриване на стойност',
    'current_value' => 'Текуща стойност',
    'new_value' => 'Нова стойност',
    'value_rename_warning' => 'Преименуването ще актуализира тази стойност навсякъде, където се използва в момента.',
    'value_delete_warning' => 'Изтриването ще премахне тази стойност от всеки запис, където се използва в момента. Това действие не може да бъде отменено.',
    'confirm_delete_value' => 'Да се изтрие ли тази стойност навсякъде, където се използва? Това действие не може да бъде отменено.',
    'used_in' => 'Използвано в',
    'not_currently_used' => 'В момента не се използва',
    'no_values' => 'Не са намерени стойности',
    'total_gdpr_records' => 'Общо GDPR записи',
    'dpia_in_progress' => 'DPIA в процес',
    'total_breaches' => 'Общо нарушения',
    'open_breaches' => 'Отворени нарушения',
    'total_third_parties' => 'Общо трети страни',
    'compliant_third_parties' => 'Съответстващи трети страни',
    'dpia_coverage' => 'Обхват на DPIA',
    'gdpr_with_dpia_required' => 'GDPR с изискване за DPIA',
    'dpia_completion_rate' => 'Процент на завършване на DPIA',
    'category' => 'Категория',
    'overview' => 'Общ преглед',
    'per_category' => 'По категория',
    'total_risk' => 'Общ риск',
    'completion_rate' => 'Процент на завършване',
    'record_type' => 'Тип запис',
    'print_report_title' => 'Отчет за съответствие',
    'generated_on' => 'Генерирано на',
    'not_started' => 'Не е започнато',
    'safeguard_scc' => 'Стандартни договорни клаузи (SCC)',
    'safeguard_bcr' => 'Задължителни фирмени правила (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (вече не е валиден)',
    'safeguard_adequacy_decision' => 'Решение за адекватност на Европейската комисия',
    'safeguard_consent' => 'Изрично съгласие на субекта на данни',
    'safeguard_model_contracts' => 'Примерни договори',
    'safeguard_certification' => 'Механизми за сертифициране',
    'safeguard_codes_of_conduct' => 'Кодекси за поведение',
    'safeguard_dpia' => 'Оценка на въздействието върху защитата на данните (DPIA)',
    'safeguard_tia' => 'Оценка на въздействието на международното предаване на данни (TIA)',
    'inactive' => 'Неактивен',
];

// ==================== CROATIAN ====================
$translations['hr'] = [
    'app_title' => 'GDPR Registar',
    'company_subtitle' => 'Privatnost i usklađenost',
    'dashboard' => 'Nadzorna ploča',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Povrede podataka',
    'breach' => 'Povreda podataka',
    'third_parties' => 'Treće strane',
    'third_party' => 'Treća strana',
    'measures' => 'Mjere',
    'reporting' => 'Izvještavanje',
    'total' => 'Ukupno',
    'active' => 'Aktivno',
    'high_risk' => 'Visok rizik',
    'dpia_required' => 'Potrebna DPIA',
    'dpia_completed' => 'DPIA dovršena',
    'new' => 'Novo',
    'export_json' => 'Izvoz JSON',
    'search' => 'Pretraživanje...',
    'search_company' => 'Pretraživanje tvrtke...',
    'filter' => 'Filtar',
    'clear' => 'Očisti',
    'risk' => 'Rizik',
    'risk_level' => 'Razina rizika',
    'status' => 'Status',
    'retention_period' => 'Razdoblje čuvanja',
    'actions' => 'Radnje',
    'view' => 'Prikaz',
    'edit' => 'Uredi',
    'delete' => 'Izbriši',
    'print' => 'Ispis',
    'confirm_delete' => 'Jeste li sigurni da želite izbrisati ovaj zapis? Ova se radnja ne može poništiti.',
    'processing_activity' => 'Aktivnost obrade',
    'purpose' => 'Svrha',
    'data_subjects' => 'Ispitanici',
    'personal_data' => 'Osobni podaci',
    'recipients' => 'Primatelji',
    'legal_basis' => 'Pravna osnova',
    'legitimate_interest' => 'Legitimni interes',
    'department' => 'Odjel',
    'or_type_custom_department' => 'Ili unesite prilagođeni odjel',
    'or_type_custom_name' => 'Ili unesite ime',
    'or_type_custom_risk_origin' => 'Ili unesite prilagođeni izvor rizika',
    'or_type_custom_status' => 'Ili unesite prilagođeni status',
    'or_type_custom_approval' => 'Ili unesite prilagođeni status odobrenja',
    'or_type_custom_consultation' => 'Ili unesite prilagođenu vrijednost',
    'or_type_custom_compliance_status' => 'Ili unesite prilagođeni status usklađenosti',
    'or_type_custom_breach_type' => 'Ili unesite prilagođeni tip povrede',
    'international_transfer' => 'Međunarodni prijenos',
    'to_country' => 'U državu',
    'we_are_processor' => 'Mi smo izvršitelj obrade',
    'processing_agreement_third_party' => 'Ugovor o obradi s trećom stranom',
    'technical_measures' => 'Tehničke mjere',
    'organizational_measures' => 'Organizacijske mjere',
    'safeguards' => 'Zaštitne mjere',
    'review_date' => 'Datum pregleda',
    'controller' => 'Voditelj obrade',
    'joint_controller' => 'Zajednički voditelj obrade',
    'dpo' => 'DPO',
    'representative' => 'Predstavnik',
    'name' => 'Ime',
    'contact' => 'Kontakt',
    'title' => 'Naslov',
    'description' => 'Opis',
    'risk_origin' => 'Izvor rizika',
    'affected_subjects' => 'Pogođeni ispitanici',
    'management_approval' => 'Odobrenje uprave',
    'approved_by' => 'Odobrio',
    'approval_date' => 'Datum odobrenja',
    'consultation_conducted' => 'Provedeno savjetovanje',
    'consultation_details' => 'Detalji savjetovanja',
    'recommendations' => 'Preporuke',
    'notes' => 'Bilješke',
    'necessity_test' => 'Test nužnosti',
    'proportionality_test' => 'Test proporcionalnosti',
    'mitigation_measures' => 'Mjere ublažavanja',
    'residual_risk' => 'Preostali rizik',
    'breach_date' => 'Datum povrede',
    'discovery_date' => 'Datum otkrivanja',
    'breach_type' => 'Vrsta povrede',
    'causes' => 'Uzroci',
    'measures_taken' => 'Poduzete mjere',
    'notified_authority' => 'Tijelo obaviješteno',
    'notification_date' => 'Datum obavijesti',
    'notified_affected' => 'Pogođeni obaviješteni',
    'company_name' => 'Naziv tvrtke',
    'contact_person' => 'Kontakt osoba',
    'email' => 'E-pošta',
    'phone' => 'Telefon',
    'address' => 'Adresa',
    'service_provided' => 'Pružena usluga',
    'agreement_signed' => 'Ugovor potpisan',
    'agreement_date' => 'Datum ugovora',
    'expiry_date' => 'Datum isteka',
    'compliance_status' => 'Status usklađenosti',
    'save' => 'Spremi',
    'cancel' => 'Odustani',
    'add' => 'Dodaj',
    'close' => 'Zatvori',
    'language' => 'Jezik',
    'logout' => 'Odjava',
    'logout_confirm' => 'Odjaviti se iz ove sesije?',
    'full_report' => 'Cjeloviti izvještaj',
    'backup' => 'Sigurnosna kopija',
    'zip_backup' => 'ZIP sigurnosna kopija',
    'statistics' => 'Statistika',
    'no_records' => 'Nema pronađenih zapisa',
    'showing' => 'Prikazano',
    'of' => 'od',
    'yes' => 'Da',
    'no' => 'Ne',
    'unknown' => 'Nepoznato',
    'not_required' => 'Nije potrebno',
    'in_progress' => 'U tijeku',
    'completed' => 'Dovršeno',
    'approved' => 'Odobreno',
    'draft' => 'Nacrt',
    'open' => 'Otvoreno',
    'investigating' => 'U istrazi',
    'contained' => 'Sanirano',
    'resolved' => 'Riješeno',
    'closed' => 'Zatvoreno',
    'compliant' => 'Usklađeno',
    'non_compliant' => 'Neusklađeno',
    'review_needed' => 'Potreban pregled',
    'low' => 'Nizak',
    'medium' => 'Srednji',
    'high' => 'Visok',
    'confidentiality' => 'Povjerljivost',
    'integrity' => 'Cjelovitost',
    'availability' => 'Dostupnost',
    'mixed' => 'Mješovito',
    'contract' => 'Ugovor',
    'consent' => 'Privola',
    'legal_obligation' => 'Pravna obveza',
    'legitimate_interests' => 'Legitimni interesi',
    'vital_interests' => 'Ključni interesi',
    'public_task' => 'Javna zadaća',
    'technical' => 'Tehnička',
    'organizational' => 'Organizacijska',
    'human_error' => 'Ljudska pogreška',
    'external' => 'Vanjski',
    'systematic_monitoring' => 'Sustavno praćenje',
    'sensitive_data' => 'Osjetljivi podaci',
    'other' => 'Ostalo',
    'administration' => 'Administracija',
    'hr' => 'Ljudski resursi',
    'finance' => 'Financije',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Operacije',
    'pending' => 'Na čekanju',
    'rejected' => 'Odbijeno',
    'planned' => 'Planirano',
    'donations' => 'Donacije',
    'create_dpia' => 'Izradi DPIA',
    'create_dpia_from_gdpr' => 'Izradi DPIA iz GDPR-a',
    'click_create_dpia_for_gdpr' => 'Kliknite "Izradi DPIA" za GDPR zapis koji zahtijeva DPIA:',
    'new_gdpr_record' => 'Novi GDPR zapis',
    'edit_gdpr_record' => 'Uredi GDPR zapis',
    'new_dpia' => 'Nova DPIA',
    'edit_dpia' => 'Uredi DPIA',
    'new_breach' => 'Nova povreda podataka',
    'edit_breach' => 'Uredi povredu podataka',
    'new_third_party' => 'Nova treća strana',
    'edit_third_party' => 'Uredi treću stranu',
    'record' => 'Zapis',
    'page' => 'Stranica',
    'generated' => 'Generirano',
    'successfully_added' => 'uspješno dodano',
    'successfully_updated' => 'uspješno ažurirano',
    'unsaved_changes_confirm' => 'Postoje nespremljene promjene. Jeste li sigurni da želite otkazati?',
    'select_or_type_below' => 'Odaberite ili upišite ispod',
    'or_type_custom_retention_period' => 'Ili unesite prilagođeno razdoblje čuvanja',
    'or_type_custom_safeguards' => 'Ili unesite prilagođene zaštitne mjere (odvojene točkom-zarezom)',
    'or_type_custom_measures' => 'Ili unesite prilagođene mjere (odvojene točkom-zarezom)',
    'hold_ctrl_to_select_multiple' => 'Držite Ctrl (Windows) ili Cmd (Mac) za odabir više stavki',
    'custom_mitigation_measures' => 'Prilagođene mjere ublažavanja (odvojene točkom-zarezom)',
    'custom_measures_taken' => 'Prilagođene poduzete mjere (odvojene točkom-zarezom)',
    'custom_measures_placeholder' => 'npr. Prilagođena mjera 1; Prilagođena mjera 2',
    'gdpr_record_id' => 'ID GDPR zapisa',
    'gdpr_record' => 'GDPR zapis',
    'dpia_for_gdpr' => 'DPIA za GDPR',
    'dpia_exists_for_gdpr' => 'DPIA za ovaj GDPR već postoji',
    'for_gdpr_record' => 'za GDPR zapis',
    'only_one_dpia_allowed' => 'Dopuštena je samo jedna DPIA po GDPR zapisu.',
    'risk_distribution' => 'Raspodjela rizika',
    'gdpr_compliance_overview' => 'Pregled usklađenosti s GDPR-om',
    'inactive_draft' => 'Neaktivno / Nacrt',
    'collected_from_records' => 'Prikupljeno iz zapisa',
    'measure' => 'Mjera',
    'value' => 'Vrijednost',
    'source' => 'Izvor',
    'configuration' => 'Konfiguracija',
    'no_technical_measures' => 'Nisu pronađene tehničke mjere',
    'no_organizational_measures' => 'Nisu pronađene organizacijske mjere',
    'edit_measure' => 'Uredi mjeru',
    'current_measure' => 'Trenutna mjera',
    'new_measure_name' => 'Novi naziv mjere',
    'measure_renamed_success' => 'Mjera je uspješno preimenovana posvuda gdje se koristi.',
    'measure_rename_warning' => 'Ovo će preimenovati mjeru u svakom GDPR, DPIA i zapisu povrede podataka gdje se koristi.',
    'measure_deleted_success' => 'Mjera je uspješno izbrisana posvuda gdje se koristila.',
    'confirm_delete_measure' => 'Jeste li sigurni da želite izbrisati ovu mjeru? Bit će uklonjena iz svakog GDPR, DPIA i zapisa povrede podataka gdje se koristi. Ova se radnja ne može poništiti.',
    'responsible' => 'Odgovorna osoba',
    'responsible_placeholder' => 'Tko je odgovoran za ovu mjeru?',
    'unassigned' => 'Nedodijeljeno',
    'value_renamed_success' => 'Vrijednost je uspješno preimenovana posvuda gdje se koristi.',
    'value_deleted_success' => 'Vrijednost je uspješno uklonjena posvuda gdje se koristila.',
    'edit_value' => 'Uredi vrijednost',
    'delete_value' => 'Izbriši vrijednost',
    'current_value' => 'Trenutna vrijednost',
    'new_value' => 'Nova vrijednost',
    'value_rename_warning' => 'Preimenovanje će ažurirati ovu vrijednost posvuda gdje se trenutno koristi.',
    'value_delete_warning' => 'Brisanje će ukloniti ovu vrijednost iz svakog zapisa gdje se trenutno koristi. Ova se radnja ne može poništiti.',
    'confirm_delete_value' => 'Izbrisati ovu vrijednost posvuda gdje se koristi? Ova se radnja ne može poništiti.',
    'used_in' => 'Korišteno u',
    'not_currently_used' => 'Trenutno se ne koristi',
    'no_values' => 'Nisu pronađene vrijednosti',
    'total_gdpr_records' => 'Ukupno GDPR zapisa',
    'dpia_in_progress' => 'DPIA u tijeku',
    'total_breaches' => 'Ukupno povreda',
    'open_breaches' => 'Otvorene povrede',
    'total_third_parties' => 'Ukupno trećih strana',
    'compliant_third_parties' => 'Usklađene treće strane',
    'dpia_coverage' => 'Pokrivenost DPIA-om',
    'gdpr_with_dpia_required' => 'GDPR koji zahtijeva DPIA',
    'dpia_completion_rate' => 'Stopa dovršenosti DPIA',
    'category' => 'Kategorija',
    'overview' => 'Pregled',
    'per_category' => 'Po kategoriji',
    'total_risk' => 'Ukupni rizik',
    'completion_rate' => 'Stopa dovršenosti',
    'record_type' => 'Vrsta zapisa',
    'print_report_title' => 'Izvještaj o usklađenosti',
    'generated_on' => 'Generirano',
    'not_started' => 'Nije započeto',
    'safeguard_scc' => 'Standardne ugovorne klauzule (SCC)',
    'safeguard_bcr' => 'Obvezujuća korporativna pravila (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (više ne vrijedi)',
    'safeguard_adequacy_decision' => 'Odluka Europske komisije o primjerenosti',
    'safeguard_consent' => 'Posebna privola ispitanika',
    'safeguard_model_contracts' => 'Modelni ugovori',
    'safeguard_certification' => 'Mehanizmi certificiranja',
    'safeguard_codes_of_conduct' => 'Kodeksi ponašanja',
    'safeguard_dpia' => 'Procjena učinka na zaštitu podataka (DPIA)',
    'safeguard_tia' => 'Procjena učinka međunarodnog prijenosa podataka (TIA)',
    'inactive' => 'Neaktivno',
];

// ==================== SLOVAK ====================
$translations['sk'] = [
    'app_title' => 'Register GDPR',
    'company_subtitle' => 'Ochrana súkromia a súlad',
    'dashboard' => 'Prehľad',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Úniky údajov',
    'breach' => 'Únik údajov',
    'third_parties' => 'Tretie strany',
    'third_party' => 'Tretia strana',
    'measures' => 'Opatrenia',
    'reporting' => 'Reportovanie',
    'total' => 'Spolu',
    'active' => 'Aktívny',
    'high_risk' => 'Vysoké riziko',
    'dpia_required' => 'Vyžaduje sa DPIA',
    'dpia_completed' => 'DPIA dokončená',
    'new' => 'Nový',
    'export_json' => 'Export JSON',
    'search' => 'Hľadať...',
    'search_company' => 'Hľadať spoločnosť...',
    'filter' => 'Filter',
    'clear' => 'Vymazať',
    'risk' => 'Riziko',
    'risk_level' => 'Úroveň rizika',
    'status' => 'Stav',
    'retention_period' => 'Doba uchovávania',
    'actions' => 'Akcie',
    'view' => 'Zobraziť',
    'edit' => 'Upraviť',
    'delete' => 'Vymazať',
    'print' => 'Tlačiť',
    'confirm_delete' => 'Naozaj chcete vymazať tento záznam? Túto akciu nemožno vrátiť späť.',
    'processing_activity' => 'Spracovateľská činnosť',
    'purpose' => 'Účel',
    'data_subjects' => 'Dotknuté osoby',
    'personal_data' => 'Osobné údaje',
    'recipients' => 'Príjemcovia',
    'legal_basis' => 'Právny základ',
    'legitimate_interest' => 'Oprávnený záujem',
    'department' => 'Oddelenie',
    'or_type_custom_department' => 'Alebo zadajte vlastné oddelenie',
    'or_type_custom_name' => 'Alebo zadajte meno',
    'or_type_custom_risk_origin' => 'Alebo zadajte vlastný zdroj rizika',
    'or_type_custom_status' => 'Alebo zadajte vlastný stav',
    'or_type_custom_approval' => 'Alebo zadajte vlastný stav schválenia',
    'or_type_custom_consultation' => 'Alebo zadajte vlastnú hodnotu',
    'or_type_custom_compliance_status' => 'Alebo zadajte vlastný stav súladu',
    'or_type_custom_breach_type' => 'Alebo zadajte vlastný typ úniku',
    'international_transfer' => 'Medzinárodný prenos',
    'to_country' => 'Do krajiny',
    'we_are_processor' => 'Sme sprostredkovateľ',
    'processing_agreement_third_party' => 'Zmluva o spracovaní s treťou stranou',
    'technical_measures' => 'Technické opatrenia',
    'organizational_measures' => 'Organizačné opatrenia',
    'safeguards' => 'Záruky',
    'review_date' => 'Dátum kontroly',
    'controller' => 'Prevádzkovateľ',
    'joint_controller' => 'Spoločný prevádzkovateľ',
    'dpo' => 'DPO',
    'representative' => 'Zástupca',
    'name' => 'Meno',
    'contact' => 'Kontakt',
    'title' => 'Názov',
    'description' => 'Popis',
    'risk_origin' => 'Zdroj rizika',
    'affected_subjects' => 'Dotknuté subjekty',
    'management_approval' => 'Schválenie manažmentom',
    'approved_by' => 'Schválil',
    'approval_date' => 'Dátum schválenia',
    'consultation_conducted' => 'Konzultácia vykonaná',
    'consultation_details' => 'Detaily konzultácie',
    'recommendations' => 'Odporúčania',
    'notes' => 'Poznámky',
    'necessity_test' => 'Test nevyhnutnosti',
    'proportionality_test' => 'Test proporcionality',
    'mitigation_measures' => 'Zmierňujúce opatrenia',
    'residual_risk' => 'Zostatkové riziko',
    'breach_date' => 'Dátum úniku',
    'discovery_date' => 'Dátum zistenia',
    'breach_type' => 'Typ úniku',
    'causes' => 'Príčiny',
    'measures_taken' => 'Prijaté opatrenia',
    'notified_authority' => 'Úrad informovaný',
    'notification_date' => 'Dátum oznámenia',
    'notified_affected' => 'Dotknuté osoby informované',
    'company_name' => 'Názov spoločnosti',
    'contact_person' => 'Kontaktná osoba',
    'email' => 'E-mail',
    'phone' => 'Telefón',
    'address' => 'Adresa',
    'service_provided' => 'Poskytovaná služba',
    'agreement_signed' => 'Zmluva podpísaná',
    'agreement_date' => 'Dátum zmluvy',
    'expiry_date' => 'Dátum vypršania',
    'compliance_status' => 'Stav súladu',
    'save' => 'Uložiť',
    'cancel' => 'Zrušiť',
    'add' => 'Pridať',
    'close' => 'Zavrieť',
    'language' => 'Jazyk',
    'logout' => 'Odhlásiť sa',
    'logout_confirm' => 'Odhlásiť sa z tejto relácie?',
    'full_report' => 'Úplná správa',
    'backup' => 'Záloha',
    'zip_backup' => 'ZIP záloha',
    'statistics' => 'Štatistiky',
    'no_records' => 'Neboli nájdené žiadne záznamy',
    'showing' => 'Zobrazené',
    'of' => 'z',
    'yes' => 'Áno',
    'no' => 'Nie',
    'unknown' => 'Neznáme',
    'not_required' => 'Nevyžaduje sa',
    'in_progress' => 'Prebieha',
    'completed' => 'Dokončené',
    'approved' => 'Schválené',
    'draft' => 'Návrh',
    'open' => 'Otvorené',
    'investigating' => 'Vyšetruje sa',
    'contained' => 'Zvládnuté',
    'resolved' => 'Vyriešené',
    'closed' => 'Uzavreté',
    'compliant' => 'V súlade',
    'non_compliant' => 'V rozpore',
    'review_needed' => 'Potrebná kontrola',
    'low' => 'Nízke',
    'medium' => 'Stredné',
    'high' => 'Vysoké',
    'confidentiality' => 'Dôvernosť',
    'integrity' => 'Integrita',
    'availability' => 'Dostupnosť',
    'mixed' => 'Zmiešané',
    'contract' => 'Zmluva',
    'consent' => 'Súhlas',
    'legal_obligation' => 'Zákonná povinnosť',
    'legitimate_interests' => 'Oprávnené záujmy',
    'vital_interests' => 'Životne dôležité záujmy',
    'public_task' => 'Verejná úloha',
    'technical' => 'Technické',
    'organizational' => 'Organizačné',
    'human_error' => 'Ľudská chyba',
    'external' => 'Externé',
    'systematic_monitoring' => 'Systematické monitorovanie',
    'sensitive_data' => 'Citlivé údaje',
    'other' => 'Iné',
    'administration' => 'Administratíva',
    'hr' => 'Ľudské zdroje',
    'finance' => 'Financie',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Prevádzka',
    'pending' => 'Čaká sa',
    'rejected' => 'Zamietnuté',
    'planned' => 'Plánované',
    'donations' => 'Dary',
    'create_dpia' => 'Vytvoriť DPIA',
    'create_dpia_from_gdpr' => 'Vytvoriť DPIA z GDPR',
    'click_create_dpia_for_gdpr' => 'Kliknite na "Vytvoriť DPIA" pre záznam GDPR, ktorý vyžaduje DPIA:',
    'new_gdpr_record' => 'Nový záznam GDPR',
    'edit_gdpr_record' => 'Upraviť záznam GDPR',
    'new_dpia' => 'Nová DPIA',
    'edit_dpia' => 'Upraviť DPIA',
    'new_breach' => 'Nový únik údajov',
    'edit_breach' => 'Upraviť únik údajov',
    'new_third_party' => 'Nová tretia strana',
    'edit_third_party' => 'Upraviť tretiu stranu',
    'record' => 'Záznam',
    'page' => 'Stránka',
    'generated' => 'Vygenerované',
    'successfully_added' => 'úspešne pridané',
    'successfully_updated' => 'úspešne aktualizované',
    'unsaved_changes_confirm' => 'Existujú neuložené zmeny. Naozaj chcete zrušiť?',
    'select_or_type_below' => 'Vyberte alebo zadajte nižšie',
    'or_type_custom_retention_period' => 'Alebo zadajte vlastnú dobu uchovávania',
    'or_type_custom_safeguards' => 'Alebo zadajte vlastné záruky (oddelené bodkočiarkou)',
    'or_type_custom_measures' => 'Alebo zadajte vlastné opatrenia (oddelené bodkočiarkou)',
    'hold_ctrl_to_select_multiple' => 'Podržte Ctrl (Windows) alebo Cmd (Mac) pre výber viacerých položiek',
    'custom_mitigation_measures' => 'Vlastné zmierňujúce opatrenia (oddelené bodkočiarkou)',
    'custom_measures_taken' => 'Vlastné prijaté opatrenia (oddelené bodkočiarkou)',
    'custom_measures_placeholder' => 'napr. vlastné opatrenie 1; vlastné opatrenie 2',
    'gdpr_record_id' => 'ID záznamu GDPR',
    'gdpr_record' => 'Záznam GDPR',
    'dpia_for_gdpr' => 'DPIA pre GDPR',
    'dpia_exists_for_gdpr' => 'Pre tento GDPR už DPIA existuje',
    'for_gdpr_record' => 'pre záznam GDPR',
    'only_one_dpia_allowed' => 'Pre každý záznam GDPR je povolená len jedna DPIA.',
    'risk_distribution' => 'Rozdelenie rizika',
    'gdpr_compliance_overview' => 'Prehľad súladu s GDPR',
    'inactive_draft' => 'Neaktívny / Návrh',
    'collected_from_records' => 'Zozbierané zo záznamov',
    'measure' => 'Opatrenie',
    'value' => 'Hodnota',
    'source' => 'Zdroj',
    'configuration' => 'Konfigurácia',
    'no_technical_measures' => 'Neboli nájdené žiadne technické opatrenia',
    'no_organizational_measures' => 'Neboli nájdené žiadne organizačné opatrenia',
    'edit_measure' => 'Upraviť opatrenie',
    'current_measure' => 'Aktuálne opatrenie',
    'new_measure_name' => 'Nový názov opatrenia',
    'measure_renamed_success' => 'Opatrenie bolo úspešne premenované všade, kde sa používa.',
    'measure_rename_warning' => 'Týmto sa premenuje opatrenie vo všetkých záznamoch GDPR, DPIA a úniku údajov, kde sa používa.',
    'measure_deleted_success' => 'Opatrenie bolo úspešne odstránené zo všetkých miest, kde sa používalo.',
    'confirm_delete_measure' => 'Naozaj chcete vymazať toto opatrenie? Bude odstránené zo všetkých záznamov GDPR, DPIA a úniku údajov, kde sa používa. Túto akciu nemožno vrátiť späť.',
    'responsible' => 'Zodpovedná osoba',
    'responsible_placeholder' => 'Kto je zodpovedný za toto opatrenie?',
    'unassigned' => 'Nepriradené',
    'value_renamed_success' => 'Hodnota bola úspešne premenovaná všade, kde sa používa.',
    'value_deleted_success' => 'Hodnota bola úspešne odstránená zo všetkých miest, kde sa používala.',
    'edit_value' => 'Upraviť hodnotu',
    'delete_value' => 'Vymazať hodnotu',
    'current_value' => 'Aktuálna hodnota',
    'new_value' => 'Nová hodnota',
    'value_rename_warning' => 'Premenovanie aktualizuje túto hodnotu všade, kde sa aktuálne používa.',
    'value_delete_warning' => 'Vymazanie odstráni túto hodnotu zo všetkých záznamov, kde sa aktuálne používa. Túto akciu nemožno vrátiť späť.',
    'confirm_delete_value' => 'Vymazať túto hodnotu všade, kde sa používa? Túto akciu nemožno vrátiť späť.',
    'used_in' => 'Použité v',
    'not_currently_used' => 'Aktuálne sa nepoužíva',
    'no_values' => 'Neboli nájdené žiadne hodnoty',
    'total_gdpr_records' => 'Celkový počet záznamov GDPR',
    'dpia_in_progress' => 'DPIA prebieha',
    'total_breaches' => 'Celkový počet únikov',
    'open_breaches' => 'Otvorené úniky',
    'total_third_parties' => 'Celkový počet tretích strán',
    'compliant_third_parties' => 'Tretie strany v súlade',
    'dpia_coverage' => 'Pokrytie DPIA',
    'gdpr_with_dpia_required' => 'GDPR vyžadujúce DPIA',
    'dpia_completion_rate' => 'Miera dokončenia DPIA',
    'category' => 'Kategória',
    'overview' => 'Prehľad',
    'per_category' => 'Podľa kategórie',
    'total_risk' => 'Celkové riziko',
    'completion_rate' => 'Miera dokončenia',
    'record_type' => 'Typ záznamu',
    'print_report_title' => 'Správa o súlade',
    'generated_on' => 'Vygenerované dňa',
    'not_started' => 'Nezačaté',
    'safeguard_scc' => 'Štandardné zmluvné doložky (SCC)',
    'safeguard_bcr' => 'Záväzné podnikové pravidlá (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (už neplatí)',
    'safeguard_adequacy_decision' => 'Rozhodnutie Európskej komisie o primeranosti',
    'safeguard_consent' => 'Osobitný súhlas dotknutej osoby',
    'safeguard_model_contracts' => 'Vzorové zmluvy',
    'safeguard_certification' => 'Certifikačné mechanizmy',
    'safeguard_codes_of_conduct' => 'Kódexy správania',
    'safeguard_dpia' => 'Posúdenie vplyvu na ochranu údajov (DPIA)',
    'safeguard_tia' => 'Posúdenie vplyvu medzinárodného prenosu údajov (TIA)',
    'inactive' => 'Neaktívny',
];

// ==================== SLOVENIAN ====================
$translations['sl'] = [
    'app_title' => 'Register GDPR',
    'company_subtitle' => 'Zasebnost in skladnost',
    'dashboard' => 'Nadzorna plošča',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Kršitve varstva podatkov',
    'breach' => 'Kršitev varstva podatkov',
    'third_parties' => 'Tretje osebe',
    'third_party' => 'Tretja oseba',
    'measures' => 'Ukrepi',
    'reporting' => 'Poročanje',
    'total' => 'Skupaj',
    'active' => 'Aktivno',
    'high_risk' => 'Visoko tveganje',
    'dpia_required' => 'Zahtevana DPIA',
    'dpia_completed' => 'DPIA zaključena',
    'new' => 'Novo',
    'export_json' => 'Izvoz JSON',
    'search' => 'Iskanje...',
    'search_company' => 'Iskanje podjetja...',
    'filter' => 'Filter',
    'clear' => 'Počisti',
    'risk' => 'Tveganje',
    'risk_level' => 'Stopnja tveganja',
    'status' => 'Stanje',
    'retention_period' => 'Obdobje hrambe',
    'actions' => 'Dejanja',
    'view' => 'Ogled',
    'edit' => 'Uredi',
    'delete' => 'Izbriši',
    'print' => 'Natisni',
    'confirm_delete' => 'Ali ste prepričani, da želite izbrisati ta zapis? Tega dejanja ni mogoče razveljaviti.',
    'processing_activity' => 'Dejavnost obdelave',
    'purpose' => 'Namen',
    'data_subjects' => 'Posamezniki, na katere se nanašajo osebni podatki',
    'personal_data' => 'Osebni podatki',
    'recipients' => 'Prejemniki',
    'legal_basis' => 'Pravna podlaga',
    'legitimate_interest' => 'Zakoniti interes',
    'department' => 'Oddelek',
    'or_type_custom_department' => 'Ali vnesite poljuben oddelek',
    'or_type_custom_name' => 'Ali vnesite ime',
    'or_type_custom_risk_origin' => 'Ali vnesite poljuben izvor tveganja',
    'or_type_custom_status' => 'Ali vnesite poljuben status',
    'or_type_custom_approval' => 'Ali vnesite poljuben status odobritve',
    'or_type_custom_consultation' => 'Ali vnesite poljubno vrednost',
    'or_type_custom_compliance_status' => 'Ali vnesite poljuben status skladnosti',
    'or_type_custom_breach_type' => 'Ali vnesite poljubno vrsto kršitve',
    'international_transfer' => 'Mednarodni prenos',
    'to_country' => 'V državo',
    'we_are_processor' => 'Smo obdelovalec',
    'processing_agreement_third_party' => 'Pogodba o obdelavi s tretjo osebo',
    'technical_measures' => 'Tehnični ukrepi',
    'organizational_measures' => 'Organizacijski ukrepi',
    'safeguards' => 'Zaščitni ukrepi',
    'review_date' => 'Datum pregleda',
    'controller' => 'Upravljavec',
    'joint_controller' => 'Skupni upravljavec',
    'dpo' => 'DPO',
    'representative' => 'Predstavnik',
    'name' => 'Ime',
    'contact' => 'Kontakt',
    'title' => 'Naslov',
    'description' => 'Opis',
    'risk_origin' => 'Izvor tveganja',
    'affected_subjects' => 'Prizadeti posamezniki',
    'management_approval' => 'Odobritev vodstva',
    'approved_by' => 'Odobril',
    'approval_date' => 'Datum odobritve',
    'consultation_conducted' => 'Posvetovanje opravljeno',
    'consultation_details' => 'Podrobnosti posvetovanja',
    'recommendations' => 'Priporočila',
    'notes' => 'Opombe',
    'necessity_test' => 'Test nujnosti',
    'proportionality_test' => 'Test sorazmernosti',
    'mitigation_measures' => 'Ukrepi za omilitev',
    'residual_risk' => 'Preostalo tveganje',
    'breach_date' => 'Datum kršitve',
    'discovery_date' => 'Datum odkritja',
    'breach_type' => 'Vrsta kršitve',
    'causes' => 'Vzroki',
    'measures_taken' => 'Sprejeti ukrepi',
    'notified_authority' => 'Organ obveščen',
    'notification_date' => 'Datum obvestila',
    'notified_affected' => 'Prizadeti posamezniki obveščeni',
    'company_name' => 'Ime podjetja',
    'contact_person' => 'Kontaktna oseba',
    'email' => 'E-pošta',
    'phone' => 'Telefon',
    'address' => 'Naslov',
    'service_provided' => 'Zagotovljena storitev',
    'agreement_signed' => 'Pogodba podpisana',
    'agreement_date' => 'Datum pogodbe',
    'expiry_date' => 'Datum poteka',
    'compliance_status' => 'Status skladnosti',
    'save' => 'Shrani',
    'cancel' => 'Prekliči',
    'add' => 'Dodaj',
    'close' => 'Zapri',
    'language' => 'Jezik',
    'logout' => 'Odjava',
    'logout_confirm' => 'Se želite odjaviti iz te seje?',
    'full_report' => 'Celotno poročilo',
    'backup' => 'Varnostna kopija',
    'zip_backup' => 'ZIP varnostna kopija',
    'statistics' => 'Statistika',
    'no_records' => 'Ni najdenih zapisov',
    'showing' => 'Prikazano',
    'of' => 'od',
    'yes' => 'Da',
    'no' => 'Ne',
    'unknown' => 'Neznano',
    'not_required' => 'Ni potrebno',
    'in_progress' => 'V teku',
    'completed' => 'Zaključeno',
    'approved' => 'Odobreno',
    'draft' => 'Osnutek',
    'open' => 'Odprto',
    'investigating' => 'V preiskavi',
    'contained' => 'Obvladano',
    'resolved' => 'Rešeno',
    'closed' => 'Zaprto',
    'compliant' => 'Skladno',
    'non_compliant' => 'Neskladno',
    'review_needed' => 'Potreben pregled',
    'low' => 'Nizko',
    'medium' => 'Srednje',
    'high' => 'Visoko',
    'confidentiality' => 'Zaupnost',
    'integrity' => 'Celovitost',
    'availability' => 'Razpoložljivost',
    'mixed' => 'Mešano',
    'contract' => 'Pogodba',
    'consent' => 'Privolitev',
    'legal_obligation' => 'Pravna obveznost',
    'legitimate_interests' => 'Zakoniti interesi',
    'vital_interests' => 'Življenjski interesi',
    'public_task' => 'Javna naloga',
    'technical' => 'Tehnično',
    'organizational' => 'Organizacijsko',
    'human_error' => 'Človeška napaka',
    'external' => 'Zunanje',
    'systematic_monitoring' => 'Sistematično spremljanje',
    'sensitive_data' => 'Občutljivi podatki',
    'other' => 'Drugo',
    'administration' => 'Administracija',
    'hr' => 'Kadrovska služba',
    'finance' => 'Finance',
    'marketing' => 'Trženje',
    'it' => 'IT',
    'operations' => 'Operacije',
    'pending' => 'V čakanju',
    'rejected' => 'Zavrnjeno',
    'planned' => 'Načrtovano',
    'donations' => 'Donacije',
    'create_dpia' => 'Ustvari DPIA',
    'create_dpia_from_gdpr' => 'Ustvari DPIA iz GDPR',
    'click_create_dpia_for_gdpr' => 'Kliknite "Ustvari DPIA" za zapis GDPR, ki zahteva DPIA:',
    'new_gdpr_record' => 'Nov zapis GDPR',
    'edit_gdpr_record' => 'Uredi zapis GDPR',
    'new_dpia' => 'Nova DPIA',
    'edit_dpia' => 'Uredi DPIA',
    'new_breach' => 'Nova kršitev varstva podatkov',
    'edit_breach' => 'Uredi kršitev varstva podatkov',
    'new_third_party' => 'Nova tretja oseba',
    'edit_third_party' => 'Uredi tretjo osebo',
    'record' => 'Zapis',
    'page' => 'Stran',
    'generated' => 'Ustvarjeno',
    'successfully_added' => 'uspešno dodano',
    'successfully_updated' => 'uspešno posodobljeno',
    'unsaved_changes_confirm' => 'Obstajajo neshranjene spremembe. Ali ste prepričani, da želite preklicati?',
    'select_or_type_below' => 'Izberite ali vnesite spodaj',
    'or_type_custom_retention_period' => 'Ali vnesite poljubno obdobje hrambe',
    'or_type_custom_safeguards' => 'Ali vnesite poljubne zaščitne ukrepe (ločene s podpičjem)',
    'or_type_custom_measures' => 'Ali vnesite poljubne ukrepe (ločene s podpičjem)',
    'hold_ctrl_to_select_multiple' => 'Za izbiro več postavk pridržite Ctrl (Windows) ali Cmd (Mac)',
    'custom_mitigation_measures' => 'Poljubni ukrepi za omilitev (ločeni s podpičjem)',
    'custom_measures_taken' => 'Poljubni sprejeti ukrepi (ločeni s podpičjem)',
    'custom_measures_placeholder' => 'npr. poljuben ukrep 1; poljuben ukrep 2',
    'gdpr_record_id' => 'ID zapisa GDPR',
    'gdpr_record' => 'Zapis GDPR',
    'dpia_for_gdpr' => 'DPIA za GDPR',
    'dpia_exists_for_gdpr' => 'DPIA za ta GDPR že obstaja',
    'for_gdpr_record' => 'za zapis GDPR',
    'only_one_dpia_allowed' => 'Dovoljena je le ena DPIA na zapis GDPR.',
    'risk_distribution' => 'Porazdelitev tveganja',
    'gdpr_compliance_overview' => 'Pregled skladnosti z GDPR',
    'inactive_draft' => 'Neaktivno / Osnutek',
    'collected_from_records' => 'Zbrano iz zapisov',
    'measure' => 'Ukrep',
    'value' => 'Vrednost',
    'source' => 'Vir',
    'configuration' => 'Konfiguracija',
    'no_technical_measures' => 'Ni najdenih tehničnih ukrepov',
    'no_organizational_measures' => 'Ni najdenih organizacijskih ukrepov',
    'edit_measure' => 'Uredi ukrep',
    'current_measure' => 'Trenutni ukrep',
    'new_measure_name' => 'Novo ime ukrepa',
    'measure_renamed_success' => 'Ukrep je bil uspešno preimenovan povsod, kjer se uporablja.',
    'measure_rename_warning' => 'S tem se preimenuje ukrep v vseh zapisih GDPR, DPIA in kršitev varstva podatkov, kjer se uporablja.',
    'measure_deleted_success' => 'Ukrep je bil uspešno izbrisan povsod, kjer se je uporabljal.',
    'confirm_delete_measure' => 'Ali ste prepričani, da želite izbrisati ta ukrep? Odstranjen bo iz vseh zapisov GDPR, DPIA in kršitev varstva podatkov, kjer se uporablja. Tega dejanja ni mogoče razveljaviti.',
    'responsible' => 'Odgovorna oseba',
    'responsible_placeholder' => 'Kdo je odgovoren za ta ukrep?',
    'unassigned' => 'Ni dodeljeno',
    'value_renamed_success' => 'Vrednost je bila uspešno preimenovana povsod, kjer se uporablja.',
    'value_deleted_success' => 'Vrednost je bila uspešno odstranjena povsod, kjer se je uporabljala.',
    'edit_value' => 'Uredi vrednost',
    'delete_value' => 'Izbriši vrednost',
    'current_value' => 'Trenutna vrednost',
    'new_value' => 'Nova vrednost',
    'value_rename_warning' => 'Preimenovanje bo posodobilo to vrednost povsod, kjer se trenutno uporablja.',
    'value_delete_warning' => 'Brisanje bo odstranilo to vrednost iz vseh zapisov, kjer se trenutno uporablja. Tega dejanja ni mogoče razveljaviti.',
    'confirm_delete_value' => 'Izbrišem to vrednost povsod, kjer se uporablja? Tega dejanja ni mogoče razveljaviti.',
    'used_in' => 'Uporabljeno v',
    'not_currently_used' => 'Trenutno se ne uporablja',
    'no_values' => 'Ni najdenih vrednosti',
    'total_gdpr_records' => 'Skupno število zapisov GDPR',
    'dpia_in_progress' => 'DPIA v teku',
    'total_breaches' => 'Skupno število kršitev',
    'open_breaches' => 'Odprte kršitve',
    'total_third_parties' => 'Skupno število tretjih oseb',
    'compliant_third_parties' => 'Skladne tretje osebe',
    'dpia_coverage' => 'Pokritost z DPIA',
    'gdpr_with_dpia_required' => 'GDPR z zahtevo po DPIA',
    'dpia_completion_rate' => 'Stopnja dokončanosti DPIA',
    'category' => 'Kategorija',
    'overview' => 'Pregled',
    'per_category' => 'Po kategoriji',
    'total_risk' => 'Skupno tveganje',
    'completion_rate' => 'Stopnja dokončanosti',
    'record_type' => 'Vrsta zapisa',
    'print_report_title' => 'Poročilo o skladnosti',
    'generated_on' => 'Ustvarjeno dne',
    'not_started' => 'Ni se začelo',
    'safeguard_scc' => 'Standardne pogodbene klavzule (SCC)',
    'safeguard_bcr' => 'Zavezujoča poslovna pravila (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (ni več veljaven)',
    'safeguard_adequacy_decision' => 'Sklep Evropske komisije o ustreznosti',
    'safeguard_consent' => 'Posebna privolitev posameznika',
    'safeguard_model_contracts' => 'Vzorčne pogodbe',
    'safeguard_certification' => 'Mehanizmi certificiranja',
    'safeguard_codes_of_conduct' => 'Kodeksi ravnanja',
    'safeguard_dpia' => 'Ocena učinka v zvezi z varstvom podatkov (DPIA)',
    'safeguard_tia' => 'Ocena učinka mednarodnega prenosa podatkov (TIA)',
    'inactive' => 'Neaktivno',
];

// ==================== LITHUANIAN ====================
$translations['lt'] = [
    'app_title' => 'BDAR registras',
    'company_subtitle' => 'Privatumas ir atitiktis',
    'dashboard' => 'Skydelis',
    'gdpr' => 'BDAR',
    'dpia' => 'PADV',
    'breaches' => 'Duomenų saugumo pažeidimai',
    'breach' => 'Duomenų saugumo pažeidimas',
    'third_parties' => 'Trečiosios šalys',
    'third_party' => 'Trečioji šalis',
    'measures' => 'Priemonės',
    'reporting' => 'Ataskaitos',
    'total' => 'Iš viso',
    'active' => 'Aktyvus',
    'high_risk' => 'Didelė rizika',
    'dpia_required' => 'Reikalingas PADV',
    'dpia_completed' => 'PADV atliktas',
    'new' => 'Naujas',
    'export_json' => 'Eksportuoti JSON',
    'search' => 'Ieškoti...',
    'search_company' => 'Ieškoti įmonės...',
    'filter' => 'Filtras',
    'clear' => 'Išvalyti',
    'risk' => 'Rizika',
    'risk_level' => 'Rizikos lygis',
    'status' => 'Būsena',
    'retention_period' => 'Saugojimo laikotarpis',
    'actions' => 'Veiksmai',
    'view' => 'Peržiūrėti',
    'edit' => 'Redaguoti',
    'delete' => 'Trinti',
    'print' => 'Spausdinti',
    'confirm_delete' => 'Ar tikrai norite ištrinti šį įrašą? Šio veiksmo anuliuoti negalima.',
    'processing_activity' => 'Duomenų tvarkymo veikla',
    'purpose' => 'Tikslas',
    'data_subjects' => 'Duomenų subjektai',
    'personal_data' => 'Asmens duomenys',
    'recipients' => 'Gavėjai',
    'legal_basis' => 'Teisinis pagrindas',
    'legitimate_interest' => 'Teisėtas interesas',
    'department' => 'Skyrius',
    'or_type_custom_department' => 'Arba įveskite savo skyrių',
    'or_type_custom_name' => 'Arba įveskite vardą',
    'or_type_custom_risk_origin' => 'Arba įveskite savo rizikos šaltinį',
    'or_type_custom_status' => 'Arba įveskite savo būseną',
    'or_type_custom_approval' => 'Arba įveskite savo patvirtinimo būseną',
    'or_type_custom_consultation' => 'Arba įveskite savo reikšmę',
    'or_type_custom_compliance_status' => 'Arba įveskite savo atitikties būseną',
    'or_type_custom_breach_type' => 'Arba įveskite savo pažeidimo tipą',
    'international_transfer' => 'Tarptautinis perdavimas',
    'to_country' => 'Į šalį',
    'we_are_processor' => 'Mes esame duomenų tvarkytojas',
    'processing_agreement_third_party' => 'Duomenų tvarkymo sutartis su trečiąja šalimi',
    'technical_measures' => 'Techninės priemonės',
    'organizational_measures' => 'Organizacinės priemonės',
    'safeguards' => 'Apsaugos priemonės',
    'review_date' => 'Peržiūros data',
    'controller' => 'Duomenų valdytojas',
    'joint_controller' => 'Bendras duomenų valdytojas',
    'dpo' => 'DPO',
    'representative' => 'Atstovas',
    'name' => 'Vardas',
    'contact' => 'Kontaktas',
    'title' => 'Pavadinimas',
    'description' => 'Aprašymas',
    'risk_origin' => 'Rizikos šaltinis',
    'affected_subjects' => 'Paveikti subjektai',
    'management_approval' => 'Vadovybės patvirtinimas',
    'approved_by' => 'Patvirtino',
    'approval_date' => 'Patvirtinimo data',
    'consultation_conducted' => 'Konsultacija atlikta',
    'consultation_details' => 'Konsultacijos detalės',
    'recommendations' => 'Rekomendacijos',
    'notes' => 'Pastabos',
    'necessity_test' => 'Būtinumo testas',
    'proportionality_test' => 'Proporcingumo testas',
    'mitigation_measures' => 'Rizikos mažinimo priemonės',
    'residual_risk' => 'Likutinė rizika',
    'breach_date' => 'Pažeidimo data',
    'discovery_date' => 'Nustatymo data',
    'breach_type' => 'Pažeidimo tipas',
    'causes' => 'Priežastys',
    'measures_taken' => 'Taikytos priemonės',
    'notified_authority' => 'Institucija informuota',
    'notification_date' => 'Pranešimo data',
    'notified_affected' => 'Paveikti asmenys informuoti',
    'company_name' => 'Įmonės pavadinimas',
    'contact_person' => 'Kontaktinis asmuo',
    'email' => 'El. paštas',
    'phone' => 'Telefonas',
    'address' => 'Adresas',
    'service_provided' => 'Teikiama paslauga',
    'agreement_signed' => 'Sutartis pasirašyta',
    'agreement_date' => 'Sutarties data',
    'expiry_date' => 'Galiojimo pabaigos data',
    'compliance_status' => 'Atitikties būsena',
    'save' => 'Išsaugoti',
    'cancel' => 'Atšaukti',
    'add' => 'Pridėti',
    'close' => 'Uždaryti',
    'language' => 'Kalba',
    'logout' => 'Atsijungti',
    'logout_confirm' => 'Atsijungti nuo šios sesijos?',
    'full_report' => 'Pilna ataskaita',
    'backup' => 'Atsarginė kopija',
    'zip_backup' => 'ZIP atsarginė kopija',
    'statistics' => 'Statistika',
    'no_records' => 'Įrašų nerasta',
    'showing' => 'Rodoma',
    'of' => 'iš',
    'yes' => 'Taip',
    'no' => 'Ne',
    'unknown' => 'Nežinoma',
    'not_required' => 'Nereikalaujama',
    'in_progress' => 'Vykdoma',
    'completed' => 'Baigta',
    'approved' => 'Patvirtinta',
    'draft' => 'Juodraštis',
    'open' => 'Atviras',
    'investigating' => 'Tiriama',
    'contained' => 'Sulokalizuota',
    'resolved' => 'Išspręsta',
    'closed' => 'Uždaryta',
    'compliant' => 'Atitinka',
    'non_compliant' => 'Neatitinka',
    'review_needed' => 'Reikalinga peržiūra',
    'low' => 'Žema',
    'medium' => 'Vidutinė',
    'high' => 'Aukšta',
    'confidentiality' => 'Konfidencialumas',
    'integrity' => 'Vientisumas',
    'availability' => 'Prieinamumas',
    'mixed' => 'Mišrus',
    'contract' => 'Sutartis',
    'consent' => 'Sutikimas',
    'legal_obligation' => 'Teisinė prievolė',
    'legitimate_interests' => 'Teisėti interesai',
    'vital_interests' => 'Gyvybiniai interesai',
    'public_task' => 'Viešoji užduotis',
    'technical' => 'Techninė',
    'organizational' => 'Organizacinė',
    'human_error' => 'Žmogiškoji klaida',
    'external' => 'Išorinė',
    'systematic_monitoring' => 'Sistemingas stebėjimas',
    'sensitive_data' => 'Jautrūs duomenys',
    'other' => 'Kita',
    'administration' => 'Administravimas',
    'hr' => 'Personalas',
    'finance' => 'Finansai',
    'marketing' => 'Rinkodara',
    'it' => 'IT',
    'operations' => 'Operacijos',
    'pending' => 'Laukiama',
    'rejected' => 'Atmesta',
    'planned' => 'Suplanuota',
    'donations' => 'Aukos',
    'create_dpia' => 'Sukurti PADV',
    'create_dpia_from_gdpr' => 'Sukurti PADV iš BDAR',
    'click_create_dpia_for_gdpr' => 'Spustelėkite „Sukurti PADV“ BDAR įrašui, kuriam reikalingas PADV:',
    'new_gdpr_record' => 'Naujas BDAR įrašas',
    'edit_gdpr_record' => 'Redaguoti BDAR įrašą',
    'new_dpia' => 'Naujas PADV',
    'edit_dpia' => 'Redaguoti PADV',
    'new_breach' => 'Naujas duomenų saugumo pažeidimas',
    'edit_breach' => 'Redaguoti duomenų saugumo pažeidimą',
    'new_third_party' => 'Nauja trečioji šalis',
    'edit_third_party' => 'Redaguoti trečiąją šalį',
    'record' => 'Įrašas',
    'page' => 'Puslapis',
    'generated' => 'Sugeneruota',
    'successfully_added' => 'sėkmingai pridėta',
    'successfully_updated' => 'sėkmingai atnaujinta',
    'unsaved_changes_confirm' => 'Yra neišsaugotų pakeitimų. Ar tikrai norite atšaukti?',
    'select_or_type_below' => 'Pasirinkite arba įveskite žemiau',
    'or_type_custom_retention_period' => 'Arba įveskite savo saugojimo laikotarpį',
    'or_type_custom_safeguards' => 'Arba įveskite savo apsaugos priemones (atskirtas kabliataškiu)',
    'or_type_custom_measures' => 'Arba įveskite savo priemones (atskirtas kabliataškiu)',
    'hold_ctrl_to_select_multiple' => 'Norėdami pasirinkti kelis, laikykite nuspaudę Ctrl (Windows) arba Cmd (Mac)',
    'custom_mitigation_measures' => 'Savo rizikos mažinimo priemonės (atskirtos kabliataškiu)',
    'custom_measures_taken' => 'Savo taikytos priemonės (atskirtos kabliataškiu)',
    'custom_measures_placeholder' => 'pvz., sava priemonė 1; sava priemonė 2',
    'gdpr_record_id' => 'BDAR įrašo ID',
    'gdpr_record' => 'BDAR įrašas',
    'dpia_for_gdpr' => 'PADV šiam BDAR',
    'dpia_exists_for_gdpr' => 'Šiam BDAR jau yra PADV',
    'for_gdpr_record' => 'BDAR įrašui',
    'only_one_dpia_allowed' => 'Vienam BDAR įrašui leidžiamas tik vienas PADV.',
    'risk_distribution' => 'Rizikos pasiskirstymas',
    'gdpr_compliance_overview' => 'BDAR atitikties apžvalga',
    'inactive_draft' => 'Neaktyvus / Juodraštis',
    'collected_from_records' => 'Surinkta iš įrašų',
    'measure' => 'Priemonė',
    'value' => 'Reikšmė',
    'source' => 'Šaltinis',
    'configuration' => 'Konfigūracija',
    'no_technical_measures' => 'Techninių priemonių nerasta',
    'no_organizational_measures' => 'Organizacinių priemonių nerasta',
    'edit_measure' => 'Redaguoti priemonę',
    'current_measure' => 'Dabartinė priemonė',
    'new_measure_name' => 'Naujas priemonės pavadinimas',
    'measure_renamed_success' => 'Priemonė sėkmingai pervadinta visur, kur ji naudojama.',
    'measure_rename_warning' => 'Tai pervadins priemonę visuose BDAR, PADV ir duomenų saugumo pažeidimų įrašuose, kuriuose ji naudojama.',
    'measure_deleted_success' => 'Priemonė sėkmingai ištrinta visur, kur ji buvo naudojama.',
    'confirm_delete_measure' => 'Ar tikrai norite ištrinti šią priemonę? Ji bus pašalinta iš visų BDAR, PADV ir duomenų saugumo pažeidimų įrašų, kuriuose naudojama. Šio veiksmo anuliuoti negalima.',
    'responsible' => 'Atsakingas asmuo',
    'responsible_placeholder' => 'Kas atsakingas už šią priemonę?',
    'unassigned' => 'Nepriskirta',
    'value_renamed_success' => 'Reikšmė sėkmingai pervadinta visur, kur ji naudojama.',
    'value_deleted_success' => 'Reikšmė sėkmingai pašalinta visur, kur ji buvo naudojama.',
    'edit_value' => 'Redaguoti reikšmę',
    'delete_value' => 'Trinti reikšmę',
    'current_value' => 'Dabartinė reikšmė',
    'new_value' => 'Nauja reikšmė',
    'value_rename_warning' => 'Pervadinus bus atnaujinta ši reikšmė visur, kur ji šiuo metu naudojama.',
    'value_delete_warning' => 'Ištrynus ši reikšmė bus pašalinta iš visų įrašų, kuriuose ji šiuo metu naudojama. Šio veiksmo anuliuoti negalima.',
    'confirm_delete_value' => 'Ištrinti šią reikšmę visur, kur ji naudojama? Šio veiksmo anuliuoti negalima.',
    'used_in' => 'Naudojama',
    'not_currently_used' => 'Šiuo metu nenaudojama',
    'no_values' => 'Reikšmių nerasta',
    'total_gdpr_records' => 'Iš viso BDAR įrašų',
    'dpia_in_progress' => 'Vykdomas PADV',
    'total_breaches' => 'Iš viso pažeidimų',
    'open_breaches' => 'Atviri pažeidimai',
    'total_third_parties' => 'Iš viso trečiųjų šalių',
    'compliant_third_parties' => 'Atitinkančios trečiosios šalys',
    'dpia_coverage' => 'PADV aprėptis',
    'gdpr_with_dpia_required' => 'BDAR, kuriems reikalingas PADV',
    'dpia_completion_rate' => 'PADV užbaigimo rodiklis',
    'category' => 'Kategorija',
    'overview' => 'Apžvalga',
    'per_category' => 'Pagal kategoriją',
    'total_risk' => 'Bendra rizika',
    'completion_rate' => 'Užbaigimo rodiklis',
    'record_type' => 'Įrašo tipas',
    'print_report_title' => 'Atitikties ataskaita',
    'generated_on' => 'Sugeneruota',
    'not_started' => 'Nepradėta',
    'safeguard_scc' => 'Standartinės sutarčių sąlygos (SCC)',
    'safeguard_bcr' => 'Privalomos įmonių taisyklės (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (nebegalioja)',
    'safeguard_adequacy_decision' => 'Europos Komisijos tinkamumo sprendimas',
    'safeguard_consent' => 'Konkretus duomenų subjekto sutikimas',
    'safeguard_model_contracts' => 'Pavyzdinės sutartys',
    'safeguard_certification' => 'Sertifikavimo mechanizmai',
    'safeguard_codes_of_conduct' => 'Elgesio kodeksai',
    'safeguard_dpia' => 'Poveikio duomenų apsaugai vertinimas (PADV)',
    'safeguard_tia' => 'Tarptautinio duomenų perdavimo poveikio vertinimas (TIA)',
    'inactive' => 'Neaktyvus',
];

// ==================== LATVIAN ====================
$translations['lv'] = [
    'app_title' => 'VDAR reģistrs',
    'company_subtitle' => 'Privātums un atbilstība',
    'dashboard' => 'Panelis',
    'gdpr' => 'VDAR',
    'dpia' => 'DAIN',
    'breaches' => 'Datu aizsardzības pārkāpumi',
    'breach' => 'Datu aizsardzības pārkāpums',
    'third_parties' => 'Trešās puses',
    'third_party' => 'Trešā puse',
    'measures' => 'Pasākumi',
    'reporting' => 'Atskaites',
    'total' => 'Kopā',
    'active' => 'Aktīvs',
    'high_risk' => 'Augsts risks',
    'dpia_required' => 'Nepieciešams DAIN',
    'dpia_completed' => 'DAIN pabeigts',
    'new' => 'Jauns',
    'export_json' => 'Eksportēt JSON',
    'search' => 'Meklēt...',
    'search_company' => 'Meklēt uzņēmumu...',
    'filter' => 'Filtrs',
    'clear' => 'Notīrīt',
    'risk' => 'Risks',
    'risk_level' => 'Riska līmenis',
    'status' => 'Statuss',
    'retention_period' => 'Glabāšanas periods',
    'actions' => 'Darbības',
    'view' => 'Skatīt',
    'edit' => 'Rediģēt',
    'delete' => 'Dzēst',
    'print' => 'Drukāt',
    'confirm_delete' => 'Vai tiešām vēlaties dzēst šo ierakstu? Šo darbību nevar atsaukt.',
    'processing_activity' => 'Apstrādes darbība',
    'purpose' => 'Mērķis',
    'data_subjects' => 'Datu subjekti',
    'personal_data' => 'Personas dati',
    'recipients' => 'Saņēmēji',
    'legal_basis' => 'Juridiskais pamats',
    'legitimate_interest' => 'Leģitīmās intereses',
    'department' => 'Nodaļa',
    'or_type_custom_department' => 'Vai ievadiet pielāgotu nodaļu',
    'or_type_custom_name' => 'Vai ievadiet vārdu',
    'or_type_custom_risk_origin' => 'Vai ievadiet pielāgotu riska avotu',
    'or_type_custom_status' => 'Vai ievadiet pielāgotu statusu',
    'or_type_custom_approval' => 'Vai ievadiet pielāgotu apstiprinājuma statusu',
    'or_type_custom_consultation' => 'Vai ievadiet pielāgotu vērtību',
    'or_type_custom_compliance_status' => 'Vai ievadiet pielāgotu atbilstības statusu',
    'or_type_custom_breach_type' => 'Vai ievadiet pielāgotu pārkāpuma veidu',
    'international_transfer' => 'Starptautiska nodošana',
    'to_country' => 'Uz valsti',
    'we_are_processor' => 'Mēs esam apstrādātājs',
    'processing_agreement_third_party' => 'Apstrādes līgums ar trešo pusi',
    'technical_measures' => 'Tehniskie pasākumi',
    'organizational_measures' => 'Organizatoriskie pasākumi',
    'safeguards' => 'Aizsardzības pasākumi',
    'review_date' => 'Pārskatīšanas datums',
    'controller' => 'Pārzinis',
    'joint_controller' => 'Kopīgais pārzinis',
    'dpo' => 'DPO',
    'representative' => 'Pārstāvis',
    'name' => 'Vārds',
    'contact' => 'Kontakts',
    'title' => 'Nosaukums',
    'description' => 'Apraksts',
    'risk_origin' => 'Riska avots',
    'affected_subjects' => 'Skartie subjekti',
    'management_approval' => 'Vadības apstiprinājums',
    'approved_by' => 'Apstiprināja',
    'approval_date' => 'Apstiprinājuma datums',
    'consultation_conducted' => 'Konsultācija veikta',
    'consultation_details' => 'Konsultācijas detaļas',
    'recommendations' => 'Ieteikumi',
    'notes' => 'Piezīmes',
    'necessity_test' => 'Nepieciešamības tests',
    'proportionality_test' => 'Proporcionalitātes tests',
    'mitigation_measures' => 'Mazināšanas pasākumi',
    'residual_risk' => 'Atlikušais risks',
    'breach_date' => 'Pārkāpuma datums',
    'discovery_date' => 'Atklāšanas datums',
    'breach_type' => 'Pārkāpuma veids',
    'causes' => 'Cēloņi',
    'measures_taken' => 'Veiktie pasākumi',
    'notified_authority' => 'Iestāde informēta',
    'notification_date' => 'Paziņojuma datums',
    'notified_affected' => 'Skartās personas informētas',
    'company_name' => 'Uzņēmuma nosaukums',
    'contact_person' => 'Kontaktpersona',
    'email' => 'E-pasts',
    'phone' => 'Tālrunis',
    'address' => 'Adrese',
    'service_provided' => 'Sniegtais pakalpojums',
    'agreement_signed' => 'Līgums parakstīts',
    'agreement_date' => 'Līguma datums',
    'expiry_date' => 'Derīguma termiņa datums',
    'compliance_status' => 'Atbilstības statuss',
    'save' => 'Saglabāt',
    'cancel' => 'Atcelt',
    'add' => 'Pievienot',
    'close' => 'Aizvērt',
    'language' => 'Valoda',
    'logout' => 'Izrakstīties',
    'logout_confirm' => 'Izrakstīties no šīs sesijas?',
    'full_report' => 'Pilns pārskats',
    'backup' => 'Rezerves kopija',
    'zip_backup' => 'ZIP rezerves kopija',
    'statistics' => 'Statistika',
    'no_records' => 'Ieraksti nav atrasti',
    'showing' => 'Rāda',
    'of' => 'no',
    'yes' => 'Jā',
    'no' => 'Nē',
    'unknown' => 'Nezināms',
    'not_required' => 'Nav nepieciešams',
    'in_progress' => 'Norisinās',
    'completed' => 'Pabeigts',
    'approved' => 'Apstiprināts',
    'draft' => 'Melnraksts',
    'open' => 'Atvērts',
    'investigating' => 'Tiek izmeklēts',
    'contained' => 'Ierobežots',
    'resolved' => 'Atrisināts',
    'closed' => 'Slēgts',
    'compliant' => 'Atbilstošs',
    'non_compliant' => 'Neatbilstošs',
    'review_needed' => 'Nepieciešama pārskatīšana',
    'low' => 'Zems',
    'medium' => 'Vidējs',
    'high' => 'Augsts',
    'confidentiality' => 'Konfidencialitāte',
    'integrity' => 'Integritāte',
    'availability' => 'Pieejamība',
    'mixed' => 'Jaukts',
    'contract' => 'Līgums',
    'consent' => 'Piekrišana',
    'legal_obligation' => 'Juridisks pienākums',
    'legitimate_interests' => 'Leģitīmās intereses',
    'vital_interests' => 'Vitāli svarīgas intereses',
    'public_task' => 'Sabiedrisks uzdevums',
    'technical' => 'Tehnisks',
    'organizational' => 'Organizatorisks',
    'human_error' => 'Cilvēka kļūda',
    'external' => 'Ārējs',
    'systematic_monitoring' => 'Sistemātiska uzraudzība',
    'sensitive_data' => 'Sensitīvi dati',
    'other' => 'Cits',
    'administration' => 'Administrācija',
    'hr' => 'Personāls',
    'finance' => 'Finanses',
    'marketing' => 'Mārketings',
    'it' => 'IT',
    'operations' => 'Darbības',
    'pending' => 'Gaida izskatīšanu',
    'rejected' => 'Noraidīts',
    'planned' => 'Plānots',
    'donations' => 'Ziedojumi',
    'create_dpia' => 'Izveidot DAIN',
    'create_dpia_from_gdpr' => 'Izveidot DAIN no VDAR',
    'click_create_dpia_for_gdpr' => 'Noklikšķiniet uz "Izveidot DAIN" VDAR ierakstam, kuram nepieciešams DAIN:',
    'new_gdpr_record' => 'Jauns VDAR ieraksts',
    'edit_gdpr_record' => 'Rediģēt VDAR ierakstu',
    'new_dpia' => 'Jauns DAIN',
    'edit_dpia' => 'Rediģēt DAIN',
    'new_breach' => 'Jauns datu aizsardzības pārkāpums',
    'edit_breach' => 'Rediģēt datu aizsardzības pārkāpumu',
    'new_third_party' => 'Jauna trešā puse',
    'edit_third_party' => 'Rediģēt trešo pusi',
    'record' => 'Ieraksts',
    'page' => 'Lapa',
    'generated' => 'Ģenerēts',
    'successfully_added' => 'veiksmīgi pievienots',
    'successfully_updated' => 'veiksmīgi atjaunināts',
    'unsaved_changes_confirm' => 'Ir nesaglabātas izmaiņas. Vai tiešām vēlaties atcelt?',
    'select_or_type_below' => 'Izvēlieties vai ierakstiet zemāk',
    'or_type_custom_retention_period' => 'Vai ievadiet pielāgotu glabāšanas periodu',
    'or_type_custom_safeguards' => 'Vai ievadiet pielāgotus aizsardzības pasākumus (atdalītus ar semikolu)',
    'or_type_custom_measures' => 'Vai ievadiet pielāgotus pasākumus (atdalītus ar semikolu)',
    'hold_ctrl_to_select_multiple' => 'Turiet nospiestu Ctrl (Windows) vai Cmd (Mac), lai atlasītu vairākus',
    'custom_mitigation_measures' => 'Pielāgoti mazināšanas pasākumi (atdalīti ar semikolu)',
    'custom_measures_taken' => 'Pielāgoti veiktie pasākumi (atdalīti ar semikolu)',
    'custom_measures_placeholder' => 'piem., pielāgots pasākums 1; pielāgots pasākums 2',
    'gdpr_record_id' => 'VDAR ieraksta ID',
    'gdpr_record' => 'VDAR ieraksts',
    'dpia_for_gdpr' => 'DAIN priekš VDAR',
    'dpia_exists_for_gdpr' => 'Šim VDAR jau ir DAIN',
    'for_gdpr_record' => 'VDAR ierakstam',
    'only_one_dpia_allowed' => 'Vienam VDAR ierakstam ir atļauts tikai viens DAIN.',
    'risk_distribution' => 'Riska sadalījums',
    'gdpr_compliance_overview' => 'VDAR atbilstības pārskats',
    'inactive_draft' => 'Neaktīvs / Melnraksts',
    'collected_from_records' => 'Apkopots no ierakstiem',
    'measure' => 'Pasākums',
    'value' => 'Vērtība',
    'source' => 'Avots',
    'configuration' => 'Konfigurācija',
    'no_technical_measures' => 'Tehniskie pasākumi nav atrasti',
    'no_organizational_measures' => 'Organizatoriskie pasākumi nav atrasti',
    'edit_measure' => 'Rediģēt pasākumu',
    'current_measure' => 'Pašreizējais pasākums',
    'new_measure_name' => 'Jaunais pasākuma nosaukums',
    'measure_renamed_success' => 'Pasākums veiksmīgi pārdēvēts visur, kur tas tiek izmantots.',
    'measure_rename_warning' => 'Tas pārdēvēs pasākumu visos VDAR, DAIN un datu aizsardzības pārkāpumu ierakstos, kur tas tiek izmantots.',
    'measure_deleted_success' => 'Pasākums veiksmīgi dzēsts visur, kur tas tika izmantots.',
    'confirm_delete_measure' => 'Vai tiešām vēlaties dzēst šo pasākumu? Tas tiks noņemts no visiem VDAR, DAIN un datu aizsardzības pārkāpumu ierakstiem, kur tas tiek izmantots. Šo darbību nevar atsaukt.',
    'responsible' => 'Atbildīgā persona',
    'responsible_placeholder' => 'Kurš ir atbildīgs par šo pasākumu?',
    'unassigned' => 'Nav piešķirts',
    'value_renamed_success' => 'Vērtība veiksmīgi pārdēvēta visur, kur tā tiek izmantota.',
    'value_deleted_success' => 'Vērtība veiksmīgi noņemta visur, kur tā tika izmantota.',
    'edit_value' => 'Rediģēt vērtību',
    'delete_value' => 'Dzēst vērtību',
    'current_value' => 'Pašreizējā vērtība',
    'new_value' => 'Jaunā vērtība',
    'value_rename_warning' => 'Pārdēvēšana atjauninās šo vērtību visur, kur tā pašlaik tiek izmantota.',
    'value_delete_warning' => 'Dzēšana noņems šo vērtību no visiem ierakstiem, kur tā pašlaik tiek izmantota. Šo darbību nevar atsaukt.',
    'confirm_delete_value' => 'Dzēst šo vērtību visur, kur tā tiek izmantota? Šo darbību nevar atsaukt.',
    'used_in' => 'Izmantots',
    'not_currently_used' => 'Pašlaik netiek izmantots',
    'no_values' => 'Vērtības nav atrastas',
    'total_gdpr_records' => 'VDAR ierakstu kopskaits',
    'dpia_in_progress' => 'DAIN norisinās',
    'total_breaches' => 'Pārkāpumu kopskaits',
    'open_breaches' => 'Atvērtie pārkāpumi',
    'total_third_parties' => 'Trešo pušu kopskaits',
    'compliant_third_parties' => 'Atbilstošas trešās puses',
    'dpia_coverage' => 'DAIN pārklājums',
    'gdpr_with_dpia_required' => 'VDAR ar nepieciešamu DAIN',
    'dpia_completion_rate' => 'DAIN pabeigšanas līmenis',
    'category' => 'Kategorija',
    'overview' => 'Pārskats',
    'per_category' => 'Pēc kategorijas',
    'total_risk' => 'Kopējais risks',
    'completion_rate' => 'Pabeigšanas līmenis',
    'record_type' => 'Ieraksta veids',
    'print_report_title' => 'Atbilstības pārskats',
    'generated_on' => 'Ģenerēts',
    'not_started' => 'Nav sākts',
    'safeguard_scc' => 'Standarta līguma klauzulas (SCC)',
    'safeguard_bcr' => 'Saistoši uzņēmuma noteikumi (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (vairs nav spēkā)',
    'safeguard_adequacy_decision' => 'Eiropas Komisijas lēmums par aizsardzības līmeņa pietiekamību',
    'safeguard_consent' => 'Datu subjekta īpaša piekrišana',
    'safeguard_model_contracts' => 'Parauglīgumi',
    'safeguard_certification' => 'Sertifikācijas mehānismi',
    'safeguard_codes_of_conduct' => 'Rīcības kodeksi',
    'safeguard_dpia' => 'Novērtējums par ietekmi uz datu aizsardzību (DAIN)',
    'safeguard_tia' => 'Novērtējums par starptautiskas datu nodošanas ietekmi (TIA)',
    'inactive' => 'Neaktīvs',
];

// ==================== ESTONIAN ====================
$translations['et'] = [
    'app_title' => 'IKÜM register',
    'company_subtitle' => 'Privaatsus ja vastavus',
    'dashboard' => 'Töölaud',
    'gdpr' => 'IKÜM',
    'dpia' => 'AKUH',
    'breaches' => 'Andmekaitse rikkumised',
    'breach' => 'Andmekaitse rikkumine',
    'third_parties' => 'Kolmandad isikud',
    'third_party' => 'Kolmas isik',
    'measures' => 'Meetmed',
    'reporting' => 'Aruandlus',
    'total' => 'Kokku',
    'active' => 'Aktiivne',
    'high_risk' => 'Kõrge risk',
    'dpia_required' => 'AKUH nõutav',
    'dpia_completed' => 'AKUH lõpetatud',
    'new' => 'Uus',
    'export_json' => 'Ekspordi JSON',
    'search' => 'Otsi...',
    'search_company' => 'Otsi ettevõtet...',
    'filter' => 'Filter',
    'clear' => 'Tühjenda',
    'risk' => 'Risk',
    'risk_level' => 'Riskitase',
    'status' => 'Olek',
    'retention_period' => 'Säilitamisperiood',
    'actions' => 'Toimingud',
    'view' => 'Vaata',
    'edit' => 'Muuda',
    'delete' => 'Kustuta',
    'print' => 'Prindi',
    'confirm_delete' => 'Kas olete kindel, et soovite selle kirje kustutada? Seda toimingut ei saa tagasi võtta.',
    'processing_activity' => 'Töötlemistoiming',
    'purpose' => 'Eesmärk',
    'data_subjects' => 'Andmesubjektid',
    'personal_data' => 'Isikuandmed',
    'recipients' => 'Vastuvõtjad',
    'legal_basis' => 'Õiguslik alus',
    'legitimate_interest' => 'Õigustatud huvi',
    'department' => 'Osakond',
    'or_type_custom_department' => 'Või sisestage kohandatud osakond',
    'or_type_custom_name' => 'Või sisestage nimi',
    'or_type_custom_risk_origin' => 'Või sisestage kohandatud riskiallikas',
    'or_type_custom_status' => 'Või sisestage kohandatud olek',
    'or_type_custom_approval' => 'Või sisestage kohandatud kinnitusolek',
    'or_type_custom_consultation' => 'Või sisestage kohandatud väärtus',
    'or_type_custom_compliance_status' => 'Või sisestage kohandatud vastavusolek',
    'or_type_custom_breach_type' => 'Või sisestage kohandatud rikkumise tüüp',
    'international_transfer' => 'Rahvusvaheline edastamine',
    'to_country' => 'Sihtriik',
    'we_are_processor' => 'Meie oleme volitatud töötleja',
    'processing_agreement_third_party' => 'Andmetöötluse leping kolmanda isikuga',
    'technical_measures' => 'Tehnilised meetmed',
    'organizational_measures' => 'Korralduslikud meetmed',
    'safeguards' => 'Kaitsemeetmed',
    'review_date' => 'Läbivaatamise kuupäev',
    'controller' => 'Vastutav töötleja',
    'joint_controller' => 'Kaasvastutav töötleja',
    'dpo' => 'DPO',
    'representative' => 'Esindaja',
    'name' => 'Nimi',
    'contact' => 'Kontakt',
    'title' => 'Pealkiri',
    'description' => 'Kirjeldus',
    'risk_origin' => 'Riski allikas',
    'affected_subjects' => 'Mõjutatud isikud',
    'management_approval' => 'Juhtkonna kinnitus',
    'approved_by' => 'Kinnitas',
    'approval_date' => 'Kinnitamise kuupäev',
    'consultation_conducted' => 'Konsultatsioon toimunud',
    'consultation_details' => 'Konsultatsiooni üksikasjad',
    'recommendations' => 'Soovitused',
    'notes' => 'Märkused',
    'necessity_test' => 'Vajalikkuse test',
    'proportionality_test' => 'Proportsionaalsuse test',
    'mitigation_measures' => 'Leevendusmeetmed',
    'residual_risk' => 'Jääkrisk',
    'breach_date' => 'Rikkumise kuupäev',
    'discovery_date' => 'Avastamise kuupäev',
    'breach_type' => 'Rikkumise tüüp',
    'causes' => 'Põhjused',
    'measures_taken' => 'Võetud meetmed',
    'notified_authority' => 'Järelevalveasutus teavitatud',
    'notification_date' => 'Teavitamise kuupäev',
    'notified_affected' => 'Mõjutatud isikud teavitatud',
    'company_name' => 'Ettevõtte nimi',
    'contact_person' => 'Kontaktisik',
    'email' => 'E-post',
    'phone' => 'Telefon',
    'address' => 'Aadress',
    'service_provided' => 'Osutatav teenus',
    'agreement_signed' => 'Leping allkirjastatud',
    'agreement_date' => 'Lepingu kuupäev',
    'expiry_date' => 'Aegumiskuupäev',
    'compliance_status' => 'Vastavusolek',
    'save' => 'Salvesta',
    'cancel' => 'Tühista',
    'add' => 'Lisa',
    'close' => 'Sulge',
    'language' => 'Keel',
    'logout' => 'Logi välja',
    'logout_confirm' => 'Kas logida sellest seansist välja?',
    'full_report' => 'Täielik aruanne',
    'backup' => 'Varukoopia',
    'zip_backup' => 'ZIP-varukoopia',
    'statistics' => 'Statistika',
    'no_records' => 'Kirjeid ei leitud',
    'showing' => 'Kuvatakse',
    'of' => '/',
    'yes' => 'Jah',
    'no' => 'Ei',
    'unknown' => 'Teadmata',
    'not_required' => 'Pole nõutav',
    'in_progress' => 'Pooleli',
    'completed' => 'Lõpetatud',
    'approved' => 'Kinnitatud',
    'draft' => 'Mustand',
    'open' => 'Avatud',
    'investigating' => 'Uuritakse',
    'contained' => 'Ohjatud',
    'resolved' => 'Lahendatud',
    'closed' => 'Suletud',
    'compliant' => 'Vastav',
    'non_compliant' => 'Mittevastav',
    'review_needed' => 'Vajab läbivaatamist',
    'low' => 'Madal',
    'medium' => 'Keskmine',
    'high' => 'Kõrge',
    'confidentiality' => 'Konfidentsiaalsus',
    'integrity' => 'Terviklus',
    'availability' => 'Käideldavus',
    'mixed' => 'Segatud',
    'contract' => 'Leping',
    'consent' => 'Nõusolek',
    'legal_obligation' => 'Juriidiline kohustus',
    'legitimate_interests' => 'Õigustatud huvid',
    'vital_interests' => 'Eluliselt tähtsad huvid',
    'public_task' => 'Avalik ülesanne',
    'technical' => 'Tehniline',
    'organizational' => 'Korralduslik',
    'human_error' => 'Inimlik viga',
    'external' => 'Väline',
    'systematic_monitoring' => 'Süstemaatiline jälgimine',
    'sensitive_data' => 'Tundlikud andmed',
    'other' => 'Muu',
    'administration' => 'Haldus',
    'hr' => 'Personal',
    'finance' => 'Finants',
    'marketing' => 'Turundus',
    'it' => 'IT',
    'operations' => 'Toimingud',
    'pending' => 'Ootel',
    'rejected' => 'Tagasi lükatud',
    'planned' => 'Planeeritud',
    'donations' => 'Annetused',
    'create_dpia' => 'Loo AKUH',
    'create_dpia_from_gdpr' => 'Loo AKUH IKÜM-ist',
    'click_create_dpia_for_gdpr' => 'Klõpsake AKUH-i nõudva IKÜM-i kirje jaoks nuppu „Loo AKUH":',
    'new_gdpr_record' => 'Uus IKÜM-i kirje',
    'edit_gdpr_record' => 'Muuda IKÜM-i kirjet',
    'new_dpia' => 'Uus AKUH',
    'edit_dpia' => 'Muuda AKUH-i',
    'new_breach' => 'Uus andmekaitse rikkumine',
    'edit_breach' => 'Muuda andmekaitse rikkumist',
    'new_third_party' => 'Uus kolmas isik',
    'edit_third_party' => 'Muuda kolmandat isikut',
    'record' => 'Kirje',
    'page' => 'Leht',
    'generated' => 'Loodud',
    'successfully_added' => 'edukalt lisatud',
    'successfully_updated' => 'edukalt uuendatud',
    'unsaved_changes_confirm' => 'Salvestamata muudatused on olemas. Kas soovite kindlasti tühistada?',
    'select_or_type_below' => 'Valige või sisestage allpool',
    'or_type_custom_retention_period' => 'Või sisestage kohandatud säilitamisperiood',
    'or_type_custom_safeguards' => 'Või sisestage kohandatud kaitsemeetmed (eraldatud semikooloniga)',
    'or_type_custom_measures' => 'Või sisestage kohandatud meetmed (eraldatud semikooloniga)',
    'hold_ctrl_to_select_multiple' => 'Hoidke mitme valimiseks all Ctrl (Windows) või Cmd (Mac)',
    'custom_mitigation_measures' => 'Kohandatud leevendusmeetmed (eraldatud semikooloniga)',
    'custom_measures_taken' => 'Kohandatud võetud meetmed (eraldatud semikooloniga)',
    'custom_measures_placeholder' => 'nt kohandatud meede 1; kohandatud meede 2',
    'gdpr_record_id' => 'IKÜM-i kirje ID',
    'gdpr_record' => 'IKÜM-i kirje',
    'dpia_for_gdpr' => 'AKUH selle IKÜM-i jaoks',
    'dpia_exists_for_gdpr' => 'Selle IKÜM-i jaoks on juba AKUH olemas',
    'for_gdpr_record' => 'IKÜM-i kirje jaoks',
    'only_one_dpia_allowed' => 'Iga IKÜM-i kirje kohta on lubatud ainult üks AKUH.',
    'risk_distribution' => 'Riskide jaotus',
    'gdpr_compliance_overview' => 'IKÜM-i vastavuse ülevaade',
    'inactive_draft' => 'Passiivne / Mustand',
    'collected_from_records' => 'Kogutud kirjetest',
    'measure' => 'Meede',
    'value' => 'Väärtus',
    'source' => 'Allikas',
    'configuration' => 'Seadistus',
    'no_technical_measures' => 'Tehnilisi meetmeid ei leitud',
    'no_organizational_measures' => 'Korralduslikke meetmeid ei leitud',
    'edit_measure' => 'Muuda meedet',
    'current_measure' => 'Praegune meede',
    'new_measure_name' => 'Meetme uus nimi',
    'measure_renamed_success' => 'Meede nimetati edukalt ümber kõikjal, kus seda kasutatakse.',
    'measure_rename_warning' => 'See nimetab meetme ümber kõigis IKÜM-i, AKUH-i ja andmekaitse rikkumiste kirjetes, kus seda kasutatakse.',
    'measure_deleted_success' => 'Meede kustutati edukalt kõikjalt, kus seda kasutati.',
    'confirm_delete_measure' => 'Kas olete kindel, et soovite selle meetme kustutada? See eemaldatakse kõigist IKÜM-i, AKUH-i ja andmekaitse rikkumiste kirjetest, kus seda kasutatakse. Seda toimingut ei saa tagasi võtta.',
    'responsible' => 'Vastutaja',
    'responsible_placeholder' => 'Kes vastutab selle meetme eest?',
    'unassigned' => 'Määramata',
    'value_renamed_success' => 'Väärtus nimetati edukalt ümber kõikjal, kus seda kasutatakse.',
    'value_deleted_success' => 'Väärtus eemaldati edukalt kõikjalt, kus seda kasutati.',
    'edit_value' => 'Muuda väärtust',
    'delete_value' => 'Kustuta väärtus',
    'current_value' => 'Praegune väärtus',
    'new_value' => 'Uus väärtus',
    'value_rename_warning' => 'Ümbernimetamine uuendab seda väärtust kõikjal, kus seda praegu kasutatakse.',
    'value_delete_warning' => 'Kustutamine eemaldab selle väärtuse kõigist kirjetest, kus seda praegu kasutatakse. Seda toimingut ei saa tagasi võtta.',
    'confirm_delete_value' => 'Kas kustutada see väärtus kõikjal, kus seda kasutatakse? Seda toimingut ei saa tagasi võtta.',
    'used_in' => 'Kasutusel',
    'not_currently_used' => 'Praegu ei kasutata',
    'no_values' => 'Väärtusi ei leitud',
    'total_gdpr_records' => 'IKÜM-i kirjeid kokku',
    'dpia_in_progress' => 'AKUH pooleli',
    'total_breaches' => 'Rikkumisi kokku',
    'open_breaches' => 'Avatud rikkumised',
    'total_third_parties' => 'Kolmandaid isikuid kokku',
    'compliant_third_parties' => 'Vastavad kolmandad isikud',
    'dpia_coverage' => 'AKUH-i katvus',
    'gdpr_with_dpia_required' => 'AKUH-i vajavad IKÜM-i kirjed',
    'dpia_completion_rate' => 'AKUH-i lõpetamise määr',
    'category' => 'Kategooria',
    'overview' => 'Ülevaade',
    'per_category' => 'Kategooria kaupa',
    'total_risk' => 'Kogurisk',
    'completion_rate' => 'Lõpetamise määr',
    'record_type' => 'Kirje tüüp',
    'print_report_title' => 'Vastavusaruanne',
    'generated_on' => 'Loodud',
    'not_started' => 'Alustamata',
    'safeguard_scc' => 'Näidislepingu tüüptingimused (SCC)',
    'safeguard_bcr' => 'Siduvad kontsernisisesed eeskirjad (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (enam ei kehti)',
    'safeguard_adequacy_decision' => 'Euroopa Komisjoni piisavusotsus',
    'safeguard_consent' => 'Andmesubjekti selgesõnaline nõusolek',
    'safeguard_model_contracts' => 'Näidislepingud',
    'safeguard_certification' => 'Sertifitseerimismehhanismid',
    'safeguard_codes_of_conduct' => 'Toimimisjuhendid',
    'safeguard_dpia' => 'Andmekaitsealane mõjuhinnang (AKUH)',
    'safeguard_tia' => 'Rahvusvahelise andmeedastuse mõjuhinnang (TIA)',
    'inactive' => 'Passiivne',
];

// ==================== SERBIAN ====================
$translations['sr'] = [
    'app_title' => 'GDPR registar',
    'company_subtitle' => 'Privatnost i usklađenost',
    'dashboard' => 'Kontrolna tabla',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Povrede podataka',
    'breach' => 'Povreda podataka',
    'third_parties' => 'Treća lica',
    'third_party' => 'Treće lice',
    'measures' => 'Mere',
    'reporting' => 'Izveštavanje',
    'total' => 'Ukupno',
    'active' => 'Aktivno',
    'high_risk' => 'Visok rizik',
    'dpia_required' => 'Potrebna DPIA',
    'dpia_completed' => 'DPIA završena',
    'new' => 'Novo',
    'export_json' => 'Izvoz JSON',
    'search' => 'Pretraga...',
    'search_company' => 'Pretraga kompanije...',
    'filter' => 'Filter',
    'clear' => 'Očisti',
    'risk' => 'Rizik',
    'risk_level' => 'Nivo rizika',
    'status' => 'Status',
    'retention_period' => 'Period čuvanja',
    'actions' => 'Radnje',
    'view' => 'Prikaz',
    'edit' => 'Izmeni',
    'delete' => 'Obriši',
    'print' => 'Štampaj',
    'confirm_delete' => 'Da li ste sigurni da želite da obrišete ovaj zapis? Ova radnja se ne može poništiti.',
    'processing_activity' => 'Aktivnost obrade',
    'purpose' => 'Svrha',
    'data_subjects' => 'Lica na koja se podaci odnose',
    'personal_data' => 'Lični podaci',
    'recipients' => 'Primaoci',
    'legal_basis' => 'Pravni osnov',
    'legitimate_interest' => 'Legitimni interes',
    'department' => 'Odeljenje',
    'or_type_custom_department' => 'Ili unesite prilagođeno odeljenje',
    'or_type_custom_name' => 'Ili unesite ime',
    'or_type_custom_risk_origin' => 'Ili unesite prilagođeni izvor rizika',
    'or_type_custom_status' => 'Ili unesite prilagođeni status',
    'or_type_custom_approval' => 'Ili unesite prilagođeni status odobrenja',
    'or_type_custom_consultation' => 'Ili unesite prilagođenu vrednost',
    'or_type_custom_compliance_status' => 'Ili unesite prilagođeni status usklađenosti',
    'or_type_custom_breach_type' => 'Ili unesite prilagođeni tip povrede',
    'international_transfer' => 'Međunarodni prenos',
    'to_country' => 'U zemlju',
    'we_are_processor' => 'Mi smo obrađivač',
    'processing_agreement_third_party' => 'Ugovor o obradi sa trećim licem',
    'technical_measures' => 'Tehničke mere',
    'organizational_measures' => 'Organizacione mere',
    'safeguards' => 'Zaštitne mere',
    'review_date' => 'Datum pregleda',
    'controller' => 'Rukovalac',
    'joint_controller' => 'Zajednički rukovalac',
    'dpo' => 'DPO',
    'representative' => 'Predstavnik',
    'name' => 'Ime',
    'contact' => 'Kontakt',
    'title' => 'Naslov',
    'description' => 'Opis',
    'risk_origin' => 'Izvor rizika',
    'affected_subjects' => 'Pogođena lica',
    'management_approval' => 'Odobrenje uprave',
    'approved_by' => 'Odobrio',
    'approval_date' => 'Datum odobrenja',
    'consultation_conducted' => 'Konsultacija sprovedena',
    'consultation_details' => 'Detalji konsultacije',
    'recommendations' => 'Preporuke',
    'notes' => 'Napomene',
    'necessity_test' => 'Test nužnosti',
    'proportionality_test' => 'Test proporcionalnosti',
    'mitigation_measures' => 'Mere ublažavanja',
    'residual_risk' => 'Preostali rizik',
    'breach_date' => 'Datum povrede',
    'discovery_date' => 'Datum otkrivanja',
    'breach_type' => 'Vrsta povrede',
    'causes' => 'Uzroci',
    'measures_taken' => 'Preduzete mere',
    'notified_authority' => 'Organ obavešten',
    'notification_date' => 'Datum obaveštenja',
    'notified_affected' => 'Pogođena lica obaveštena',
    'company_name' => 'Naziv kompanije',
    'contact_person' => 'Kontakt osoba',
    'email' => 'E-pošta',
    'phone' => 'Telefon',
    'address' => 'Adresa',
    'service_provided' => 'Pružena usluga',
    'agreement_signed' => 'Ugovor potpisan',
    'agreement_date' => 'Datum ugovora',
    'expiry_date' => 'Datum isteka',
    'compliance_status' => 'Status usklađenosti',
    'save' => 'Sačuvaj',
    'cancel' => 'Otkaži',
    'add' => 'Dodaj',
    'close' => 'Zatvori',
    'language' => 'Jezik',
    'logout' => 'Odjava',
    'logout_confirm' => 'Odjaviti se sa ove sesije?',
    'full_report' => 'Potpuni izveštaj',
    'backup' => 'Rezervna kopija',
    'zip_backup' => 'ZIP rezervna kopija',
    'statistics' => 'Statistika',
    'no_records' => 'Nema pronađenih zapisa',
    'showing' => 'Prikazano',
    'of' => 'od',
    'yes' => 'Da',
    'no' => 'Ne',
    'unknown' => 'Nepoznato',
    'not_required' => 'Nije potrebno',
    'in_progress' => 'U toku',
    'completed' => 'Završeno',
    'approved' => 'Odobreno',
    'draft' => 'Nacrt',
    'open' => 'Otvoreno',
    'investigating' => 'U istrazi',
    'contained' => 'Sanirano',
    'resolved' => 'Rešeno',
    'closed' => 'Zatvoreno',
    'compliant' => 'Usklađeno',
    'non_compliant' => 'Neusklađeno',
    'review_needed' => 'Potreban pregled',
    'low' => 'Nizak',
    'medium' => 'Srednji',
    'high' => 'Visok',
    'confidentiality' => 'Poverljivost',
    'integrity' => 'Integritet',
    'availability' => 'Dostupnost',
    'mixed' => 'Mešovito',
    'contract' => 'Ugovor',
    'consent' => 'Pristanak',
    'legal_obligation' => 'Pravna obaveza',
    'legitimate_interests' => 'Legitimni interesi',
    'vital_interests' => 'Životno važni interesi',
    'public_task' => 'Javni zadatak',
    'technical' => 'Tehnička',
    'organizational' => 'Organizaciona',
    'human_error' => 'Ljudska greška',
    'external' => 'Spoljna',
    'systematic_monitoring' => 'Sistematsko praćenje',
    'sensitive_data' => 'Osetljivi podaci',
    'other' => 'Ostalo',
    'administration' => 'Administracija',
    'hr' => 'Ljudski resursi',
    'finance' => 'Finansije',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Operacije',
    'pending' => 'Na čekanju',
    'rejected' => 'Odbijeno',
    'planned' => 'Planirano',
    'donations' => 'Donacije',
    'create_dpia' => 'Kreiraj DPIA',
    'create_dpia_from_gdpr' => 'Kreiraj DPIA iz GDPR',
    'click_create_dpia_for_gdpr' => 'Kliknite na "Kreiraj DPIA" za GDPR zapis koji zahteva DPIA:',
    'new_gdpr_record' => 'Novi GDPR zapis',
    'edit_gdpr_record' => 'Izmeni GDPR zapis',
    'new_dpia' => 'Nova DPIA',
    'edit_dpia' => 'Izmeni DPIA',
    'new_breach' => 'Nova povreda podataka',
    'edit_breach' => 'Izmeni povredu podataka',
    'new_third_party' => 'Novo treće lice',
    'edit_third_party' => 'Izmeni treće lice',
    'record' => 'Zapis',
    'page' => 'Stranica',
    'generated' => 'Generisano',
    'successfully_added' => 'uspešno dodato',
    'successfully_updated' => 'uspešno ažurirano',
    'unsaved_changes_confirm' => 'Postoje nesačuvane izmene. Da li ste sigurni da želite da otkažete?',
    'select_or_type_below' => 'Izaberite ili unesite ispod',
    'or_type_custom_retention_period' => 'Ili unesite prilagođen period čuvanja',
    'or_type_custom_safeguards' => 'Ili unesite prilagođene zaštitne mere (odvojene tačkom-zarezom)',
    'or_type_custom_measures' => 'Ili unesite prilagođene mere (odvojene tačkom-zarezom)',
    'hold_ctrl_to_select_multiple' => 'Držite Ctrl (Windows) ili Cmd (Mac) za višestruki izbor',
    'custom_mitigation_measures' => 'Prilagođene mere ublažavanja (odvojene tačkom-zarezom)',
    'custom_measures_taken' => 'Prilagođene preduzete mere (odvojene tačkom-zarezom)',
    'custom_measures_placeholder' => 'npr. prilagođena mera 1; prilagođena mera 2',
    'gdpr_record_id' => 'ID GDPR zapisa',
    'gdpr_record' => 'GDPR zapis',
    'dpia_for_gdpr' => 'DPIA za GDPR',
    'dpia_exists_for_gdpr' => 'DPIA za ovaj GDPR već postoji',
    'for_gdpr_record' => 'za GDPR zapis',
    'only_one_dpia_allowed' => 'Dozvoljena je samo jedna DPIA po GDPR zapisu.',
    'risk_distribution' => 'Raspodela rizika',
    'gdpr_compliance_overview' => 'Pregled usklađenosti sa GDPR',
    'inactive_draft' => 'Neaktivno / Nacrt',
    'collected_from_records' => 'Prikupljeno iz zapisa',
    'measure' => 'Mera',
    'value' => 'Vrednost',
    'source' => 'Izvor',
    'configuration' => 'Konfiguracija',
    'no_technical_measures' => 'Nisu pronađene tehničke mere',
    'no_organizational_measures' => 'Nisu pronađene organizacione mere',
    'edit_measure' => 'Izmeni meru',
    'current_measure' => 'Trenutna mera',
    'new_measure_name' => 'Novi naziv mere',
    'measure_renamed_success' => 'Mera je uspešno preimenovana svuda gde se koristi.',
    'measure_rename_warning' => 'Ovo će preimenovati meru u svakom GDPR, DPIA i zapisu povrede podataka gde se koristi.',
    'measure_deleted_success' => 'Mera je uspešno obrisana svuda gde se koristila.',
    'confirm_delete_measure' => 'Da li ste sigurni da želite da obrišete ovu meru? Biće uklonjena iz svakog GDPR, DPIA i zapisa povrede podataka gde se koristi. Ova radnja se ne može poništiti.',
    'responsible' => 'Odgovorno lice',
    'responsible_placeholder' => 'Ko je odgovoran za ovu meru?',
    'unassigned' => 'Nedodeljeno',
    'value_renamed_success' => 'Vrednost je uspešno preimenovana svuda gde se koristi.',
    'value_deleted_success' => 'Vrednost je uspešno uklonjena svuda gde se koristila.',
    'edit_value' => 'Izmeni vrednost',
    'delete_value' => 'Obriši vrednost',
    'current_value' => 'Trenutna vrednost',
    'new_value' => 'Nova vrednost',
    'value_rename_warning' => 'Preimenovanje će ažurirati ovu vrednost svuda gde se trenutno koristi.',
    'value_delete_warning' => 'Brisanje će ukloniti ovu vrednost iz svakog zapisa gde se trenutno koristi. Ova radnja se ne može poništiti.',
    'confirm_delete_value' => 'Obrisati ovu vrednost svuda gde se koristi? Ova radnja se ne može poništiti.',
    'used_in' => 'Korišćeno u',
    'not_currently_used' => 'Trenutno se ne koristi',
    'no_values' => 'Nisu pronađene vrednosti',
    'total_gdpr_records' => 'Ukupno GDPR zapisa',
    'dpia_in_progress' => 'DPIA u toku',
    'total_breaches' => 'Ukupno povreda',
    'open_breaches' => 'Otvorene povrede',
    'total_third_parties' => 'Ukupno trećih lica',
    'compliant_third_parties' => 'Usklađena treća lica',
    'dpia_coverage' => 'Pokrivenost DPIA',
    'gdpr_with_dpia_required' => 'GDPR koji zahteva DPIA',
    'dpia_completion_rate' => 'Stopa završenosti DPIA',
    'category' => 'Kategorija',
    'overview' => 'Pregled',
    'per_category' => 'Po kategoriji',
    'total_risk' => 'Ukupan rizik',
    'completion_rate' => 'Stopa završenosti',
    'record_type' => 'Vrsta zapisa',
    'print_report_title' => 'Izveštaj o usklađenosti',
    'generated_on' => 'Generisano',
    'not_started' => 'Nije započeto',
    'safeguard_scc' => 'Standardne ugovorne klauzule (SCC)',
    'safeguard_bcr' => 'Obavezujuća korporativna pravila (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (više nije važeći)',
    'safeguard_adequacy_decision' => 'Odluka Evropske komisije o adekvatnosti',
    'safeguard_consent' => 'Posebna saglasnost lica na koje se podaci odnose',
    'safeguard_model_contracts' => 'Model ugovori',
    'safeguard_certification' => 'Mehanizmi sertifikacije',
    'safeguard_codes_of_conduct' => 'Kodeksi ponašanja',
    'safeguard_dpia' => 'Procena uticaja na zaštitu podataka (DPIA)',
    'safeguard_tia' => 'Procena uticaja međunarodnog prenosa podataka (TIA)',
    'inactive' => 'Neaktivno',
];

// ==================== BENGALI ====================
$translations['bn'] = [
    'app_title' => 'GDPR নিবন্ধন',
    'company_subtitle' => 'গোপনীয়তা ও সম্মতি',
    'dashboard' => 'ড্যাশবোর্ড',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'তথ্য লঙ্ঘন',
    'breach' => 'তথ্য লঙ্ঘন',
    'third_parties' => 'তৃতীয় পক্ষ',
    'third_party' => 'তৃতীয় পক্ষ',
    'measures' => 'ব্যবস্থা',
    'reporting' => 'রিপোর্টিং',
    'total' => 'মোট',
    'active' => 'সক্রিয়',
    'high_risk' => 'উচ্চ ঝুঁকি',
    'dpia_required' => 'DPIA প্রয়োজন',
    'dpia_completed' => 'DPIA সম্পন্ন',
    'new' => 'নতুন',
    'export_json' => 'JSON রপ্তানি',
    'search' => 'অনুসন্ধান...',
    'search_company' => 'কোম্পানি অনুসন্ধান...',
    'filter' => 'ফিল্টার',
    'clear' => 'পরিষ্কার',
    'risk' => 'ঝুঁকি',
    'risk_level' => 'ঝুঁকির স্তর',
    'status' => 'অবস্থা',
    'retention_period' => 'ধারণ সময়কাল',
    'actions' => 'কার্যক্রম',
    'view' => 'দেখুন',
    'edit' => 'সম্পাদনা',
    'delete' => 'মুছুন',
    'print' => 'মুদ্রণ',
    'confirm_delete' => 'আপনি কি নিশ্চিত যে আপনি এই রেকর্ডটি মুছতে চান? এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না।',
    'processing_activity' => 'প্রক্রিয়াকরণ কার্যক্রম',
    'purpose' => 'উদ্দেশ্য',
    'data_subjects' => 'তথ্য বিষয়',
    'personal_data' => 'ব্যক্তিগত তথ্য',
    'recipients' => 'প্রাপক',
    'legal_basis' => 'আইনি ভিত্তি',
    'legitimate_interest' => 'বৈধ স্বার্থ',
    'department' => 'বিভাগ',
    'or_type_custom_department' => 'অথবা একটি কাস্টম বিভাগ টাইপ করুন',
    'or_type_custom_name' => 'অথবা একটি নাম টাইপ করুন',
    'or_type_custom_risk_origin' => 'অথবা একটি কাস্টম ঝুঁকির উৎস টাইপ করুন',
    'or_type_custom_status' => 'অথবা একটি কাস্টম অবস্থা টাইপ করুন',
    'or_type_custom_approval' => 'অথবা একটি কাস্টম অনুমোদন অবস্থা টাইপ করুন',
    'or_type_custom_consultation' => 'অথবা একটি কাস্টম মান টাইপ করুন',
    'or_type_custom_compliance_status' => 'অথবা একটি কাস্টম সম্মতি অবস্থা টাইপ করুন',
    'or_type_custom_breach_type' => 'অথবা একটি কাস্টম লঙ্ঘনের ধরন টাইপ করুন',
    'international_transfer' => 'আন্তর্জাতিক স্থানান্তর',
    'to_country' => 'দেশের উদ্দেশ্যে',
    'we_are_processor' => 'আমরা প্রসেসর',
    'processing_agreement_third_party' => 'তৃতীয় পক্ষের সাথে প্রক্রিয়াকরণ চুক্তি',
    'technical_measures' => 'প্রযুক্তিগত ব্যবস্থা',
    'organizational_measures' => 'সাংগঠনিক ব্যবস্থা',
    'safeguards' => 'সুরক্ষা ব্যবস্থা',
    'review_date' => 'পর্যালোচনার তারিখ',
    'controller' => 'নিয়ন্ত্রক',
    'joint_controller' => 'যৌথ নিয়ন্ত্রক',
    'dpo' => 'DPO',
    'representative' => 'প্রতিনিধি',
    'name' => 'নাম',
    'contact' => 'যোগাযোগ',
    'title' => 'শিরোনাম',
    'description' => 'বিবরণ',
    'risk_origin' => 'ঝুঁকির উৎস',
    'affected_subjects' => 'প্রভাবিত বিষয়সমূহ',
    'management_approval' => 'ব্যবস্থাপনা অনুমোদন',
    'approved_by' => 'অনুমোদনকারী',
    'approval_date' => 'অনুমোদনের তারিখ',
    'consultation_conducted' => 'পরামর্শ সম্পন্ন হয়েছে',
    'consultation_details' => 'পরামর্শের বিবরণ',
    'recommendations' => 'সুপারিশ',
    'notes' => 'নোট',
    'necessity_test' => 'প্রয়োজনীয়তা পরীক্ষা',
    'proportionality_test' => 'আনুপাতিকতা পরীক্ষা',
    'mitigation_measures' => 'প্রশমন ব্যবস্থা',
    'residual_risk' => 'অবশিষ্ট ঝুঁকি',
    'breach_date' => 'লঙ্ঘনের তারিখ',
    'discovery_date' => 'আবিষ্কারের তারিখ',
    'breach_type' => 'লঙ্ঘনের ধরন',
    'causes' => 'কারণসমূহ',
    'measures_taken' => 'গৃহীত ব্যবস্থা',
    'notified_authority' => 'কর্তৃপক্ষকে অবহিত করা হয়েছে',
    'notification_date' => 'বিজ্ঞপ্তির তারিখ',
    'notified_affected' => 'প্রভাবিত ব্যক্তিদের অবহিত করা হয়েছে',
    'company_name' => 'কোম্পানির নাম',
    'contact_person' => 'যোগাযোগের ব্যক্তি',
    'email' => 'ইমেইল',
    'phone' => 'ফোন',
    'address' => 'ঠিকানা',
    'service_provided' => 'প্রদত্ত সেবা',
    'agreement_signed' => 'চুক্তি স্বাক্ষরিত',
    'agreement_date' => 'চুক্তির তারিখ',
    'expiry_date' => 'মেয়াদোত্তীর্ণের তারিখ',
    'compliance_status' => 'সম্মতির অবস্থা',
    'save' => 'সংরক্ষণ',
    'cancel' => 'বাতিল',
    'add' => 'যোগ করুন',
    'close' => 'বন্ধ করুন',
    'language' => 'ভাষা',
    'logout' => 'লগআউট',
    'logout_confirm' => 'এই সেশন থেকে লগআউট করবেন?',
    'full_report' => 'সম্পূর্ণ প্রতিবেদন',
    'backup' => 'ব্যাকআপ',
    'zip_backup' => 'ZIP ব্যাকআপ',
    'statistics' => 'পরিসংখ্যান',
    'no_records' => 'কোনো রেকর্ড পাওয়া যায়নি',
    'showing' => 'প্রদর্শিত',
    'of' => 'এর মধ্যে',
    'yes' => 'হ্যাঁ',
    'no' => 'না',
    'unknown' => 'অজানা',
    'not_required' => 'প্রয়োজন নেই',
    'in_progress' => 'চলমান',
    'completed' => 'সম্পন্ন',
    'approved' => 'অনুমোদিত',
    'draft' => 'খসড়া',
    'open' => 'খোলা',
    'investigating' => 'তদন্তাধীন',
    'contained' => 'নিয়ন্ত্রিত',
    'resolved' => 'সমাধান হয়েছে',
    'closed' => 'বন্ধ',
    'compliant' => 'সম্মত',
    'non_compliant' => 'অসম্মত',
    'review_needed' => 'পর্যালোচনা প্রয়োজন',
    'low' => 'কম',
    'medium' => 'মাঝারি',
    'high' => 'উচ্চ',
    'confidentiality' => 'গোপনীয়তা',
    'integrity' => 'সম্পূর্ণতা',
    'availability' => 'প্রাপ্যতা',
    'mixed' => 'মিশ্র',
    'contract' => 'চুক্তি',
    'consent' => 'সম্মতি',
    'legal_obligation' => 'আইনি বাধ্যবাধকতা',
    'legitimate_interests' => 'বৈধ স্বার্থ',
    'vital_interests' => 'গুরুত্বপূর্ণ স্বার্থ',
    'public_task' => 'সরকারি কাজ',
    'technical' => 'প্রযুক্তিগত',
    'organizational' => 'সাংগঠনিক',
    'human_error' => 'মানবিক ভুল',
    'external' => 'বাহ্যিক',
    'systematic_monitoring' => 'পদ্ধতিগত পর্যবেক্ষণ',
    'sensitive_data' => 'সংবেদনশীল তথ্য',
    'other' => 'অন্যান্য',
    'administration' => 'প্রশাসন',
    'hr' => 'মানব সম্পদ',
    'finance' => 'অর্থ',
    'marketing' => 'বিপণন',
    'it' => 'আইটি',
    'operations' => 'পরিচালনা',
    'pending' => 'মুলতুবি',
    'rejected' => 'প্রত্যাখ্যাত',
    'planned' => 'পরিকল্পিত',
    'donations' => 'অনুদান',
    'create_dpia' => 'DPIA তৈরি করুন',
    'create_dpia_from_gdpr' => 'GDPR থেকে DPIA তৈরি করুন',
    'click_create_dpia_for_gdpr' => 'DPIA প্রয়োজন এমন GDPR রেকর্ডের জন্য "DPIA তৈরি করুন" ক্লিক করুন:',
    'new_gdpr_record' => 'নতুন GDPR রেকর্ড',
    'edit_gdpr_record' => 'GDPR রেকর্ড সম্পাদনা করুন',
    'new_dpia' => 'নতুন DPIA',
    'edit_dpia' => 'DPIA সম্পাদনা করুন',
    'new_breach' => 'নতুন তথ্য লঙ্ঘন',
    'edit_breach' => 'তথ্য লঙ্ঘন সম্পাদনা করুন',
    'new_third_party' => 'নতুন তৃতীয় পক্ষ',
    'edit_third_party' => 'তৃতীয় পক্ষ সম্পাদনা করুন',
    'record' => 'রেকর্ড',
    'page' => 'পৃষ্ঠা',
    'generated' => 'তৈরি হয়েছে',
    'successfully_added' => 'সফলভাবে যোগ করা হয়েছে',
    'successfully_updated' => 'সফলভাবে আপডেট করা হয়েছে',
    'unsaved_changes_confirm' => 'সংরক্ষিত হয়নি এমন পরিবর্তন রয়েছে। আপনি কি নিশ্চিতভাবে বাতিল করতে চান?',
    'select_or_type_below' => 'নির্বাচন করুন অথবা নিচে টাইপ করুন',
    'or_type_custom_retention_period' => 'অথবা একটি কাস্টম ধারণ সময়কাল টাইপ করুন',
    'or_type_custom_safeguards' => 'অথবা কাস্টম সুরক্ষা ব্যবস্থা টাইপ করুন (সেমিকোলন দ্বারা পৃথক)',
    'or_type_custom_measures' => 'অথবা কাস্টম ব্যবস্থা টাইপ করুন (সেমিকোলন দ্বারা পৃথক)',
    'hold_ctrl_to_select_multiple' => 'একাধিক নির্বাচন করতে Ctrl (Windows) অথবা Cmd (Mac) ধরে রাখুন',
    'custom_mitigation_measures' => 'কাস্টম প্রশমন ব্যবস্থা (সেমিকোলন দ্বারা পৃথক)',
    'custom_measures_taken' => 'কাস্টম গৃহীত ব্যবস্থা (সেমিকোলন দ্বারা পৃথক)',
    'custom_measures_placeholder' => 'যেমন কাস্টম ব্যবস্থা ১; কাস্টম ব্যবস্থা ২',
    'gdpr_record_id' => 'GDPR রেকর্ড আইডি',
    'gdpr_record' => 'GDPR রেকর্ড',
    'dpia_for_gdpr' => 'GDPR এর জন্য DPIA',
    'dpia_exists_for_gdpr' => 'এই GDPR এর জন্য ইতিমধ্যে একটি DPIA বিদ্যমান',
    'for_gdpr_record' => 'GDPR রেকর্ডের জন্য',
    'only_one_dpia_allowed' => 'প্রতিটি GDPR রেকর্ডে শুধুমাত্র একটি DPIA অনুমোদিত।',
    'risk_distribution' => 'ঝুঁকির বিতরণ',
    'gdpr_compliance_overview' => 'GDPR সম্মতি সংক্ষিপ্ত বিবরণ',
    'inactive_draft' => 'নিষ্ক্রিয় / খসড়া',
    'collected_from_records' => 'রেকর্ড থেকে সংগৃহীত',
    'measure' => 'ব্যবস্থা',
    'value' => 'মান',
    'source' => 'উৎস',
    'configuration' => 'কনফিগারেশন',
    'no_technical_measures' => 'কোনো প্রযুক্তিগত ব্যবস্থা পাওয়া যায়নি',
    'no_organizational_measures' => 'কোনো সাংগঠনিক ব্যবস্থা পাওয়া যায়নি',
    'edit_measure' => 'ব্যবস্থা সম্পাদনা করুন',
    'current_measure' => 'বর্তমান ব্যবস্থা',
    'new_measure_name' => 'নতুন ব্যবস্থার নাম',
    'measure_renamed_success' => 'ব্যবস্থাটি যেখানেই ব্যবহৃত হয় সেখানে সফলভাবে পুনঃনামকরণ করা হয়েছে।',
    'measure_rename_warning' => 'এটি এই ব্যবস্থাটি যে সমস্ত GDPR, DPIA এবং তথ্য লঙ্ঘন রেকর্ডে ব্যবহৃত হয় সেখানে পুনঃনামকরণ করবে।',
    'measure_deleted_success' => 'ব্যবস্থাটি যেখানেই ব্যবহৃত হয়েছিল সেখান থেকে সফলভাবে মুছে ফেলা হয়েছে।',
    'confirm_delete_measure' => 'আপনি কি নিশ্চিত যে আপনি এই ব্যবস্থাটি মুছতে চান? এটি ব্যবহৃত হওয়া প্রতিটি GDPR, DPIA এবং তথ্য লঙ্ঘন রেকর্ড থেকে সরানো হবে। এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না।',
    'responsible' => 'দায়িত্বপ্রাপ্ত',
    'responsible_placeholder' => 'এই ব্যবস্থার জন্য কে দায়ী?',
    'unassigned' => 'অনির্ধারিত',
    'value_renamed_success' => 'মানটি যেখানেই ব্যবহৃত হয় সেখানে সফলভাবে পুনঃনামকরণ করা হয়েছে।',
    'value_deleted_success' => 'মানটি যেখানেই ব্যবহৃত হয়েছিল সেখান থেকে সফলভাবে সরানো হয়েছে।',
    'edit_value' => 'মান সম্পাদনা করুন',
    'delete_value' => 'মান মুছুন',
    'current_value' => 'বর্তমান মান',
    'new_value' => 'নতুন মান',
    'value_rename_warning' => 'পুনঃনামকরণ এই মানটি বর্তমানে যেখানে ব্যবহৃত হয় সেখানে আপডেট করবে।',
    'value_delete_warning' => 'মুছে ফেলা এই মানটি বর্তমানে ব্যবহৃত হওয়া প্রতিটি রেকর্ড থেকে সরিয়ে দেবে। এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না।',
    'confirm_delete_value' => 'এই মানটি যেখানেই ব্যবহৃত হয় সেখান থেকে মুছবেন? এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না।',
    'used_in' => 'ব্যবহৃত হয়েছে',
    'not_currently_used' => 'বর্তমানে ব্যবহৃত হচ্ছে না',
    'no_values' => 'কোনো মান পাওয়া যায়নি',
    'total_gdpr_records' => 'মোট GDPR রেকর্ড',
    'dpia_in_progress' => 'DPIA চলমান',
    'total_breaches' => 'মোট লঙ্ঘন',
    'open_breaches' => 'খোলা লঙ্ঘন',
    'total_third_parties' => 'মোট তৃতীয় পক্ষ',
    'compliant_third_parties' => 'সম্মত তৃতীয় পক্ষ',
    'dpia_coverage' => 'DPIA কভারেজ',
    'gdpr_with_dpia_required' => 'DPIA প্রয়োজন এমন GDPR',
    'dpia_completion_rate' => 'DPIA সমাপ্তির হার',
    'category' => 'বিভাগ',
    'overview' => 'সংক্ষিপ্ত বিবরণ',
    'per_category' => 'বিভাগ অনুযায়ী',
    'total_risk' => 'মোট ঝুঁকি',
    'completion_rate' => 'সমাপ্তির হার',
    'record_type' => 'রেকর্ডের ধরন',
    'print_report_title' => 'সম্মতি প্রতিবেদন',
    'generated_on' => 'তৈরি হয়েছে',
    'not_started' => 'শুরু হয়নি',
    'safeguard_scc' => 'মানক চুক্তির শর্তাবলী (SCC)',
    'safeguard_bcr' => 'বাধ্যতামূলক কর্পোরেট নিয়মাবলী (BCR)',
    'safeguard_privacy_shield' => 'প্রাইভেসি শিল্ড (আর বৈধ নয়)',
    'safeguard_adequacy_decision' => 'ইউরোপীয় কমিশনের পর্যাপ্ততা সিদ্ধান্ত',
    'safeguard_consent' => 'তথ্য বিষয়ের নির্দিষ্ট সম্মতি',
    'safeguard_model_contracts' => 'মডেল চুক্তি',
    'safeguard_certification' => 'সার্টিফিকেশন প্রক্রিয়া',
    'safeguard_codes_of_conduct' => 'আচরণবিধি',
    'safeguard_dpia' => 'তথ্য সুরক্ষা প্রভাব মূল্যায়ন (DPIA)',
    'safeguard_tia' => 'আন্তর্জাতিক তথ্য স্থানান্তর প্রভাব মূল্যায়ন (TIA)',
    'inactive' => 'নিষ্ক্রিয়',
];

// ==================== URDU ====================
$translations['ur'] = [
    'app_title' => 'GDPR رجسٹر',
    'company_subtitle' => 'رازداری اور تعمیل',
    'dashboard' => 'ڈیش بورڈ',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'ڈیٹا کی خلاف ورزیاں',
    'breach' => 'ڈیٹا کی خلاف ورزی',
    'third_parties' => 'تیسرے فریق',
    'third_party' => 'تیسرا فریق',
    'measures' => 'اقدامات',
    'reporting' => 'رپورٹنگ',
    'total' => 'کل',
    'active' => 'فعال',
    'high_risk' => 'زیادہ خطرہ',
    'dpia_required' => 'DPIA درکار ہے',
    'dpia_completed' => 'DPIA مکمل',
    'new' => 'نیا',
    'export_json' => 'JSON ایکسپورٹ کریں',
    'search' => 'تلاش کریں...',
    'search_company' => 'کمپنی تلاش کریں...',
    'filter' => 'فلٹر',
    'clear' => 'صاف کریں',
    'risk' => 'خطرہ',
    'risk_level' => 'خطرے کی سطح',
    'status' => 'حیثیت',
    'retention_period' => 'برقراری کی مدت',
    'actions' => 'اقدامات',
    'view' => 'دیکھیں',
    'edit' => 'ترمیم کریں',
    'delete' => 'حذف کریں',
    'print' => 'پرنٹ کریں',
    'confirm_delete' => 'کیا آپ واقعی اس ریکارڈ کو حذف کرنا چاہتے ہیں؟ اس عمل کو واپس نہیں لیا جا سکتا۔',
    'processing_activity' => 'پروسیسنگ کی سرگرمی',
    'purpose' => 'مقصد',
    'data_subjects' => 'ڈیٹا کے موضوعات',
    'personal_data' => 'ذاتی ڈیٹا',
    'recipients' => 'وصول کنندگان',
    'legal_basis' => 'قانونی بنیاد',
    'legitimate_interest' => 'جائز مفاد',
    'department' => 'شعبہ',
    'or_type_custom_department' => 'یا ایک اپنی مرضی کا شعبہ ٹائپ کریں',
    'or_type_custom_name' => 'یا ایک نام ٹائپ کریں',
    'or_type_custom_risk_origin' => 'یا اپنی مرضی کا خطرے کا ماخذ ٹائپ کریں',
    'or_type_custom_status' => 'یا اپنی مرضی کی حیثیت ٹائپ کریں',
    'or_type_custom_approval' => 'یا اپنی مرضی کی منظوری کی حیثیت ٹائپ کریں',
    'or_type_custom_consultation' => 'یا اپنی مرضی کی قدر ٹائپ کریں',
    'or_type_custom_compliance_status' => 'یا اپنی مرضی کی تعمیل کی حیثیت ٹائپ کریں',
    'or_type_custom_breach_type' => 'یا اپنی مرضی کی خلاف ورزی کی قسم ٹائپ کریں',
    'international_transfer' => 'بین الاقوامی منتقلی',
    'to_country' => 'ملک کو',
    'we_are_processor' => 'ہم پروسیسر ہیں',
    'processing_agreement_third_party' => 'تیسرے فریق کے ساتھ پروسیسنگ معاہدہ',
    'technical_measures' => 'تکنیکی اقدامات',
    'organizational_measures' => 'تنظیمی اقدامات',
    'safeguards' => 'حفاظتی تدابیر',
    'review_date' => 'جائزے کی تاریخ',
    'controller' => 'کنٹرولر',
    'joint_controller' => 'مشترکہ کنٹرولر',
    'dpo' => 'DPO',
    'representative' => 'نمائندہ',
    'name' => 'نام',
    'contact' => 'رابطہ',
    'title' => 'عنوان',
    'description' => 'تفصیل',
    'risk_origin' => 'خطرے کا ماخذ',
    'affected_subjects' => 'متاثرہ موضوعات',
    'management_approval' => 'انتظامیہ کی منظوری',
    'approved_by' => 'منظور کردہ از',
    'approval_date' => 'منظوری کی تاریخ',
    'consultation_conducted' => 'مشاورت مکمل',
    'consultation_details' => 'مشاورت کی تفصیلات',
    'recommendations' => 'سفارشات',
    'notes' => 'نوٹس',
    'necessity_test' => 'ضرورت کا امتحان',
    'proportionality_test' => 'تناسب کا امتحان',
    'mitigation_measures' => 'تخفیفی اقدامات',
    'residual_risk' => 'باقی ماندہ خطرہ',
    'breach_date' => 'خلاف ورزی کی تاریخ',
    'discovery_date' => 'دریافت کی تاریخ',
    'breach_type' => 'خلاف ورزی کی قسم',
    'causes' => 'وجوہات',
    'measures_taken' => 'اختیار کردہ اقدامات',
    'notified_authority' => 'اتھارٹی کو مطلع کیا گیا',
    'notification_date' => 'اطلاع کی تاریخ',
    'notified_affected' => 'متاثرہ افراد کو مطلع کیا گیا',
    'company_name' => 'کمپنی کا نام',
    'contact_person' => 'رابطہ شخص',
    'email' => 'ای میل',
    'phone' => 'فون',
    'address' => 'پتہ',
    'service_provided' => 'فراہم کردہ خدمت',
    'agreement_signed' => 'معاہدہ دستخط شدہ',
    'agreement_date' => 'معاہدے کی تاریخ',
    'expiry_date' => 'میعاد ختم ہونے کی تاریخ',
    'compliance_status' => 'تعمیل کی حیثیت',
    'save' => 'محفوظ کریں',
    'cancel' => 'منسوخ کریں',
    'add' => 'شامل کریں',
    'close' => 'بند کریں',
    'language' => 'زبان',
    'logout' => 'لاگ آؤٹ',
    'logout_confirm' => 'اس سیشن سے لاگ آؤٹ کریں؟',
    'full_report' => 'مکمل رپورٹ',
    'backup' => 'بیک اپ',
    'zip_backup' => 'ZIP بیک اپ',
    'statistics' => 'اعداد و شمار',
    'no_records' => 'کوئی ریکارڈ نہیں ملا',
    'showing' => 'دکھایا جا رہا ہے',
    'of' => 'از',
    'yes' => 'ہاں',
    'no' => 'نہیں',
    'unknown' => 'نامعلوم',
    'not_required' => 'ضرورت نہیں',
    'in_progress' => 'جاری ہے',
    'completed' => 'مکمل',
    'approved' => 'منظور شدہ',
    'draft' => 'مسودہ',
    'open' => 'کھلا',
    'investigating' => 'تحقیقات جاری',
    'contained' => 'قابو میں',
    'resolved' => 'حل شدہ',
    'closed' => 'بند',
    'compliant' => 'موافق',
    'non_compliant' => 'غیر موافق',
    'review_needed' => 'جائزہ درکار',
    'low' => 'کم',
    'medium' => 'درمیانہ',
    'high' => 'زیادہ',
    'confidentiality' => 'رازداری',
    'integrity' => 'سالمیت',
    'availability' => 'دستیابی',
    'mixed' => 'مخلوط',
    'contract' => 'معاہدہ',
    'consent' => 'رضامندی',
    'legal_obligation' => 'قانونی فرض',
    'legitimate_interests' => 'جائز مفادات',
    'vital_interests' => 'اہم مفادات',
    'public_task' => 'عوامی فریضہ',
    'technical' => 'تکنیکی',
    'organizational' => 'تنظیمی',
    'human_error' => 'انسانی غلطی',
    'external' => 'بیرونی',
    'systematic_monitoring' => 'منظم نگرانی',
    'sensitive_data' => 'حساس ڈیٹا',
    'other' => 'دیگر',
    'administration' => 'انتظامیہ',
    'hr' => 'انسانی وسائل',
    'finance' => 'مالیات',
    'marketing' => 'مارکیٹنگ',
    'it' => 'آئی ٹی',
    'operations' => 'آپریشنز',
    'pending' => 'زیر التوا',
    'rejected' => 'مسترد',
    'planned' => 'منصوبہ بند',
    'donations' => 'عطیات',
    'create_dpia' => 'DPIA بنائیں',
    'create_dpia_from_gdpr' => 'GDPR سے DPIA بنائیں',
    'click_create_dpia_for_gdpr' => 'DPIA کی ضرورت والے GDPR ریکارڈ کے لیے "DPIA بنائیں" پر کلک کریں:',
    'new_gdpr_record' => 'نیا GDPR ریکارڈ',
    'edit_gdpr_record' => 'GDPR ریکارڈ میں ترمیم کریں',
    'new_dpia' => 'نیا DPIA',
    'edit_dpia' => 'DPIA میں ترمیم کریں',
    'new_breach' => 'نئی ڈیٹا خلاف ورزی',
    'edit_breach' => 'ڈیٹا خلاف ورزی میں ترمیم کریں',
    'new_third_party' => 'نیا تیسرا فریق',
    'edit_third_party' => 'تیسرے فریق میں ترمیم کریں',
    'record' => 'ریکارڈ',
    'page' => 'صفحہ',
    'generated' => 'تیار کردہ',
    'successfully_added' => 'کامیابی سے شامل کیا گیا',
    'successfully_updated' => 'کامیابی سے اپ ڈیٹ کیا گیا',
    'unsaved_changes_confirm' => 'غیر محفوظ شدہ تبدیلیاں موجود ہیں۔ کیا آپ واقعی منسوخ کرنا چاہتے ہیں؟',
    'select_or_type_below' => 'منتخب کریں یا نیچے ٹائپ کریں',
    'or_type_custom_retention_period' => 'یا اپنی مرضی کی برقراری کی مدت ٹائپ کریں',
    'or_type_custom_safeguards' => 'یا اپنی مرضی کی حفاظتی تدابیر ٹائپ کریں (سیمی کالن سے الگ)',
    'or_type_custom_measures' => 'یا اپنی مرضی کے اقدامات ٹائپ کریں (سیمی کالن سے الگ)',
    'hold_ctrl_to_select_multiple' => 'متعدد منتخب کرنے کے لیے Ctrl (ونڈوز) یا Cmd (میک) دبائے رکھیں',
    'custom_mitigation_measures' => 'اپنی مرضی کے تخفیفی اقدامات (سیمی کالن سے الگ)',
    'custom_measures_taken' => 'اپنی مرضی کے اختیار کردہ اقدامات (سیمی کالن سے الگ)',
    'custom_measures_placeholder' => 'مثلاً اپنی مرضی کا اقدام 1؛ اپنی مرضی کا اقدام 2',
    'gdpr_record_id' => 'GDPR ریکارڈ ID',
    'gdpr_record' => 'GDPR ریکارڈ',
    'dpia_for_gdpr' => 'GDPR کے لیے DPIA',
    'dpia_exists_for_gdpr' => 'اس GDPR کے لیے پہلے سے ایک DPIA موجود ہے',
    'for_gdpr_record' => 'GDPR ریکارڈ کے لیے',
    'only_one_dpia_allowed' => 'ہر GDPR ریکارڈ کے لیے صرف ایک DPIA کی اجازت ہے۔',
    'risk_distribution' => 'خطرے کی تقسیم',
    'gdpr_compliance_overview' => 'GDPR تعمیل کا جائزہ',
    'inactive_draft' => 'غیر فعال / مسودہ',
    'collected_from_records' => 'ریکارڈز سے جمع کیا گیا',
    'measure' => 'اقدام',
    'value' => 'قدر',
    'source' => 'ماخذ',
    'configuration' => 'ترتیب',
    'no_technical_measures' => 'کوئی تکنیکی اقدامات نہیں ملے',
    'no_organizational_measures' => 'کوئی تنظیمی اقدامات نہیں ملے',
    'edit_measure' => 'اقدام میں ترمیم کریں',
    'current_measure' => 'موجودہ اقدام',
    'new_measure_name' => 'اقدام کا نیا نام',
    'measure_renamed_success' => 'اقدام کا نام کامیابی سے ہر اس جگہ تبدیل کر دیا گیا جہاں یہ استعمال ہوتا ہے۔',
    'measure_rename_warning' => 'یہ ہر اس GDPR، DPIA اور ڈیٹا خلاف ورزی ریکارڈ میں اقدام کا نام تبدیل کر دے گا جہاں یہ استعمال ہوتا ہے۔',
    'measure_deleted_success' => 'اقدام کامیابی سے ہر اس جگہ سے حذف کر دیا گیا جہاں یہ استعمال ہوتا تھا۔',
    'confirm_delete_measure' => 'کیا آپ واقعی اس اقدام کو حذف کرنا چاہتے ہیں؟ یہ ہر اس GDPR، DPIA اور ڈیٹا خلاف ورزی ریکارڈ سے ہٹا دیا جائے گا جہاں یہ استعمال ہوتا ہے۔ اس عمل کو واپس نہیں لیا جا سکتا۔',
    'responsible' => 'ذمہ دار',
    'responsible_placeholder' => 'اس اقدام کا ذمہ دار کون ہے؟',
    'unassigned' => 'غیر تفویض شدہ',
    'value_renamed_success' => 'قدر کا نام کامیابی سے ہر اس جگہ تبدیل کر دیا گیا جہاں یہ استعمال ہوتی ہے۔',
    'value_deleted_success' => 'قدر کامیابی سے ہر اس جگہ سے حذف کر دی گئی جہاں یہ استعمال ہوتی تھی۔',
    'edit_value' => 'قدر میں ترمیم کریں',
    'delete_value' => 'قدر حذف کریں',
    'current_value' => 'موجودہ قدر',
    'new_value' => 'نئی قدر',
    'value_rename_warning' => 'نام تبدیل کرنے سے یہ قدر ہر اس جگہ اپ ڈیٹ ہو جائے گی جہاں یہ فی الحال استعمال ہوتی ہے۔',
    'value_delete_warning' => 'حذف کرنے سے یہ قدر ہر اس ریکارڈ سے صاف ہو جائے گی جہاں یہ فی الحال استعمال ہوتی ہے۔ اس عمل کو واپس نہیں لیا جا سکتا۔',
    'confirm_delete_value' => 'کیا اس قدر کو ہر اس جگہ سے حذف کر دیا جائے جہاں یہ استعمال ہوتی ہے؟ اس عمل کو واپس نہیں لیا جا سکتا۔',
    'used_in' => 'اس میں استعمال ہوا',
    'not_currently_used' => 'فی الحال استعمال نہیں ہو رہا',
    'no_values' => 'کوئی قدریں نہیں ملیں',
    'total_gdpr_records' => 'کل GDPR ریکارڈز',
    'dpia_in_progress' => 'جاری DPIA',
    'total_breaches' => 'کل خلاف ورزیاں',
    'open_breaches' => 'کھلی خلاف ورزیاں',
    'total_third_parties' => 'کل تیسرے فریق',
    'compliant_third_parties' => 'موافق تیسرے فریق',
    'dpia_coverage' => 'DPIA کوریج',
    'gdpr_with_dpia_required' => 'DPIA درکار GDPR',
    'dpia_completion_rate' => 'DPIA کی تکمیل کی شرح',
    'category' => 'زمرہ',
    'overview' => 'جائزہ',
    'per_category' => 'زمرہ کے لحاظ سے',
    'total_risk' => 'کل خطرہ',
    'completion_rate' => 'تکمیل کی شرح',
    'record_type' => 'ریکارڈ کی قسم',
    'print_report_title' => 'تعمیل رپورٹ',
    'generated_on' => 'تیار کردہ بتاریخ',
    'not_started' => 'شروع نہیں ہوا',
    'safeguard_scc' => 'معیاری معاہداتی شقیں (SCC)',
    'safeguard_bcr' => 'پابند کارپوریٹ قواعد (BCR)',
    'safeguard_privacy_shield' => 'پرائیویسی شیلڈ (اب درست نہیں)',
    'safeguard_adequacy_decision' => 'یورپی کمیشن کا مناسبیت کا فیصلہ',
    'safeguard_consent' => 'ڈیٹا کے موضوع کی خصوصی رضامندی',
    'safeguard_model_contracts' => 'نمونہ معاہدے',
    'safeguard_certification' => 'سرٹیفیکیشن میکانزم',
    'safeguard_codes_of_conduct' => 'ضابطہ اخلاق',
    'safeguard_dpia' => 'ڈیٹا تحفظ اثر کی تشخیص (DPIA)',
    'safeguard_tia' => 'بین الاقوامی ڈیٹا منتقلی اثر کی تشخیص (TIA)',
    'inactive' => 'غیر فعال',
];

// ==================== MALAY ====================
$translations['ms'] = [
    'app_title' => 'Daftar GDPR',
    'company_subtitle' => 'Privasi & Pematuhan',
    'dashboard' => 'Papan Pemuka',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Pelanggaran Data',
    'breach' => 'Pelanggaran Data',
    'third_parties' => 'Pihak Ketiga',
    'third_party' => 'Pihak Ketiga',
    'measures' => 'Langkah-langkah',
    'reporting' => 'Pelaporan',
    'total' => 'Jumlah',
    'active' => 'Aktif',
    'high_risk' => 'Risiko Tinggi',
    'dpia_required' => 'DPIA Diperlukan',
    'dpia_completed' => 'DPIA Selesai',
    'new' => 'Baharu',
    'export_json' => 'Eksport JSON',
    'search' => 'Cari...',
    'search_company' => 'Cari syarikat...',
    'filter' => 'Penapis',
    'clear' => 'Kosongkan',
    'risk' => 'Risiko',
    'risk_level' => 'Tahap Risiko',
    'status' => 'Status',
    'retention_period' => 'Tempoh Penyimpanan',
    'actions' => 'Tindakan',
    'view' => 'Lihat',
    'edit' => 'Sunting',
    'delete' => 'Padam',
    'print' => 'Cetak',
    'confirm_delete' => 'Adakah anda pasti mahu memadam rekod ini? Tindakan ini tidak boleh dibatalkan.',
    'processing_activity' => 'Aktiviti Pemprosesan',
    'purpose' => 'Tujuan',
    'data_subjects' => 'Subjek Data',
    'personal_data' => 'Data Peribadi',
    'recipients' => 'Penerima',
    'legal_basis' => 'Asas Perundangan',
    'legitimate_interest' => 'Kepentingan Sah',
    'department' => 'Jabatan',
    'or_type_custom_department' => 'Atau taip jabatan tersuai',
    'or_type_custom_name' => 'Atau taip nama',
    'or_type_custom_risk_origin' => 'Atau taip punca risiko tersuai',
    'or_type_custom_status' => 'Atau taip status tersuai',
    'or_type_custom_approval' => 'Atau taip status kelulusan tersuai',
    'or_type_custom_consultation' => 'Atau taip nilai tersuai',
    'or_type_custom_compliance_status' => 'Atau taip status pematuhan tersuai',
    'or_type_custom_breach_type' => 'Atau taip jenis pelanggaran tersuai',
    'international_transfer' => 'Pemindahan Antarabangsa',
    'to_country' => 'Ke Negara',
    'we_are_processor' => 'Kami adalah Pemproses',
    'processing_agreement_third_party' => 'Perjanjian Pemprosesan dengan Pihak Ketiga',
    'technical_measures' => 'Langkah Teknikal',
    'organizational_measures' => 'Langkah Organisasi',
    'safeguards' => 'Perlindungan',
    'review_date' => 'Tarikh Semakan',
    'controller' => 'Pengawal',
    'joint_controller' => 'Pengawal Bersama',
    'dpo' => 'DPO',
    'representative' => 'Wakil',
    'name' => 'Nama',
    'contact' => 'Hubungi',
    'title' => 'Tajuk',
    'description' => 'Penerangan',
    'risk_origin' => 'Punca Risiko',
    'affected_subjects' => 'Subjek Terjejas',
    'management_approval' => 'Kelulusan Pengurusan',
    'approved_by' => 'Diluluskan Oleh',
    'approval_date' => 'Tarikh Kelulusan',
    'consultation_conducted' => 'Perundingan Dijalankan',
    'consultation_details' => 'Butiran Perundingan',
    'recommendations' => 'Cadangan',
    'notes' => 'Nota',
    'necessity_test' => 'Ujian Keperluan',
    'proportionality_test' => 'Ujian Kadar Perimbangan',
    'mitigation_measures' => 'Langkah Mitigasi',
    'residual_risk' => 'Risiko Baki',
    'breach_date' => 'Tarikh Pelanggaran',
    'discovery_date' => 'Tarikh Penemuan',
    'breach_type' => 'Jenis Pelanggaran',
    'causes' => 'Punca',
    'measures_taken' => 'Langkah Diambil',
    'notified_authority' => 'Pihak Berkuasa Dimaklumkan',
    'notification_date' => 'Tarikh Pemberitahuan',
    'notified_affected' => 'Pihak Terjejas Dimaklumkan',
    'company_name' => 'Nama Syarikat',
    'contact_person' => 'Orang Hubungan',
    'email' => 'E-mel',
    'phone' => 'Telefon',
    'address' => 'Alamat',
    'service_provided' => 'Perkhidmatan Disediakan',
    'agreement_signed' => 'Perjanjian Ditandatangani',
    'agreement_date' => 'Tarikh Perjanjian',
    'expiry_date' => 'Tarikh Tamat Tempoh',
    'compliance_status' => 'Status Pematuhan',
    'save' => 'Simpan',
    'cancel' => 'Batal',
    'add' => 'Tambah',
    'close' => 'Tutup',
    'language' => 'Bahasa',
    'logout' => 'Log Keluar',
    'logout_confirm' => 'Log keluar dari sesi ini?',
    'full_report' => 'Laporan Penuh',
    'backup' => 'Sandaran',
    'zip_backup' => 'Sandaran ZIP',
    'statistics' => 'Statistik',
    'no_records' => 'Tiada rekod dijumpai',
    'showing' => 'Menunjukkan',
    'of' => 'daripada',
    'yes' => 'Ya',
    'no' => 'Tidak',
    'unknown' => 'Tidak diketahui',
    'not_required' => 'Tidak Diperlukan',
    'in_progress' => 'Dalam Proses',
    'completed' => 'Selesai',
    'approved' => 'Diluluskan',
    'draft' => 'Draf',
    'open' => 'Terbuka',
    'investigating' => 'Sedang Disiasat',
    'contained' => 'Terkawal',
    'resolved' => 'Diselesaikan',
    'closed' => 'Ditutup',
    'compliant' => 'Patuh',
    'non_compliant' => 'Tidak Patuh',
    'review_needed' => 'Perlu Disemak',
    'low' => 'Rendah',
    'medium' => 'Sederhana',
    'high' => 'Tinggi',
    'confidentiality' => 'Kerahsiaan',
    'integrity' => 'Integriti',
    'availability' => 'Ketersediaan',
    'mixed' => 'Campuran',
    'contract' => 'Kontrak',
    'consent' => 'Persetujuan',
    'legal_obligation' => 'Kewajipan Undang-undang',
    'legitimate_interests' => 'Kepentingan Sah',
    'vital_interests' => 'Kepentingan Penting',
    'public_task' => 'Tugas Awam',
    'technical' => 'Teknikal',
    'organizational' => 'Organisasi',
    'human_error' => 'Kesilapan Manusia',
    'external' => 'Luaran',
    'systematic_monitoring' => 'Pemantauan Sistematik',
    'sensitive_data' => 'Data Sensitif',
    'other' => 'Lain-lain',
    'administration' => 'Pentadbiran',
    'hr' => 'Sumber Manusia',
    'finance' => 'Kewangan',
    'marketing' => 'Pemasaran',
    'it' => 'IT',
    'operations' => 'Operasi',
    'pending' => 'Menunggu',
    'rejected' => 'Ditolak',
    'planned' => 'Dirancang',
    'donations' => 'Derma',
    'create_dpia' => 'Cipta DPIA',
    'create_dpia_from_gdpr' => 'Cipta DPIA daripada GDPR',
    'click_create_dpia_for_gdpr' => 'Klik "Cipta DPIA" untuk rekod GDPR yang memerlukan DPIA:',
    'new_gdpr_record' => 'Rekod GDPR Baharu',
    'edit_gdpr_record' => 'Sunting Rekod GDPR',
    'new_dpia' => 'DPIA Baharu',
    'edit_dpia' => 'Sunting DPIA',
    'new_breach' => 'Pelanggaran Data Baharu',
    'edit_breach' => 'Sunting Pelanggaran Data',
    'new_third_party' => 'Pihak Ketiga Baharu',
    'edit_third_party' => 'Sunting Pihak Ketiga',
    'record' => 'Rekod',
    'page' => 'Halaman',
    'generated' => 'Dijana',
    'successfully_added' => 'berjaya ditambah',
    'successfully_updated' => 'berjaya dikemas kini',
    'unsaved_changes_confirm' => 'Terdapat perubahan yang belum disimpan. Adakah anda pasti mahu membatalkan?',
    'select_or_type_below' => 'Pilih atau taip di bawah',
    'or_type_custom_retention_period' => 'Atau taip tempoh penyimpanan tersuai',
    'or_type_custom_safeguards' => 'Atau taip perlindungan tersuai (dipisahkan dengan koma bertitik)',
    'or_type_custom_measures' => 'Atau taip langkah tersuai (dipisahkan dengan koma bertitik)',
    'hold_ctrl_to_select_multiple' => 'Tahan Ctrl (Windows) atau Cmd (Mac) untuk memilih berbilang',
    'custom_mitigation_measures' => 'Langkah mitigasi tersuai (dipisahkan dengan koma bertitik)',
    'custom_measures_taken' => 'Langkah tersuai yang diambil (dipisahkan dengan koma bertitik)',
    'custom_measures_placeholder' => 'cth. Langkah tersuai 1; Langkah tersuai 2',
    'gdpr_record_id' => 'ID Rekod GDPR',
    'gdpr_record' => 'Rekod GDPR',
    'dpia_for_gdpr' => 'DPIA untuk GDPR',
    'dpia_exists_for_gdpr' => 'DPIA sudah wujud untuk GDPR',
    'for_gdpr_record' => 'untuk rekod GDPR',
    'only_one_dpia_allowed' => 'Hanya satu DPIA dibenarkan bagi setiap rekod GDPR.',
    'risk_distribution' => 'Taburan Risiko',
    'gdpr_compliance_overview' => 'Gambaran Keseluruhan Pematuhan GDPR',
    'inactive_draft' => 'Tidak Aktif / Draf',
    'collected_from_records' => 'Dikumpul daripada rekod',
    'measure' => 'Langkah',
    'value' => 'Nilai',
    'source' => 'Sumber',
    'configuration' => 'Konfigurasi',
    'no_technical_measures' => 'Tiada langkah teknikal dijumpai',
    'no_organizational_measures' => 'Tiada langkah organisasi dijumpai',
    'edit_measure' => 'Sunting Langkah',
    'current_measure' => 'Langkah Semasa',
    'new_measure_name' => 'Nama Langkah Baharu',
    'measure_renamed_success' => 'Langkah berjaya dinamakan semula di semua tempat ia digunakan.',
    'measure_rename_warning' => 'Ini akan menamakan semula langkah dalam setiap rekod GDPR, DPIA dan Pelanggaran Data di mana ia digunakan.',
    'measure_deleted_success' => 'Langkah berjaya dipadam di semua tempat ia pernah digunakan.',
    'confirm_delete_measure' => 'Adakah anda pasti mahu memadam langkah ini? Ia akan dialih keluar daripada setiap rekod GDPR, DPIA dan Pelanggaran Data di mana ia digunakan. Tindakan ini tidak boleh dibatalkan.',
    'responsible' => 'Bertanggungjawab',
    'responsible_placeholder' => 'Siapakah yang bertanggungjawab bagi langkah ini?',
    'unassigned' => 'Tidak Ditugaskan',
    'value_renamed_success' => 'Nilai berjaya dinamakan semula di semua tempat ia digunakan.',
    'value_deleted_success' => 'Nilai berjaya dialih keluar di semua tempat ia pernah digunakan.',
    'edit_value' => 'Sunting nilai',
    'delete_value' => 'Padam nilai',
    'current_value' => 'Nilai semasa',
    'new_value' => 'Nilai baharu',
    'value_rename_warning' => 'Penamaan semula akan mengemas kini nilai ini di semua tempat ia sedang digunakan.',
    'value_delete_warning' => 'Pemadaman akan mengosongkan nilai ini daripada setiap rekod di mana ia sedang digunakan. Tindakan ini tidak boleh dibatalkan.',
    'confirm_delete_value' => 'Padam nilai ini di semua tempat ia digunakan? Tindakan ini tidak boleh dibatalkan.',
    'used_in' => 'Digunakan dalam',
    'not_currently_used' => 'Tidak digunakan pada masa ini',
    'no_values' => 'Tiada nilai dijumpai',
    'total_gdpr_records' => 'Jumlah rekod GDPR',
    'dpia_in_progress' => 'DPIA dalam proses',
    'total_breaches' => 'Jumlah pelanggaran',
    'open_breaches' => 'Pelanggaran terbuka',
    'total_third_parties' => 'Jumlah pihak ketiga',
    'compliant_third_parties' => 'Pihak ketiga patuh',
    'dpia_coverage' => 'Liputan DPIA',
    'gdpr_with_dpia_required' => 'GDPR yang memerlukan DPIA',
    'dpia_completion_rate' => 'Kadar penyempurnaan DPIA',
    'category' => 'Kategori',
    'overview' => 'Gambaran Keseluruhan',
    'per_category' => 'Mengikut Kategori',
    'total_risk' => 'Jumlah Risiko',
    'completion_rate' => 'Kadar Penyempurnaan',
    'record_type' => 'Jenis Rekod',
    'print_report_title' => 'Laporan Pematuhan',
    'generated_on' => 'Dijana pada',
    'not_started' => 'Belum Bermula',
    'safeguard_scc' => 'Klausa Kontrak Standard (SCC)',
    'safeguard_bcr' => 'Peraturan Korporat Mengikat (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (tidak lagi sah)',
    'safeguard_adequacy_decision' => 'Keputusan Kecukupan Suruhanjaya Eropah',
    'safeguard_consent' => 'Persetujuan khusus daripada subjek data',
    'safeguard_model_contracts' => 'Kontrak model',
    'safeguard_certification' => 'Mekanisme pensijilan',
    'safeguard_codes_of_conduct' => 'Kod tatalaku',
    'safeguard_dpia' => 'Penilaian Kesan Perlindungan Data (DPIA)',
    'safeguard_tia' => 'Penilaian Kesan Pemindahan Data Antarabangsa (TIA)',
    'inactive' => 'Tidak Aktif',
];

// ==================== FILIPINO ====================
$translations['tl'] = [
    'app_title' => 'Rehistro ng GDPR',
    'company_subtitle' => 'Privacy at Pagsunod',
    'dashboard' => 'Dashboard',
    'gdpr' => 'GDPR',
    'dpia' => 'DPIA',
    'breaches' => 'Paglabag sa Data',
    'breach' => 'Paglabag sa Data',
    'third_parties' => 'Mga Third Party',
    'third_party' => 'Third Party',
    'measures' => 'Mga Hakbang',
    'reporting' => 'Pag-uulat',
    'total' => 'Kabuuan',
    'active' => 'Aktibo',
    'high_risk' => 'Mataas na Panganib',
    'dpia_required' => 'Kailangan ang DPIA',
    'dpia_completed' => 'Natapos ang DPIA',
    'new' => 'Bago',
    'export_json' => 'I-export ang JSON',
    'search' => 'Maghanap...',
    'search_company' => 'Maghanap ng kumpanya...',
    'filter' => 'Filter',
    'clear' => 'I-clear',
    'risk' => 'Panganib',
    'risk_level' => 'Antas ng Panganib',
    'status' => 'Katayuan',
    'retention_period' => 'Panahon ng Pagpapanatili',
    'actions' => 'Mga Aksyon',
    'view' => 'Tingnan',
    'edit' => 'I-edit',
    'delete' => 'Tanggalin',
    'print' => 'I-print',
    'confirm_delete' => 'Sigurado ka bang gusto mong tanggalin ang talaang ito? Hindi na ito maibabalik pa.',
    'processing_activity' => 'Aktibidad ng Pagproseso',
    'purpose' => 'Layunin',
    'data_subjects' => 'Mga Paksa ng Data',
    'personal_data' => 'Personal na Data',
    'recipients' => 'Mga Tatanggap',
    'legal_basis' => 'Legal na Batayan',
    'legitimate_interest' => 'Lehitimong Interes',
    'department' => 'Departamento',
    'or_type_custom_department' => 'O mag-type ng custom na departamento',
    'or_type_custom_name' => 'O mag-type ng pangalan',
    'or_type_custom_risk_origin' => 'O mag-type ng custom na pinagmulan ng panganib',
    'or_type_custom_status' => 'O mag-type ng custom na katayuan',
    'or_type_custom_approval' => 'O mag-type ng custom na katayuan ng pag-apruba',
    'or_type_custom_consultation' => 'O mag-type ng custom na halaga',
    'or_type_custom_compliance_status' => 'O mag-type ng custom na katayuan ng pagsunod',
    'or_type_custom_breach_type' => 'O mag-type ng custom na uri ng paglabag',
    'international_transfer' => 'Internasyonal na Paglipat',
    'to_country' => 'Sa Bansa',
    'we_are_processor' => 'Kami ang Processor',
    'processing_agreement_third_party' => 'Kasunduan sa Pagproseso sa Third Party',
    'technical_measures' => 'Mga Teknikal na Hakbang',
    'organizational_measures' => 'Mga Pang-organisasyong Hakbang',
    'safeguards' => 'Mga Pananggalang',
    'review_date' => 'Petsa ng Pagsusuri',
    'controller' => 'Controller',
    'joint_controller' => 'Magkasamang Controller',
    'dpo' => 'DPO',
    'representative' => 'Kinatawan',
    'name' => 'Pangalan',
    'contact' => 'Kontak',
    'title' => 'Pamagat',
    'description' => 'Paglalarawan',
    'risk_origin' => 'Pinagmulan ng Panganib',
    'affected_subjects' => 'Mga Apektadong Paksa',
    'management_approval' => 'Pag-apruba ng Pamamahala',
    'approved_by' => 'Inaprubahan ni',
    'approval_date' => 'Petsa ng Pag-apruba',
    'consultation_conducted' => 'Isinagawang Konsultasyon',
    'consultation_details' => 'Mga Detalye ng Konsultasyon',
    'recommendations' => 'Mga Rekomendasyon',
    'notes' => 'Mga Tala',
    'necessity_test' => 'Pagsusuri sa Pangangailangan',
    'proportionality_test' => 'Pagsusuri sa Proporsyonalidad',
    'mitigation_measures' => 'Mga Hakbang sa Pagpapagaan',
    'residual_risk' => 'Natitirang Panganib',
    'breach_date' => 'Petsa ng Paglabag',
    'discovery_date' => 'Petsa ng Pagkatuklas',
    'breach_type' => 'Uri ng Paglabag',
    'causes' => 'Mga Dahilan',
    'measures_taken' => 'Mga Hakbang na Ginawa',
    'notified_authority' => 'Naabisuhan ang Awtoridad',
    'notification_date' => 'Petsa ng Abiso',
    'notified_affected' => 'Naabisuhan ang mga Apektado',
    'company_name' => 'Pangalan ng Kumpanya',
    'contact_person' => 'Taong Makokontak',
    'email' => 'Email',
    'phone' => 'Telepono',
    'address' => 'Address',
    'service_provided' => 'Serbisyong Ibinigay',
    'agreement_signed' => 'Napirmahan ang Kasunduan',
    'agreement_date' => 'Petsa ng Kasunduan',
    'expiry_date' => 'Petsa ng Pag-expire',
    'compliance_status' => 'Katayuan ng Pagsunod',
    'save' => 'I-save',
    'cancel' => 'Kanselahin',
    'add' => 'Idagdag',
    'close' => 'Isara',
    'language' => 'Wika',
    'logout' => 'Mag-log out',
    'logout_confirm' => 'Mag-log out mula sa session na ito?',
    'full_report' => 'Buong Ulat',
    'backup' => 'Backup',
    'zip_backup' => 'ZIP na Backup',
    'statistics' => 'Estadistika',
    'no_records' => 'Walang nahanap na mga talaan',
    'showing' => 'Ipinapakita',
    'of' => 'ng',
    'yes' => 'Oo',
    'no' => 'Hindi',
    'unknown' => 'Hindi Alam',
    'not_required' => 'Hindi Kinakailangan',
    'in_progress' => 'Isinasagawa',
    'completed' => 'Natapos',
    'approved' => 'Inaprubahan',
    'draft' => 'Draft',
    'open' => 'Bukas',
    'investigating' => 'Iniimbestigahan',
    'contained' => 'Nakontrol',
    'resolved' => 'Naresolba',
    'closed' => 'Sarado',
    'compliant' => 'Sumusunod',
    'non_compliant' => 'Hindi Sumusunod',
    'review_needed' => 'Kailangan ng Pagsusuri',
    'low' => 'Mababa',
    'medium' => 'Katamtaman',
    'high' => 'Mataas',
    'confidentiality' => 'Pagiging Kumpidensyal',
    'integrity' => 'Integridad',
    'availability' => 'Kakayahang Magamit',
    'mixed' => 'Halo-halo',
    'contract' => 'Kontrata',
    'consent' => 'Pahintulot',
    'legal_obligation' => 'Legal na Obligasyon',
    'legitimate_interests' => 'Mga Lehitimong Interes',
    'vital_interests' => 'Mahahalagang Interes',
    'public_task' => 'Pampublikong Gawain',
    'technical' => 'Teknikal',
    'organizational' => 'Pang-organisasyon',
    'human_error' => 'Pagkakamali ng Tao',
    'external' => 'Panlabas',
    'systematic_monitoring' => 'Sistematikong Pagmamanman',
    'sensitive_data' => 'Sensitibong Data',
    'other' => 'Iba pa',
    'administration' => 'Administrasyon',
    'hr' => 'Human Resources',
    'finance' => 'Pananalapi',
    'marketing' => 'Marketing',
    'it' => 'IT',
    'operations' => 'Mga Operasyon',
    'pending' => 'Nakabinbin',
    'rejected' => 'Tinanggihan',
    'planned' => 'Nakaplano',
    'donations' => 'Mga Donasyon',
    'create_dpia' => 'Gumawa ng DPIA',
    'create_dpia_from_gdpr' => 'Gumawa ng DPIA mula sa GDPR',
    'click_create_dpia_for_gdpr' => 'I-click ang "Gumawa ng DPIA" para sa talaan ng GDPR na nangangailangan ng DPIA:',
    'new_gdpr_record' => 'Bagong Talaan ng GDPR',
    'edit_gdpr_record' => 'I-edit ang Talaan ng GDPR',
    'new_dpia' => 'Bagong DPIA',
    'edit_dpia' => 'I-edit ang DPIA',
    'new_breach' => 'Bagong Paglabag sa Data',
    'edit_breach' => 'I-edit ang Paglabag sa Data',
    'new_third_party' => 'Bagong Third Party',
    'edit_third_party' => 'I-edit ang Third Party',
    'record' => 'Talaan',
    'page' => 'Pahina',
    'generated' => 'Nabuo',
    'successfully_added' => 'matagumpay na naidagdag',
    'successfully_updated' => 'matagumpay na na-update',
    'unsaved_changes_confirm' => 'May mga hindi na-save na pagbabago. Sigurado ka bang gusto mong kanselahin?',
    'select_or_type_below' => 'Pumili o mag-type sa ibaba',
    'or_type_custom_retention_period' => 'O mag-type ng custom na panahon ng pagpapanatili',
    'or_type_custom_safeguards' => 'O mag-type ng custom na mga pananggalang (paghihiwalayin ng semicolon)',
    'or_type_custom_measures' => 'O mag-type ng custom na mga hakbang (paghihiwalayin ng semicolon)',
    'hold_ctrl_to_select_multiple' => 'Pindutin at hawakan ang Ctrl (Windows) o Cmd (Mac) para pumili ng marami',
    'custom_mitigation_measures' => 'Custom na mga hakbang sa pagpapagaan (paghihiwalayin ng semicolon)',
    'custom_measures_taken' => 'Custom na mga hakbang na ginawa (paghihiwalayin ng semicolon)',
    'custom_measures_placeholder' => 'hal. Custom na hakbang 1; Custom na hakbang 2',
    'gdpr_record_id' => 'ID ng Talaan ng GDPR',
    'gdpr_record' => 'Talaan ng GDPR',
    'dpia_for_gdpr' => 'DPIA para sa GDPR',
    'dpia_exists_for_gdpr' => 'May umiiral nang DPIA para sa GDPR',
    'for_gdpr_record' => 'para sa talaan ng GDPR',
    'only_one_dpia_allowed' => 'Isang DPIA lamang ang pinapayagan bawat talaan ng GDPR.',
    'risk_distribution' => 'Pamamahagi ng Panganib',
    'gdpr_compliance_overview' => 'Pangkalahatang-ideya ng Pagsunod sa GDPR',
    'inactive_draft' => 'Hindi Aktibo / Draft',
    'collected_from_records' => 'Nakolekta mula sa mga talaan',
    'measure' => 'Hakbang',
    'value' => 'Halaga',
    'source' => 'Pinagmulan',
    'configuration' => 'Konpigurasyon',
    'no_technical_measures' => 'Walang nahanap na mga teknikal na hakbang',
    'no_organizational_measures' => 'Walang nahanap na mga pang-organisasyong hakbang',
    'edit_measure' => 'I-edit ang Hakbang',
    'current_measure' => 'Kasalukuyang Hakbang',
    'new_measure_name' => 'Bagong Pangalan ng Hakbang',
    'measure_renamed_success' => 'Matagumpay na napalitan ang pangalan ng hakbang saanman ito ginagamit.',
    'measure_rename_warning' => 'Papalitan nito ang pangalan ng hakbang sa bawat talaan ng GDPR, DPIA, at Paglabag sa Data kung saan ito ginagamit.',
    'measure_deleted_success' => 'Matagumpay na natanggal ang hakbang saanman ito dati ginamit.',
    'confirm_delete_measure' => 'Sigurado ka bang gusto mong tanggalin ang hakbang na ito? Aalisin ito mula sa bawat talaan ng GDPR, DPIA, at Paglabag sa Data kung saan ito ginagamit. Hindi na ito maibabalik pa.',
    'responsible' => 'Responsable',
    'responsible_placeholder' => 'Sino ang responsable para sa hakbang na ito?',
    'unassigned' => 'Hindi Naitalaga',
    'value_renamed_success' => 'Matagumpay na napalitan ang pangalan ng halaga saanman ito ginagamit.',
    'value_deleted_success' => 'Matagumpay na natanggal ang halaga saanman ito dati ginamit.',
    'edit_value' => 'I-edit ang halaga',
    'delete_value' => 'Tanggalin ang halaga',
    'current_value' => 'Kasalukuyang halaga',
    'new_value' => 'Bagong halaga',
    'value_rename_warning' => 'Ia-update ng pagpapalit ng pangalan ang halagang ito saanman ito kasalukuyang ginagamit.',
    'value_delete_warning' => 'Aalisin ng pagtanggal ang halagang ito mula sa bawat talaan kung saan ito kasalukuyang ginagamit. Hindi na ito maibabalik pa.',
    'confirm_delete_value' => 'Tanggalin ang halagang ito saanman ito ginagamit? Hindi na ito maibabalik pa.',
    'used_in' => 'Ginamit sa',
    'not_currently_used' => 'Hindi kasalukuyang ginagamit',
    'no_values' => 'Walang nahanap na mga halaga',
    'total_gdpr_records' => 'Kabuuang mga talaan ng GDPR',
    'dpia_in_progress' => 'Isinasagawang DPIA',
    'total_breaches' => 'Kabuuang mga paglabag',
    'open_breaches' => 'Bukas na mga paglabag',
    'total_third_parties' => 'Kabuuang mga third party',
    'compliant_third_parties' => 'Sumusunod na mga third party',
    'dpia_coverage' => 'Saklaw ng DPIA',
    'gdpr_with_dpia_required' => 'GDPR na nangangailangan ng DPIA',
    'dpia_completion_rate' => 'Rate ng pagkumpleto ng DPIA',
    'category' => 'Kategorya',
    'overview' => 'Pangkalahatang-ideya',
    'per_category' => 'Ayon sa Kategorya',
    'total_risk' => 'Kabuuang Panganib',
    'completion_rate' => 'Rate ng Pagkumpleto',
    'record_type' => 'Uri ng Talaan',
    'print_report_title' => 'Ulat sa Pagsunod',
    'generated_on' => 'Nabuo noong',
    'not_started' => 'Hindi Pa Nagsisimula',
    'safeguard_scc' => 'Mga Karaniwang Klausula sa Kontrata (SCC)',
    'safeguard_bcr' => 'Nagbubuklod na mga Panuntunan ng Korporasyon (BCR)',
    'safeguard_privacy_shield' => 'Privacy Shield (hindi na balido)',
    'safeguard_adequacy_decision' => 'Desisyon ng Sapat na Proteksyon ng European Commission',
    'safeguard_consent' => 'Tiyak na pahintulot mula sa paksa ng data',
    'safeguard_model_contracts' => 'Mga modelong kontrata',
    'safeguard_certification' => 'Mga mekanismo ng sertipikasyon',
    'safeguard_codes_of_conduct' => 'Mga kodigo ng asal',
    'safeguard_dpia' => 'Pagtatasa ng Epekto sa Proteksyon ng Data (DPIA)',
    'safeguard_tia' => 'Pagtatasa ng Epekto ng Internasyonal na Paglipat ng Data (TIA)',
    'inactive' => 'Hindi Aktibo',
];

// Fallback for missing translations
function t($key) {
    global $lang, $translations;
    if (isset($translations[$lang][$key])) {
        return $translations[$lang][$key];
    }
    // Fallback to English
    if (isset($translations['en'][$key])) {
        return $translations['en'][$key];
    }
    return $key;
}

// Helper functions for labels (for print views)
function getLegalBasisLabel($key) {
    $map = [
        'contract' => t('contract'),
        'consent' => t('consent'),
        'legal_obligation' => t('legal_obligation'),
        'legitimate_interests' => t('legitimate_interests'),
        'vital_interests' => t('vital_interests'),
        'public_task' => t('public_task'),
    ];
    return $map[$key] ?? $key;
}

function getDepartmentLabel($key) {
    $map = [
        'administration' => t('administration'),
        'hr' => t('hr'),
        'finance' => t('finance'),
        'marketing' => t('marketing'),
        'it' => t('it'),
        'operations' => t('operations'),
        'other' => t('other'),
    ];
    return $map[$key] ?? $key;
}

function getBreachTypeLabel($key) {
    // Config.php ('breach_types') is the source of truth so any type added
    // or renamed there (or typed freely on a breach record and later edited
    // in Configuration) shows up correctly here, not just the 4 built-in ones.
    $configTypes = getConfig('breach_types', []);
    if (isset($configTypes[$key])) return $configTypes[$key];
    $map = [
        'confidentiality' => t('confidentiality'),
        'integrity' => t('integrity'),
        'availability' => t('availability'),
        'mixed' => t('mixed'),
        'other' => t('other'),
    ];
    return $map[$key] ?? $key;
}

function getComplianceStatusLabel($key) {
    $map = [
        'compliant' => t('compliant'),
        'non_compliant' => t('non_compliant'),
        'review_needed' => t('review_needed'),
        'unknown' => t('unknown'),
    ];
    return $map[$key] ?? $key;
}

// --- ROT47 Functions ---
function rot47encode($string) {
    if (empty($string)) return '';
    $result = '';
    for ($i = 0; $i < strlen($string); $i++) {
        $char = ord($string[$i]);
        if ($char >= 33 && $char <= 126) {
            $char = 33 + (($char - 33 + 47) % 94);
        }
        $result .= chr($char);
    }
    return $result;
}

function rot47decode($string) {
    return rot47encode($string);
}

// --- Functions ---

function loadRecords($file) {
    if (!file_exists($file)) return [];
    $content = file_get_contents($file);
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

function saveRecords($file, $records) {
    file_put_contents($file, json_encode($records, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    return true;
}

function findRecord($records, $id) {
    foreach ($records as $index => $record) {
        if (isset($record['id']) && $record['id'] == $id) {
            return ['index' => $index, 'record' => $record];
        }
    }
    return null;
}

function findDpiaByGdprId($dpiaRecords, $gdprId) {
    foreach ($dpiaRecords as $index => $record) {
        if (isset($record['record_id']) && $record['record_id'] == $gdprId) {
            return ['index' => $index, 'record' => $record];
        }
    }
    return null;
}

function formatDate($date) {
    if (empty($date)) return '-';
    return date('d-m-Y', strtotime($date));
}

function formatDateTime($datetime) {
    if (empty($datetime)) return '-';
    return date('d-m-Y H:i', strtotime($datetime));
}

function getRiskClass($level) {
    $map = ['low' => 'badge-low', 'medium' => 'badge-medium', 'high' => 'badge-high'];
    return $map[$level] ?? 'badge-low';
}

function getStatusClass($status) {
    $map = [
        'active' => 'badge-active', 'inactive' => 'badge-inactive', 'draft' => 'badge-draft',
        'not_started' => 'badge-inactive',
        'in_progress' => 'badge-progress', 'not_required' => 'badge-inactive',
        'completed' => 'badge-active', 'approved' => 'badge-active',
        'open' => 'badge-active', 'investigating' => 'badge-progress',
        'contained' => 'badge-medium', 'resolved' => 'badge-active',
        'closed' => 'badge-inactive', 'compliant' => 'badge-active',
        'non_compliant' => 'badge-inactive', 'review_needed' => 'badge-draft'
    ];
    return $map[$status] ?? 'badge-inactive';
}

function truncateText($text, $length = null, $force = true) {
    if (empty($text)) return '';
    if ($length === null) $length = getConfig('truncate_length', 60);
    if (!$force || strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '…';
}

function getNextIdGdpr($records) {
    $start = getConfig('gdpr_id_start', 200000001);
    if (empty($records)) return $start;
    $ids = array_column($records, 'id');
    return max($ids) + 1;
}

function getNextIdDpia($records) {
    $start = getConfig('dpia_id_start', 300000001);
    if (empty($records)) return $start;
    $ids = array_column($records, 'id');
    return max($ids) + 1;
}

function getNextIdBreach($records) {
    $start = getConfig('breach_id_start', 400000001);
    if (empty($records)) return $start;
    $ids = array_column($records, 'id');
    return max($ids) + 1;
}

function getNextIdThirdParty($records) {
    $start = getConfig('thirdparty_id_start', 500000001);
    if (empty($records)) return $start;
    $ids = array_column($records, 'id');
    return max($ids) + 1;
}

function splitMeasureList($value) {
    if (empty($value)) return [];
    return array_values(array_filter(array_map('trim', explode(';', $value)), function($v) { return $v !== ''; }));
}

// Safeguards are stored as a "; "-joined list where each item may be one of
// the fixed, translatable safeguard_* keys (from config's safeguards_options)
// or free text the user typed themselves. t() transparently falls back to
// returning the item unchanged when it isn't a known translation key, so
// this safely handles both cases.
function displaySafeguards($value) {
    if (empty($value)) return '-';
    $items = splitMeasureList($value);
    if (empty($items)) return '-';
    return implode('; ', array_map('t', $items));
}

function getAllTechnicalMeasures($gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords) {
    $measures = [];
    foreach ($gdprRecords as $r) if (!empty($r['technical_measures'])) $measures = array_merge($measures, splitMeasureList($r['technical_measures']));
    foreach ($dpiaRecords as $r) { if (!empty($r['mitigation_measures'])) $measures = array_merge($measures, splitMeasureList($r['mitigation_measures'])); if (!empty($r['technical_measures'])) $measures = array_merge($measures, splitMeasureList($r['technical_measures'])); }
    foreach ($breachRecords as $r) if (!empty($r['measures_taken'])) $measures = array_merge($measures, splitMeasureList($r['measures_taken']));
    return array_values(array_unique(array_filter($measures)));
}

function getAllOrganizationalMeasures($gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords) {
    $measures = [];
    foreach ($gdprRecords as $r) if (!empty($r['organizational_measures'])) $measures = array_merge($measures, splitMeasureList($r['organizational_measures']));
    foreach ($dpiaRecords as $r) if (!empty($r['organizational_measures'])) $measures = array_merge($measures, splitMeasureList($r['organizational_measures']));
    foreach ($breachRecords as $r) if (!empty($r['measures_taken'])) $measures = array_merge($measures, splitMeasureList($r['measures_taken']));
    return array_values(array_unique(array_filter($measures)));
}

// Departments used in records that aren't already one of the configured
// department keys — lets custom-typed departments (from the "or type your
// own" field) show up as selectable options too, same as with measures.
// Scans across all record types (GDPR, DPIA, breach, third party) so a
// department typed anywhere is reused everywhere else.
function getAllDepartmentsUsed($configDepartments, $gdprRecords, $dpiaRecords = [], $breachRecords = [], $thirdpartyRecords = []) {
    $extra = [];
    foreach (array_merge($gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords) as $r) {
        $dept = trim($r['department'] ?? '');
        if ($dept !== '' && !isset($configDepartments[$dept])) {
            $extra[] = $dept;
        }
    }
    return array_values(array_unique($extra));
}

function getAllRetentionPeriods($gdprRecords) {
    $periods = [];
    foreach ($gdprRecords as $r) {
        if (!empty($r['retention_periods'])) {
            $periods[] = $r['retention_periods'];
        }
    }
    return array_unique(array_filter($periods));
}

function getAllSafeguards($gdprRecords) {
    $safeguards = [];
    foreach ($gdprRecords as $r) {
        if (!empty($r['safeguards'])) {
            $safeguards[] = $r['safeguards'];
        }
    }
    return array_unique(array_filter($safeguards));
}

// Previously typed contact names (controller / joint controller / DPO /
// representative) — decoded from ROT47 storage — so they can be reused via
// a dropdown instead of retyped every time, while a "type your own" field
// still allows a fresh name to be entered.
function getAllContactNames($gdprRecords, $field) {
    $names = [];
    foreach ($gdprRecords as $r) {
        if (!empty($r[$field])) {
            $decoded = trim(rot47decode($r[$field]));
            if ($decoded !== '') {
                $names[] = $decoded;
            }
        }
    }
    return array_values(array_unique($names));
}

// Risk-origin values used in DPIA records that aren't already one of the
// configured keys — lets a custom-typed risk origin (from the "or type your
// own" field) show up as a selectable option too, same approach as
// departments and measures.
function getAllRiskOriginsUsed($dpiaRecords, $configRiskOrigins) {
    $extra = [];
    foreach ($dpiaRecords as $r) {
        $origin = trim($r['risk_origin'] ?? '');
        if ($origin !== '' && !isset($configRiskOrigins[$origin])) {
            $extra[] = $origin;
        }
    }
    return array_values(array_unique($extra));
}

// Previously typed "approved by" names in DPIA records, for reuse via a
// dropdown + "type your own" field, same pattern as the GDPR contact names.
function getAllApprovedByNames($dpiaRecords) {
    $names = [];
    foreach ($dpiaRecords as $r) {
        $name = trim($r['approved_by'] ?? '');
        if ($name !== '') {
            $names[] = $name;
        }
    }
    return array_values(array_unique($names));
}

// Generic version of the above: values used for a given field in a set of
// records that aren't already one of the configured keys — used for DPIA
// status, management approval, and consultation fields so custom-typed
// values become reusable options too.
function getAllRecordFieldValuesUsed($records, $field, $configOptions) {
    $extra = [];
    foreach ($records as $r) {
        $val = trim($r[$field] ?? '');
        if ($val !== '' && !isset($configOptions[$val])) {
            $extra[] = $val;
        }
    }
    return array_values(array_unique($extra));
}

// Where a given dynamic value is currently used, per record type, so the
// Configuration tab can show a "used in N record(s)" badge and the edit/
// delete actions can warn about impact before cascading a change.
function countDynamicValueUsage($fieldType, $value, $gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords) {
    $counts = [];
    $countField = function($records, $field) use ($value) {
        $n = 0;
        foreach ($records as $r) { if (($r[$field] ?? '') === $value) $n++; }
        return $n;
    };
    switch ($fieldType) {
        case 'department':
            if ($n = $countField($gdprRecords, 'department')) $counts['GDPR'] = $n;
            if ($n = $countField($dpiaRecords, 'department')) $counts['DPIA'] = $n;
            if ($n = $countField($breachRecords, 'department')) $counts['Breach'] = $n;
            if ($n = $countField($thirdpartyRecords, 'department')) $counts['3rd party'] = $n;
            break;
        case 'risk_origin':
            if ($n = $countField($dpiaRecords, 'risk_origin')) $counts['DPIA'] = $n;
            break;
        case 'dpia_status':
            if ($n = $countField($dpiaRecords, 'status')) $counts['DPIA'] = $n;
            break;
        case 'management_approval':
            if ($n = $countField($dpiaRecords, 'management_approval')) $counts['DPIA'] = $n;
            break;
        case 'consultation_conducted':
            if ($n = $countField($dpiaRecords, 'consultation_conducted')) $counts['DPIA'] = $n;
            break;
        case 'approved_by':
            if ($n = $countField($dpiaRecords, 'approved_by')) $counts['DPIA'] = $n;
            break;
        case 'compliance_status':
            if ($n = $countField($thirdpartyRecords, 'compliance_status')) $counts['3rd party'] = $n;
            break;
        case 'agreement_signed':
            if ($n = $countField($thirdpartyRecords, 'processing_agreement_signed')) $counts['3rd party'] = $n;
            break;
        case 'breach_type':
            if ($n = $countField($breachRecords, 'breach_type')) $counts['Breach'] = $n;
            break;
        case 'name_data_controller':
        case 'name_joint_data_controller':
        case 'name_dpo':
        case 'name_representative':
            $n = 0;
            foreach ($gdprRecords as $r) {
                if (!empty($r[$fieldType]) && trim(rot47decode($r[$fieldType])) === $value) $n++;
            }
            if ($n) $counts['GDPR'] = $n;
            break;
    }
    return $counts;
}

// Same matching logic as countDynamicValueUsage, but returns one entry per
// matching record (type, id, tab/edit param, label) instead of a per-source
// count, so every individual usage can be listed and linked to directly.
function getDynamicValueUsageRecords($fieldType, $value, $gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords) {
    $entries = [];
    $collect = function($records, $field) use (&$entries, $value) {
        $out = [];
        foreach ($records as $r) { if (($r[$field] ?? '') === $value) $out[] = $r['id']; }
        return $out;
    };
    $addEntries = function($ids, $tab, $editParam, $label) use (&$entries) {
        foreach ($ids as $id) {
            $entries[] = ['tab' => $tab, 'edit_param' => $editParam, 'id' => $id, 'label' => $label];
        }
    };
    switch ($fieldType) {
        case 'department':
            $addEntries($collect($gdprRecords, 'department'), 'gdpr', 'edit_gdpr', t('gdpr'));
            $addEntries($collect($dpiaRecords, 'department'), 'dpia', 'edit_dpia', t('dpia'));
            $addEntries($collect($breachRecords, 'department'), 'breach', 'edit_breach', t('breach'));
            $addEntries($collect($thirdpartyRecords, 'department'), 'thirdparty', 'edit_thirdparty', t('third_party'));
            break;
        case 'risk_origin':
            $addEntries($collect($dpiaRecords, 'risk_origin'), 'dpia', 'edit_dpia', t('dpia'));
            break;
        case 'dpia_status':
            $addEntries($collect($dpiaRecords, 'status'), 'dpia', 'edit_dpia', t('dpia'));
            break;
        case 'management_approval':
            $addEntries($collect($dpiaRecords, 'management_approval'), 'dpia', 'edit_dpia', t('dpia'));
            break;
        case 'consultation_conducted':
            $addEntries($collect($dpiaRecords, 'consultation_conducted'), 'dpia', 'edit_dpia', t('dpia'));
            break;
        case 'approved_by':
            $addEntries($collect($dpiaRecords, 'approved_by'), 'dpia', 'edit_dpia', t('dpia'));
            break;
        case 'compliance_status':
            $addEntries($collect($thirdpartyRecords, 'compliance_status'), 'thirdparty', 'edit_thirdparty', t('third_party'));
            break;
        case 'agreement_signed':
            $addEntries($collect($thirdpartyRecords, 'processing_agreement_signed'), 'thirdparty', 'edit_thirdparty', t('third_party'));
            break;
        case 'breach_type':
            $addEntries($collect($breachRecords, 'breach_type'), 'breach', 'edit_breach', t('breach'));
            break;
        case 'name_data_controller':
        case 'name_joint_data_controller':
        case 'name_dpo':
        case 'name_representative':
            $ids = [];
            foreach ($gdprRecords as $r) {
                if (!empty($r[$fieldType]) && trim(rot47decode($r[$fieldType])) === $value) $ids[] = $r['id'];
            }
            $addEntries($ids, 'gdpr', 'edit_gdpr', t('gdpr'));
            break;
    }
    return $entries;
}



// --- Yes/No label functie ---
function getYesNoLabel($value) {
    if ($value === 'yes' || $value === 'Yes' || $value === 'Ja') return t('yes');
    if ($value === 'no' || $value === 'No' || $value === 'Nee') return t('no');
    return $value;
}

// --- Configuratie opslaan functie ---
function saveConfigFile($newConfig) {
    $content = '<?php' . "\n";
    $content .= '// ============================================================' . "\n";
    $content .= '// CONFIGURATIE BESTAND - AVG Register' . "\n";
    $content .= '// ============================================================' . "\n\n";
    $content .= '$config = ' . var_export($newConfig, true) . ';' . "\n\n";
    $content .= '// --- Helper functies ---' . "\n";
    $content .= 'if (!function_exists(\'getConfig\')) { function getConfig($key, $default = null) { global $config; return isset($config[$key]) ? $config[$key] : $default; } }' . "\n";
    $content .= 'if (!function_exists(\'setConfig\')) { function setConfig($key, $value) { global $config; $config[$key] = $value; } }' . "\n";
    $content .= 'if (!function_exists(\'getCompanyName\')) { function getCompanyName() { return getConfig(\'company_name\', \'Company Name\'); } }' . "\n";
    $content .= 'if (!function_exists(\'getDepartments\')) { function getDepartments() { $file = getConfig(\'departments_file\', \'departments.json\'); if (!file_exists($file)) return []; $data = json_decode(file_get_contents($file), true); return is_array($data) ? $data : []; } }' . "\n";
    $content .= 'if (!function_exists(\'saveDepartments\')) { function saveDepartments($departments) { $file = getConfig(\'departments_file\', \'departments.json\'); return file_put_contents($file, json_encode($departments, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false; } }' . "\n";
    $content .= 'if (!function_exists(\'getSafeguardsOptions\')) { function getSafeguardsOptions() { return getConfig(\'safeguards_options\', []); } }' . "\n";
    $content .= 'if (!function_exists(\'rot47encode\')) { function rot47encode($string) { if (empty($string)) return \'\'; $result = \'\'; for ($i = 0; $i < strlen($string); $i++) { $char = ord($string[$i]); if ($char >= 33 && $char <= 126) { $char = 33 + (($char - 33 + 47) % 94); } $result .= chr($char); } return $result; } }' . "\n";
    $content .= 'if (!function_exists(\'rot47decode\')) { function rot47decode($string) { return rot47encode($string); } }' . "\n";
    $content .= '$companyName = getCompanyName();' . "\n";
    $content .= '$companySubtitle = getConfig(\'company_subtitle\', \'Privacy & Compliance\');' . "\n";
    $content .= '$appTitle = getConfig(\'app_title\', \'AVG Register\');' . "\n";
    $content .= '$appVersion = getConfig(\'app_version\', \'2.0\');' . "\n";
    $content .= '$gdprFile = getConfig(\'gdpr_file\', \'gdpr_register.json\');' . "\n";
    $content .= '$dpiaFile = getConfig(\'dpia_file\', \'dpia_registrations.json\');' . "\n";
    $content .= '$breachFile = getConfig(\'breach_file\', \'data_breaches.json\');' . "\n";
    $content .= '$thirdpartyFile = getConfig(\'thirdparty_file\', \'third_parties.json\');' . "\n";
    $content .= '$departmentsFile = getConfig(\'departments_file\', \'departments.json\');' . "\n";
    $content .= '$defaultUserId = getConfig(\'default_user_id\', 1);' . "\n";
    $content .= '$gdprIdStart = getConfig(\'gdpr_id_start\', 200000001);' . "\n";
    $content .= '$dpiaIdStart = getConfig(\'dpia_id_start\', 300000001);' . "\n";
    $content .= '$breachIdStart = getConfig(\'breach_id_start\', 400000001);' . "\n";
    $content .= '$thirdpartyIdStart = getConfig(\'thirdparty_id_start\', 500000001);' . "\n";
    $content .= '$itemsPerPage = getConfig(\'items_per_page\', 50);' . "\n";
    $content .= '$truncateLength = getConfig(\'truncate_length\', 60);' . "\n";
    $content .= '?>';
    return file_put_contents('config.php', $content);
}

// --- Load Data ---
$gdprRecords = loadRecords($gdprFile);
$dpiaRecords = loadRecords($dpiaFile);
$breachRecords = loadRecords($breachFile);
$thirdpartyRecords = loadRecords($thirdpartyFile);

// --- Get all retention periods from GDPR records ---
$retentionPeriods = getAllRetentionPeriods($gdprRecords);

// --- Get departments from departments.json, plus any custom ones already
// used anywhere (GDPR, DPIA, breach, or third-party records), so a
// department typed in any one of those shows up as a selectable option in
// all of them. ---
$departmentsList = getDepartments();
$departmentsUsedInRecords = getAllDepartmentsUsed($departmentsList, $gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords);
foreach ($departmentsUsedInRecords as $customDept) {
    $departmentsList[$customDept] = $customDept;
}

// Kept as an alias so the breach/third-party forms (which previously used
// this name) keep working without further changes; it's now the same
// cross-record-type list as $departmentsList above.
$departmentsListFromGdpr = $departmentsList;

// --- Get safeguards options from config ---
$safeguardsOptions = getConfig('safeguards_options', []);

// --- Get ALL unique measures from records for multi-select options ---
// (technical/organizational measures no longer have a seed list in config;
// the dropdown is built purely from what's already used in records, same
// approach as departments.)
$allTechMeasuresFromRecords = getAllTechnicalMeasures($gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords);
$allOrgMeasuresFromRecords = getAllOrganizationalMeasures($gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords);
$allSafeguardsFromRecords = getAllSafeguards($gdprRecords);

$allTechMeasuresOptions = array_unique($allTechMeasuresFromRecords);
$allOrgMeasuresOptions = array_unique($allOrgMeasuresFromRecords);
$allSafeguardsOptions = array_unique(array_merge($safeguardsOptions, $allSafeguardsFromRecords));

// --- Previously typed contact names, for reuse via dropdown + custom field ---
$allDataControllerNames = getAllContactNames($gdprRecords, 'name_data_controller');
$allJointControllerNames = getAllContactNames($gdprRecords, 'name_joint_data_controller');
$allDpoNames = getAllContactNames($gdprRecords, 'name_dpo');
$allRepresentativeNames = getAllContactNames($gdprRecords, 'name_representative');

// --- Risk origin (DPIA): config options + any custom values already used in records ---
$riskOriginOptions = getConfig('risk_origin', []);
$riskOriginUsedInRecords = getAllRiskOriginsUsed($dpiaRecords, $riskOriginOptions);
foreach ($riskOriginUsedInRecords as $customOrigin) {
    $riskOriginOptions[$customOrigin] = $customOrigin;
}

// --- Previously typed "approved by" names (DPIA), for reuse via dropdown + custom field ---
$allApprovedByNames = getAllApprovedByNames($dpiaRecords);

// --- DPIA Status: config options + any custom values already used in DPIA records ---
$dpiaStatuses = getConfig('dpia_statuses', []);
foreach (getAllRecordFieldValuesUsed($dpiaRecords, 'status', $dpiaStatuses) as $customStatus) {
    $dpiaStatuses[$customStatus] = $customStatus;
}

// --- Management goedkeuring: config options + any custom values already used in DPIA records ---
$managementApprovalOptions = getConfig('management_approval_options', []);
foreach (getAllRecordFieldValuesUsed($dpiaRecords, 'management_approval', $managementApprovalOptions) as $customApproval) {
    $managementApprovalOptions[$customApproval] = $customApproval;
}

// --- Consultatie uitgevoerd: its own option list (separate from the shared
// yes/no options used elsewhere), config options + any custom values already
// used in DPIA records ---
$consultationOptions = getConfig('consultation_options', []);
foreach (getAllRecordFieldValuesUsed($dpiaRecords, 'consultation_conducted', $consultationOptions) as $customConsultation) {
    $consultationOptions[$customConsultation] = $customConsultation;
}

// --- Compliance status (third party): config options + any custom values
// already used in third-party records ---
$complianceStatuses = getConfig('compliance_statuses', []);
foreach (getAllRecordFieldValuesUsed($thirdpartyRecords, 'compliance_status', $complianceStatuses) as $customCompliance) {
    $complianceStatuses[$customCompliance] = $customCompliance;
}

// --- Overeenkomst getekend (third party): its own option list (separate
// from the shared yes/no/in-progress options used by breach notifications),
// config options + any custom values already used in third-party records ---
$agreementSignedOptions = getConfig('yes_no_progress_options', []);
foreach (getAllRecordFieldValuesUsed($thirdpartyRecords, 'processing_agreement_signed', $agreementSignedOptions) as $customAgreement) {
    $agreementSignedOptions[$customAgreement] = $customAgreement;
}

// --- Type lek (breach type): config options + any custom values already
// used in data_breaches.json ---
$breachTypes = getConfig('breach_types', []);
foreach (getAllRecordFieldValuesUsed($breachRecords, 'breach_type', $breachTypes) as $customBreachType) {
    $breachTypes[$customBreachType] = $customBreachType;
}

// --- Handle Actions ---
$message = '';
$messageType = '';
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'gdpr';


// --- Handle File Downloads ---
if (isset($_GET['action']) && $_GET['action'] === 'download' && isset($_GET['file'])) {
    $fileMap = [
        'gdpr' => $gdprFile,
        'dpia' => $dpiaFile,
        'breach' => $breachFile,
        'thirdparty' => $thirdpartyFile
    ];
    
    $fileKey = $_GET['file'];
    if (isset($fileMap[$fileKey])) {
        $filePath = $fileMap[$fileKey];
        if (file_exists($filePath)) {
            $fileNames = [
                'gdpr' => 'gdpr_register',
                'dpia' => 'dpia_registrations',
                'breach' => 'data_breaches',
                'thirdparty' => 'third_parties'
            ];
            $downloadName = $fileNames[$fileKey] . '_' . date('Y-m-d') . '.json';
            
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="' . $downloadName . '"');
            header('Content-Length: ' . filesize($filePath));
            readfile($filePath);
            exit;
        } else {
            $message = 'Bestand niet gevonden: ' . htmlspecialchars($filePath);
            $messageType = 'danger';
        }
    } else {
        $message = 'Ongeldige bestandsselectie.';
        $messageType = 'danger';
    }
}


// --- Handle Print Report (volledig rapport) ---
if (isset($_GET['action']) && $_GET['action'] === 'print_report') {
    // Laad alle data opnieuw voor de print
    $printGdpr = loadRecords($gdprFile);
    $printDpia = loadRecords($dpiaFile);
    $printBreach = loadRecords($breachFile);
    $printThirdparty = loadRecords($thirdpartyFile);
    
    // Haal de labels op
    $riskLevels = getConfig('risk_levels', []);
    $gdprStatuses = getConfig('gdpr_statuses', []);
    $dpiaStatuses = getConfig('dpia_statuses', []);
    $breachStatuses = getConfig('breach_statuses', []);
    $breachTypes = getConfig('breach_types', []);
    $complianceStatuses = getConfig('compliance_statuses', []);
    $legalBasisOptions = getConfig('legal_basis', []);
    // $departmentsList is already loaded above (departments.json + any
    // custom department values already in use), no need to reload it here.
    
    ?>
    <!DOCTYPE html>
    <html lang="<?= $lang ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= t('print_report_title') ?> - <?= htmlspecialchars($companyName) ?></title>
        <style>
            /* ============================================================
               PRINT STIJLEN - PER RECORD OP 1 A4 PAGINA
               ============================================================ */
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Courier New', Courier, monospace;
                background: #fff;
                color: #1a1a1a;
                font-size: 11px;
                margin: 0;
                padding: 0;
            }
            
            .page {
                width: 210mm;
                min-height: 297mm;
                padding: 20mm 15mm;
                margin: 0 auto;
                background: #fff;
                page-break-after: always;
                page-break-inside: avoid;
                border-bottom: 1px dashed #ccc;
                position: relative;
            }
            
            .page-header {
                border-bottom: 3px double #222;
                padding-bottom: 10px;
                margin-bottom: 15px;
                display: flex;
                justify-content: space-between;
                align-items: flex-end;
            }
            .page-header h1 {
                font-size: 18px;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            .page-header h1 small {
                font-size: 12px;
                font-weight: 300;
                color: #555;
                text-transform: none;
            }
            .page-header .meta {
                font-size: 10px;
                color: #888;
                text-align: right;
            }
            .page-header .meta .id-label {
                font-weight: 700;
                font-size: 14px;
                color: #222;
                display: block;
            }
            
            .record-type {
                display: inline-block;
                padding: 2px 12px;
                font-size: 9px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 1px;
                background: #222;
                color: #fff;
                border: 1px solid #000;
                margin-bottom: 10px;
            }
            
            .detail-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 6px 20px;
            }
            .detail-item {
                padding: 4px 0;
                border-bottom: 1px solid #f0f0f0;
            }
            .detail-item.full {
                grid-column: 1 / -1;
            }
            .detail-item .label {
                font-size: 8px;
                text-transform: uppercase;
                color: #888;
                font-weight: 600;
                display: block;
                letter-spacing: 0.3px;
            }
            .detail-item .value {
                font-size: 10px;
                color: #1a1a1a;
                word-break: break-word;
                line-height: 1.4;
            }
            
            .badge {
                display: inline-block;
                padding: 1px 6px;
                font-size: 8px;
                font-weight: 600;
                background: #eee;
                border: 1px solid #888;
                color: #000;
                text-transform: uppercase;
                letter-spacing: 0.3px;
            }
            .badge-high { background: #222; color: #fff; border-color: #000; }
            .badge-medium { background: #888; color: #fff; border-color: #666; }
            .badge-low { background: #ddd; color: #222; border-color: #aaa; }
            .badge-active { border-left: 4px solid #222; }
            .badge-inactive { border-left: 4px solid #aaa; opacity: 0.7; }
            .badge-draft { border-left: 4px solid #888; opacity: 0.8; }
            .badge-progress { border-left: 4px solid #666; }
            .badge-required { background: #222; color: #fff; border-color: #000; }
            .badge-not-required { background: #ddd; color: #555; border-color: #aaa; }
            
            .contact-section {
                background: #f5f5f5;
                padding: 8px 10px;
                border: 1px solid #ddd;
                margin: 4px 0;
            }
            .contact-section .label {
                font-size: 8px;
                text-transform: uppercase;
                color: #888;
                font-weight: 600;
                display: block;
            }
            .contact-section .contact-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 2px 10px;
                margin-top: 2px;
            }
            .contact-section .contact-grid span {
                font-size: 9px;
            }
            .contact-section .contact-grid .key {
                color: #888;
            }
            
            .page-footer {
                position: absolute;
                bottom: 15mm;
                left: 15mm;
                right: 15mm;
                border-top: 1px solid #ddd;
                padding-top: 8px;
                font-size: 8px;
                color: #888;
                display: flex;
                justify-content: space-between;
            }
            
            .summary-page .summary-grid {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 12px;
                margin: 20px 0;
            }
            .summary-page .stat {
                background: #f8f8f8;
                border: 1px solid #ddd;
                padding: 12px;
                text-align: center;
            }
            .summary-page .stat .num {
                font-size: 28px;
                font-weight: 700;
                color: #000;
            }
            .summary-page .stat .label {
                font-size: 9px;
                text-transform: uppercase;
                color: #666;
            }
            .summary-page .stat.highlight { border-left: 4px solid #222; }
            .summary-page .stat.risk { border-left: 4px solid #a00; }
            .summary-page .stat.risk .num { color: #a00; }
            
            .summary-page .table-overview {
                width: 100%;
                border-collapse: collapse;
                font-size: 10px;
                margin-top: 15px;
            }
            .summary-page .table-overview thead {
                background: #222;
                color: #fff;
            }
            .summary-page .table-overview thead th {
                padding: 4px 8px;
                text-align: left;
                font-size: 8px;
                text-transform: uppercase;
                border: 1px solid #111;
            }
            .summary-page .table-overview tbody td {
                padding: 3px 8px;
                border: 1px solid #ccc;
            }
            .summary-page .table-overview tbody tr:nth-child(even) {
                background: #f9f9f9;
            }
            
            @media print {
                body { margin: 0; padding: 0; }
                .page { width: 100%; min-height: 100vh; padding: 20mm 15mm; margin: 0; border: none; page-break-after: always; page-break-inside: avoid; }
                .page:last-child { page-break-after: avoid; }
            }
            @media screen and (max-width: 768px) {
                .page { width: 100%; min-height: auto; padding: 15px; }
                .detail-grid { grid-template-columns: 1fr; }
                .summary-page .summary-grid { grid-template-columns: 1fr 1fr; }
                .contact-section .contact-grid { grid-template-columns: 1fr; }
                .page-footer { position: relative; bottom: auto; left: auto; right: auto; margin-top: 15px; }
            }
        </style>
    </head>
    <body>
        
        <!-- ============================================================
             PAGE 1: SAMENVATTING
             ============================================================ -->
        <div class="page summary-page">
            <div class="page-header">
                <h1><?= htmlspecialchars($appTitle) ?> <small><?= t('print_report_title') ?></small></h1>
                <div class="meta">
                    <?= htmlspecialchars($companyName) ?><br>
                    <?= date('d-m-Y H:i') ?> · v<?= htmlspecialchars($appVersion) ?>
                </div>
            </div>
            
            <div style="margin-bottom:15px;">
                <span style="font-size:12px; font-weight:300;"><?= htmlspecialchars($companySubtitle) ?></span>
            </div>
            
            <div class="summary-grid">
                <div class="stat highlight"><div class="num"><?= count($printGdpr) ?></div><div class="label"><?= t('total') ?> <?= t('gdpr') ?></div></div>
                <div class="stat highlight"><div class="num"><?= count(array_filter($printGdpr, function($r) { return ($r['status'] ?? '') === 'active'; })) ?></div><div class="label"><?= t('active') ?> <?= t('gdpr') ?></div></div>
                <div class="stat risk"><div class="num"><?= count(array_filter($printGdpr, function($r) { return ($r['risk_level'] ?? '') === 'high'; })) ?></div><div class="label"><?= t('high_risk') ?></div></div>
                <div class="stat highlight"><div class="num"><?= count($printDpia) ?></div><div class="label"><?= t('total') ?> <?= t('dpia') ?></div></div>
                <div class="stat highlight"><div class="num"><?= count(array_filter($printDpia, function($r) { return ($r['status'] ?? '') === 'completed' || ($r['status'] ?? '') === 'approved'; })) ?></div><div class="label"><?= t('dpia_completed') ?></div></div>
                <div class="stat highlight"><div class="num"><?= count($printBreach) ?></div><div class="label"><?= t('breaches') ?></div></div>
                <div class="stat highlight"><div class="num"><?= count($printThirdparty) ?></div><div class="label"><?= t('third_parties') ?></div></div>
                <div class="stat highlight"><div class="num"><?= count(array_filter($printThirdparty, function($r) { return ($r['compliance_status'] ?? '') === 'compliant'; })) ?></div><div class="label"><?= t('compliant') ?></div></div>
            </div>
            
            <h3 style="font-size:12px; text-transform:uppercase; letter-spacing:1px; margin:15px 0 8px 0; border-bottom:1px solid #ddd; padding-bottom:4px;"><?= t('statistics') ?></h3>
            
            <table class="table-overview">
                <thead>
                    <tr>
                        <th><?= t('category') ?></th>
                        <th><?= t('total') ?></th>
                        <th><?= t('active') ?>/<?= t('compliant') ?></th>
                        <th><?= t('in_progress') ?></th>
                        <th><?= t('high_risk') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong><?= t('gdpr') ?></strong></td>
                        <td><?= count($printGdpr) ?></td>
                        <td><?= count(array_filter($printGdpr, function($r) { return ($r['status'] ?? '') === 'active'; })) ?></td>
                        <td>-</td>
                        <td><?= count(array_filter($printGdpr, function($r) { return ($r['risk_level'] ?? '') === 'high'; })) ?></td>
                    </tr>
                    <tr>
                        <td><strong><?= t('dpia') ?></strong></td>
                        <td><?= count($printDpia) ?></td>
                        <td><?= count(array_filter($printDpia, function($r) { return ($r['status'] ?? '') === 'completed' || ($r['status'] ?? '') === 'approved'; })) ?></td>
                        <td><?= count(array_filter($printDpia, function($r) { return ($r['status'] ?? '') === 'in_progress'; })) ?></td>
                        <td><?= count(array_filter($printDpia, function($r) { return ($r['overall_risk_level'] ?? '') === 'high'; })) ?></td>
                    </tr>
                    <tr>
                        <td><strong><?= t('breaches') ?></strong></td>
                        <td><?= count($printBreach) ?></td>
                        <td><?= count(array_filter($printBreach, function($r) { return ($r['status'] ?? '') === 'resolved' || ($r['status'] ?? '') === 'closed'; })) ?></td>
                        <td><?= count(array_filter($printBreach, function($r) { return ($r['status'] ?? '') === 'investigating'; })) ?></td>
                        <td><?= count(array_filter($printBreach, function($r) { return ($r['risk_level'] ?? '') === 'high'; })) ?></td>
                    </tr>
                    <tr>
                        <td><strong><?= t('third_parties') ?></strong></td>
                        <td><?= count($printThirdparty) ?></td>
                        <td><?= count(array_filter($printThirdparty, function($r) { return ($r['compliance_status'] ?? '') === 'compliant'; })) ?></td>
                        <td><?= count(array_filter($printThirdparty, function($r) { return ($r['compliance_status'] ?? '') === 'review_needed'; })) ?></td>
                        <td>-</td>
                    </tr>
                </tbody>
            </table>
            
            <div class="page-footer">
                <span><?= htmlspecialchars($appTitle) ?> v<?= htmlspecialchars($appVersion) ?></span>
                <span><?= t('page') ?> 1 van <?= 1 + count($printGdpr) + count($printDpia) + count($printBreach) + count($printThirdparty) ?></span>
                <span><?= t('generated_on') ?>: <?= date('d-m-Y H:i') ?></span>
            </div>
        </div>
        
        <!-- ============================================================
             GDPR RECORDS - PER RECORD OP APARTE PAGINA
             ============================================================ -->
        <?php 
        $pageNum = 2;
        foreach ($printGdpr as $r): 
        ?>
        <div class="page">
            <div class="page-header">
                <div>
                    <span class="record-type"><?= t('gdpr') ?> <?= t('record') ?></span>
                    <h1>#<?= $r['id'] ?> <small><?= htmlspecialchars($r['processing_activity'] ?? 'Onbekend') ?></small></h1>
                </div>
                <div class="meta">
                    <span class="id-label"><?= date('d-m-Y', strtotime($r['created_at'] ?? 'now')) ?></span>
                    <span style="font-size:9px; color:#888;"><?= t('created_at') ?? 'Aangemaakt' ?>: <?= formatDateTime($r['created_at'] ?? '') ?></span>
                </div>
            </div>
            
            <div style="margin-bottom:10px;">
                <span class="badge <?= getRiskClass($r['risk_level'] ?? 'low') ?>"><?= t('risk') ?>: <?= t($r['risk_level'] ?? 'low') ?></span>
                <span class="badge <?= getStatusClass($r['status'] ?? 'active') ?>"><?= t('status') ?>: <?= t($r['status'] ?? 'active') ?></span>
                <?= (($r['dpia_required'] ?? 'no') === 'yes') ? '<span class="badge badge-required">' . t('dpia_required') . '</span>' : '<span class="badge badge-not-required">' . t('not_required') . '</span>' ?>
            </div>
            
            <div class="detail-grid">
                <div class="detail-item"><span class="label"><?= t('processing_activity') ?></span><span class="value"><?= htmlspecialchars($r['processing_activity'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('purpose') ?></span><span class="value"><?= htmlspecialchars($r['purpose_of_processing'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('data_subjects') ?></span><span class="value"><?= htmlspecialchars($r['categories_data_subjects'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('personal_data') ?></span><span class="value"><?= htmlspecialchars($r['categories_personal_data'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('recipients') ?></span><span class="value"><?= htmlspecialchars($r['categories_recipients'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('legal_basis') ?></span><span class="value"><?= htmlspecialchars(getLegalBasisLabel($r['legal_basis'] ?? 'contract')) ?></span></div>
                <div class="detail-item"><span class="label"><?= t('retention_period') ?></span><span class="value"><?= htmlspecialchars($r['retention_periods'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($r['department'] ?? '-')) ?></span></div>
                <div class="detail-item"><span class="label"><?= t('dpia') ?> <?= t('status') ?></span><span class="value"><?= t($r['dpia_status'] ?? 'not_required') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('review_date') ?></span><span class="value"><?= formatDate($r['review_due_date'] ?? '') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('international_transfer') ?></span><span class="value"><?= ucfirst($r['is_international_data_transfers'] ?? 'unknown') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('to_country') ?></span><span class="value"><?= htmlspecialchars($r['to_country'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('we_are_processor') ?></span><span class="value"><?= getYesNoLabel($r['we_are_processor'] ?? 'no') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('processing_agreement_third_party') ?></span><span class="value"><?= getYesNoLabel($r['has_processing_agreement_with_third_party'] ?? 'no') ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('technical_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['technical_measures'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('organizational_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['organizational_measures'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('safeguards') ?></span><span class="value"><?= nl2br(htmlspecialchars(displaySafeguards($r['safeguards'] ?? ''))) ?></span></div>
            </div>
            
            <!-- Contactpersonen -->
            <div style="margin-top:10px;">
                <div class="contact-section">
                    <span class="label"><?= t('controller') ?></span>
                    <div class="contact-grid">
                        <span><span class="key"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($r['name_data_controller']) ? rot47decode($r['name_data_controller']) : '-') ?></span>
                        <span><span class="key"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($r['contact_data_controller']) ? rot47decode($r['contact_data_controller']) : '-') ?></span>
                    </div>
                </div>
                <div class="contact-section">
                    <span class="label"><?= t('joint_controller') ?></span>
                    <div class="contact-grid">
                        <span><span class="key"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($r['name_joint_data_controller']) ? rot47decode($r['name_joint_data_controller']) : '-') ?></span>
                        <span><span class="key"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($r['contact_joint_data_controller']) ? rot47decode($r['contact_joint_data_controller']) : '-') ?></span>
                    </div>
                </div>
                <div class="contact-section">
                    <span class="label"><?= t('dpo') ?></span>
                    <div class="contact-grid">
                        <span><span class="key"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($r['name_dpo']) ? rot47decode($r['name_dpo']) : '-') ?></span>
                        <span><span class="key"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($r['contact_dpo']) ? rot47decode($r['contact_dpo']) : '-') ?></span>
                    </div>
                </div>
                <div class="contact-section">
                    <span class="label"><?= t('representative') ?></span>
                    <div class="contact-grid">
                        <span><span class="key"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($r['name_representative']) ? rot47decode($r['name_representative']) : '-') ?></span>
                        <span><span class="key"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($r['contact_representative']) ? rot47decode($r['contact_representative']) : '-') ?></span>
                    </div>
                </div>
            </div>
            
            <div class="page-footer">
                <span><?= t('gdpr') ?> #<?= $r['id'] ?></span>
                <span><?= t('page') ?> <?= $pageNum++ ?> van <?= 1 + count($printGdpr) + count($printDpia) + count($printBreach) + count($printThirdparty) ?></span>
                <span><?= htmlspecialchars($r['processing_activity'] ?? '') ?></span>
            </div>
        </div>
        <?php endforeach; ?>
        
        <!-- ============================================================
             DPIA RECORDS - PER RECORD OP APARTE PAGINA
             ============================================================ -->
        <?php foreach ($printDpia as $r): ?>
        <div class="page">
            <div class="page-header">
                <div>
                    <span class="record-type"><?= t('dpia') ?> <?= t('record') ?></span>
                    <h1>#<?= $r['id'] ?> <small><?= htmlspecialchars($r['title'] ?? 'Onbekend') ?></small></h1>
                </div>
                <div class="meta">
                    <span class="id-label"><?= formatDate($r['registered_at'] ?? '') ?></span>
                    <span style="font-size:9px; color:#888;"><?= t('registered_at') ?? 'Aangemaakt' ?>: <?= formatDateTime($r['registered_at'] ?? '') ?></span>
                </div>
            </div>
            
            <div style="margin-bottom:10px;">
                <span class="badge <?= getRiskClass($r['overall_risk_level'] ?? 'medium') ?>"><?= t('risk') ?>: <?= t($r['overall_risk_level'] ?? 'medium') ?></span>
                <span class="badge <?= getStatusClass($r['status'] ?? 'draft') ?>"><?= t('status') ?>: <?= t($r['status'] ?? 'draft') ?></span>
                <?= !empty($r['record_id']) ? '<span class="badge badge-active">' . t('gdpr') . ' #'.$r['record_id'].'</span>' : '' ?>
            </div>
            
            <div class="detail-grid">
                <div class="detail-item full"><span class="label"><?= t('description') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['description'] ?? '-')) ?></span></div>
                <div class="detail-item"><span class="label"><?= t('gdpr_record') ?></span><span class="value"><?= !empty($r['record_id']) ? '#'.$r['record_id'] : '-' ?></span></div>
                <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($r['department'] ?? '-')) ?></span></div>
                <div class="detail-item"><span class="label"><?= t('risk_origin') ?></span><span class="value"><?= htmlspecialchars($r['risk_origin'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('affected_subjects') ?></span><span class="value"><?= $r['data_subjects_affected'] ?? '-' ?></span></div>
                <div class="detail-item"><span class="label"><?= t('management_approval') ?></span><span class="value"><?= htmlspecialchars($r['management_approval'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('data_categories') ?></span><span class="value"><?= htmlspecialchars($r['data_categories'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('consultation_conducted') ?></span><span class="value"><?= getYesNoLabel($r['consultation_conducted'] ?? 'no') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('approved_by') ?></span><span class="value"><?= htmlspecialchars($r['approved_by'] ?? '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('approval_date') ?></span><span class="value"><?= formatDate($r['approval_date'] ?? '') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('review_date') ?></span><span class="value"><?= formatDate($r['review_date'] ?? '') ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('processing_activity') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['processing_activity_description'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('necessity_test') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['necessity_test'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('proportionality_test') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['proportionality_test'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('mitigation_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['mitigation_measures'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('residual_risk') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['residual_risk'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('recommendations') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['recommendations'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('consultation_details') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['consultation_details'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('notes') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['notes'] ?? '-')) ?></span></div>
            </div>
            
            <div class="page-footer">
                <span><?= t('dpia') ?> #<?= $r['id'] ?></span>
                <span><?= t('page') ?> <?= $pageNum++ ?> van <?= 1 + count($printGdpr) + count($printDpia) + count($printBreach) + count($printThirdparty) ?></span>
                <span><?= htmlspecialchars($r['title'] ?? '') ?></span>
            </div>
        </div>
        <?php endforeach; ?>
        
        <!-- ============================================================
             BREACH RECORDS - PER RECORD OP APARTE PAGINA
             ============================================================ -->
        <?php foreach ($printBreach as $r): ?>
        <div class="page">
            <div class="page-header">
                <div>
                    <span class="record-type"><?= t('breach') ?></span>
                    <h1>#<?= $r['id'] ?> <small><?= htmlspecialchars($r['title'] ?? 'Onbekend') ?></small></h1>
                </div>
                <div class="meta">
                    <span class="id-label"><?= formatDate($r['breach_date'] ?? '') ?></span>
                    <span style="font-size:9px; color:#888;"><?= t('discovered') ?? 'Ontdekt' ?>: <?= formatDate($r['discovery_date'] ?? '') ?></span>
                </div>
            </div>
            
            <div style="margin-bottom:10px;">
                <span class="badge <?= getRiskClass($r['risk_level'] ?? 'low') ?>"><?= t('risk') ?>: <?= t($r['risk_level'] ?? 'low') ?></span>
                <span class="badge <?= getStatusClass($r['status'] ?? 'open') ?>"><?= t('status') ?>: <?= t($r['status'] ?? 'open') ?></span>
                <span class="badge"><?= t('breach_type') ?>: <?= getBreachTypeLabel($r['breach_type'] ?? '') ?></span>
            </div>
            
            <div class="detail-grid">
                <div class="detail-item full"><span class="label"><?= t('description') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['description'] ?? '-')) ?></span></div>
                <div class="detail-item"><span class="label"><?= t('breach_date') ?></span><span class="value"><?= formatDate($r['breach_date'] ?? '') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('discovery_date') ?></span><span class="value"><?= formatDate($r['discovery_date'] ?? '') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($r['department'] ?? '-')) ?></span></div>
                <div class="detail-item"><span class="label"><?= t('breach_type') ?></span><span class="value"><?= getBreachTypeLabel($r['breach_type'] ?? '') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('affected_subjects') ?></span><span class="value"><?= $r['affected_data_subjects'] ?? '-' ?></span></div>
                <div class="detail-item"><span class="label"><?= t('notified_authority') ?></span><span class="value"><?= getYesNoLabel($r['notified_authority'] ?? 'no') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('notification_date') ?></span><span class="value"><?= formatDate($r['notification_date'] ?? '') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('notified_affected') ?></span><span class="value"><?= getYesNoLabel($r['notified_affected_persons'] ?? 'no') ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('personal_data') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['personal_data_affected'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('causes') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['causes'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('measures_taken') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['measures_taken'] ?? '-')) ?></span></div>
            </div>
            
            <div class="page-footer">
                <span><?= t('breach') ?> #<?= $r['id'] ?></span>
                <span><?= t('page') ?> <?= $pageNum++ ?> van <?= 1 + count($printGdpr) + count($printDpia) + count($printBreach) + count($printThirdparty) ?></span>
                <span><?= htmlspecialchars($r['title'] ?? '') ?></span>
            </div>
        </div>
        <?php endforeach; ?>
        
        <!-- ============================================================
             THIRD PARTY RECORDS - PER RECORD OP APARTE PAGINA
             ============================================================ -->
        <?php foreach ($printThirdparty as $r): ?>
        <div class="page">
            <div class="page-header">
                <div>
                    <span class="record-type"><?= t('third_party') ?></span>
                    <h1>#<?= $r['id'] ?> <small><?= htmlspecialchars(!empty($r['company_name']) ? rot47decode($r['company_name']) : 'Onbekend') ?></small></h1>
                </div>
                <div class="meta">
                    <span class="id-label"><?= formatDate($r['created_at'] ?? '') ?></span>
                    <span style="font-size:9px; color:#888;"><?= t('created_at') ?? 'Aangemaakt' ?>: <?= formatDateTime($r['created_at'] ?? '') ?></span>
                </div>
            </div>
            
            <div style="margin-bottom:10px;">
                <span class="badge <?= getStatusClass($r['compliance_status'] ?? 'review_needed') ?>"><?= t('compliance_status') ?>: <?= getComplianceStatusLabel($r['compliance_status'] ?? 'review_needed') ?></span>
                <span class="badge <?= ($r['processing_agreement_signed'] ?? '') === 'yes' ? 'badge-active' : 'badge-inactive' ?>"><?= t('agreement_signed') ?>: <?= getYesNoLabel($r['processing_agreement_signed'] ?? 'no') ?></span>
            </div>
            
            <div class="detail-grid">
                <div class="detail-item full"><span class="label"><?= t('company_name') ?></span><span class="value"><?= htmlspecialchars(!empty($r['company_name']) ? rot47decode($r['company_name']) : '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('contact_person') ?></span><span class="value"><?= htmlspecialchars(!empty($r['contact_person']) ? rot47decode($r['contact_person']) : '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('email') ?></span><span class="value"><?= htmlspecialchars(!empty($r['email']) ? rot47decode($r['email']) : '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('phone') ?></span><span class="value"><?= htmlspecialchars(!empty($r['phone']) ? rot47decode($r['phone']) : '-') ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('address') ?></span><span class="value"><?= htmlspecialchars(!empty($r['address']) ? rot47decode($r['address']) : '-') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($r['department'] ?? '-')) ?></span></div>
                <div class="detail-item full"><span class="label"><?= t('service_provided') ?></span><span class="value"><?= nl2br(htmlspecialchars($r['service_provided'] ?? '-')) ?></span></div>
                <div class="detail-item"><span class="label"><?= t('agreement_signed') ?></span><span class="value"><?= getYesNoLabel($r['processing_agreement_signed'] ?? 'no') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('compliance_status') ?></span><span class="value"><?= getComplianceStatusLabel($r['compliance_status'] ?? 'review_needed') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('agreement_date') ?></span><span class="value"><?= formatDate($r['agreement_date'] ?? '') ?></span></div>
                <div class="detail-item"><span class="label"><?= t('expiry_date') ?></span><span class="value"><?= formatDate($r['agreement_expiry_date'] ?? '') ?></span></div>
            </div>
            
            <div class="page-footer">
                <span><?= t('third_party') ?> #<?= $r['id'] ?></span>
                <span><?= t('page') ?> <?= $pageNum++ ?> van <?= 1 + count($printGdpr) + count($printDpia) + count($printBreach) + count($printThirdparty) ?></span>
                <span><?= htmlspecialchars(!empty($r['company_name']) ? rot47decode($r['company_name']) : '') ?></span>
            </div>
        </div>
        <?php endforeach; ?>
        
    </body>
    </html>
    <?php
    exit;
}

// --- Handle Print Single Record ---
if (isset($_GET['action']) && $_GET['action'] === 'print_record' && isset($_GET['type']) && isset($_GET['id'])) {
    $type = $_GET['type'];
    $id = (int)$_GET['id'];
    $record = null;
    
    switch ($type) {
        case 'gdpr':
            $found = findRecord($gdprRecords, $id);
            if ($found) $record = $found['record'];
            break;
        case 'dpia':
            $found = findRecord($dpiaRecords, $id);
            if ($found) $record = $found['record'];
            break;
        case 'breach':
            $found = findRecord($breachRecords, $id);
            if ($found) $record = $found['record'];
            break;
        case 'thirdparty':
            $found = findRecord($thirdpartyRecords, $id);
            if ($found) $record = $found['record'];
            break;
    }
    
    if (!$record) {
        die('Record niet gevonden.');
    }
    
    $recordTypeLabels = [
        'gdpr' => t('gdpr'),
        'dpia' => t('dpia'),
        'breach' => t('breach'),
        'thirdparty' => t('third_party')
    ];
    $recordTypeLabel = $recordTypeLabels[$type] ?? 'Record';
    
    ?>
    <!DOCTYPE html>
    <html lang="<?= $lang ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= t('record') ?> #<?= $id ?> - <?= htmlspecialchars($companyName) ?></title>
        <style>
            /* ============================================================
               PRINT STIJLEN - ENKEL RECORD OP 1 A4 PAGINA
               ============================================================ */
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Courier New', Courier, monospace;
                background: #fff;
                color: #1a1a1a;
                font-size: 11px;
                margin: 0;
                padding: 20px;
            }
            
            .page {
                width: 210mm;
                min-height: 297mm;
                padding: 20mm 15mm;
                margin: 0 auto;
                background: #fff;
                page-break-after: avoid;
                page-break-inside: avoid;
                position: relative;
            }
            
            .page-header {
                border-bottom: 3px double #222;
                padding-bottom: 10px;
                margin-bottom: 15px;
                display: flex;
                justify-content: space-between;
                align-items: flex-end;
            }
            .page-header h1 {
                font-size: 18px;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            .page-header h1 small {
                font-size: 12px;
                font-weight: 300;
                color: #555;
                text-transform: none;
            }
            .page-header .meta {
                font-size: 10px;
                color: #888;
                text-align: right;
            }
            .page-header .meta .id-label {
                font-weight: 700;
                font-size: 14px;
                color: #222;
                display: block;
            }
            
            .record-type {
                display: inline-block;
                padding: 2px 12px;
                font-size: 9px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 1px;
                background: #222;
                color: #fff;
                border: 1px solid #000;
                margin-bottom: 10px;
            }
            
            .detail-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 6px 20px;
            }
            .detail-item {
                padding: 4px 0;
                border-bottom: 1px solid #f0f0f0;
            }
            .detail-item.full {
                grid-column: 1 / -1;
            }
            .detail-item .label {
                font-size: 8px;
                text-transform: uppercase;
                color: #888;
                font-weight: 600;
                display: block;
                letter-spacing: 0.3px;
            }
            .detail-item .value {
                font-size: 10px;
                color: #1a1a1a;
                word-break: break-word;
                line-height: 1.4;
            }
            
            .badge {
                display: inline-block;
                padding: 1px 6px;
                font-size: 8px;
                font-weight: 600;
                background: #eee;
                border: 1px solid #888;
                color: #000;
                text-transform: uppercase;
                letter-spacing: 0.3px;
            }
            .badge-high { background: #222; color: #fff; border-color: #000; }
            .badge-medium { background: #888; color: #fff; border-color: #666; }
            .badge-low { background: #ddd; color: #222; border-color: #aaa; }
            .badge-active { border-left: 4px solid #222; }
            .badge-inactive { border-left: 4px solid #aaa; opacity: 0.7; }
            .badge-draft { border-left: 4px solid #888; opacity: 0.8; }
            .badge-progress { border-left: 4px solid #666; }
            .badge-required { background: #222; color: #fff; border-color: #000; }
            .badge-not-required { background: #ddd; color: #555; border-color: #aaa; }
            
            .contact-section {
                background: #f5f5f5;
                padding: 8px 10px;
                border: 1px solid #ddd;
                margin: 4px 0;
            }
            .contact-section .label {
                font-size: 8px;
                text-transform: uppercase;
                color: #888;
                font-weight: 600;
                display: block;
            }
            .contact-section .contact-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 2px 10px;
                margin-top: 2px;
            }
            .contact-section .contact-grid span {
                font-size: 9px;
            }
            .contact-section .contact-grid .key {
                color: #888;
            }
            
            .page-footer {
                position: absolute;
                bottom: 15mm;
                left: 15mm;
                right: 15mm;
                border-top: 1px solid #ddd;
                padding-top: 8px;
                font-size: 8px;
                color: #888;
                display: flex;
                justify-content: space-between;
            }
            
            .print-btn {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 10px 20px;
                background: #222;
                color: #fff;
                border: 1px solid #000;
                font-size: 14px;
                cursor: pointer;
                font-family: inherit;
                z-index: 1000;
                transition: background 0.2s;
            }
            .print-btn:hover { background: #555; }
            
            .close-btn-print {
                position: fixed;
                top: 20px;
                right: 140px;
                padding: 10px 20px;
                background: #eee;
                color: #222;
                border: 1px solid #aaa;
                font-size: 14px;
                cursor: pointer;
                font-family: inherit;
                z-index: 1000;
                text-decoration: none;
                transition: background 0.2s;
            }
            .close-btn-print:hover { background: #ddd; }
            
            @media print {
                body { margin: 0; padding: 0; background: #fff; }
                .page { width: 100%; min-height: 100vh; padding: 20mm 15mm; margin: 0; border: none; page-break-after: avoid; }
                .print-btn, .close-btn-print { display: none !important; }
            }
            @media screen and (max-width: 768px) {
                .page { width: 100%; min-height: auto; padding: 15px; }
                .detail-grid { grid-template-columns: 1fr; }
                .contact-section .contact-grid { grid-template-columns: 1fr; }
                .page-footer { position: relative; bottom: auto; left: auto; right: auto; margin-top: 15px; }
                .print-btn, .close-btn-print { position: fixed; top: 10px; right: 10px; padding: 6px 12px; font-size: 12px; }
                .close-btn-print { right: 110px; }
            }
        </style>
    </head>
    <body>
        <button class="print-btn" onclick="window.print()"><i class="fas fa-print"></i> <?= t('print') ?></button>
        <a href="?tab=<?= $type ?>&lang=<?= $lang ?>" class="close-btn-print">&times; <?= t('close') ?></a>
        
        <!-- ============================================================
             RECORD PRINT
             ============================================================ -->
        <div class="page">
            <div class="page-header">
                <div>
                    <span class="record-type"><?= $recordTypeLabel ?></span>
                    <h1>#<?= $id ?> <small><?= htmlspecialchars($record['processing_activity'] ?? $record['title'] ?? $record['company_name'] ?? 'Onbekend') ?></small></h1>
                </div>
                <div class="meta">
                    <span class="id-label"><?= date('d-m-Y', strtotime($record['created_at'] ?? $record['registered_at'] ?? 'now')) ?></span>
                    <span style="font-size:9px; color:#888;"><?= htmlspecialchars($companyName) ?></span>
                </div>
            </div>
            
            <?php if ($type === 'gdpr'): ?>
                <!-- GDPR RECORD -->
                <div style="margin-bottom:10px;">
                    <span class="badge <?= getRiskClass($record['risk_level'] ?? 'low') ?>"><?= t('risk') ?>: <?= t($record['risk_level'] ?? 'low') ?></span>
                    <span class="badge <?= getStatusClass($record['status'] ?? 'active') ?>"><?= t('status') ?>: <?= t($record['status'] ?? 'active') ?></span>
                    <?= (($record['dpia_required'] ?? 'no') === 'yes') ? '<span class="badge badge-required">' . t('dpia_required') . '</span>' : '<span class="badge badge-not-required">' . t('not_required') . '</span>' ?>
                </div>
                
                <div class="detail-grid">
                    <div class="detail-item"><span class="label"><?= t('processing_activity') ?></span><span class="value"><?= htmlspecialchars($record['processing_activity'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('purpose') ?></span><span class="value"><?= htmlspecialchars($record['purpose_of_processing'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('data_subjects') ?></span><span class="value"><?= htmlspecialchars($record['categories_data_subjects'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('personal_data') ?></span><span class="value"><?= htmlspecialchars($record['categories_personal_data'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('recipients') ?></span><span class="value"><?= htmlspecialchars($record['categories_recipients'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('legal_basis') ?></span><span class="value"><?= htmlspecialchars(getLegalBasisLabel($record['legal_basis'] ?? 'contract')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('retention_period') ?></span><span class="value"><?= htmlspecialchars($record['retention_periods'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($record['department'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('dpia') ?> <?= t('status') ?></span><span class="value"><?= t($record['dpia_status'] ?? 'not_required') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('review_date') ?></span><span class="value"><?= formatDate($record['review_due_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('international_transfer') ?></span><span class="value"><?= ucfirst($record['is_international_data_transfers'] ?? 'unknown') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('to_country') ?></span><span class="value"><?= htmlspecialchars($record['to_country'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('we_are_processor') ?></span><span class="value"><?= getYesNoLabel($record['we_are_processor'] ?? 'no') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('processing_agreement_third_party') ?></span><span class="value"><?= getYesNoLabel($record['has_processing_agreement_with_third_party'] ?? 'no') ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('technical_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['technical_measures'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('organizational_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['organizational_measures'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('safeguards') ?></span><span class="value"><?= nl2br(htmlspecialchars(displaySafeguards($record['safeguards'] ?? ''))) ?></span></div>
                </div>
                
                <!-- Contactpersonen -->
                <div style="margin-top:10px;">
                    <div class="contact-section">
                        <span class="label"><?= t('controller') ?></span>
                        <div class="contact-grid">
                            <span><span class="key"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($record['name_data_controller']) ? rot47decode($record['name_data_controller']) : '-') ?></span>
                            <span><span class="key"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($record['contact_data_controller']) ? rot47decode($record['contact_data_controller']) : '-') ?></span>
                        </div>
                    </div>
                    <div class="contact-section">
                        <span class="label"><?= t('joint_controller') ?></span>
                        <div class="contact-grid">
                            <span><span class="key"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($record['name_joint_data_controller']) ? rot47decode($record['name_joint_data_controller']) : '-') ?></span>
                            <span><span class="key"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($record['contact_joint_data_controller']) ? rot47decode($record['contact_joint_data_controller']) : '-') ?></span>
                        </div>
                    </div>
                    <div class="contact-section">
                        <span class="label"><?= t('dpo') ?></span>
                        <div class="contact-grid">
                            <span><span class="key"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($record['name_dpo']) ? rot47decode($record['name_dpo']) : '-') ?></span>
                            <span><span class="key"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($record['contact_dpo']) ? rot47decode($record['contact_dpo']) : '-') ?></span>
                        </div>
                    </div>
                    <div class="contact-section">
                        <span class="label"><?= t('representative') ?></span>
                        <div class="contact-grid">
                            <span><span class="key"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($record['name_representative']) ? rot47decode($record['name_representative']) : '-') ?></span>
                            <span><span class="key"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($record['contact_representative']) ? rot47decode($record['contact_representative']) : '-') ?></span>
                        </div>
                    </div>
                </div>
                
            <?php elseif ($type === 'dpia'): ?>
                <!-- DPIA RECORD -->
                <div style="margin-bottom:10px;">
                    <span class="badge <?= getRiskClass($record['overall_risk_level'] ?? 'medium') ?>"><?= t('risk') ?>: <?= t($record['overall_risk_level'] ?? 'medium') ?></span>
                    <span class="badge <?= getStatusClass($record['status'] ?? 'draft') ?>"><?= t('status') ?>: <?= t($record['status'] ?? 'draft') ?></span>
                    <?= !empty($record['record_id']) ? '<span class="badge badge-active">' . t('gdpr') . ' #'.$record['record_id'].'</span>' : '' ?>
                </div>
                
                <div class="detail-grid">
                    <div class="detail-item full"><span class="label"><?= t('description') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['description'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('gdpr_record') ?></span><span class="value"><?= !empty($record['record_id']) ? '#'.$record['record_id'] : '-' ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($record['department'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('risk_origin') ?></span><span class="value"><?= htmlspecialchars($record['risk_origin'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('affected_subjects') ?></span><span class="value"><?= $record['data_subjects_affected'] ?? '-' ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('management_approval') ?></span><span class="value"><?= htmlspecialchars($record['management_approval'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('data_categories') ?></span><span class="value"><?= htmlspecialchars($record['data_categories'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('consultation_conducted') ?></span><span class="value"><?= getYesNoLabel($record['consultation_conducted'] ?? 'no') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('approved_by') ?></span><span class="value"><?= htmlspecialchars($record['approved_by'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('approval_date') ?></span><span class="value"><?= formatDate($record['approval_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('review_date') ?></span><span class="value"><?= formatDate($record['review_date'] ?? '') ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('processing_activity') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['processing_activity_description'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('necessity_test') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['necessity_test'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('proportionality_test') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['proportionality_test'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('mitigation_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['mitigation_measures'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('residual_risk') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['residual_risk'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('recommendations') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['recommendations'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('consultation_details') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['consultation_details'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('notes') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['notes'] ?? '-')) ?></span></div>
                </div>
                
            <?php elseif ($type === 'breach'): ?>
                <!-- BREACH RECORD -->
                <div style="margin-bottom:10px;">
                    <span class="badge <?= getRiskClass($record['risk_level'] ?? 'low') ?>"><?= t('risk') ?>: <?= t($record['risk_level'] ?? 'low') ?></span>
                    <span class="badge <?= getStatusClass($record['status'] ?? 'open') ?>"><?= t('status') ?>: <?= t($record['status'] ?? 'open') ?></span>
                    <span class="badge"><?= t('breach_type') ?>: <?= getBreachTypeLabel($record['breach_type'] ?? '') ?></span>
                </div>
                
                <div class="detail-grid">
                    <div class="detail-item full"><span class="label"><?= t('description') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['description'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('breach_date') ?></span><span class="value"><?= formatDate($record['breach_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('discovery_date') ?></span><span class="value"><?= formatDate($record['discovery_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($record['department'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('breach_type') ?></span><span class="value"><?= getBreachTypeLabel($record['breach_type'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('affected_subjects') ?></span><span class="value"><?= $record['affected_data_subjects'] ?? '-' ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('notified_authority') ?></span><span class="value"><?= getYesNoLabel($record['notified_authority'] ?? 'no') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('notification_date') ?></span><span class="value"><?= formatDate($record['notification_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('notified_affected') ?></span><span class="value"><?= getYesNoLabel($record['notified_affected_persons'] ?? 'no') ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('personal_data') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['personal_data_affected'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('causes') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['causes'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('measures_taken') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['measures_taken'] ?? '-')) ?></span></div>
                </div>
                
            <?php elseif ($type === 'thirdparty'): ?>
                <!-- THIRD PARTY RECORD -->
                <div style="margin-bottom:10px;">
                    <span class="badge <?= getStatusClass($record['compliance_status'] ?? 'review_needed') ?>"><?= t('compliance_status') ?>: <?= getComplianceStatusLabel($record['compliance_status'] ?? 'review_needed') ?></span>
                    <span class="badge <?= ($record['processing_agreement_signed'] ?? '') === 'yes' ? 'badge-active' : 'badge-inactive' ?>"><?= t('agreement_signed') ?>: <?= getYesNoLabel($record['processing_agreement_signed'] ?? 'no') ?></span>
                </div>
                
                <div class="detail-grid">
                    <div class="detail-item full"><span class="label"><?= t('company_name') ?></span><span class="value"><?= htmlspecialchars(!empty($record['company_name']) ? rot47decode($record['company_name']) : '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('contact_person') ?></span><span class="value"><?= htmlspecialchars(!empty($record['contact_person']) ? rot47decode($record['contact_person']) : '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('email') ?></span><span class="value"><?= htmlspecialchars(!empty($record['email']) ? rot47decode($record['email']) : '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('phone') ?></span><span class="value"><?= htmlspecialchars(!empty($record['phone']) ? rot47decode($record['phone']) : '-') ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('address') ?></span><span class="value"><?= htmlspecialchars(!empty($record['address']) ? rot47decode($record['address']) : '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($record['department'] ?? '-')) ?></span></div>
                    <div class="detail-item full"><span class="label"><?= t('service_provided') ?></span><span class="value"><?= nl2br(htmlspecialchars($record['service_provided'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('agreement_signed') ?></span><span class="value"><?= getYesNoLabel($record['processing_agreement_signed'] ?? 'no') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('compliance_status') ?></span><span class="value"><?= getComplianceStatusLabel($record['compliance_status'] ?? 'review_needed') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('agreement_date') ?></span><span class="value"><?= formatDate($record['agreement_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('expiry_date') ?></span><span class="value"><?= formatDate($record['agreement_expiry_date'] ?? '') ?></span></div>
                </div>
            <?php endif; ?>
            
            <div class="page-footer">
                <span><?= $recordTypeLabel ?> #<?= $id ?></span>
                <span><?= htmlspecialchars($companyName) ?></span>
                <span><?= t('generated_on') ?>: <?= date('d-m-Y H:i') ?></span>
            </div>
        </div>
        
        <script>
            // Auto print bij laden (optioneel)
            // window.onload = function() { window.print(); };
        </script>
    </body>
    </html>
    <?php
    exit;
}

// --- Process POST requests (CRUD) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // --- GDPR SAVE ---
    if ($action === 'save_gdpr') {
        // Multi-select technical measures (semicolon-separated: commas can
        // legitimately appear inside a measure's own text, so ';' is the
        // list separator everywhere in this app)
        $techMeasures = isset($_POST['technical_measures']) && is_array($_POST['technical_measures']) ? $_POST['technical_measures'] : [];
        $techCustom = $_POST['technical_measures_custom'] ?? '';
        $finalTechList = array_merge($techMeasures, splitMeasureList($techCustom));
        $finalTech = implode('; ', array_values(array_unique(array_filter($finalTechList, function($v) { return trim($v) !== ''; }))));

        // Multi-select organizational measures
        $orgMeasures = isset($_POST['organizational_measures']) && is_array($_POST['organizational_measures']) ? $_POST['organizational_measures'] : [];
        $orgCustom = $_POST['organizational_measures_custom'] ?? '';
        $finalOrgList = array_merge($orgMeasures, splitMeasureList($orgCustom));
        $finalOrg = implode('; ', array_values(array_unique(array_filter($finalOrgList, function($v) { return trim($v) !== ''; }))));

        // Multi-select safeguards
        $safeguardsSelected = isset($_POST['safeguards']) && is_array($_POST['safeguards']) ? $_POST['safeguards'] : [];
        $safeguardsCustom = $_POST['safeguards_custom'] ?? '';
        $finalSafeguardsList = array_merge($safeguardsSelected, splitMeasureList($safeguardsCustom));
        $finalSafeguards = implode('; ', array_values(array_unique(array_filter($finalSafeguardsList, function($v) { return trim($v) !== ''; }))));
        
        // Afdeling - from dropdown, or freely typed custom department
        $deptCustom = trim($_POST['department_custom'] ?? '');
        $finalDepartment = $deptCustom !== '' ? $deptCustom : ($_POST['department'] ?? 'administration');

        // Bewaarperiode - from dropdown or custom
        $retention = $_POST['retention_periods'] ?? '';
        $retentionCustom = $_POST['retention_periods_custom'] ?? '';
        $finalRetention = !empty($retentionCustom) ? $retentionCustom : $retention;
        
        // Naam-velden (controller/gezamenlijke controller/DPO/vertegenwoordiger):
        // gekozen uit eerder gebruikte namen (select), of een zelf getypte naam
        // heeft voorrang als die is ingevuld.
        $nameFieldsWithCustom = ['name_data_controller', 'name_joint_data_controller', 'name_dpo', 'name_representative'];
        foreach ($nameFieldsWithCustom as $nf) {
            $customName = trim($_POST[$nf . '_custom'] ?? '');
            if ($customName !== '') {
                $_POST[$nf] = $customName;
            }
        }

        // Contact fields - ENCODE with ROT47
        $contactFields = [
            'contact_data_controller', 'name_data_controller',
            'contact_dpo', 'name_dpo',
            'contact_joint_data_controller', 'name_joint_data_controller',
            'contact_representative', 'name_representative'
        ];
        $contactData = [];
        foreach ($contactFields as $field) {
            $value = $_POST[$field] ?? '';
            $contactData[$field] = !empty($value) ? rot47encode($value) : '';
        }
        
        // DPIA required - gebruik 'yes' in kleine letters
        $dpiaRequired = isset($_POST['dpia_required']) ? strtolower($_POST['dpia_required']) : 'no';
        if ($dpiaRequired !== 'yes' && $dpiaRequired !== 'no') {
            $dpiaRequired = 'no';
        }
        
        // we_are_processor - gebruik 'yes' in kleine letters
        $weAreProcessor = isset($_POST['we_are_processor']) ? strtolower($_POST['we_are_processor']) : 'no';
        if ($weAreProcessor !== 'yes' && $weAreProcessor !== 'no') {
            $weAreProcessor = 'no';
        }
        
        // has_processing_agreement_with_third_party - gebruik 'yes' in kleine letters
        $hasAgreement = isset($_POST['has_processing_agreement_with_third_party']) ? strtolower($_POST['has_processing_agreement_with_third_party']) : 'no';
        if ($hasAgreement !== 'yes' && $hasAgreement !== 'no') {
            $hasAgreement = 'no';
        }
        
        $recordData = [
            'id' => isset($_POST['id']) && !empty($_POST['id']) ? (int)$_POST['id'] : null,
            'processing_activity' => $_POST['processing_activity'] ?? '',
            'purpose_of_processing' => $_POST['purpose_of_processing'] ?? '',
            'categories_data_subjects' => $_POST['categories_data_subjects'] ?? '',
            'categories_personal_data' => $_POST['categories_personal_data'] ?? '',
            'categories_recipients' => $_POST['categories_recipients'] ?? '',
            'legal_basis' => $_POST['legal_basis'] ?? '',
            'legitimate_interest_description' => $_POST['legitimate_interest_description'] ?? '',
            'retention_periods' => $finalRetention,
            'technical_measures' => $finalTech,
            'organizational_measures' => $finalOrg,
            'safeguards' => $finalSafeguards,
            'risk_level' => $_POST['risk_level'] ?? 'low',
            'dpia_required' => $dpiaRequired,
            'dpia_status' => $_POST['dpia_status'] ?? 'not_required',
            'status' => $_POST['status'] ?? 'active',
            'department' => $finalDepartment,
            'has_processing_agreement_with_third_party' => $hasAgreement,
            'we_are_processor' => $weAreProcessor,
            'is_international_data_transfers' => $_POST['is_international_data_transfers'] ?? 'unknown',
            'to_country' => $_POST['to_country'] ?? '',
            'review_due_date' => $_POST['review_due_date'] ?? '',
            // Contact fields (ROT47 encoded)
            'contact_data_controller' => $contactData['contact_data_controller'],
            'name_data_controller' => $contactData['name_data_controller'],
            'contact_dpo' => $contactData['contact_dpo'],
            'name_dpo' => $contactData['name_dpo'],
            'contact_joint_data_controller' => $contactData['contact_joint_data_controller'],
            'name_joint_data_controller' => $contactData['name_joint_data_controller'],
            'contact_representative' => $contactData['contact_representative'],
            'name_representative' => $contactData['name_representative'],
        ];
        
        $now = date('Y-m-d H:i:s');
        if ($recordData['id'] === null) {
            $recordData['id'] = getNextIdGdpr($gdprRecords);
            $recordData['created_at'] = $now;
            $recordData['created_by'] = $defaultUserId;
            $gdprRecords[] = $recordData;
            $message = 'GDPR record #' . $recordData['id'] . ' ' . t('successfully_added') . '!';
            $messageType = 'success';
        } else {
            foreach ($gdprRecords as $key => $rec) {
                if ($rec['id'] == $recordData['id']) {
                    $recordData['created_at'] = isset($rec['created_at']) ? $rec['created_at'] : $now;
                    $recordData['created_by'] = isset($rec['created_by']) ? $rec['created_by'] : $defaultUserId;
                    $recordData['updated_at'] = $now;
                    $recordData['updated_by'] = $defaultUserId;
                    $gdprRecords[$key] = $recordData;
                    break;
                }
            }
            $message = 'GDPR record #' . $recordData['id'] . ' ' . t('successfully_updated') . '!';
            $messageType = 'success';
        }
        saveRecords($gdprFile, $gdprRecords);
        $gdprRecords = loadRecords($gdprFile);
        header('Location: ?tab=gdpr&lang=' . $lang);
        exit;
    }
    
    // --- GDPR DELETE ---
    if ($action === 'delete_gdpr') {
        $id = (int)$_POST['id'];
        foreach ($gdprRecords as $key => $rec) if ($rec['id'] == $id) { unset($gdprRecords[$key]); break; }
        $gdprRecords = array_values($gdprRecords);
        saveRecords($gdprFile, $gdprRecords);
        $gdprRecords = loadRecords($gdprFile);
        header('Location: ?tab=gdpr&lang=' . $lang);
        exit;
    }
    
    // --- DPIA SAVE ---
    if ($action === 'save_dpia') {
        $gdprId = isset($_POST['record_id']) && !empty($_POST['record_id']) ? (int)$_POST['record_id'] : null;
        $currentId = isset($_POST['id']) && !empty($_POST['id']) ? (int)$_POST['id'] : null;
        
        // Controleer of er al een DPIA bestaat voor dit GDPR record
        if ($gdprId) {
            $existingDpia = findDpiaByGdprId($dpiaRecords, $gdprId);
            if ($existingDpia && $existingDpia['record']['id'] != $currentId) {
                $message = t('dpia_exists_for_gdpr') . ' #' . $existingDpia['record']['id'] . ' ' . t('for_gdpr_record') . ' #' . $gdprId . '. ' . t('only_one_dpia_allowed');
                $messageType = 'danger';
                header('Location: ?tab=dpia&error=' . urlencode($message) . '&lang=' . $lang);
                exit;
            }
        }
        
        // Mitigerende maatregelen - multi-select + eigen invoer, apart voor
        // technisch en organisatorisch (zodat zelf getypte maatregelen niet
        // meer in een gemeenschappelijke, ongesorteerde "custom" pot vallen)
        $mitigationTech = isset($_POST['mitigation_technical_measures']) && is_array($_POST['mitigation_technical_measures']) ? $_POST['mitigation_technical_measures'] : [];
        $mitigationOrg = isset($_POST['mitigation_organizational_measures']) && is_array($_POST['mitigation_organizational_measures']) ? $_POST['mitigation_organizational_measures'] : [];
        $mitigationTechCustom = trim($_POST['mitigation_technical_measures_custom'] ?? '');
        $mitigationOrgCustom = trim($_POST['mitigation_organizational_measures_custom'] ?? '');

        $finalMitigationTechList = $mitigationTech;
        if ($mitigationTechCustom !== '') {
            $finalMitigationTechList = array_merge($finalMitigationTechList, splitMeasureList($mitigationTechCustom));
        }
        $finalMitigationOrgList = $mitigationOrg;
        if ($mitigationOrgCustom !== '') {
            $finalMitigationOrgList = array_merge($finalMitigationOrgList, splitMeasureList($mitigationOrgCustom));
        }
        $finalMitigationTechList = array_values(array_unique(array_filter($finalMitigationTechList, function($v) { return trim($v) !== ''; })));
        $finalMitigationOrgList = array_values(array_unique(array_filter($finalMitigationOrgList, function($v) { return trim($v) !== ''; })));

        $finalMitigationTechStr = implode('; ', $finalMitigationTechList);
        $finalMitigationOrgStr = implode('; ', $finalMitigationOrgList);
        // Combined string kept for backwards-compatible display in views/reports
        $finalMitigation = implode('; ', array_filter([$finalMitigationTechStr, $finalMitigationOrgStr], function($v) { return $v !== ''; }));
        
        // Afdeling - from dropdown, or freely typed custom department;
        // if left empty, inherit the department from the linked GDPR record
        $deptCustom = trim($_POST['department_custom'] ?? '');
        $deptSelected = trim($_POST['department'] ?? '');
        if ($deptCustom !== '') {
            $finalDepartment = $deptCustom;
        } elseif ($deptSelected !== '') {
            $finalDepartment = $deptSelected;
        } else {
            $linkedGdpr = $gdprId ? findRecord($gdprRecords, $gdprId) : null;
            $finalDepartment = $linkedGdpr ? ($linkedGdpr['record']['department'] ?? '') : '';
        }

        // Risico oorsprong - from dropdown, or freely typed custom value
        $riskOriginCustom = trim($_POST['risk_origin_custom'] ?? '');
        $finalRiskOrigin = $riskOriginCustom !== '' ? $riskOriginCustom : ($_POST['risk_origin'] ?? 'other');

        // Goedgekeurd door - from dropdown of previously used names, or a freshly typed one
        $approvedByCustom = trim($_POST['approved_by_custom'] ?? '');
        $finalApprovedBy = $approvedByCustom !== '' ? $approvedByCustom : ($_POST['approved_by'] ?? '');

        // Status - from dropdown, or freely typed custom value
        $statusCustom = trim($_POST['status_custom'] ?? '');
        $finalStatus = $statusCustom !== '' ? $statusCustom : ($_POST['status'] ?? 'draft');

        // Management goedkeuring - from dropdown, or freely typed custom value
        $managementApprovalCustom = trim($_POST['management_approval_custom'] ?? '');
        $finalManagementApproval = $managementApprovalCustom !== '' ? $managementApprovalCustom : ($_POST['management_approval'] ?? 'pending');

        // Consultatie uitgevoerd - from dropdown, or freely typed custom value
        $consultationCustom = trim($_POST['consultation_conducted_custom'] ?? '');
        $finalConsultation = $consultationCustom !== '' ? $consultationCustom : ($_POST['consultation_conducted'] ?? 'no');

        $recordData = [
            'id' => $currentId,
            'record_id' => $gdprId,
            'title' => $_POST['title'] ?? '',
            'description' => $_POST['description'] ?? '',
            'processing_activity_description' => $_POST['processing_activity_description'] ?? '',
            'department' => $finalDepartment,
            'risk_origin' => $finalRiskOrigin,
            'necessity_test' => $_POST['necessity_test'] ?? '',
            'proportionality_test' => $_POST['proportionality_test'] ?? '',
            'mitigation_measures' => $finalMitigation,
            'technical_measures' => $finalMitigationTechStr,
            'organizational_measures' => $finalMitigationOrgStr,
            'residual_risk' => $_POST['residual_risk'] ?? '',
            'overall_risk_level' => $_POST['overall_risk_level'] ?? 'medium',
            'status' => $finalStatus,
            'data_subjects_affected' => isset($_POST['data_subjects_affected']) && !empty($_POST['data_subjects_affected']) ? (int)$_POST['data_subjects_affected'] : null,
            'data_categories' => $_POST['data_categories'] ?? '',
            'consultation_conducted' => $finalConsultation,
            'consultation_details' => $_POST['consultation_details'] ?? '',
            'recommendations' => $_POST['recommendations'] ?? '',
            'management_approval' => $finalManagementApproval,
            'approved_by' => $finalApprovedBy,
            'approval_date' => $_POST['approval_date'] ?? '',
            'review_date' => $_POST['review_date'] ?? '',
            'notes' => $_POST['notes'] ?? '',
            'necessity' => $_POST['necessity'] ?? '',
            'proportionality' => $_POST['proportionality'] ?? '',
            'necessity_proportionality' => $_POST['necessity_proportionality'] ?? '',
            'risk_assessment_matrix' => $_POST['risk_assessment_matrix'] ?? '',
            'compliance_checklist' => $_POST['compliance_checklist'] ?? '',
        ];
        $now = date('Y-m-d H:i:s');
        if ($recordData['id'] === null) {
            $recordData['id'] = getNextIdDpia($dpiaRecords);
            $recordData['registered_at'] = $now;
            $recordData['registered_by'] = $defaultUserId;
            $dpiaRecords[] = $recordData;
            $message = 'DPIA #' . $recordData['id'] . ' ' . t('successfully_added') . '!';
            $messageType = 'success';
        } else {
            foreach ($dpiaRecords as $key => $rec) {
                if ($rec['id'] == $recordData['id']) {
                    $recordData['registered_at'] = isset($rec['registered_at']) ? $rec['registered_at'] : $now;
                    $recordData['registered_by'] = isset($rec['registered_by']) ? $rec['registered_by'] : $defaultUserId;
                    $recordData['updated_at'] = $now;
                    $dpiaRecords[$key] = $recordData;
                    break;
                }
            }
            $message = 'DPIA #' . $recordData['id'] . ' ' . t('successfully_updated') . '!';
            $messageType = 'success';
        }
        saveRecords($dpiaFile, $dpiaRecords);
        $dpiaRecords = loadRecords($dpiaFile);
        if (!empty($recordData['record_id'])) {
            foreach ($gdprRecords as $key => $rec) {
                if ($rec['id'] == $recordData['record_id']) {
                    $gdprRecords[$key]['dpia_status'] = $recordData['status'];
                    saveRecords($gdprFile, $gdprRecords);
                    $gdprRecords = loadRecords($gdprFile);
                    break;
                }
            }
        }
        header('Location: ?tab=dpia&lang=' . $lang);
        exit;
    }
    
    // --- DPIA DELETE ---
    if ($action === 'delete_dpia') {
        $id = (int)$_POST['id'];
        $deletedGdprId = null;
        foreach ($dpiaRecords as $key => $rec) if ($rec['id'] == $id) { $deletedGdprId = $rec['record_id'] ?? null; unset($dpiaRecords[$key]); break; }
        $dpiaRecords = array_values($dpiaRecords);
        saveRecords($dpiaFile, $dpiaRecords);
        $dpiaRecords = loadRecords($dpiaFile);

        // The GDPR record keeps a mirrored copy of the DPIA status (so it can
        // show/filter on it without a join). Deleting the DPIA without
        // resetting that copy left a stale "completed"/"approved" status
        // behind that still counted in the dashboard stats even though no
        // DPIA existed anymore - reset it back to "not started" here.
        if ($deletedGdprId) {
            foreach ($gdprRecords as $key => $rec) {
                if ($rec['id'] == $deletedGdprId) {
                    $gdprRecords[$key]['dpia_status'] = 'not_started';
                    break;
                }
            }
            saveRecords($gdprFile, $gdprRecords);
            $gdprRecords = loadRecords($gdprFile);
        }
        header('Location: ?tab=dpia&lang=' . $lang);
        exit;
    }
    
    // --- BREACH SAVE ---
    if ($action === 'save_breach') {
        // Genomen maatregelen - multi-select + custom
        $measuresTech = isset($_POST['breach_technical_measures']) && is_array($_POST['breach_technical_measures']) ? $_POST['breach_technical_measures'] : [];
        $measuresOrg = isset($_POST['breach_organizational_measures']) && is_array($_POST['breach_organizational_measures']) ? $_POST['breach_organizational_measures'] : [];
        $measuresCustom = $_POST['breach_measures_custom'] ?? '';

        $finalMeasuresList = array_merge($measuresTech, $measuresOrg, splitMeasureList($measuresCustom));
        $finalMeasures = implode('; ', array_values(array_unique(array_filter($finalMeasuresList, function($v) { return trim($v) !== ''; }))));
        
        // Afdeling - from dropdown, or freely typed custom department
        $deptCustom = trim($_POST['department_custom'] ?? '');
        $finalDepartment = $deptCustom !== '' ? $deptCustom : ($_POST['department'] ?? '');

        // Type lek - from dropdown, or freely typed custom value
        $breachTypeCustom = trim($_POST['breach_type_custom'] ?? '');
        $finalBreachType = $breachTypeCustom !== '' ? $breachTypeCustom : ($_POST['breach_type'] ?? 'confidentiality');

        $recordData = [
            'id' => isset($_POST['id']) && !empty($_POST['id']) ? (int)$_POST['id'] : null,
            'title' => $_POST['title'] ?? '',
            'description' => $_POST['description'] ?? '',
            'department' => $finalDepartment,
            'breach_date' => $_POST['breach_date'] ?? '',
            'discovery_date' => $_POST['discovery_date'] ?? '',
            'breach_type' => $finalBreachType,
            'personal_data_affected' => $_POST['personal_data_affected'] ?? '',
            'affected_data_subjects' => isset($_POST['affected_data_subjects']) && !empty($_POST['affected_data_subjects']) ? (int)$_POST['affected_data_subjects'] : null,
            'causes' => $_POST['causes'] ?? '',
            'measures_taken' => $finalMeasures,
            'notified_authority' => $_POST['notified_authority'] ?? 'no',
            'notification_date' => $_POST['notification_date'] ?? '',
            'notified_affected_persons' => $_POST['notified_affected_persons'] ?? 'no',
            'risk_level' => $_POST['risk_level'] ?? 'low',
            'status' => $_POST['status'] ?? 'open',
            'reported_by' => $defaultUserId,
            'assigned_to' => isset($_POST['assigned_to']) && !empty($_POST['assigned_to']) ? (int)$_POST['assigned_to'] : null,
        ];
        $now = date('Y-m-d H:i:s');
        if ($recordData['id'] === null) {
            $recordData['id'] = getNextIdBreach($breachRecords);
            $recordData['created_at'] = $now;
            $breachRecords[] = $recordData;
            $message = 'Data breach #' . $recordData['id'] . ' ' . t('successfully_added') . '!';
            $messageType = 'success';
        } else {
            foreach ($breachRecords as $key => $rec) {
                if ($rec['id'] == $recordData['id']) {
                    $recordData['created_at'] = isset($rec['created_at']) ? $rec['created_at'] : $now;
                    $recordData['updated_at'] = $now;
                    $breachRecords[$key] = $recordData;
                    break;
                }
            }
            $message = 'Data breach #' . $recordData['id'] . ' ' . t('successfully_updated') . '!';
            $messageType = 'success';
        }
        saveRecords($breachFile, $breachRecords);
        $breachRecords = loadRecords($breachFile);
        header('Location: ?tab=breach&lang=' . $lang);
        exit;
    }
    
    // --- BREACH DELETE ---
    if ($action === 'delete_breach') {
        $id = (int)$_POST['id'];
        foreach ($breachRecords as $key => $rec) if ($rec['id'] == $id) { unset($breachRecords[$key]); break; }
        $breachRecords = array_values($breachRecords);
        saveRecords($breachFile, $breachRecords);
        $breachRecords = loadRecords($breachFile);
        header('Location: ?tab=breach&lang=' . $lang);
        exit;
    }
    
    // --- THIRD PARTY SAVE ---
    if ($action === 'save_thirdparty') {
        // Encode third party fields with ROT47
        $thirdPartyFields = ['company_name', 'contact_person', 'email', 'phone', 'address'];
        $encodedData = [];
        foreach ($thirdPartyFields as $field) {
            $value = $_POST[$field] ?? '';
            $encodedData[$field] = !empty($value) ? rot47encode($value) : '';
        }
        
        // Afdeling - from dropdown, or freely typed custom department
        $deptCustom = trim($_POST['department_custom'] ?? '');
        $finalDepartment = $deptCustom !== '' ? $deptCustom : ($_POST['department'] ?? '');

        // Overeenkomst getekend - from dropdown, or freely typed custom value
        $agreementCustom = trim($_POST['processing_agreement_signed_custom'] ?? '');
        $finalAgreementSigned = $agreementCustom !== '' ? $agreementCustom : ($_POST['processing_agreement_signed'] ?? 'no');

        // Compliance status - from dropdown, or freely typed custom value
        $complianceCustom = trim($_POST['compliance_status_custom'] ?? '');
        $finalComplianceStatus = $complianceCustom !== '' ? $complianceCustom : ($_POST['compliance_status'] ?? 'review_needed');

        $recordData = [
            'id' => isset($_POST['id']) && !empty($_POST['id']) ? (int)$_POST['id'] : null,
            'company_name' => $encodedData['company_name'],
            'contact_person' => $encodedData['contact_person'],
            'email' => $encodedData['email'],
            'phone' => $encodedData['phone'],
            'address' => $encodedData['address'],
            'department' => $finalDepartment,
            'service_provided' => $_POST['service_provided'] ?? '',
            'processing_agreement_signed' => $finalAgreementSigned,
            'agreement_date' => $_POST['agreement_date'] ?? '',
            'agreement_expiry_date' => $_POST['agreement_expiry_date'] ?? '',
            'compliance_status' => $finalComplianceStatus,
        ];
        $now = date('Y-m-d H:i:s');
        if ($recordData['id'] === null) {
            $recordData['id'] = getNextIdThirdParty($thirdpartyRecords);
            $recordData['created_by'] = $defaultUserId;
            $recordData['created_at'] = $now;
            $thirdpartyRecords[] = $recordData;
            $message = 'Third party #' . $recordData['id'] . ' ' . t('successfully_added') . '!';
            $messageType = 'success';
        } else {
            foreach ($thirdpartyRecords as $key => $rec) {
                if ($rec['id'] == $recordData['id']) {
                    $recordData['created_by'] = isset($rec['created_by']) ? $rec['created_by'] : $defaultUserId;
                    $recordData['created_at'] = isset($rec['created_at']) ? $rec['created_at'] : $now;
                    $recordData['updated_at'] = $now;
                    $thirdpartyRecords[$key] = $recordData;
                    break;
                }
            }
            $message = 'Third party #' . $recordData['id'] . ' ' . t('successfully_updated') . '!';
            $messageType = 'success';
        }
        saveRecords($thirdpartyFile, $thirdpartyRecords);
        $thirdpartyRecords = loadRecords($thirdpartyFile);
        header('Location: ?tab=thirdparty&lang=' . $lang);
        exit;
    }
    
    // --- THIRD PARTY DELETE ---
    if ($action === 'delete_thirdparty') {
        $id = (int)$_POST['id'];
        foreach ($thirdpartyRecords as $key => $rec) if ($rec['id'] == $id) { unset($thirdpartyRecords[$key]); break; }
        $thirdpartyRecords = array_values($thirdpartyRecords);
        saveRecords($thirdpartyFile, $thirdpartyRecords);
        $thirdpartyRecords = loadRecords($thirdpartyFile);
        header('Location: ?tab=thirdparty&lang=' . $lang);
        exit;
    }

    // --- MEASURE RENAME (cascades across all records + config options) ---
    if ($action === 'rename_measure') {
        $measureType = $_POST['measure_type'] ?? '';
        $oldValue = trim($_POST['old_measure'] ?? '');
        $newValue = trim($_POST['new_measure'] ?? '');

        if ($oldValue !== '' && $newValue !== '' && in_array($measureType, ['technical', 'organizational'], true)) {
            if ($newValue !== $oldValue) {
                // Replace an exact token inside a semicolon-separated field, wherever it occurs
                $replaceMeasureToken = function($fieldValue) use ($oldValue, $newValue) {
                    $parts = splitMeasureList($fieldValue);
                    if (empty($parts)) return $fieldValue;
                    $changed = false;
                    foreach ($parts as $i => $part) {
                        if ($part === $oldValue) { $parts[$i] = $newValue; $changed = true; }
                    }
                    if (!$changed) return $fieldValue;
                    return implode('; ', array_values(array_unique($parts)));
                };

                // GDPR records
                foreach ($gdprRecords as $key => $rec) {
                    if (!empty($rec['technical_measures'])) $gdprRecords[$key]['technical_measures'] = $replaceMeasureToken($rec['technical_measures']);
                    if (!empty($rec['organizational_measures'])) $gdprRecords[$key]['organizational_measures'] = $replaceMeasureToken($rec['organizational_measures']);
                }
                saveRecords($gdprFile, $gdprRecords);
                $gdprRecords = loadRecords($gdprFile);

                // DPIA records (mitigation_measures combines technical + organizational items)
                foreach ($dpiaRecords as $key => $rec) {
                    if (!empty($rec['mitigation_measures'])) $dpiaRecords[$key]['mitigation_measures'] = $replaceMeasureToken($rec['mitigation_measures']);
                    if (!empty($rec['technical_measures'])) $dpiaRecords[$key]['technical_measures'] = $replaceMeasureToken($rec['technical_measures']);
                    if (!empty($rec['organizational_measures'])) $dpiaRecords[$key]['organizational_measures'] = $replaceMeasureToken($rec['organizational_measures']);
                }
                saveRecords($dpiaFile, $dpiaRecords);
                $dpiaRecords = loadRecords($dpiaFile);

                // Breach records (measures_taken combines technical + organizational items)
                foreach ($breachRecords as $key => $rec) {
                    if (!empty($rec['measures_taken'])) $breachRecords[$key]['measures_taken'] = $replaceMeasureToken($rec['measures_taken']);
                }
                saveRecords($breachFile, $breachRecords);
                $breachRecords = loadRecords($breachFile);
            }

            $message = t('measure_renamed_success');
            $messageType = 'success';
        }
        header('Location: ?tab=measures&lang=' . $lang);
        exit;
    }

    // --- MEASURE DELETE (removes the measure everywhere it's used) ---
    if ($action === 'delete_measure') {
        $measureType = $_POST['measure_type'] ?? '';
        $oldValue = trim($_POST['old_measure'] ?? '');

        if ($oldValue !== '' && in_array($measureType, ['technical', 'organizational'], true)) {
            $removeMeasureToken = function($fieldValue) use ($oldValue) {
                $parts = splitMeasureList($fieldValue);
                if (empty($parts)) return $fieldValue;
                $parts = array_values(array_filter($parts, function($p) use ($oldValue) { return $p !== $oldValue; }));
                return implode('; ', $parts);
            };

            foreach ($gdprRecords as $key => $rec) {
                if (!empty($rec['technical_measures'])) $gdprRecords[$key]['technical_measures'] = $removeMeasureToken($rec['technical_measures']);
                if (!empty($rec['organizational_measures'])) $gdprRecords[$key]['organizational_measures'] = $removeMeasureToken($rec['organizational_measures']);
            }
            saveRecords($gdprFile, $gdprRecords);
            $gdprRecords = loadRecords($gdprFile);

            foreach ($dpiaRecords as $key => $rec) {
                if (!empty($rec['mitigation_measures'])) $dpiaRecords[$key]['mitigation_measures'] = $removeMeasureToken($rec['mitigation_measures']);
                if (!empty($rec['technical_measures'])) $dpiaRecords[$key]['technical_measures'] = $removeMeasureToken($rec['technical_measures']);
                if (!empty($rec['organizational_measures'])) $dpiaRecords[$key]['organizational_measures'] = $removeMeasureToken($rec['organizational_measures']);
            }
            saveRecords($dpiaFile, $dpiaRecords);
            $dpiaRecords = loadRecords($dpiaFile);

            foreach ($breachRecords as $key => $rec) {
                if (!empty($rec['measures_taken'])) $breachRecords[$key]['measures_taken'] = $removeMeasureToken($rec['measures_taken']);
            }
            saveRecords($breachFile, $breachRecords);
            $breachRecords = loadRecords($breachFile);

            $message = t('measure_deleted_success');
            $messageType = 'success';
        }
        header('Location: ?tab=measures&lang=' . $lang);
        exit;
    }

    // --- DYNAMIC VALUE RENAME/DELETE (department, risk origin, DPIA status,
    //     management approval, consultation, approved-by, contact names) ---
    if ($action === 'rename_dynamic_value' || $action === 'delete_dynamic_value') {
        $fieldType = $_POST['field_type'] ?? '';
        $oldValue = trim($_POST['old_value'] ?? '');
        $isDelete = ($action === 'delete_dynamic_value');
        $newValue = $isDelete ? '' : trim($_POST['new_value'] ?? '');

        $validFieldTypes = [
            'department', 'risk_origin', 'dpia_status', 'management_approval',
            'consultation_conducted', 'approved_by',
            'name_data_controller', 'name_joint_data_controller', 'name_dpo', 'name_representative',
            'compliance_status', 'agreement_signed', 'breach_type',
        ];

        if ($oldValue !== '' && in_array($fieldType, $validFieldTypes, true) && ($isDelete || ($newValue !== '' && $newValue !== $oldValue))) {
            $touchedGdpr = false; $touchedDpia = false; $touchedBreach = false; $touchedThirdparty = false;

            // Rename/remove a value in a config array (e.g. risk_origin,
            // dpia_statuses) and persist config.php, if it was a config key.
            $updateConfigOption = function($configKey) use ($oldValue, $newValue, $isDelete, $config) {
                $cfg = getConfig($configKey, []);
                if (!isset($cfg[$oldValue])) return;
                $label = $cfg[$oldValue];
                unset($cfg[$oldValue]);
                if (!$isDelete) { $cfg[$newValue] = ($label === $oldValue) ? $newValue : $label; }
                $newConfig = $config;
                $newConfig[$configKey] = $cfg;
                saveConfigFile($newConfig);
            };

            switch ($fieldType) {
                case 'department':
                    foreach ($gdprRecords as $k => $r) { if (($r['department'] ?? '') === $oldValue) { $gdprRecords[$k]['department'] = $newValue; $touchedGdpr = true; } }
                    foreach ($dpiaRecords as $k => $r) { if (($r['department'] ?? '') === $oldValue) { $dpiaRecords[$k]['department'] = $newValue; $touchedDpia = true; } }
                    foreach ($breachRecords as $k => $r) { if (($r['department'] ?? '') === $oldValue) { $breachRecords[$k]['department'] = $newValue; $touchedBreach = true; } }
                    foreach ($thirdpartyRecords as $k => $r) { if (($r['department'] ?? '') === $oldValue) { $thirdpartyRecords[$k]['department'] = $newValue; $touchedThirdparty = true; } }
                    $deptList = getDepartments();
                    if (isset($deptList[$oldValue])) {
                        $deptLabel = $deptList[$oldValue];
                        unset($deptList[$oldValue]);
                        if (!$isDelete) { $deptList[$newValue] = ($deptLabel === $oldValue) ? $newValue : $deptLabel; }
                        saveDepartments($deptList);
                    }
                    break;

                case 'risk_origin':
                    foreach ($dpiaRecords as $k => $r) { if (($r['risk_origin'] ?? '') === $oldValue) { $dpiaRecords[$k]['risk_origin'] = $newValue; $touchedDpia = true; } }
                    $updateConfigOption('risk_origin');
                    break;

                case 'dpia_status':
                    foreach ($dpiaRecords as $k => $r) { if (($r['status'] ?? '') === $oldValue) { $dpiaRecords[$k]['status'] = $newValue; $touchedDpia = true; } }
                    $updateConfigOption('dpia_statuses');
                    break;

                case 'management_approval':
                    foreach ($dpiaRecords as $k => $r) { if (($r['management_approval'] ?? '') === $oldValue) { $dpiaRecords[$k]['management_approval'] = $newValue; $touchedDpia = true; } }
                    $updateConfigOption('management_approval_options');
                    break;

                case 'consultation_conducted':
                    foreach ($dpiaRecords as $k => $r) { if (($r['consultation_conducted'] ?? '') === $oldValue) { $dpiaRecords[$k]['consultation_conducted'] = $newValue; $touchedDpia = true; } }
                    $updateConfigOption('consultation_options');
                    break;

                case 'approved_by':
                    foreach ($dpiaRecords as $k => $r) { if (($r['approved_by'] ?? '') === $oldValue) { $dpiaRecords[$k]['approved_by'] = $newValue; $touchedDpia = true; } }
                    break;

                case 'compliance_status':
                    foreach ($thirdpartyRecords as $k => $r) { if (($r['compliance_status'] ?? '') === $oldValue) { $thirdpartyRecords[$k]['compliance_status'] = $newValue; $touchedThirdparty = true; } }
                    $updateConfigOption('compliance_statuses');
                    break;

                case 'agreement_signed':
                    // Note: intentionally NOT touching the 'yes_no_progress_options'
                    // config array here — it's shared with the breach form's
                    // notified_authority/notified_affected_persons fields, and
                    // renaming/deleting a value here should only affect third-party
                    // records, not those unrelated fields.
                    foreach ($thirdpartyRecords as $k => $r) { if (($r['processing_agreement_signed'] ?? '') === $oldValue) { $thirdpartyRecords[$k]['processing_agreement_signed'] = $newValue; $touchedThirdparty = true; } }
                    break;

                case 'breach_type':
                    foreach ($breachRecords as $k => $r) { if (($r['breach_type'] ?? '') === $oldValue) { $breachRecords[$k]['breach_type'] = $newValue; $touchedBreach = true; } }
                    $updateConfigOption('breach_types');
                    break;

                case 'name_data_controller':
                case 'name_joint_data_controller':
                case 'name_dpo':
                case 'name_representative':
                    foreach ($gdprRecords as $k => $r) {
                        if (!empty($r[$fieldType]) && trim(rot47decode($r[$fieldType])) === $oldValue) {
                            $gdprRecords[$k][$fieldType] = $newValue !== '' ? rot47encode($newValue) : '';
                            $touchedGdpr = true;
                        }
                    }
                    break;
            }

            if ($touchedGdpr) { saveRecords($gdprFile, $gdprRecords); $gdprRecords = loadRecords($gdprFile); }
            if ($touchedDpia) { saveRecords($dpiaFile, $dpiaRecords); $dpiaRecords = loadRecords($dpiaFile); }
            if ($touchedBreach) { saveRecords($breachFile, $breachRecords); $breachRecords = loadRecords($breachFile); }
            if ($touchedThirdparty) { saveRecords($thirdpartyFile, $thirdpartyRecords); $thirdpartyRecords = loadRecords($thirdpartyFile); }

            $message = $isDelete ? t('value_deleted_success') : t('value_renamed_success');
            $messageType = 'success';
        }
        header('Location: ?tab=measures&lang=' . $lang);
        exit;
    }
}

// --- Handle ZIP Backup Download (password protected) ---
if (isset($_GET['action']) && $_GET['action'] === 'zipbackup') {
    // A password is required and must be supplied via POST (never via the URL/GET).
    $zipPassword = isset($_POST['zip_password']) ? (string)$_POST['zip_password'] : '';
    $zipPasswordConfirm = isset($_POST['zip_password_confirm']) ? (string)$_POST['zip_password_confirm'] : '';

    if ($zipPassword === '' || strlen($zipPassword) < 6 || $zipPassword !== $zipPasswordConfirm) {
        header('Location: ?tab=report&lang=' . $lang . '&zipbackup_error=1');
        exit;
    }

    // Only the four data register files are included in the backup.
    $backupFiles = [$gdprFile, $dpiaFile, $breachFile, $thirdpartyFile];
    $zipName = 'avg_backup_' . date('Y-m-d_H-i-s') . '.zip';

    if (class_exists('ZipArchive') && method_exists('ZipArchive', 'setEncryptionName')) {
        $zip = new ZipArchive();
        if ($zip->open($zipName, ZipArchive::CREATE) === TRUE) {
            foreach ($backupFiles as $file) {
                if (is_file($file)) {
                    $zip->addFile($file, basename($file));
                }
            }
            // Protect the archive with the supplied password using AES-256 encryption.
            $zip->setPassword($zipPassword);
            foreach ($backupFiles as $file) {
                if (is_file($file)) {
                    $zip->setEncryptionName(basename($file), ZipArchive::EM_AES_256);
                }
            }
            $zip->close();
            if (file_exists($zipName)) {
                header('Content-Type: application/zip');
                header('Content-Disposition: attachment; filename="' . $zipName . '"');
                header('Content-Length: ' . filesize($zipName));
                readfile($zipName);
                unlink($zipName);
                exit;
            }
        }
    }

    // Fallback if ZipArchive / AES encryption is not available on this server:
    // deny the download rather than sending an unencrypted archive.
    header('Location: ?tab=report&lang=' . $lang . '&zipbackup_error=nozip');
    exit;
}

// --- Handle JSON Backup Download ---
if (isset($_GET['action']) && $_GET['action'] === 'backup') {
    $backup = [
        'company_name' => getCompanyName(),
        'backup_date' => date('Y-m-d H:i:s'),
        'app_version' => getConfig('app_version', '2.0'),
        'gdpr_register' => $gdprRecords,
        'dpia_registrations' => $dpiaRecords,
        'data_breaches' => $breachRecords,
        'third_parties' => $thirdpartyRecords,
        'config' => $config
    ];
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="avg_backup_' . date('Y-m-d') . '.json"');
    echo json_encode($backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// --- Get record for editing ---
$editRecord = null;
$editDpia = null;
$editBreach = null;
$editThirdparty = null;

if (isset($_GET['edit_gdpr']) && !empty($_GET['edit_gdpr'])) {
    $found = findRecord($gdprRecords, (int)$_GET['edit_gdpr']);
    if ($found) $editRecord = $found['record'];
}
if (isset($_GET['edit_dpia']) && !empty($_GET['edit_dpia'])) {
    $found = findRecord($dpiaRecords, (int)$_GET['edit_dpia']);
    if ($found) $editDpia = $found['record'];
}
if (isset($_GET['edit_breach']) && !empty($_GET['edit_breach'])) {
    $found = findRecord($breachRecords, (int)$_GET['edit_breach']);
    if ($found) $editBreach = $found['record'];
}
if (isset($_GET['edit_thirdparty']) && !empty($_GET['edit_thirdparty'])) {
    $found = findRecord($thirdpartyRecords, (int)$_GET['edit_thirdparty']);
    if ($found) $editThirdparty = $found['record'];
}

// --- Get record for viewing ---
$viewRecord = null;
$viewDpia = null;
$viewBreach = null;
$viewThirdparty = null;

if (isset($_GET['view_gdpr']) && !empty($_GET['view_gdpr'])) {
    $found = findRecord($gdprRecords, (int)$_GET['view_gdpr']);
    if ($found) $viewRecord = $found['record'];
}
if (isset($_GET['view_dpia']) && !empty($_GET['view_dpia'])) {
    $found = findRecord($dpiaRecords, (int)$_GET['view_dpia']);
    if ($found) $viewDpia = $found['record'];
}
if (isset($_GET['view_breach']) && !empty($_GET['view_breach'])) {
    $found = findRecord($breachRecords, (int)$_GET['view_breach']);
    if ($found) $viewBreach = $found['record'];
}
if (isset($_GET['view_thirdparty']) && !empty($_GET['view_thirdparty'])) {
    $found = findRecord($thirdpartyRecords, (int)$_GET['view_thirdparty']);
    if ($found) $viewThirdparty = $found['record'];
}

// --- Handle DPIA creation from GDPR list ---
$prefillGdprId = isset($_GET['create_dpia_for']) ? (int)$_GET['create_dpia_for'] : null;
$prefillRecord = null;
$prefillTitle = '';
$dpiaExistsForGdpr = false;
$existingDpiaId = null;

if ($prefillGdprId) {
    $found = findRecord($gdprRecords, $prefillGdprId);
    if ($found) {
        $prefillRecord = $found['record'];
        $prefillTitle = 'DPIA: ' . ($prefillRecord['processing_activity'] ?? 'Onbekende activiteit');
        
        // Controleer of er al een DPIA bestaat voor dit GDPR record
        $existingDpia = findDpiaByGdprId($dpiaRecords, $prefillGdprId);
        if ($existingDpia) {
            $dpiaExistsForGdpr = true;
            $existingDpiaId = $existingDpia['record']['id'];
        } else {
            $editDpia = null;
            $_GET['new_dpia'] = 1;
        }
    }
}

// --- Foutmelding van DPIA duplicate ---
if (isset($_GET['error']) && !empty($_GET['error'])) {
    $message = htmlspecialchars($_GET['error']);
    $messageType = 'danger';
}

// --- Search & Filter ---
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filterRisk = isset($_GET['filter_risk']) ? $_GET['filter_risk'] : '';
$filterStatus = isset($_GET['filter_status']) ? $_GET['filter_status'] : '';
$filterDpiaRequired = isset($_GET['filter_dpia_required']) ? $_GET['filter_dpia_required'] : '';
$filterDpiaStatus = isset($_GET['filter_dpia_status']) ? $_GET['filter_dpia_status'] : '';
$filterBreachType = isset($_GET['filter_breach_type']) ? $_GET['filter_breach_type'] : '';
$filterBreachStatus = isset($_GET['filter_breach_status']) ? $_GET['filter_breach_status'] : '';
$filterComplianceStatus = isset($_GET['filter_compliance_status']) ? $_GET['filter_compliance_status'] : '';

// --- GDPR Filtering ---
$displayRecords = $gdprRecords;
if ($search && $activeTab === 'gdpr') {
    $displayRecords = array_filter($displayRecords, function($r) use ($search) {
        $search = strtolower($search);
        return strpos(strtolower($r['processing_activity'] ?? ''), $search) !== false ||
               strpos(strtolower($r['purpose_of_processing'] ?? ''), $search) !== false ||
               strpos(strtolower($r['categories_data_subjects'] ?? ''), $search) !== false;
    });
}
if ($filterRisk && $activeTab === 'gdpr') $displayRecords = array_filter($displayRecords, function($r) use ($filterRisk) { return ($r['risk_level'] ?? '') === $filterRisk; });
if ($filterStatus && $activeTab === 'gdpr') $displayRecords = array_filter($displayRecords, function($r) use ($filterStatus) { return ($r['status'] ?? '') === $filterStatus; });
if ($filterDpiaRequired && $activeTab === 'gdpr') $displayRecords = array_filter($displayRecords, function($r) use ($filterDpiaRequired) { return ($r['dpia_required'] ?? 'no') === $filterDpiaRequired; });

// --- DPIA Filtering ---
$displayDpia = $dpiaRecords;
if ($search && $activeTab === 'dpia') {
    $displayDpia = array_filter($displayDpia, function($r) use ($search) {
        $search = strtolower($search);
        return strpos(strtolower($r['title'] ?? ''), $search) !== false ||
               strpos(strtolower($r['description'] ?? ''), $search) !== false ||
               strpos(strtolower($r['processing_activity_description'] ?? ''), $search) !== false;
    });
}
if ($filterDpiaStatus && $activeTab === 'dpia') $displayDpia = array_filter($displayDpia, function($r) use ($filterDpiaStatus) { return ($r['status'] ?? '') === $filterDpiaStatus; });

// --- Breach Filtering ---
$displayBreach = $breachRecords;
if ($search && $activeTab === 'breach') {
    $displayBreach = array_filter($displayBreach, function($r) use ($search) {
        $search = strtolower($search);
        return strpos(strtolower($r['title'] ?? ''), $search) !== false ||
               strpos(strtolower($r['description'] ?? ''), $search) !== false;
    });
}
if ($filterBreachType && $activeTab === 'breach') $displayBreach = array_filter($displayBreach, function($r) use ($filterBreachType) { return ($r['breach_type'] ?? '') === $filterBreachType; });
if ($filterBreachStatus && $activeTab === 'breach') $displayBreach = array_filter($displayBreach, function($r) use ($filterBreachStatus) { return ($r['status'] ?? '') === $filterBreachStatus; });

// --- Third Party Filtering ---
$displayThirdparty = $thirdpartyRecords;
if ($search && $activeTab === 'thirdparty') {
    $displayThirdparty = array_filter($displayThirdparty, function($r) use ($search) {
        $search = strtolower($search);
        $companyName = !empty($r['company_name']) ? rot47decode($r['company_name']) : '';
        $contactPerson = !empty($r['contact_person']) ? rot47decode($r['contact_person']) : '';
        return strpos(strtolower($companyName), $search) !== false ||
               strpos(strtolower($r['service_provided'] ?? ''), $search) !== false ||
               strpos(strtolower($contactPerson), $search) !== false;
    });
}
if ($filterComplianceStatus && $activeTab === 'thirdparty') $displayThirdparty = array_filter($displayThirdparty, function($r) use ($filterComplianceStatus) { return ($r['compliance_status'] ?? '') === $filterComplianceStatus; });

// --- Statistics ---
$totalGdpr = count($gdprRecords);
$activeGdpr = count(array_filter($gdprRecords, function($r) { return ($r['status'] ?? '') === 'active'; }));
$highRiskGdpr = count(array_filter($gdprRecords, function($r) { return ($r['risk_level'] ?? '') === 'high'; }));
$dpiaRequiredCount = count(array_filter($gdprRecords, function($r) { return ($r['dpia_required'] ?? 'no') === 'yes'; }));
$dpiaCompletedCount = count(array_filter($gdprRecords, function($r) { return ($r['dpia_status'] ?? '') === 'completed' || ($r['dpia_status'] ?? '') === 'approved'; }));

$totalDpia = count($dpiaRecords);
$inProgressDpia = count(array_filter($dpiaRecords, function($r) { return ($r['status'] ?? '') === 'in_progress'; }));
$completedDpia = count(array_filter($dpiaRecords, function($r) { return ($r['status'] ?? '') === 'completed' || ($r['status'] ?? '') === 'approved'; }));
$highRiskDpia = count(array_filter($dpiaRecords, function($r) { return ($r['overall_risk_level'] ?? '') === 'high'; }));

$totalBreach = count($breachRecords);
$openBreach = count(array_filter($breachRecords, function($r) { return ($r['status'] ?? '') === 'open'; }));
$highRiskBreach = count(array_filter($breachRecords, function($r) { return ($r['risk_level'] ?? '') === 'high'; }));

$totalThirdparty = count($thirdpartyRecords);
$compliantThirdparty = count(array_filter($thirdpartyRecords, function($r) { return ($r['compliance_status'] ?? '') === 'compliant'; }));
$reviewNeededThirdparty = count(array_filter($thirdpartyRecords, function($r) { return ($r['compliance_status'] ?? '') === 'review_needed'; }));

// --- Collect all measures ---
$allTechnicalMeasures = getAllTechnicalMeasures($gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords);
$allOrganizationalMeasures = getAllOrganizationalMeasures($gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords);

// Get config values for display
$riskLevels = getConfig('risk_levels', []);
$gdprStatuses = getConfig('gdpr_statuses', []);
// $dpiaStatuses is already loaded earlier (dpia_statuses config + any
// custom values already used in DPIA records).
$breachStatuses = getConfig('breach_statuses', []);
// $breachTypes is already loaded earlier (breach_types config + any custom
// values already used in data_breaches.json).
// $complianceStatuses is already loaded earlier (compliance_statuses config
// + any custom values already used in third-party records).
$legalBasisOptions = getConfig('legal_basis', []);
// $departmentsList is already loaded earlier (departments.json + any
// custom department values already in use).
// $riskOriginOptions is already loaded earlier (risk_origin config + any
// custom values already used in DPIA records).
// $consultationOptions and $managementApprovalOptions are already loaded
// earlier (their config options + any custom values already used in DPIA
// records).
// $agreementSignedOptions is already loaded earlier (yes_no_progress_options
// config + any custom values already used in third-party records).
$yesNoOptions = getConfig('yes_no_options', []);
$yesNoProgressOptions = getConfig('yes_no_progress_options', []);
$internationalTransferOptions = getConfig('international_transfer_options', []);
$safeguardsOptions = getConfig('safeguards_options', []);
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($appTitle) ?> - <?= htmlspecialchars($companyName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ============================================================
           MAIN STYLES
           ============================================================ */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Courier New', Courier, monospace;
            background: #f0f0f0;
            color: #1a1a1a;
            padding: 20px;
        }
        .app-container {
            max-width: 1600px;
            margin: 0 auto;
            background: #ffffff;
            padding: 30px 25px;
            border: 1px solid #cccccc;
            box-shadow: 6px 6px 0 rgba(0,0,0,0.08);
        }
        .header {
            border-bottom: 3px double #222;
            padding-bottom: 15px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        .header h1 {
            font-size: 30px;
            font-weight: 700;
            letter-spacing: -0.5px;
            text-transform: uppercase;
            color: #000;
        }
        .header h1 small { font-size: 16px; font-weight: 300; color: #555; text-transform: none; }
        .header .version { font-size: 12px; color: #888; margin-left: 10px; }
        .header .sub {
            font-size: 14px;
            color: #444;
            background: #eee;
            padding: 4px 14px;
            border: 1px solid #aaa;
            font-weight: 300;
        }
        .bank-stripe {
            background: #222;
            color: #fff;
            padding: 8px 18px;
            font-size: 13px;
            letter-spacing: 1px;
            margin-bottom: 25px;
            border: 1px solid #000;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        .bank-stripe span { opacity: 0.9; }
        .tabs {
            display: flex;
            gap: 4px;
            margin-bottom: 25px;
            background: #ffffff;
            padding: 4px;
            border: 1px solid #ccc;
            flex-wrap: wrap;
        }
        .tabs .tab {
            padding: 12px 28px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            color: #555;
            transition: all 0.2s;
            background: #f5f5f5;
            border: 1px solid #ddd;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            font-family: inherit;
        }
        .tabs .tab:hover { background: #e0e0e0; color: #000; }
        .tabs .tab.active { background: #222; color: #fff; border-color: #000; }
        .tabs .tab .badge-count {
            background: rgba(255,255,255,0.2);
            padding: 2px 10px;
            font-size: 11px;
            border-radius: 0;
        }
        .tabs .tab.active .badge-count { background: rgba(255,255,255,0.2); }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
            gap: 12px;
            margin-bottom: 30px;
        }
        .stat-box {
            background: #f8f8f8;
            border: 1px solid #ccc;
            padding: 10px 12px;
            text-align: center;
        }
        .stat-box .number { font-size: 24px; font-weight: 700; color: #000; }
        .stat-box .label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; color: #555; }
        .stat-box .sub-label { font-size: 9px; color: #888; margin-top: 2px; }
        .stat-box.highlight { border-left: 4px solid #222; }
        .stat-box.risk-high .number { color: #a00; }
        .stat-box.risk-high { border-left-color: #a00; }
        
        .toolbar {
            background: #fafafa;
            border: 1px solid #d0d0d0;
            padding: 14px 18px;
            margin-bottom: 18px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }
        .toolbar .search-box {
            flex: 1;
            min-width: 180px;
            display: flex;
            align-items: center;
            background: #fff;
            border: 1px solid #bbb;
            padding: 0 10px;
        }
        .toolbar .search-box i { color: #888; font-size: 14px; }
        .toolbar .search-box input {
            border: none;
            padding: 8px 10px;
            font-size: 13px;
            background: transparent;
            width: 100%;
            outline: none;
            font-family: inherit;
        }
        .toolbar select {
            padding: 8px 12px;
            border: 1px solid #bbb;
            background: #fff;
            font-size: 13px;
            font-family: inherit;
            color: #1a1a1a;
            outline: none;
            cursor: pointer;
            min-width: 120px;
        }
        .toolbar .btn-clear {
            background: #eee;
            border: 1px solid #aaa;
            padding: 8px 14px;
            font-size: 13px;
            cursor: pointer;
            color: #333;
            transition: all 0.2s;
            font-weight: 500;
            font-family: inherit;
        }
        .toolbar .btn-clear:hover { background: #ddd; }
        .toolbar .btn {
            padding: 8px 16px;
            border: 1px solid #222;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #fff;
            color: #222;
        }
        .toolbar .btn:hover { background: #222; color: #fff; }
        .toolbar .btn-primary { background: #222; color: #fff; }
        .toolbar .btn-primary:hover { background: #555; }
        
        .btn-add {
            background: #222;
            color: #fff;
            padding: 8px 16px;
            border: 1px solid #222;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-add:hover { background: #555; }
        
        .btn-export {
            background: #eee;
            color: #222;
            padding: 8px 16px;
            border: 1px solid #888;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-export:hover { background: #ddd; border-color: #222; }
        
        .btn-dpia-create {
            background: #fff;
            color: #222;
            border: 1px solid #222;
            padding: 3px 8px;
            font-size: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        .btn-dpia-create:hover { background: #222; color: #fff; }
        .btn-dpia-create .fa-plus-circle { font-size: 11px; }
        .btn-dpia-create.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            background: #eee;
            color: #888;
            border-color: #aaa;
        }
        .btn-dpia-create.disabled:hover {
            background: #eee;
            color: #888;
        }
        
        .btn-backup {
            background: #222;
            color: #fff;
            padding: 8px 16px;
            border: 1px solid #222;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-backup:hover { background: #555; }
        .btn-backup i { color: #fff; }

        /* ZIP backup password modal */
        .pwmodal-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.6);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1100;
            padding: 20px;
        }
        .pwmodal-overlay.open { display: flex; }
        .pwmodal-content {
            background: #ffffff;
            border: 1px solid #222;
            max-width: 420px;
            width: 100%;
            padding: 0;
        }
        .pwmodal-header {
            padding: 16px 20px;
            border-bottom: 1px solid #222;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .pwmodal-header h3 { margin: 0; font-size: 15px; }
        .pwmodal-body { padding: 20px; }
        .pwmodal-body .form-group { margin-bottom: 14px; }
        .pwmodal-body label { display: block; margin-bottom: 6px; font-size: 13px; font-weight: 600; }
        .pwmodal-body input[type="password"],
        .pwmodal-body input[type="text"],
        .pwmodal-body textarea {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #999;
            font-family: inherit;
            font-size: 13px;
            box-sizing: border-box;
        }
        .pwmodal-body textarea { resize: vertical; min-height: 36px; }
        .pwmodal-hint { font-size: 12px; color: #666; margin-top: -8px; margin-bottom: 14px; }
        .pwmodal-error { font-size: 12px; color: #b00020; margin-bottom: 12px; }
        .pwmodal-footer {
            padding: 14px 20px;
            border-top: 1px solid #222;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .pwmodal-footer button { font-family: inherit; }

        .table-container {
            border: 1px solid #d0d0d0;
            margin-bottom: 25px;
            background: #fff;
        }
        .table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; background: #fff; }
        thead { background: #222; color: #fff; }
        thead th {
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 8px 10px;
            text-align: left;
            border: 1px solid #111;
            font-size: 11px;
        }
        tbody tr { border-bottom: 1px solid #ddd; }
        tbody tr:nth-child(even) { background: #f9f9f9; }
        tbody tr:hover { background: #f0f0f0; }
        tbody td { padding: 7px 10px; border: 1px solid #ccc; vertical-align: middle; }
        
        .badge {
            display: inline-block;
            padding: 2px 8px;
            font-size: 10px;
            font-weight: 600;
            background: #eee;
            border: 1px solid #888;
            color: #000;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .badge-high { background: #222; color: #fff; border-color: #000; }
        .badge-medium { background: #888; color: #fff; border-color: #666; }
        .badge-low { background: #ddd; color: #222; border-color: #aaa; }
        .badge-active { border-left: 4px solid #222; }
        .badge-inactive { border-left: 4px solid #aaa; opacity: 0.7; }
        .badge-draft { border-left: 4px solid #888; opacity: 0.8; }
        .badge-progress { border-left: 4px solid #666; }
        .badge-required { background: #222; color: #fff; border-color: #000; }
        .badge-not-required { background: #ddd; color: #555; border-color: #aaa; }
        .badge-exists { background: #888; color: #fff; border-color: #666; }
        
        .btn-group { display: flex; gap: 3px; flex-wrap: wrap; justify-content: center; }
        .btn-icon {
            width: 30px;
            height: 30px;
            border: 1px solid #aaa;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            background: #fff;
            color: #333;
        }
        .btn-icon:hover { background: #222; color: #fff; }
        .btn-icon.view { color: #333; }
        .btn-icon.view:hover { background: #222; color: #fff; }
        .btn-icon.edit { color: #333; }
        .btn-icon.edit:hover { background: #222; color: #fff; }
        .btn-icon.delete { color: #a00; border-color: #a00; }
        .btn-icon.delete:hover { background: #a00; color: #fff; }
        .btn-icon.print-record { color: #333; }
        .btn-icon.print-record:hover { background: #222; color: #fff; }
        
        /* ============================================================
           MODAL STYLES - CLICK OUTSIDE TO CLOSE
           ============================================================ */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.6);
            display: <?= ($viewRecord || $editRecord || $viewDpia || $editDpia || $viewBreach || $editBreach || $viewThirdparty || $editThirdparty || isset($_GET['new_gdpr']) || isset($_GET['new_dpia']) || isset($_GET['new_breach']) || isset($_GET['new_thirdparty']) || ($prefillGdprId && !$dpiaExistsForGdpr)) ? 'flex' : 'none' ?>;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            padding: 20px;
            cursor: pointer; /* Indicates clickable area outside modal */
        }
        .modal-content {
            background: #ffffff;
            border: 1px solid #222;
            max-width: 950px;
            width: 100%;
            max-height: 92vh;
            overflow-y: auto;
            box-shadow: 10px 10px 0 rgba(0,0,0,0.1);
            animation: slideIn 0.3s ease;
            cursor: default; /* Reset cursor for content area */
            position: relative;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .modal-header {
            padding: 16px 22px;
            border-bottom: 2px solid #222;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8f8f8;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        .modal-header h3 { font-size: 17px; color: #000; font-family: inherit; }
        .modal-header .close-btn {
            background: none;
            border: none;
            font-size: 22px;
            color: #555;
            cursor: pointer;
            padding: 0 6px;
            transition: color 0.2s;
            font-family: inherit;
            text-decoration: none;
        }
        .modal-header .close-btn:hover { color: #a00; }
        .modal-body { padding: 20px 24px; }
        .modal-footer {
            padding: 14px 22px;
            border-top: 1px solid #ddd;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            background: #f8f8f8;
            position: sticky;
            bottom: 0;
            z-index: 10;
        }
        
        .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 25px; }
        .detail-item { padding: 6px 0; border-bottom: 1px solid #eee; }
        .detail-item.full-width { grid-column: 1 / -1; }
        .detail-item .label {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #666;
            font-weight: 600;
            display: block;
        }
        .detail-item .value { font-size: 13px; color: #1a1a1a; margin-top: 3px; word-break: break-word; }
        
        .form-group { margin-bottom: 12px; }
        .form-group label {
            display: block;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            color: #333;
            margin-bottom: 3px;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            font-family: inherit;
            font-size: 13px;
            padding: 6px 8px;
            border: 1px solid #bbb;
            background: #fff;
            color: #1a1a1a;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: 2px solid #222;
        }
        .form-group select[multiple] {
            height: 150px;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 50px;
            transition: height 0.2s ease;
        }
        .form-group textarea:focus {
            min-height: 80px;
        }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .form-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
        
        .status-dot {
            display: inline-block;
            width: 7px;
            height: 7px;
            border-radius: 50%;
            margin-right: 3px;
            border: 1px solid #666;
        }
        .status-dot.active { background: #222; }
        .status-dot.inactive { background: #aaa; }
        .status-dot.draft { background: #888; }
        .status-dot.in_progress { background: #666; }
        .status-dot.completed { background: #222; }
        .status-dot.approved { background: #222; }
        .status-dot.open { background: #a00; }
        .status-dot.investigating { background: #666; }
        .status-dot.contained { background: #888; }
        .status-dot.resolved { background: #222; }
        .status-dot.closed { background: #aaa; }
        .status-dot.compliant { background: #222; }
        .status-dot.non_compliant { background: #a00; }
        .status-dot.review_needed { background: #888; }
        
        .empty-state {
            padding: 25px;
            background: #fafafa;
            border: 1px dashed #aaa;
            color: #666;
            text-align: center;
            font-style: italic;
        }
        .empty-state i { font-size: 28px; display: block; margin-bottom: 8px; }
        
        .footer {
            margin-top: 35px;
            padding-top: 18px;
            border-top: 2px solid #ddd;
            font-size: 12px;
            color: #444;
            text-align: center;
            letter-spacing: 0.3px;
        }
        
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .btn {
            padding: 8px 20px;
            border: 1px solid #222;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #fff;
            color: #222;
        }
        .btn:hover { background: #222; color: #fff; }
        .btn-success { background: #222; color: #fff; border-color: #000; }
        .btn-success:hover { background: #555; }
        .btn-secondary { border-color: #888; color: #555; }
        .btn-secondary:hover { background: #888; color: #fff; }
        .btn-warning { border-color: #a60; color: #a60; }
        .btn-warning:hover { background: #a60; color: #fff; }
        
        .pagination {
            padding: 10px 14px;
            border-top: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            font-size: 12px;
            color: #555;
        }
        
        .message {
            padding: 10px 16px;
            border: 1px solid #aaa;
            margin-bottom: 18px;
            font-weight: 500;
        }
        .message.success { background: #e8f0e8; border-color: #2a5a2a; color: #1a3a1a; }
        .message.danger { background: #f0e8e8; border-color: #8a2a2a; color: #5a1a1a; }
        .message.info { background: #e8ecf0; border-color: #2a4a6a; color: #1a2a4a; }
        
        .prefill-notice {
            background: #f0f0f0;
            border: 1px solid #aaa;
            padding: 8px 14px;
            margin: 10px 22px 0 22px;
            font-size: 12px;
            border-left: 4px solid #222;
        }
        .prefill-notice strong { color: #000; }
        
        .section-title {
            font-size: 18px;
            font-weight: 700;
            margin: 30px 0 12px 0;
            padding-bottom: 5px;
            border-bottom: 2px solid #222;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .section-title small {
            font-weight: 300;
            font-size: 13px;
            color: #555;
            margin-left: 10px;
        }
        
        .dpia-clickable {
            cursor: pointer;
            text-decoration: underline;
            color: #222;
        }
        .dpia-clickable:hover {
            color: #666;
        }
        
        /* Rapportage stijlen */
        .report-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .report-card {
            border: 1px solid #ccc;
            padding: 20px;
            background: #fafafa;
        }
        .report-card h4 {
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 15px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 8px;
        }
        .progress-bar-container {
            width: 100%;
            background: #eee;
            height: 20px;
            border: 1px solid #aaa;
            margin: 4px 0;
            position: relative;
        }
        .progress-bar-fill {
            height: 100%;
            background: #222;
            transition: width 0.5s ease;
        }
        .progress-label {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            margin-top: 2px;
        }
        
        .stat-row {
            display: flex;
            justify-content: space-between;
            padding: 4px 0;
            border-bottom: 1px solid #eee;
            font-size: 13px;
        }
        .stat-row .stat-value {
            font-weight: 700;
        }
        
        .report-chart {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        
        .print-btn {
            background: #222;
            color: #fff;
            padding: 8px 20px;
            border: 1px solid #222;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .print-btn:hover { background: #555; }
        .print-btn i { color: #fff; }
        
        .language-selector {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #f5f5f5;
            padding: 4px 12px;
            border: 1px solid #ddd;
        }
        .language-selector select {
            padding: 4px 8px;
            border: 1px solid #aaa;
            background: #fff;
            font-size: 13px;
            font-family: inherit;
            cursor: pointer;
            outline: none;
        }
        .language-selector label {
            font-size: 12px;
            font-weight: 600;
            color: #555;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        @media (max-width: 768px) {
            .app-container { padding: 15px; }
            .header h1 { font-size: 20px; }
            .header { flex-direction: column; align-items: flex-start; gap: 8px; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .toolbar { flex-direction: column; }
            .toolbar .search-box { width: 100%; }
            .detail-grid { grid-template-columns: 1fr; }
            .form-row, .form-row-3 { grid-template-columns: 1fr; }
            .modal-content { max-width: 100%; margin: 10px; max-height: 95vh; }
            table { font-size: 11px; }
            thead th, tbody td { padding: 4px 6px; }
            .tabs { flex-wrap: wrap; }
            .tabs .tab { flex: 1; justify-content: center; padding: 8px 12px; font-size: 12px; min-width: 60px; }
            .bank-stripe { font-size: 11px; flex-direction: column; gap: 4px; }
            .report-grid { grid-template-columns: 1fr; }
            .language-selector { width: 100%; justify-content: center; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr; }
            body { padding: 10px; }
            .app-container { padding: 10px; }
        }
    </style>
</head>
<body>

<div class="app-container">

    <!-- ============================================================
         HEADER
         ============================================================ -->
    <div class="header">
        <div>
            <h1><img src="logo.png" width="6%" heigth="6%"> <?= htmlspecialchars($appTitle) ?> <small><?= htmlspecialchars($companyName) ?></small>
            <span class="version">v<?= htmlspecialchars($appVersion) ?></span></h1>
            <div style="font-size: 14px; color: #333; margin-top: 4px;"><?= htmlspecialchars($companySubtitle) ?></div>
        </div>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <div class="language-selector">
                <label><i class="fas fa-globe"></i> <?= t('language') ?>:</label>
                <select onchange="window.location.href='?lang='+this.value+'&tab=<?= $activeTab ?>'">
                    <?php foreach ($availableLanguages as $code => $name): ?>
                        <option value="<?= $code ?>" <?= $lang === $code ? 'selected' : '' ?>><?= $name ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="sub"><?= date('d-m-Y H:i') ?></div>
            <a href="?logout=1" class="btn-backup" style="background:#c0392b; border-color:#c0392b; text-decoration:none; display:inline-flex; align-items:center; gap:6px;" onclick="return confirm('<?= t('logout_confirm') ?>');">
                <i class="fas fa-sign-out-alt"></i> <?= t('logout') ?>
            </a>
        </div>
    </div>

    <div class="bank-stripe">
        <span>&#9654; <?= t('gdpr') ?> &middot; <?= t('dpia') ?> &middot; <?= t('breaches') ?> &middot; <?= t('third_parties') ?></span>
        <span><?= t('gdpr') ?>: <?= $totalGdpr ?> | <?= t('dpia') ?>: <?= $totalDpia ?> | <?= t('breaches') ?>: <?= $totalBreach ?> | <?= t('third_parties') ?>: <?= $totalThirdparty ?></span>
    </div>

    <!-- ============================================================
         TABS
         ============================================================ -->
    <div class="tabs">
        <a href="?tab=gdpr&lang=<?= $lang ?>" class="tab <?= $activeTab === 'gdpr' ? 'active' : '' ?>">
            <i class="fas fa-file-alt"></i> <?= t('gdpr') ?> <span class="badge-count"><?= $totalGdpr ?></span>
        </a>
        <a href="?tab=dpia&lang=<?= $lang ?>" class="tab <?= $activeTab === 'dpia' ? 'active' : '' ?>">
            <i class="fas fa-balance-scale"></i> <?= t('dpia') ?> <span class="badge-count"><?= $totalDpia ?></span>
        </a>
        <a href="?tab=breach&lang=<?= $lang ?>" class="tab <?= $activeTab === 'breach' ? 'active' : '' ?>">
            <i class="fas fa-exclamation-triangle"></i> <?= t('breaches') ?> <span class="badge-count"><?= $totalBreach ?></span>
        </a>
        <a href="?tab=thirdparty&lang=<?= $lang ?>" class="tab <?= $activeTab === 'thirdparty' ? 'active' : '' ?>">
            <i class="fas fa-handshake"></i> <?= t('third_parties') ?> <span class="badge-count"><?= $totalThirdparty ?></span>
        </a>
        <a href="?tab=measures&lang=<?= $lang ?>" class="tab <?= $activeTab === 'measures' ? 'active' : '' ?>">
            <i class="fas fa-shield-alt"></i> <?= t('configuration') ?>
        </a>
        <a href="?tab=report&lang=<?= $lang ?>" class="tab <?= $activeTab === 'report' ? 'active' : '' ?>">
            <i class="fas fa-chart-bar"></i> <?= t('reporting') ?>
        </a>
    </div>

    <!-- ============================================================
         MESSAGE
         ============================================================ -->
    <?php if ($message): ?>
        <div class="message <?= $messageType ?>">
            <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : ($messageType === 'danger' ? 'exclamation-circle' : 'info-circle') ?>"></i>
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- ============================================================
         GDPR TAB
         ============================================================ -->
    <div class="tab-content <?= $activeTab === 'gdpr' ? 'active' : '' ?>" id="tab-gdpr">
        <div class="stats-grid">
            <div class="stat-box"><div class="number"><?= $totalGdpr ?></div><div class="label"><?= t('total') ?></div></div>
            <div class="stat-box highlight"><div class="number"><?= $activeGdpr ?></div><div class="label"><?= t('active') ?></div></div>
            <div class="stat-box risk-high"><div class="number"><?= $highRiskGdpr ?></div><div class="label"><?= t('high_risk') ?></div></div>
            <div class="stat-box highlight"><div class="number"><?= $dpiaRequiredCount ?></div><div class="label"><?= t('dpia_required') ?></div></div>
            <div class="stat-box highlight"><div class="number"><?= $dpiaCompletedCount ?></div><div class="label"><?= t('dpia_completed') ?></div></div>
        </div>

        <div class="toolbar">
            <form method="GET" style="display:contents; flex:1; display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
                <input type="hidden" name="tab" value="gdpr">
                <input type="hidden" name="lang" value="<?= $lang ?>">
                <div class="search-box"><i class="fas fa-search"></i><input type="text" name="search" placeholder="<?= t('search') ?>" value="<?= htmlspecialchars($search) ?>"></div>
                <select name="filter_risk">
                    <option value=""><?= t('risk') ?></option>
                    <?php foreach ($riskLevels as $key => $label): ?>
                        <option value="<?= $key ?>" <?= $filterRisk === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="filter_dpia_required">
                    <option value=""><?= t('dpia') ?></option>
                    <option value="yes" <?= $filterDpiaRequired === 'yes' ? 'selected' : '' ?>><?= t('dpia_required') ?></option>
                    <option value="no" <?= $filterDpiaRequired === 'no' ? 'selected' : '' ?>><?= t('not_required') ?></option>
                </select>
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> <?= t('filter') ?></button>
                <a href="?tab=gdpr&lang=<?= $lang ?>" class="btn-clear"><i class="fas fa-times"></i> <?= t('clear') ?></a>
            </form>
            <a href="?tab=gdpr&new_gdpr=1&lang=<?= $lang ?>" class="btn-add"><i class="fas fa-plus"></i> <?= t('new') ?></a>
            <a href="?action=download&file=gdpr&lang=<?= $lang ?>" class="btn-export"><i class="fas fa-download"></i> <?= t('export_json') ?></a>
        </div>

        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead><tr>
                        <th>ID</th>
                        <th><?= t('processing_activity') ?></th>
                        <th><?= t('risk') ?></th>
                        <th><?= t('status') ?></th>
                        <th><?= t('dpia') ?></th>
                        <th><?= t('retention_period') ?></th>
                        <th style="text-align:center;"><?= t('actions') ?></th>
                    </tr></thead>
                    <tbody>
                        <?php if (count($displayRecords) === 0): ?>
                            <tr><td colspan="7" class="empty-state"><i class="fas fa-inbox"></i><?= t('no_records') ?></td></tr>
                        <?php else: foreach ($displayRecords as $record): ?>
                            <tr>
                                <td><strong>#<?= $record['id'] ?></strong></td>
                                <td>
                                    <div><?= htmlspecialchars($record['processing_activity'] ?? '') ?></div>
                                    <div style="font-size:11px;color:#666;"><?= htmlspecialchars($record['categories_data_subjects'] ?? '') ?></div>
                                </td>
                                <td><span class="badge <?= getRiskClass($record['risk_level'] ?? 'low') ?>"><?= t($record['risk_level'] ?? 'low') ?></span></td>
                                <td><span class="status-dot <?= ($record['status'] ?? 'active') ?>"></span><span class="badge <?= getStatusClass($record['status'] ?? 'active') ?>"><?= t($record['status'] ?? 'active') ?></span></td>
                                <td>
                                    <?php if (($record['dpia_required'] ?? 'no') === 'yes'): ?>
                                        <?php 
                                        $hasDpia = findDpiaByGdprId($dpiaRecords, $record['id']);
                                        ?>
                                        <?php if ($hasDpia): ?>
                                            <?php $dpiaStatus = $hasDpia['record']['status'] ?? 'draft'; ?>
                                            <?php if ($dpiaStatus === 'completed' || $dpiaStatus === 'approved'): ?>
                                                <span class="badge badge-active">✓ <?= t('completed') ?></span>
                                            <?php elseif ($dpiaStatus === 'in_progress'): ?>
                                                <a href="?tab=dpia&edit_dpia=<?= $hasDpia['record']['id'] ?>&lang=<?= $lang ?>" class="badge badge-progress dpia-clickable" style="text-decoration:none; display:inline-flex; align-items:center; gap:4px;">
                                                    <span class="status-dot in_progress"></span> ⏳ <?= t('in_progress') ?>
                                                </a>
                                            <?php else: ?>
                                                <a href="?tab=dpia&edit_dpia=<?= $hasDpia['record']['id'] ?>&lang=<?= $lang ?>" class="badge badge-draft dpia-clickable" style="text-decoration:none; display:inline-flex; align-items:center; gap:4px;">
                                                    <span class="status-dot draft"></span> 📝 <?= t('draft') ?>
                                                </a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="badge badge-required"><i class="fas fa-exclamation-triangle"></i> <?= t('dpia_required') ?></span>
                                            <a href="?tab=gdpr&create_dpia_for=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-dpia-create"><i class="fas fa-plus-circle"></i> <?= t('create_dpia') ?></a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge badge-not-required"><?= t('not_required') ?></span>
                                    <?php endif; ?>
                                </td>
                                <td style="font-size:11px;max-width:120px;"><?= htmlspecialchars($record['retention_periods'] ?? '-') ?></td>
                                <td style="text-align:center;">
                                    <div class="btn-group">
                                        <a href="?tab=gdpr&view_gdpr=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-icon view" title="<?= t('view') ?>"><i class="fas fa-eye"></i></a>
                                        <a href="?action=print_record&type=gdpr&id=<?= $record['id'] ?>&lang=<?= $lang ?>" target="_blank" class="btn-icon print-record" title="<?= t('print') ?>"><i class="fas fa-print"></i></a>
                                        <a href="?tab=gdpr&edit_gdpr=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-icon edit" title="<?= t('edit') ?>"><i class="fas fa-edit"></i></a>
                                        <button onclick="confirmDelete(<?= $record['id'] ?>, 'gdpr')" class="btn-icon delete" title="<?= t('delete') ?>"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination"><span><?= t('showing') ?> <?= count($displayRecords) ?> <?= t('of') ?> <?= $totalGdpr ?></span></div>
        </div>
    </div>

    <!-- ============================================================
         DPIA TAB
         ============================================================ -->
    <div class="tab-content <?= $activeTab === 'dpia' ? 'active' : '' ?>" id="tab-dpia">
        <div class="stats-grid">
            <div class="stat-box"><div class="number"><?= $totalDpia ?></div><div class="label"><?= t('total') ?></div></div>
            <div class="stat-box highlight"><div class="number"><?= $inProgressDpia ?></div><div class="label"><?= t('in_progress') ?></div></div>
            <div class="stat-box highlight"><div class="number"><?= $completedDpia ?></div><div class="label"><?= t('completed') ?></div></div>
            <div class="stat-box risk-high"><div class="number"><?= $highRiskDpia ?></div><div class="label"><?= t('high_risk') ?></div></div>
        </div>

        <?php
        $gdprNeedingDpia = [];
        foreach ($gdprRecords as $r) {
            if (isset($r['dpia_required']) && $r['dpia_required'] === 'yes') {
                $status = $r['dpia_status'] ?? 'not_required';
                $hasDpia = findDpiaByGdprId($dpiaRecords, $r['id']);
                if (!$hasDpia) {
                    $gdprNeedingDpia[] = $r;
                }
            }
        }
        ?>
        <?php if (!empty($gdprNeedingDpia)): ?>
            <div style="background:#f8f8f8;border:1px solid #ddd;padding:12px 16px;margin-bottom:15px;">
                <h4 style="font-size:13px;margin-bottom:8px;text-transform:uppercase;color:#333;">
                    <i class="fas fa-plus-circle" style="color:#222;"></i> <?= t('create_dpia_from_gdpr') ?>
                </h4>
                <p style="font-size:12px;color:#666;margin-bottom:8px;"><?= t('click_create_dpia_for_gdpr') ?></p>
                <div style="display:flex;flex-wrap:wrap;gap:6px;">
                    <?php foreach ($gdprNeedingDpia as $r): ?>
                        <a href="?tab=dpia&create_dpia_for=<?= $r['id'] ?>&lang=<?= $lang ?>" class="btn btn-primary" style="font-size:11px;padding:4px 12px;">
                            <i class="fas fa-plus-circle"></i> #<?= $r['id'] ?> - <?= htmlspecialchars($r['processing_activity'] ?? 'Onbekend') ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="toolbar">
            <form method="GET" style="display:contents; flex:1; display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
                <input type="hidden" name="tab" value="dpia">
                <input type="hidden" name="lang" value="<?= $lang ?>">
                <div class="search-box"><i class="fas fa-search"></i><input type="text" name="search" placeholder="<?= t('search') ?>" value="<?= htmlspecialchars($search) ?>"></div>
                <select name="filter_dpia_status">
                    <option value=""><?= t('status') ?></option>
                    <?php foreach ($dpiaStatuses as $key => $label): ?>
                        <option value="<?= $key ?>" <?= $filterDpiaStatus === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> <?= t('filter') ?></button>
                <a href="?tab=dpia&lang=<?= $lang ?>" class="btn-clear"><i class="fas fa-times"></i> <?= t('clear') ?></a>
            </form>
            <a href="?tab=dpia&new_dpia=1&lang=<?= $lang ?>" class="btn-add"><i class="fas fa-plus"></i> <?= t('new') ?></a>
            <a href="?action=download&file=dpia&lang=<?= $lang ?>" class="btn-export"><i class="fas fa-download"></i> <?= t('export_json') ?></a>
        </div>

        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead><tr>
                        <th>ID</th>
                        <th><?= t('title') ?></th>
                        <th><?= t('description') ?></th>
                        <th><?= t('gdpr') ?></th>
                        <th><?= t('risk') ?></th>
                        <th><?= t('status') ?></th>
                        <th style="text-align:center;"><?= t('actions') ?></th>
                    </tr></thead>
                    <tbody>
                        <?php if (count($displayDpia) === 0): ?>
                            <tr><td colspan="7" class="empty-state"><i class="fas fa-inbox"></i><?= t('no_records') ?></td></tr>
                        <?php else: foreach ($displayDpia as $record): ?>
                            <tr>
                                <td><strong>#<?= $record['id'] ?></strong></td>
                                <td style="max-width:300px; word-wrap:break-word;"><?= htmlspecialchars($record['title'] ?? '') ?></td>
                                <td><?= htmlspecialchars($record['description'] ?? '') ?></td>
                                <td><?= !empty($record['record_id']) ? '<span class="badge">#'.$record['record_id'].'</span>' : '<span class="badge" style="opacity:0.5;">-</span>' ?></td>
                                <td><span class="badge <?= getRiskClass($record['overall_risk_level'] ?? 'medium') ?>"><?= t($record['overall_risk_level'] ?? 'medium') ?></span></td>
                                <td><span class="status-dot <?= ($record['status'] ?? 'draft') ?>"></span><span class="badge <?= getStatusClass($record['status'] ?? 'draft') ?>"><?= t($record['status'] ?? 'draft') ?></span></td>
                                <td style="text-align:center;">
                                    <div class="btn-group">
                                        <a href="?tab=dpia&view_dpia=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-icon view" title="<?= t('view') ?>"><i class="fas fa-eye"></i></a>
                                        <a href="?action=print_record&type=dpia&id=<?= $record['id'] ?>&lang=<?= $lang ?>" target="_blank" class="btn-icon print-record" title="<?= t('print') ?>"><i class="fas fa-print"></i></a>
                                        <a href="?tab=dpia&edit_dpia=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-icon edit" title="<?= t('edit') ?>"><i class="fas fa-edit"></i></a>
                                        <button onclick="confirmDelete(<?= $record['id'] ?>, 'dpia')" class="btn-icon delete" title="<?= t('delete') ?>"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination"><span><?= t('showing') ?> <?= count($displayDpia) ?> <?= t('of') ?> <?= $totalDpia ?></span></div>
        </div>
    </div>

    <!-- ============================================================
         BREACH TAB
         ============================================================ -->
    <div class="tab-content <?= $activeTab === 'breach' ? 'active' : '' ?>" id="tab-breach">
        <div class="stats-grid">
            <div class="stat-box"><div class="number"><?= $totalBreach ?></div><div class="label"><?= t('total') ?></div></div>
            <div class="stat-box highlight"><div class="number"><?= $openBreach ?></div><div class="label"><?= t('open') ?></div></div>
            <div class="stat-box risk-high"><div class="number"><?= $highRiskBreach ?></div><div class="label"><?= t('high_risk') ?></div></div>
        </div>

        <div class="toolbar">
            <form method="GET" style="display:contents; flex:1; display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
                <input type="hidden" name="tab" value="breach">
                <input type="hidden" name="lang" value="<?= $lang ?>">
                <div class="search-box"><i class="fas fa-search"></i><input type="text" name="search" placeholder="<?= t('search') ?>" value="<?= htmlspecialchars($search) ?>"></div>
                <select name="filter_breach_type">
                    <option value=""><?= t('breach_type') ?></option>
                    <?php foreach ($breachTypes as $key => $label): ?>
                        <option value="<?= $key ?>" <?= $filterBreachType === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="filter_breach_status">
                    <option value=""><?= t('status') ?></option>
                    <?php foreach ($breachStatuses as $key => $label): ?>
                        <option value="<?= $key ?>" <?= $filterBreachStatus === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> <?= t('filter') ?></button>
                <a href="?tab=breach&lang=<?= $lang ?>" class="btn-clear"><i class="fas fa-times"></i> <?= t('clear') ?></a>
            </form>
            <a href="?tab=breach&new_breach=1&lang=<?= $lang ?>" class="btn-add"><i class="fas fa-plus"></i> <?= t('new') ?></a>
            <a href="?action=download&file=breach&lang=<?= $lang ?>" class="btn-export"><i class="fas fa-download"></i> <?= t('export_json') ?></a>
        </div>

        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead><tr>
                        <th>ID</th>
                        <th><?= t('title') ?></th>
                        <th><?= t('breach_date') ?></th>
                        <th><?= t('breach_type') ?></th>
                        <th><?= t('risk') ?></th>
                        <th><?= t('status') ?></th>
                        <th style="text-align:center;"><?= t('actions') ?></th>
                    </tr></thead>
                    <tbody>
                        <?php if (count($displayBreach) === 0): ?>
                            <tr><td colspan="7" class="empty-state"><i class="fas fa-inbox"></i><?= t('no_records') ?></td></tr>
                        <?php else: foreach ($displayBreach as $record): ?>
                            <tr>
                                <td><strong>#<?= $record['id'] ?></strong></td>
                                <td><?= htmlspecialchars($record['title'] ?? '') ?></td>
                                <td><?= formatDate($record['breach_date'] ?? '') ?></td>
                                <td><span class="badge"><?= getBreachTypeLabel($record['breach_type'] ?? '') ?></span></td>
                                <td><span class="badge <?= getRiskClass($record['risk_level'] ?? 'low') ?>"><?= t($record['risk_level'] ?? 'low') ?></span></td>
                                <td><span class="status-dot <?= ($record['status'] ?? 'open') ?>"></span><span class="badge <?= getStatusClass($record['status'] ?? 'open') ?>"><?= t($record['status'] ?? 'open') ?></span></td>
                                <td style="text-align:center;">
                                    <div class="btn-group">
                                        <a href="?tab=breach&view_breach=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-icon view" title="<?= t('view') ?>"><i class="fas fa-eye"></i></a>
                                        <a href="?action=print_record&type=breach&id=<?= $record['id'] ?>&lang=<?= $lang ?>" target="_blank" class="btn-icon print-record" title="<?= t('print') ?>"><i class="fas fa-print"></i></a>
                                        <a href="?tab=breach&edit_breach=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-icon edit" title="<?= t('edit') ?>"><i class="fas fa-edit"></i></a>
                                        <button onclick="confirmDelete(<?= $record['id'] ?>, 'breach')" class="btn-icon delete" title="<?= t('delete') ?>"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination"><span><?= t('showing') ?> <?= count($displayBreach) ?> <?= t('of') ?> <?= $totalBreach ?></span></div>
        </div>
    </div>

    <!-- ============================================================
         THIRD PARTY TAB
         ============================================================ -->
    <div class="tab-content <?= $activeTab === 'thirdparty' ? 'active' : '' ?>" id="tab-thirdparty">
        <div class="stats-grid">
            <div class="stat-box"><div class="number"><?= $totalThirdparty ?></div><div class="label"><?= t('total') ?></div></div>
            <div class="stat-box highlight"><div class="number"><?= $compliantThirdparty ?></div><div class="label"><?= t('compliant') ?></div></div>
            <div class="stat-box risk-high"><div class="number"><?= $reviewNeededThirdparty ?></div><div class="label"><?= t('review_needed') ?></div></div>
        </div>

        <div class="toolbar">
            <form method="GET" style="display:contents; flex:1; display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
                <input type="hidden" name="tab" value="thirdparty">
                <input type="hidden" name="lang" value="<?= $lang ?>">
                <div class="search-box"><i class="fas fa-search"></i><input type="text" name="search" placeholder="<?= t('search_company') ?>" value="<?= htmlspecialchars($search) ?>"></div>
                <select name="filter_compliance_status">
                    <option value=""><?= t('compliance_status') ?></option>
                    <?php foreach ($complianceStatuses as $key => $label): ?>
                        <option value="<?= $key ?>" <?= $filterComplianceStatus === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> <?= t('filter') ?></button>
                <a href="?tab=thirdparty&lang=<?= $lang ?>" class="btn-clear"><i class="fas fa-times"></i> <?= t('clear') ?></a>
            </form>
            <a href="?tab=thirdparty&new_thirdparty=1&lang=<?= $lang ?>" class="btn-add"><i class="fas fa-plus"></i> <?= t('new') ?></a>
            <a href="?action=download&file=thirdparty&lang=<?= $lang ?>" class="btn-export"><i class="fas fa-download"></i> <?= t('export_json') ?></a>
        </div>

        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead><tr>
                        <th>ID</th>
                        <th><?= t('company_name') ?></th>
                        <th><?= t('service_provided') ?></th>
                        <th><?= t('agreement_signed') ?></th>
                        <th><?= t('compliance_status') ?></th>
                        <th style="text-align:center;"><?= t('actions') ?></th>
                    </tr></thead>
                    <tbody>
                        <?php if (count($displayThirdparty) === 0): ?>
                            <tr><td colspan="6" class="empty-state"><i class="fas fa-inbox"></i><?= t('no_records') ?></td></tr>
                        <?php else: foreach ($displayThirdparty as $record): ?>
                            <tr>
                                <td><strong>#<?= $record['id'] ?></strong></td>
                                <td><?= htmlspecialchars(!empty($record['company_name']) ? rot47decode($record['company_name']) : '') ?></td>
                                <td><?= htmlspecialchars($record['service_provided'] ?? '') ?></td>
                                <td><span class="badge <?= ($record['processing_agreement_signed'] ?? '') === 'yes' ? 'badge-active' : 'badge-inactive' ?>"><?= getYesNoLabel($record['processing_agreement_signed'] ?? 'no') ?></span></td>
                                <td><span class="status-dot <?= ($record['compliance_status'] ?? 'review_needed') ?>"></span><span class="badge <?= getStatusClass($record['compliance_status'] ?? 'review_needed') ?>"><?= getComplianceStatusLabel($record['compliance_status'] ?? 'review_needed') ?></span></td>
                                <td style="text-align:center;">
                                    <div class="btn-group">
                                        <a href="?tab=thirdparty&view_thirdparty=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-icon view" title="<?= t('view') ?>"><i class="fas fa-eye"></i></a>
                                        <a href="?action=print_record&type=thirdparty&id=<?= $record['id'] ?>&lang=<?= $lang ?>" target="_blank" class="btn-icon print-record" title="<?= t('print') ?>"><i class="fas fa-print"></i></a>
                                        <a href="?tab=thirdparty&edit_thirdparty=<?= $record['id'] ?>&lang=<?= $lang ?>" class="btn-icon edit" title="<?= t('edit') ?>"><i class="fas fa-edit"></i></a>
                                        <button onclick="confirmDelete(<?= $record['id'] ?>, 'thirdparty')" class="btn-icon delete" title="<?= t('delete') ?>"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination"><span><?= t('showing') ?> <?= count($displayThirdparty) ?> <?= t('of') ?> <?= $totalThirdparty ?></span></div>
        </div>
    </div>

    <!-- ============================================================
         MEASURES TAB
         ============================================================ -->
    <div class="tab-content <?= $activeTab === 'measures' ? 'active' : '' ?>" id="tab-measures">
        <div class="section-title"><?= t('technical_measures') ?> <small><?= t('collected_from_records') ?></small></div>
        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead><tr><th>#</th><th><?= t('measure') ?></th><th><?= t('source') ?></th><th><?= t('actions') ?></th></tr></thead>
                    <tbody>
                        <?php if (count($allTechnicalMeasures) === 0): ?>
                            <tr><td colspan="4" class="empty-state"><i class="fas fa-inbox"></i><?= t('no_technical_measures') ?></td></tr>
                        <?php else: $counter = 1; foreach ($allTechnicalMeasures as $measure): ?>
                            <tr>
                                <td><?= $counter++ ?></td>
                                <td><?= htmlspecialchars($measure) ?></td>
                                <td>
                                    <?php 
                                    $found = false;
                                    foreach ($gdprRecords as $r) { if (!empty($r['technical_measures']) && in_array($measure, splitMeasureList($r['technical_measures']), true)) { echo '<a href="?tab=gdpr&edit_gdpr='.$r['id'].'&lang='.$lang.'" class="badge" style="text-decoration:none;">' . t('gdpr') . ' #'.$r['id'].'</a> '; $found = true; } }
                                    foreach ($dpiaRecords as $r) { if (!empty($r['mitigation_measures']) && in_array($measure, splitMeasureList($r['mitigation_measures']), true)) { echo '<a href="?tab=dpia&edit_dpia='.$r['id'].'&lang='.$lang.'" class="badge" style="text-decoration:none;">' . t('dpia') . ' #'.$r['id'].'</a> '; $found = true; } }
                                    foreach ($breachRecords as $r) { if (!empty($r['measures_taken']) && in_array($measure, splitMeasureList($r['measures_taken']), true)) { echo '<a href="?tab=breach&edit_breach='.$r['id'].'&lang='.$lang.'" class="badge" style="text-decoration:none;">' . t('breach') . ' #'.$r['id'].'</a> '; $found = true; } }
                                    if (!$found) echo '<span class="badge badge-inactive">' . t('configuration') . '</span>';
                                    ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn-icon edit" title="<?= t('edit') ?>" onclick="openMeasureEditModal('technical', <?= htmlspecialchars(json_encode($measure), ENT_QUOTES) ?>)"><i class="fas fa-edit"></i></button>
                                        <button type="button" class="btn-icon delete" title="<?= t('delete') ?>" onclick="confirmDeleteMeasure('technical', <?= htmlspecialchars(json_encode($measure), ENT_QUOTES) ?>)"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination"><span><?= t('showing') ?> <?= count($allTechnicalMeasures) ?> <?= t('technical_measures') ?></span></div>
        </div>

        <div class="section-title"><?= t('organizational_measures') ?> <small><?= t('collected_from_records') ?></small></div>
        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead><tr><th>#</th><th><?= t('measure') ?></th><th><?= t('source') ?></th><th><?= t('actions') ?></th></tr></thead>
                    <tbody>
                        <?php if (count($allOrganizationalMeasures) === 0): ?>
                            <tr><td colspan="4" class="empty-state"><i class="fas fa-inbox"></i><?= t('no_organizational_measures') ?></td></tr>
                        <?php else: $counter = 1; foreach ($allOrganizationalMeasures as $measure): ?>
                            <tr>
                                <td><?= $counter++ ?></td>
                                <td><?= htmlspecialchars($measure) ?></td>
                                <td>
                                    <?php 
                                    $found = false;
                                    foreach ($gdprRecords as $r) { if (!empty($r['organizational_measures']) && in_array($measure, splitMeasureList($r['organizational_measures']), true)) { echo '<a href="?tab=gdpr&edit_gdpr='.$r['id'].'&lang='.$lang.'" class="badge" style="text-decoration:none;">' . t('gdpr') . ' #'.$r['id'].'</a> '; $found = true; } }
                                    foreach ($dpiaRecords as $r) { if (!empty($r['organizational_measures']) && in_array($measure, splitMeasureList($r['organizational_measures']), true)) { echo '<a href="?tab=dpia&edit_dpia='.$r['id'].'&lang='.$lang.'" class="badge" style="text-decoration:none;">' . t('dpia') . ' #'.$r['id'].'</a> '; $found = true; } }
                                    foreach ($breachRecords as $r) { if (!empty($r['measures_taken']) && in_array($measure, splitMeasureList($r['measures_taken']), true)) { echo '<a href="?tab=breach&edit_breach='.$r['id'].'&lang='.$lang.'" class="badge" style="text-decoration:none;">' . t('breach') . ' #'.$r['id'].'</a> '; $found = true; } }
                                    if (!$found) echo '<span class="badge badge-inactive">' . t('configuration') . '</span>';
                                    ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn-icon edit" title="<?= t('edit') ?>" onclick="openMeasureEditModal('organizational', <?= htmlspecialchars(json_encode($measure), ENT_QUOTES) ?>)"><i class="fas fa-edit"></i></button>
                                        <button type="button" class="btn-icon delete" title="<?= t('delete') ?>" onclick="confirmDeleteMeasure('organizational', <?= htmlspecialchars(json_encode($measure), ENT_QUOTES) ?>)"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination"><span><?= t('showing') ?> <?= count($allOrganizationalMeasures) ?> <?= t('organizational_measures') ?></span></div>
        </div>

        <?php
        // Every other dynamic value list gets the same table layout: value,
        // where it's currently used, edit (rename everywhere) and delete
        // (clear everywhere). Defined once here to avoid repeating markup
        // for each of the ten fields below.
        $dynamicValueSections = [
            ['title' => t('department'), 'field_type' => 'department', 'values' => array_keys($departmentsList)],
            ['title' => t('risk_origin'), 'field_type' => 'risk_origin', 'values' => array_keys($riskOriginOptions)],
            ['title' => t('status') . ' (' . t('dpia') . ')', 'field_type' => 'dpia_status', 'values' => array_keys($dpiaStatuses)],
            ['title' => t('management_approval'), 'field_type' => 'management_approval', 'values' => array_keys($managementApprovalOptions)],
            ['title' => t('consultation_conducted'), 'field_type' => 'consultation_conducted', 'values' => array_keys($consultationOptions)],
            ['title' => t('approved_by'), 'field_type' => 'approved_by', 'values' => $allApprovedByNames],
            ['title' => t('controller') . ' — ' . t('name'), 'field_type' => 'name_data_controller', 'values' => $allDataControllerNames],
            ['title' => t('joint_controller') . ' — ' . t('name'), 'field_type' => 'name_joint_data_controller', 'values' => $allJointControllerNames],
            ['title' => t('dpo') . ' — ' . t('name'), 'field_type' => 'name_dpo', 'values' => $allDpoNames],
            ['title' => t('representative') . ' — ' . t('name'), 'field_type' => 'name_representative', 'values' => $allRepresentativeNames],
            ['title' => t('compliance_status') . ' (' . t('third_party') . ')', 'field_type' => 'compliance_status', 'values' => array_keys($complianceStatuses)],
            ['title' => t('agreement_signed') . ' (' . t('third_party') . ')', 'field_type' => 'agreement_signed', 'values' => array_keys($agreementSignedOptions)],
            ['title' => t('breach_type') . ' (' . t('breach') . ')', 'field_type' => 'breach_type', 'values' => array_keys($breachTypes)],
        ];
        ?>
        <?php foreach ($dynamicValueSections as $section): ?>
        <div class="section-title"><?= htmlspecialchars($section['title']) ?></div>
        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead><tr><th>#</th><th><?= t('value') ?></th><th><?= t('used_in') ?></th><th><?= t('actions') ?></th></tr></thead>
                    <tbody>
                        <?php if (count($section['values']) === 0): ?>
                            <tr><td colspan="4" class="empty-state"><i class="fas fa-inbox"></i><?= t('no_values') ?></td></tr>
                        <?php else: $counter = 1; foreach ($section['values'] as $val): ?>
                            <?php $usageRecords = getDynamicValueUsageRecords($section['field_type'], $val, $gdprRecords, $dpiaRecords, $breachRecords, $thirdpartyRecords); ?>
                            <tr>
                                <td><?= $counter++ ?></td>
                                <td><?= htmlspecialchars($val) ?></td>
                                <td>
                                    <?php if (empty($usageRecords)): ?>
                                        <span class="badge badge-inactive"><?= t('not_currently_used') ?></span>
                                    <?php else: foreach ($usageRecords as $u): ?>
                                        <a href="?tab=<?= $u['tab'] ?>&<?= $u['edit_param'] ?>=<?= $u['id'] ?>&lang=<?= $lang ?>" class="badge" style="text-decoration:none;"><?= htmlspecialchars($u['label']) ?> #<?= $u['id'] ?></a>
                                    <?php endforeach; endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn-icon edit" title="<?= t('edit') ?>" onclick="openDynValueEditModal('<?= $section['field_type'] ?>', <?= htmlspecialchars(json_encode($val), ENT_QUOTES) ?>)"><i class="fas fa-edit"></i></button>
                                        <button type="button" class="btn-icon delete" title="<?= t('delete') ?>" onclick="confirmDeleteDynValue('<?= $section['field_type'] ?>', <?= htmlspecialchars(json_encode($val), ENT_QUOTES) ?>)"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination"><span><?= t('showing') ?> <?= count($section['values']) ?></span></div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ============================================================
         REPORT TAB
         ============================================================ -->
    <div class="tab-content <?= $activeTab === 'report' ? 'active' : '' ?>" id="tab-report">
        <div class="section-title"><?= t('reporting') ?> <small><?= t('gdpr_compliance_overview') ?></small></div>
        
        <div style="margin-bottom:20px; display:flex; gap:10px; flex-wrap:wrap;">
            <a href="?action=print_report&lang=<?= $lang ?>" target="_blank" class="print-btn">
                <i class="fas fa-print"></i> <?= t('full_report') ?>
            </a>
           
            <button type="button" class="btn-backup" onclick="openZipPasswordModal()">
                <i class="fas fa-file-archive"></i> <?= t('zip_backup') ?>
            </button>
        </div>
        <?php if (isset($_GET['zipbackup_error'])): ?>
            <div style="margin-bottom:20px; padding:10px 14px; background:#fdecea; border:1px solid #b00020; color:#b00020; font-size:13px;">
                <?php if ($_GET['zipbackup_error'] === 'nozip'): ?>
                    ZIP-encryptie is niet beschikbaar op deze server (ZipArchive/AES ontbreekt).
                <?php else: ?>
                    Wachtwoord ontbreekt, is te kort (min. 6 tekens) of komt niet overeen. Probeer het opnieuw.
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <div class="report-grid">
            <!-- GDPR Status -->
            <div class="report-card">
                <h4><?= t('gdpr') ?> <?= t('status') ?></h4>
                <div class="report-chart">
                    <div>
                        <div class="progress-label"><span><?= t('active') ?></span><span><?= $activeGdpr ?> (<?= $totalGdpr > 0 ? round(($activeGdpr/$totalGdpr)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $totalGdpr > 0 ? round(($activeGdpr/$totalGdpr)*100) : 0 ?>%;"></div>
                        </div>
                    </div>
                    <div>
                        <div class="progress-label"><span><?= t('inactive_draft') ?></span><span><?= $totalGdpr - $activeGdpr ?> (<?= $totalGdpr > 0 ? round((($totalGdpr - $activeGdpr)/$totalGdpr)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $totalGdpr > 0 ? round((($totalGdpr - $activeGdpr)/$totalGdpr)*100) : 0 ?>%; background:#888;"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Risico Distributie GDPR -->
            <div class="report-card">
                <h4><?= t('risk_distribution') ?> (<?= t('gdpr') ?>)</h4>
                <div class="report-chart">
                    <?php 
                    $high = count(array_filter($gdprRecords, function($r) { return ($r['risk_level'] ?? '') === 'high'; }));
                    $medium = count(array_filter($gdprRecords, function($r) { return ($r['risk_level'] ?? '') === 'medium'; }));
                    $low = count(array_filter($gdprRecords, function($r) { return ($r['risk_level'] ?? '') === 'low'; }));
                    $totalRisk = $high + $medium + $low;
                    ?>
                    <div>
                        <div class="progress-label"><span><?= t('high') ?></span><span><?= $high ?> (<?= $totalRisk > 0 ? round(($high/$totalRisk)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $totalRisk > 0 ? round(($high/$totalRisk)*100) : 0 ?>%; background:#a00;"></div>
                        </div>
                    </div>
                    <div>
                        <div class="progress-label"><span><?= t('medium') ?></span><span><?= $medium ?> (<?= $totalRisk > 0 ? round(($medium/$totalRisk)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $totalRisk > 0 ? round(($medium/$totalRisk)*100) : 0 ?>%; background:#888;"></div>
                        </div>
                    </div>
                    <div>
                        <div class="progress-label"><span><?= t('low') ?></span><span><?= $low ?> (<?= $totalRisk > 0 ? round(($low/$totalRisk)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $totalRisk > 0 ? round(($low/$totalRisk)*100) : 0 ?>%; background:#ddd; border:1px solid #aaa;"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- DPIA Status -->
            <div class="report-card">
                <h4><?= t('dpia') ?> <?= t('status') ?></h4>
                <div class="report-chart">
                    <?php 
                    $dpiaCompleted = count(array_filter($dpiaRecords, function($r) { return ($r['status'] ?? '') === 'completed' || ($r['status'] ?? '') === 'approved'; }));
                    $dpiaInProgress = count(array_filter($dpiaRecords, function($r) { return ($r['status'] ?? '') === 'in_progress'; }));
                    $dpiaDraft = count(array_filter($dpiaRecords, function($r) { return ($r['status'] ?? '') === 'draft'; }));
                    $dpiaTotal = count($dpiaRecords);
                    ?>
                    <div>
                        <div class="progress-label"><span><?= t('completed') ?></span><span><?= $dpiaCompleted ?> (<?= $dpiaTotal > 0 ? round(($dpiaCompleted/$dpiaTotal)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $dpiaTotal > 0 ? round(($dpiaCompleted/$dpiaTotal)*100) : 0 ?>%; background:#222;"></div>
                        </div>
                    </div>
                    <div>
                        <div class="progress-label"><span><?= t('in_progress') ?></span><span><?= $dpiaInProgress ?> (<?= $dpiaTotal > 0 ? round(($dpiaInProgress/$dpiaTotal)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $dpiaTotal > 0 ? round(($dpiaInProgress/$dpiaTotal)*100) : 0 ?>%; background:#666;"></div>
                        </div>
                    </div>
                    <div>
                        <div class="progress-label"><span><?= t('draft') ?></span><span><?= $dpiaDraft ?> (<?= $dpiaTotal > 0 ? round(($dpiaDraft/$dpiaTotal)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $dpiaTotal > 0 ? round(($dpiaDraft/$dpiaTotal)*100) : 0 ?>%; background:#aaa;"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Derden Compliance -->
            <div class="report-card">
                <h4><?= t('third_parties') ?> <?= t('compliance_status') ?></h4>
                <div class="report-chart">
                    <?php 
                    $thirdCompliant = count(array_filter($thirdpartyRecords, function($r) { return ($r['compliance_status'] ?? '') === 'compliant'; }));
                    $thirdReview = count(array_filter($thirdpartyRecords, function($r) { return ($r['compliance_status'] ?? '') === 'review_needed'; }));
                    $thirdNon = count(array_filter($thirdpartyRecords, function($r) { return ($r['compliance_status'] ?? '') === 'non_compliant'; }));
                    $thirdTotal = count($thirdpartyRecords);
                    ?>
                    <div>
                        <div class="progress-label"><span><?= t('compliant') ?></span><span><?= $thirdCompliant ?> (<?= $thirdTotal > 0 ? round(($thirdCompliant/$thirdTotal)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $thirdTotal > 0 ? round(($thirdCompliant/$thirdTotal)*100) : 0 ?>%; background:#222;"></div>
                        </div>
                    </div>
                    <div>
                        <div class="progress-label"><span><?= t('review_needed') ?></span><span><?= $thirdReview ?> (<?= $thirdTotal > 0 ? round(($thirdReview/$thirdTotal)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $thirdTotal > 0 ? round(($thirdReview/$thirdTotal)*100) : 0 ?>%; background:#888;"></div>
                        </div>
                    </div>
                    <div>
                        <div class="progress-label"><span><?= t('non_compliant') ?></span><span><?= $thirdNon ?> (<?= $thirdTotal > 0 ? round(($thirdNon/$thirdTotal)*100) : 0 ?>%)</span></div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width:<?= $thirdTotal > 0 ? round(($thirdNon/$thirdTotal)*100) : 0 ?>%; background:#a00;"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Overzicht Statistieken -->
            <div class="report-card">
                <h4><?= t('statistics') ?></h4>
                <div class="stat-row"><span><?= t('total_gdpr_records') ?></span><span class="stat-value"><?= $totalGdpr ?></span></div>
                <div class="stat-row"><span><?= t('dpia_required') ?></span><span class="stat-value"><?= $dpiaRequiredCount ?></span></div>
                <div class="stat-row"><span><?= t('dpia_completed') ?></span><span class="stat-value"><?= $dpiaCompletedCount ?></span></div>
                <div class="stat-row"><span><?= t('dpia_in_progress') ?></span><span class="stat-value"><?= $inProgressDpia ?></span></div>
                <div class="stat-row"><span><?= t('total_breaches') ?></span><span class="stat-value"><?= $totalBreach ?></span></div>
                <div class="stat-row"><span><?= t('open_breaches') ?></span><span class="stat-value"><?= $openBreach ?></span></div>
                <div class="stat-row"><span><?= t('total_third_parties') ?></span><span class="stat-value"><?= $totalThirdparty ?></span></div>
                <div class="stat-row"><span><?= t('compliant_third_parties') ?></span><span class="stat-value"><?= $compliantThirdparty ?></span></div>
            </div>
            
            <!-- DPIA vs GDPR -->
            <div class="report-card">
                <h4><?= t('dpia_coverage') ?></h4>
                <div class="stat-row"><span><?= t('gdpr_with_dpia_required') ?></span><span class="stat-value"><?= $dpiaRequiredCount ?></span></div>
                <div class="stat-row"><span><?= t('dpia_completed') ?></span><span class="stat-value"><?= $dpiaCompletedCount ?></span></div>
                <div class="stat-row"><span><?= t('dpia_in_progress') ?></span><span class="stat-value"><?= $inProgressDpia ?></span></div>
                <div style="margin-top:10px;">
                    <div class="progress-label"><span><?= t('dpia_completion_rate') ?></span><span><?= $dpiaRequiredCount > 0 ? round(($dpiaCompletedCount/$dpiaRequiredCount)*100) : 0 ?>%</span></div>
                    <div class="progress-bar-container">
                        <div class="progress-bar-fill" style="width:<?= $dpiaRequiredCount > 0 ? round(($dpiaCompletedCount/$dpiaRequiredCount)*100) : 0 ?>%; background:#222;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
         GDPR NEW/EDIT MODAL
         ============================================================ -->
    <?php if (isset($_GET['new_gdpr']) || $editRecord): 
        $isNew = isset($_GET['new_gdpr']);
        $record = $editRecord ?: [];
        // Decode ROT47 contact fields for display
        $contactFields = ['contact_data_controller', 'name_data_controller', 'contact_dpo', 'name_dpo', 'contact_joint_data_controller', 'name_joint_data_controller', 'contact_representative', 'name_representative'];
        foreach ($contactFields as $field) {
            if (isset($record[$field]) && !empty($record[$field])) {
                $record[$field . '_display'] = rot47decode($record[$field]);
            } else {
                $record[$field . '_display'] = '';
            }
        }
    ?>
    <div class="modal-overlay" id="gdprModal" style="display:flex;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit" style="margin-right:10px;"></i> <?= $isNew ? t('new_gdpr_record') : t('edit_gdpr_record') . ' #'.$record['id'] ?></h3>
                <a href="?tab=gdpr&lang=<?= $lang ?>" class="close-btn">&times;</a>
            </div>
            <form method="POST" id="gdprForm">
                <input type="hidden" name="action" value="save_gdpr">
                <input type="hidden" name="id" value="<?= $record['id'] ?? '' ?>">
                <div class="modal-body">
                    <!-- Basisgegevens -->
                    <div class="form-group"><label><?= t('processing_activity') ?> *</label><input type="text" name="processing_activity" value="<?= htmlspecialchars($record['processing_activity'] ?? '') ?>" required></div>
                    <div class="form-group"><label><?= t('purpose') ?></label><textarea name="purpose_of_processing" oninput="autoExpand(this)"><?= htmlspecialchars($record['purpose_of_processing'] ?? '') ?></textarea></div>
                    
                    <div class="form-row">
                        <div class="form-group"><label><?= t('data_subjects') ?></label><input type="text" name="categories_data_subjects" value="<?= htmlspecialchars($record['categories_data_subjects'] ?? '') ?>"></div>
                        <div class="form-group"><label><?= t('personal_data') ?></label><input type="text" name="categories_personal_data" value="<?= htmlspecialchars($record['categories_personal_data'] ?? '') ?>"></div>
                    </div>
                    <div class="form-group"><label><?= t('recipients') ?></label><input type="text" name="categories_recipients" value="<?= htmlspecialchars($record['categories_recipients'] ?? '') ?>"></div>
                    
                    <!-- Verwerkingsverantwoordelijke -->
                    <div style="background:#f5f5f5;padding:12px;margin:10px 0;border:1px solid #ddd;">
                        <h4 style="font-size:13px;margin-bottom:8px;text-transform:uppercase;color:#333;"><i class="fas fa-user-tie"></i> <?= t('controller') ?></h4>
                        <div class="form-row">
                            <div class="form-group"><label><?= t('name') ?></label>
                                <select name="name_data_controller">
                                    <option value="">-</option>
                                    <?php foreach ($allDataControllerNames as $n): ?>
                                        <option value="<?= htmlspecialchars($n) ?>" <?= ($record['name_data_controller_display'] ?? '') === $n ? 'selected' : '' ?>><?= htmlspecialchars($n) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="name_data_controller_custom" placeholder="<?= t('or_type_custom_name') ?>" style="width:100%;margin-top:4px;" value="">
                            </div>
                            <div class="form-group"><label><?= t('contact') ?></label><input type="text" name="contact_data_controller" value="<?= htmlspecialchars($record['contact_data_controller_display'] ?? '') ?>"></div>
                        </div>
                    </div>
                    
                    <!-- Gezamenlijke Verwerkingsverantwoordelijke -->
                    <div style="background:#f5f5f5;padding:12px;margin:10px 0;border:1px solid #ddd;">
                        <h4 style="font-size:13px;margin-bottom:8px;text-transform:uppercase;color:#333;"><i class="fas fa-handshake"></i> <?= t('joint_controller') ?></h4>
                        <div class="form-row">
                            <div class="form-group"><label><?= t('name') ?></label>
                                <select name="name_joint_data_controller">
                                    <option value="">-</option>
                                    <?php foreach ($allJointControllerNames as $n): ?>
                                        <option value="<?= htmlspecialchars($n) ?>" <?= ($record['name_joint_data_controller_display'] ?? '') === $n ? 'selected' : '' ?>><?= htmlspecialchars($n) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="name_joint_data_controller_custom" placeholder="<?= t('or_type_custom_name') ?>" style="width:100%;margin-top:4px;" value="">
                            </div>
                            <div class="form-group"><label><?= t('contact') ?></label><input type="text" name="contact_joint_data_controller" value="<?= htmlspecialchars($record['contact_joint_data_controller_display'] ?? '') ?>"></div>
                        </div>
                    </div>
                    
                    <!-- DPO -->
                    <div style="background:#f5f5f5;padding:12px;margin:10px 0;border:1px solid #ddd;">
                        <h4 style="font-size:13px;margin-bottom:8px;text-transform:uppercase;color:#333;"><i class="fas fa-user-shield"></i> <?= t('dpo') ?></h4>
                        <div class="form-row">
                            <div class="form-group"><label><?= t('name') ?></label>
                                <select name="name_dpo">
                                    <option value="">-</option>
                                    <?php foreach ($allDpoNames as $n): ?>
                                        <option value="<?= htmlspecialchars($n) ?>" <?= ($record['name_dpo_display'] ?? '') === $n ? 'selected' : '' ?>><?= htmlspecialchars($n) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="name_dpo_custom" placeholder="<?= t('or_type_custom_name') ?>" style="width:100%;margin-top:4px;" value="">
                            </div>
                            <div class="form-group"><label><?= t('contact') ?></label><input type="text" name="contact_dpo" value="<?= htmlspecialchars($record['contact_dpo_display'] ?? '') ?>"></div>
                        </div>
                    </div>
                    
                    <!-- Vertegenwoordiger -->
                    <div style="background:#f5f5f5;padding:12px;margin:10px 0;border:1px solid #ddd;">
                        <h4 style="font-size:13px;margin-bottom:8px;text-transform:uppercase;color:#333;"><i class="fas fa-user-tag"></i> <?= t('representative') ?></h4>
                        <div class="form-row">
                            <div class="form-group"><label><?= t('name') ?></label>
                                <select name="name_representative">
                                    <option value="">-</option>
                                    <?php foreach ($allRepresentativeNames as $n): ?>
                                        <option value="<?= htmlspecialchars($n) ?>" <?= ($record['name_representative_display'] ?? '') === $n ? 'selected' : '' ?>><?= htmlspecialchars($n) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="name_representative_custom" placeholder="<?= t('or_type_custom_name') ?>" style="width:100%;margin-top:4px;" value="">
                            </div>
                            <div class="form-group"><label><?= t('contact') ?></label><input type="text" name="contact_representative" value="<?= htmlspecialchars($record['contact_representative_display'] ?? '') ?>"></div>
                        </div>
                    </div>
                    
                    <!-- Bewaarperiode met dropdown -->
                    <div class="form-group">
                        <label><?= t('retention_period') ?></label>
                        <select name="retention_periods" style="width:100%;">
                            <option value="">-- <?= t('select_or_type_below') ?> --</option>
                            <?php foreach ($retentionPeriods as $period): ?>
                                <option value="<?= htmlspecialchars($period) ?>" <?= ($record['retention_periods'] ?? '') === $period ? 'selected' : '' ?>><?= htmlspecialchars($period) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="retention_periods_custom" placeholder="<?= t('or_type_custom_retention_period') ?>" style="width:100%;margin-top:4px;" value="<?= !in_array($record['retention_periods'] ?? '', $retentionPeriods) ? htmlspecialchars($record['retention_periods'] ?? '') : '' ?>">
                    </div>
                    
                    <!-- Overige instellingen -->
                    <div class="form-row">
                        <div class="form-group"><label><?= t('legal_basis') ?></label>
                            <select name="legal_basis">
                                <?php foreach ($legalBasisOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['legal_basis'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label><?= t('risk_level') ?></label>
                            <select name="risk_level">
                                <?php foreach ($riskLevels as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['risk_level'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('status') ?></label>
                            <select name="status">
                                <?php foreach ($gdprStatuses as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['status'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label><?= t('department') ?></label>
                            <select name="department">
                                <?php foreach ($departmentsList as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['department'] ?? '') === $key ? 'selected' : '' ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="department_custom" placeholder="<?= t('or_type_custom_department') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('dpia_required') ?></label>
                            <select name="dpia_required">
                                <?php foreach ($yesNoOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= (($record['dpia_required'] ?? 'no') === $key) ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label><?= t('dpia_status') ?></label>
                            <select name="dpia_status">
                                <?php foreach ($dpiaStatuses as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['dpia_status'] ?? 'not_required') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group"><label><?= t('we_are_processor') ?></label>
                            <select name="we_are_processor">
                                <?php foreach ($yesNoOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= (($record['we_are_processor'] ?? 'no') === $key) ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label><?= t('processing_agreement_third_party') ?></label>
                            <select name="has_processing_agreement_with_third_party">
                                <?php foreach ($yesNoOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= (($record['has_processing_agreement_with_third_party'] ?? 'no') === $key) ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <!-- International Data Transfers -->
                    <div style="background:#f5f5f5;padding:12px;margin:10px 0;border:1px solid #ddd;">
                        <h4 style="font-size:13px;margin-bottom:8px;text-transform:uppercase;color:#333;"><i class="fas fa-globe"></i> <?= t('international_transfer') ?></h4>
                        <div class="form-row">
                            <div class="form-group"><label><?= t('international_transfer') ?></label>
                                <select name="is_international_data_transfers">
                                    <?php foreach ($internationalTransferOptions as $key => $label): ?>
                                        <option value="<?= $key ?>" <?= ($record['is_international_data_transfers'] ?? 'unknown') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group"><label><?= t('to_country') ?></label><input type="text" name="to_country" value="<?= htmlspecialchars($record['to_country'] ?? '') ?>"></div>
                        </div>
                        
                        <!-- Waarborgen - multi-select met ALLE opties -->
                        <div class="form-group">
                            <label><?= t('safeguards') ?></label>
                            <select name="safeguards[]" multiple style="height:150px;">
                                <?php 
                                $selectedSafeguards = splitMeasureList($record['safeguards'] ?? '');
                                foreach ($allSafeguardsOptions as $opt): ?>
                                    <option value="<?= htmlspecialchars($opt) ?>" <?= in_array($opt, $selectedSafeguards) ? 'selected' : '' ?>><?= htmlspecialchars(t($opt)) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="safeguards_custom" placeholder="<?= t('or_type_custom_safeguards') ?>" style="width:100%;margin-top:4px;" value="">
                            <div style="font-size:11px; color:#888; margin-top:2px;"><?= t('hold_ctrl_to_select_multiple') ?></div>
                        </div>
                    </div>
                    
                    <!-- Technische maatregelen - multi-select met ALLE opties -->
                    <div class="form-group">
                        <label><?= t('technical_measures') ?></label>
                        <select name="technical_measures[]" multiple style="height:150px;">
                            <?php 
                            $selectedTech = splitMeasureList($record['technical_measures'] ?? '');
                            foreach ($allTechMeasuresOptions as $opt): ?>
                                <option value="<?= htmlspecialchars($opt) ?>" <?= in_array($opt, $selectedTech) ? 'selected' : '' ?>><?= htmlspecialchars($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="technical_measures_custom" placeholder="<?= t('or_type_custom_measures') ?>" style="width:100%;margin-top:4px;" value="">
                        <div style="font-size:11px; color:#888; margin-top:2px;"><?= t('hold_ctrl_to_select_multiple') ?></div>
                    </div>
                    
                    <!-- Organisatorische maatregelen - multi-select met ALLE opties -->
                    <div class="form-group">
                        <label><?= t('organizational_measures') ?></label>
                        <select name="organizational_measures[]" multiple style="height:150px;">
                            <?php 
                            $selectedOrg = splitMeasureList($record['organizational_measures'] ?? '');
                            foreach ($allOrgMeasuresOptions as $opt): ?>
                                <option value="<?= htmlspecialchars($opt) ?>" <?= in_array($opt, $selectedOrg) ? 'selected' : '' ?>><?= htmlspecialchars($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="organizational_measures_custom" placeholder="<?= t('or_type_custom_measures') ?>" style="width:100%;margin-top:4px;" value="">
                        <div style="font-size:11px; color:#888; margin-top:2px;"><?= t('hold_ctrl_to_select_multiple') ?></div>
                    </div>
                    
                    <div class="form-group"><label><?= t('review_date') ?></label><input type="date" name="review_due_date" value="<?= $record['review_due_date'] ?? '' ?>"></div>
                    <div class="form-group"><label><?= t('legitimate_interest') ?></label><textarea name="legitimate_interest_description" oninput="autoExpand(this)"><?= htmlspecialchars($record['legitimate_interest_description'] ?? '') ?></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> <?= $isNew ? t('add') : t('save') ?></button>
                    <a href="?tab=gdpr&lang=<?= $lang ?>" class="btn btn-secondary"><?= t('cancel') ?></a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         DPIA NEW/EDIT MODAL
         ============================================================ -->
    <?php if ((isset($_GET['new_dpia']) || $editDpia || ($prefillGdprId && !$dpiaExistsForGdpr)) && !$dpiaExistsForGdpr): 
        $isNew = isset($_GET['new_dpia']) || ($prefillGdprId && !$dpiaExistsForGdpr);
        $record = $editDpia ?: [];
        if ($prefillGdprId && $prefillRecord && !$dpiaExistsForGdpr) {
            $record['record_id'] = $prefillGdprId;
            $record['title'] = $record['title'] ?? $prefillTitle;
            $record['processing_activity_description'] = $record['processing_activity_description'] ?? ($prefillRecord['purpose_of_processing'] ?? '');
        }
        // Parse existing mitigation measures for pre-selection. Technical and
        // organizational measures are now stored separately on the record, so
        // no guessing is needed for records saved after this change. Older
        // records that only have the combined 'mitigation_measures' field
        // fall back to matching against the known option lists.
        if (!empty($record['technical_measures']) || !empty($record['organizational_measures'])) {
            $selectedMitigationTech = splitMeasureList($record['technical_measures'] ?? '');
            $selectedMitigationOrg = splitMeasureList($record['organizational_measures'] ?? '');
        } else {
            $selectedMitigationTech = [];
            $selectedMitigationOrg = [];
            $existingMitigation = !empty($record['mitigation_measures']) ? splitMeasureList($record['mitigation_measures']) : [];
            foreach ($existingMitigation as $item) {
                if (in_array($item, $allTechMeasuresOptions)) {
                    $selectedMitigationTech[] = $item;
                } elseif (in_array($item, $allOrgMeasuresOptions)) {
                    $selectedMitigationOrg[] = $item;
                } else {
                    // Ambiguous legacy value (not known as either type) - show it
                    // under technical so it isn't silently dropped; the user can
                    // move it with the new "type your own" fields if needed.
                    $selectedMitigationTech[] = $item;
                }
            }
        }
    ?>
    <div class="modal-overlay" id="dpiaModal" style="display:flex;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit" style="margin-right:10px;"></i> <?= $isNew ? t('new_dpia') : t('edit_dpia') . ' #'.$record['id'] ?></h3>
                <a href="?tab=dpia&lang=<?= $lang ?>" class="close-btn">&times;</a>
            </div>
            <?php if ($prefillGdprId && $prefillRecord && !$dpiaExistsForGdpr): ?>
                <div class="prefill-notice"><i class="fas fa-link"></i> <strong><?= t('dpia_for_gdpr') ?> #<?= $prefillGdprId ?></strong>: <?= htmlspecialchars($prefillRecord['processing_activity'] ?? '') ?></div>
            <?php endif; ?>
            <form method="POST" id="dpiaForm">
                <input type="hidden" name="action" value="save_dpia">
                <input type="hidden" name="id" value="<?= $record['id'] ?? '' ?>">
                <div class="modal-body">
                    <div class="form-group"><label><?= t('title') ?> *</label><input type="text" name="title" value="<?= htmlspecialchars($record['title'] ?? '') ?>" required></div>
                    <div class="form-group"><label><?= t('description') ?></label><textarea name="description" oninput="autoExpand(this)"><?= htmlspecialchars($record['description'] ?? '') ?></textarea></div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('gdpr_record_id') ?></label>
                            <input type="number" name="record_id" value="<?= $record['record_id'] ?? ($prefillGdprId ?? '') ?>" <?= !empty($prefillGdprId) ? 'readonly' : '' ?>>
                            <?php if (!empty($prefillGdprId)): ?>
                                <div style="font-size:10px; color:#888; margin-top:2px;"><?= t('gdpr_record') ?> #<?= $prefillGdprId ?> - <?= htmlspecialchars($prefillRecord['processing_activity'] ?? '') ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group"><label><?= t('risk_level') ?></label>
                            <select name="overall_risk_level">
                                <?php foreach ($riskLevels as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['overall_risk_level'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('department') ?></label>
                            <select name="department">
                                <option value="">-</option>
                                <?php
                                    // Dynamically inherit the department from the linked GDPR
                                    // record (gdpr_register.json) whenever the DPIA itself doesn't
                                    // have its own department saved yet — works both for a brand
                                    // new DPIA (via the prefill flow) and when editing an existing
                                    // DPIA that's linked via record_id.
                                    $dpiaDept = $record['department'] ?? '';
                                    if ($dpiaDept === '') {
                                        $linkedGdprId = $record['record_id'] ?? $prefillGdprId ?? null;
                                        if ($linkedGdprId) {
                                            $linkedGdpr = findRecord($gdprRecords, $linkedGdprId);
                                            if ($linkedGdpr) {
                                                $dpiaDept = $linkedGdpr['record']['department'] ?? '';
                                            }
                                        }
                                    }
                                ?>
                                <?php foreach ($departmentsList as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= $dpiaDept === $key ? 'selected' : '' ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="department_custom" placeholder="<?= t('or_type_custom_department') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('status') ?></label>
                            <select name="status">
                                <?php foreach ($dpiaStatuses as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['status'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="status_custom" placeholder="<?= t('or_type_custom_status') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                        <div class="form-group"><label><?= t('risk_origin') ?></label>
                            <select name="risk_origin">
                                <option value="">-</option>
                                <?php foreach ($riskOriginOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['risk_origin'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="risk_origin_custom" placeholder="<?= t('or_type_custom_risk_origin') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('affected_subjects') ?></label><input type="number" name="data_subjects_affected" value="<?= $record['data_subjects_affected'] ?? '' ?>"></div>
                        <div class="form-group"><label><?= t('management_approval') ?></label>
                            <select name="management_approval">
                                <?php foreach ($managementApprovalOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['management_approval'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="management_approval_custom" placeholder="<?= t('or_type_custom_approval') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('approved_by') ?></label>
                            <select name="approved_by">
                                <option value="">-</option>
                                <?php foreach ($allApprovedByNames as $n): ?>
                                    <option value="<?= htmlspecialchars($n) ?>" <?= ($record['approved_by'] ?? '') === $n ? 'selected' : '' ?>><?= htmlspecialchars($n) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="approved_by_custom" placeholder="<?= t('or_type_custom_name') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                        <div class="form-group"><label><?= t('approval_date') ?></label><input type="date" name="approval_date" value="<?= $record['approval_date'] ?? '' ?>"></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('review_date') ?></label><input type="date" name="review_date" value="<?= $record['review_date'] ?? '' ?>"></div>
                        <div class="form-group"><label><?= t('consultation_conducted') ?></label>
                            <select name="consultation_conducted">
                                <?php foreach ($consultationOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= (($record['consultation_conducted'] ?? 'no') === $key) ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="consultation_conducted_custom" placeholder="<?= t('or_type_custom_consultation') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                    </div>
                    <div class="form-group"><label><?= t('data_categories') ?></label><textarea name="data_categories" oninput="autoExpand(this)"><?= htmlspecialchars($record['data_categories'] ?? '') ?></textarea></div>
                    <div class="form-group"><label><?= t('processing_activity') ?></label><textarea name="processing_activity_description" oninput="autoExpand(this)"><?= htmlspecialchars($record['processing_activity_description'] ?? '') ?></textarea></div>
                    <div class="form-group"><label><?= t('necessity_test') ?></label><textarea name="necessity_test" oninput="autoExpand(this)"><?= htmlspecialchars($record['necessity_test'] ?? '') ?></textarea></div>
                    <div class="form-group"><label><?= t('proportionality_test') ?></label><textarea name="proportionality_test" oninput="autoExpand(this)"><?= htmlspecialchars($record['proportionality_test'] ?? '') ?></textarea></div>
                    
                    <!-- Mitigerende maatregelen - multi-select met ALLE opties, plus per type een eigen invoerveld -->
                    <div class="form-group">
                        <label><?= t('mitigation_measures') ?> - <?= t('technical') ?></label>
                        <select name="mitigation_technical_measures[]" multiple style="height:150px;">
                            <?php foreach ($allTechMeasuresOptions as $opt): ?>
                                <option value="<?= htmlspecialchars($opt) ?>" <?= in_array($opt, $selectedMitigationTech) ? 'selected' : '' ?>><?= htmlspecialchars($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div style="font-size:11px; color:#888; margin-top:2px;"><?= t('hold_ctrl_to_select_multiple') ?></div>
                        <input type="text" name="mitigation_technical_measures_custom" placeholder="<?= t('custom_mitigation_measures') ?>" style="width:100%;margin-top:4px;" value="">
                    </div>
                    <div class="form-group">
                        <label><?= t('mitigation_measures') ?> - <?= t('organizational') ?></label>
                        <select name="mitigation_organizational_measures[]" multiple style="height:150px;">
                            <?php foreach ($allOrgMeasuresOptions as $opt): ?>
                                <option value="<?= htmlspecialchars($opt) ?>" <?= in_array($opt, $selectedMitigationOrg) ? 'selected' : '' ?>><?= htmlspecialchars($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div style="font-size:11px; color:#888; margin-top:2px;"><?= t('hold_ctrl_to_select_multiple') ?></div>
                        <input type="text" name="mitigation_organizational_measures_custom" placeholder="<?= t('custom_mitigation_measures') ?>" style="width:100%;margin-top:4px;" value="">
                    </div>
                    
                    <div class="form-group"><label><?= t('residual_risk') ?></label><textarea name="residual_risk" oninput="autoExpand(this)"><?= htmlspecialchars($record['residual_risk'] ?? '') ?></textarea></div>
                    <div class="form-group"><label><?= t('recommendations') ?></label><textarea name="recommendations" oninput="autoExpand(this)"><?= htmlspecialchars($record['recommendations'] ?? '') ?></textarea></div>
                    <div class="form-group"><label><?= t('consultation_details') ?></label><textarea name="consultation_details" oninput="autoExpand(this)"><?= htmlspecialchars($record['consultation_details'] ?? '') ?></textarea></div>
                    <div class="form-group"><label><?= t('notes') ?></label><textarea name="notes" oninput="autoExpand(this)"><?= htmlspecialchars($record['notes'] ?? '') ?></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> <?= $isNew ? t('add') : t('save') ?></button>
                    <a href="?tab=dpia&lang=<?= $lang ?>" class="btn btn-secondary"><?= t('cancel') ?></a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         BREACH NEW/EDIT MODAL
         ============================================================ -->
    <?php if (isset($_GET['new_breach']) || $editBreach): 
        $isNew = isset($_GET['new_breach']);
        $record = $editBreach ?: [];
        // Parse existing measures for pre-selection
        $existingMeasures = splitMeasureList($record['measures_taken'] ?? '');
        $selectedMeasuresTech = [];
        $selectedMeasuresOrg = [];
        $customMeasures = '';
        foreach ($existingMeasures as $item) {
            if (in_array($item, $allTechMeasuresOptions)) {
                $selectedMeasuresTech[] = $item;
            } elseif (in_array($item, $allOrgMeasuresOptions)) {
                $selectedMeasuresOrg[] = $item;
            } else {
                $customMeasures .= (!empty($customMeasures) ? '; ' : '') . $item;
            }
        }
    ?>
    <div class="modal-overlay" id="breachModal" style="display:flex;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit" style="margin-right:10px;"></i> <?= $isNew ? t('new_breach') : t('edit_breach') . ' #'.$record['id'] ?></h3>
                <a href="?tab=breach&lang=<?= $lang ?>" class="close-btn">&times;</a>
            </div>
            <form method="POST" id="breachForm">
                <input type="hidden" name="action" value="save_breach">
                <input type="hidden" name="id" value="<?= $record['id'] ?? '' ?>">
                <div class="modal-body">
                    <div class="form-group"><label><?= t('title') ?> *</label><input type="text" name="title" value="<?= htmlspecialchars($record['title'] ?? '') ?>" required></div>
                    <div class="form-group"><label><?= t('description') ?> *</label><textarea name="description" oninput="autoExpand(this)"><?= htmlspecialchars($record['description'] ?? '') ?></textarea></div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('breach_date') ?> *</label><input type="date" name="breach_date" value="<?= $record['breach_date'] ?? '' ?>"></div>
                        <div class="form-group"><label><?= t('discovery_date') ?> *</label><input type="date" name="discovery_date" value="<?= $record['discovery_date'] ?? '' ?>"></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('department') ?></label>
                            <?php
                                $breachDeptValue = $record['department'] ?? '';
                                $breachDeptInList = $breachDeptValue !== '' && isset($departmentsListFromGdpr[$breachDeptValue]);
                                $breachDeptCustomPrefill = ($breachDeptValue !== '' && !$breachDeptInList) ? $breachDeptValue : '';
                            ?>
                            <select name="department">
                                <option value="">-</option>
                                <?php foreach ($departmentsListFromGdpr as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= $breachDeptValue === $key ? 'selected' : '' ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="department_custom" placeholder="<?= t('or_type_custom_department') ?>" style="width:100%;margin-top:4px;" value="<?= htmlspecialchars($breachDeptCustomPrefill) ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('breach_type') ?></label>
                            <select name="breach_type">
                                <option value="">-</option>
                                <?php foreach ($breachTypes as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['breach_type'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="breach_type_custom" placeholder="<?= t('or_type_custom_breach_type') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                        <div class="form-group"><label><?= t('risk_level') ?></label>
                            <select name="risk_level">
                                <?php foreach ($riskLevels as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['risk_level'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('status') ?></label>
                            <select name="status">
                                <?php foreach ($breachStatuses as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['status'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label><?= t('affected_subjects') ?></label><input type="number" name="affected_data_subjects" value="<?= $record['affected_data_subjects'] ?? '' ?>"></div>
                    </div>
                    <div class="form-group"><label><?= t('personal_data') ?> *</label><textarea name="personal_data_affected" oninput="autoExpand(this)"><?= htmlspecialchars($record['personal_data_affected'] ?? '') ?></textarea></div>
                    <div class="form-group"><label><?= t('causes') ?> *</label><textarea name="causes" oninput="autoExpand(this)"><?= htmlspecialchars($record['causes'] ?? '') ?></textarea></div>
                    
                    <!-- Genomen maatregelen - multi-select met ALLE opties -->
                    <div class="form-group">
                        <label><?= t('measures_taken') ?> - <?= t('technical') ?></label>
                        <select name="breach_technical_measures[]" multiple style="height:150px;">
                            <?php foreach ($allTechMeasuresOptions as $opt): ?>
                                <option value="<?= htmlspecialchars($opt) ?>" <?= in_array($opt, $selectedMeasuresTech) ? 'selected' : '' ?>><?= htmlspecialchars($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div style="font-size:11px; color:#888; margin-top:2px;"><?= t('hold_ctrl_to_select_multiple') ?></div>
                    </div>
                    <div class="form-group">
                        <label><?= t('measures_taken') ?> - <?= t('organizational') ?></label>
                        <select name="breach_organizational_measures[]" multiple style="height:150px;">
                            <?php foreach ($allOrgMeasuresOptions as $opt): ?>
                                <option value="<?= htmlspecialchars($opt) ?>" <?= in_array($opt, $selectedMeasuresOrg) ? 'selected' : '' ?>><?= htmlspecialchars($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div style="font-size:11px; color:#888; margin-top:2px;"><?= t('hold_ctrl_to_select_multiple') ?></div>
                    </div>
                    <div class="form-group">
                        <label><?= t('custom_measures_taken') ?></label>
                        <input type="text" name="breach_measures_custom" placeholder="<?= t('custom_measures_placeholder') ?>" style="width:100%;" value="<?= htmlspecialchars($customMeasures) ?>">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group"><label><?= t('notified_authority') ?></label>
                            <select name="notified_authority">
                                <?php foreach ($yesNoProgressOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['notified_authority'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label><?= t('notification_date') ?></label><input type="date" name="notification_date" value="<?= $record['notification_date'] ?? '' ?>"></div>
                    </div>
                    <div class="form-group"><label><?= t('notified_affected') ?></label>
                        <select name="notified_affected_persons">
                            <?php foreach ($yesNoProgressOptions as $key => $label): ?>
                                <option value="<?= $key ?>" <?= ($record['notified_affected_persons'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> <?= $isNew ? t('add') : t('save') ?></button>
                    <a href="?tab=breach&lang=<?= $lang ?>" class="btn btn-secondary"><?= t('cancel') ?></a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         THIRD PARTY NEW/EDIT MODAL
         ============================================================ -->
    <?php if (isset($_GET['new_thirdparty']) || $editThirdparty): 
        $isNew = isset($_GET['new_thirdparty']);
        $record = $editThirdparty ?: [];
        // Decode ROT47 fields for display in edit form
        $thirdPartyDisplayFields = ['company_name', 'contact_person', 'email', 'phone', 'address'];
        foreach ($thirdPartyDisplayFields as $field) {
            if (isset($record[$field]) && !empty($record[$field])) {
                $record[$field . '_display'] = rot47decode($record[$field]);
            } else {
                $record[$field . '_display'] = '';
            }
        }
    ?>
    <div class="modal-overlay" id="thirdpartyModal" style="display:flex;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit" style="margin-right:10px;"></i> <?= $isNew ? t('new_third_party') : t('edit_third_party') . ' #'.$record['id'] ?></h3>
                <a href="?tab=thirdparty&lang=<?= $lang ?>" class="close-btn">&times;</a>
            </div>
            <form method="POST" id="thirdpartyForm">
                <input type="hidden" name="action" value="save_thirdparty">
                <input type="hidden" name="id" value="<?= $record['id'] ?? '' ?>">
                <div class="modal-body">
                    <div class="form-group"><label><?= t('company_name') ?> *</label><input type="text" name="company_name" value="<?= htmlspecialchars($record['company_name_display'] ?? '') ?>" required></div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('contact_person') ?></label><input type="text" name="contact_person" value="<?= htmlspecialchars($record['contact_person_display'] ?? '') ?>"></div>
                        <div class="form-group"><label><?= t('email') ?></label><input type="email" name="email" value="<?= htmlspecialchars($record['email_display'] ?? '') ?>"></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('phone') ?></label><input type="text" name="phone" value="<?= htmlspecialchars($record['phone_display'] ?? '') ?>"></div>
                        <div class="form-group"><label><?= t('address') ?></label><input type="text" name="address" value="<?= htmlspecialchars($record['address_display'] ?? '') ?>"></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('department') ?></label>
                            <?php
                                $thirdpartyDeptValue = $record['department'] ?? '';
                                $thirdpartyDeptInList = $thirdpartyDeptValue !== '' && isset($departmentsListFromGdpr[$thirdpartyDeptValue]);
                                $thirdpartyDeptCustomPrefill = ($thirdpartyDeptValue !== '' && !$thirdpartyDeptInList) ? $thirdpartyDeptValue : '';
                            ?>
                            <select name="department">
                                <option value="">-</option>
                                <?php foreach ($departmentsListFromGdpr as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= $thirdpartyDeptValue === $key ? 'selected' : '' ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="department_custom" placeholder="<?= t('or_type_custom_department') ?>" style="width:100%;margin-top:4px;" value="<?= htmlspecialchars($thirdpartyDeptCustomPrefill) ?>">
                        </div>
                    </div>
                    <div class="form-group"><label><?= t('service_provided') ?> *</label><textarea name="service_provided" oninput="autoExpand(this)"><?= htmlspecialchars($record['service_provided'] ?? '') ?></textarea></div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('agreement_signed') ?></label>
                            <select name="processing_agreement_signed">
                                <?php foreach ($agreementSignedOptions as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['processing_agreement_signed'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="processing_agreement_signed_custom" placeholder="<?= t('or_type_custom_consultation') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                        <div class="form-group"><label><?= t('compliance_status') ?></label>
                            <select name="compliance_status">
                                <?php foreach ($complianceStatuses as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($record['compliance_status'] ?? '') === $key ? 'selected' : '' ?>><?= t($key) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="compliance_status_custom" placeholder="<?= t('or_type_custom_compliance_status') ?>" style="width:100%;margin-top:4px;" value="">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label><?= t('agreement_date') ?></label><input type="date" name="agreement_date" value="<?= $record['agreement_date'] ?? '' ?>"></div>
                        <div class="form-group"><label><?= t('expiry_date') ?></label><input type="date" name="agreement_expiry_date" value="<?= $record['agreement_expiry_date'] ?? '' ?>"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> <?= $isNew ? t('add') : t('save') ?></button>
                    <a href="?tab=thirdparty&lang=<?= $lang ?>" class="btn btn-secondary"><?= t('cancel') ?></a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         GDPR VIEW MODAL
         ============================================================ -->
    <?php if ($viewRecord): ?>
    <div class="modal-overlay" id="viewGdprModal" style="display:flex;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-file-alt" style="margin-right:10px;"></i> <?= t('gdpr_record') ?> #<?= $viewRecord['id'] ?></h3>
                <a href="?tab=gdpr&lang=<?= $lang ?>" class="close-btn">&times;</a>
            </div>
            <div class="modal-body">
                <div class="detail-grid">
                    <div class="detail-item full-width"><span class="label"><?= t('processing_activity') ?></span><span class="value"><?= htmlspecialchars($viewRecord['processing_activity'] ?? '-') ?></span></div>
                    <div class="detail-item full-width"><span class="label"><?= t('purpose') ?></span><span class="value"><?= htmlspecialchars($viewRecord['purpose_of_processing'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('data_subjects') ?></span><span class="value"><?= htmlspecialchars($viewRecord['categories_data_subjects'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('legal_basis') ?></span><span class="value"><?= htmlspecialchars(getLegalBasisLabel($viewRecord['legal_basis'] ?? 'contract')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('risk_level') ?></span><span class="value"><span class="badge <?= getRiskClass($viewRecord['risk_level'] ?? 'low') ?>"><?= t($viewRecord['risk_level'] ?? 'low') ?></span></span></div>
                    <div class="detail-item"><span class="label"><?= t('status') ?></span><span class="value"><span class="badge <?= getStatusClass($viewRecord['status'] ?? 'active') ?>"><?= t($viewRecord['status'] ?? 'active') ?></span></span></div>
                    <div class="detail-item"><span class="label"><?= t('retention_period') ?></span><span class="value"><?= htmlspecialchars($viewRecord['retention_periods'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('dpia_required') ?></span><span class="value"><?= getYesNoLabel($viewRecord['dpia_required'] ?? 'no') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($viewRecord['department'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('dpia_status') ?></span><span class="value"><span class="badge <?= getStatusClass($viewRecord['dpia_status'] ?? 'not_required') ?>"><?= t($viewRecord['dpia_status'] ?? 'not_required') ?></span></span></div>
                    <div class="detail-item"><span class="label"><?= t('international_transfer') ?></span><span class="value"><?= ucfirst($viewRecord['is_international_data_transfers'] ?? 'unknown') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('to_country') ?></span><span class="value"><?= htmlspecialchars($viewRecord['to_country'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('we_are_processor') ?></span><span class="value"><?= getYesNoLabel($viewRecord['we_are_processor'] ?? 'no') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('processing_agreement_third_party') ?></span><span class="value"><?= getYesNoLabel($viewRecord['has_processing_agreement_with_third_party'] ?? 'no') ?></span></div>
                    
                    <div class="detail-item full-width" style="background:#f8f8f8;padding:10px;margin-top:6px;border:1px solid #ddd;">
                        <span class="label" style="font-size:12px;"><?= t('controller') ?></span>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:4px;">
                            <div><span style="color:#666;font-size:11px;"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($viewRecord['name_data_controller']) ? rot47decode($viewRecord['name_data_controller']) : '-') ?></div>
                            <div><span style="color:#666;font-size:11px;"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($viewRecord['contact_data_controller']) ? rot47decode($viewRecord['contact_data_controller']) : '-') ?></div>
                        </div>
                    </div>
                    
                    <div class="detail-item full-width" style="background:#f8f8f8;padding:10px;border:1px solid #ddd;">
                        <span class="label" style="font-size:12px;"><?= t('joint_controller') ?></span>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:4px;">
                            <div><span style="color:#666;font-size:11px;"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($viewRecord['name_joint_data_controller']) ? rot47decode($viewRecord['name_joint_data_controller']) : '-') ?></div>
                            <div><span style="color:#666;font-size:11px;"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($viewRecord['contact_joint_data_controller']) ? rot47decode($viewRecord['contact_joint_data_controller']) : '-') ?></div>
                        </div>
                    </div>
                    
                    <div class="detail-item full-width" style="background:#f8f8f8;padding:10px;border:1px solid #ddd;">
                        <span class="label" style="font-size:12px;"><?= t('dpo') ?></span>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:4px;">
                            <div><span style="color:#666;font-size:11px;"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($viewRecord['name_dpo']) ? rot47decode($viewRecord['name_dpo']) : '-') ?></div>
                            <div><span style="color:#666;font-size:11px;"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($viewRecord['contact_dpo']) ? rot47decode($viewRecord['contact_dpo']) : '-') ?></div>
                        </div>
                    </div>
                    
                    <div class="detail-item full-width" style="background:#f8f8f8;padding:10px;border:1px solid #ddd;">
                        <span class="label" style="font-size:12px;"><?= t('representative') ?></span>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:4px;">
                            <div><span style="color:#666;font-size:11px;"><?= t('name') ?>:</span> <?= htmlspecialchars(!empty($viewRecord['name_representative']) ? rot47decode($viewRecord['name_representative']) : '-') ?></div>
                            <div><span style="color:#666;font-size:11px;"><?= t('contact') ?>:</span> <?= htmlspecialchars(!empty($viewRecord['contact_representative']) ? rot47decode($viewRecord['contact_representative']) : '-') ?></div>
                        </div>
                    </div>
                    
                    <div class="detail-item full-width"><span class="label"><?= t('technical_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewRecord['technical_measures'] ?? '-')) ?></span></div>
                    <div class="detail-item full-width"><span class="label"><?= t('organizational_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewRecord['organizational_measures'] ?? '-')) ?></span></div>
                    <div class="detail-item full-width"><span class="label"><?= t('safeguards') ?></span><span class="value"><?= nl2br(htmlspecialchars(displaySafeguards($viewRecord['safeguards'] ?? ''))) ?></span></div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="?tab=gdpr&edit_gdpr=<?= $viewRecord['id'] ?>&lang=<?= $lang ?>" class="btn btn-warning"><i class="fas fa-edit"></i> <?= t('edit') ?></a>
                <a href="?tab=gdpr&lang=<?= $lang ?>" class="btn btn-secondary"><?= t('close') ?></a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         DPIA VIEW MODAL
         ============================================================ -->
    <?php if ($viewDpia): ?>
    <div class="modal-overlay" id="viewDpiaModal" style="display:flex;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-balance-scale" style="margin-right:10px;"></i> <?= t('dpia') ?> #<?= $viewDpia['id'] ?></h3>
                <a href="?tab=dpia&lang=<?= $lang ?>" class="close-btn">&times;</a>
            </div>
            <div class="modal-body">
                <div class="detail-grid">
                    <div class="detail-item full-width"><span class="label"><?= t('title') ?></span><span class="value"><?= htmlspecialchars($viewDpia['title'] ?? '-') ?></span></div>
                    <div class="detail-item full-width"><span class="label"><?= t('description') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewDpia['description'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('gdpr_record') ?></span><span class="value"><?= !empty($viewDpia['record_id']) ? '#'.$viewDpia['record_id'] : '-' ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($viewDpia['department'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('risk_level') ?></span><span class="value"><span class="badge <?= getRiskClass($viewDpia['overall_risk_level'] ?? 'medium') ?>"><?= t($viewDpia['overall_risk_level'] ?? 'medium') ?></span></span></div>
                    <div class="detail-item"><span class="label"><?= t('status') ?></span><span class="value"><span class="badge <?= getStatusClass($viewDpia['status'] ?? 'draft') ?>"><?= t($viewDpia['status'] ?? 'draft') ?></span></span></div>
                    <div class="detail-item"><span class="label"><?= t('affected_subjects') ?></span><span class="value"><?= $viewDpia['data_subjects_affected'] ?? '-' ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('management_approval') ?></span><span class="value"><?= htmlspecialchars($viewDpia['management_approval'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('approved_by') ?></span><span class="value"><?= htmlspecialchars($viewDpia['approved_by'] ?? '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('approval_date') ?></span><span class="value"><?= formatDate($viewDpia['approval_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('review_date') ?></span><span class="value"><?= formatDate($viewDpia['review_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('consultation_conducted') ?></span><span class="value"><?= getYesNoLabel($viewDpia['consultation_conducted'] ?? 'no') ?></span></div>
                    <?php if (!empty($viewDpia['necessity_test'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('necessity_test') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewDpia['necessity_test'])) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($viewDpia['proportionality_test'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('proportionality_test') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewDpia['proportionality_test'])) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($viewDpia['mitigation_measures'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('mitigation_measures') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewDpia['mitigation_measures'])) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($viewDpia['residual_risk'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('residual_risk') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewDpia['residual_risk'])) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($viewDpia['recommendations'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('recommendations') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewDpia['recommendations'])) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($viewDpia['consultation_details'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('consultation_details') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewDpia['consultation_details'])) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($viewDpia['notes'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('notes') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewDpia['notes'])) ?></span></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="modal-footer">
                <a href="?tab=dpia&edit_dpia=<?= $viewDpia['id'] ?>&lang=<?= $lang ?>" class="btn btn-warning"><i class="fas fa-edit"></i> <?= t('edit') ?></a>
                <a href="?tab=dpia&lang=<?= $lang ?>" class="btn btn-secondary"><?= t('close') ?></a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         BREACH VIEW MODAL
         ============================================================ -->
    <?php if ($viewBreach): ?>
    <div class="modal-overlay" id="viewBreachModal" style="display:flex;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle" style="margin-right:10px;"></i> <?= t('breach') ?> #<?= $viewBreach['id'] ?></h3>
                <a href="?tab=breach&lang=<?= $lang ?>" class="close-btn">&times;</a>
            </div>
            <div class="modal-body">
                <div class="detail-grid">
                    <div class="detail-item full-width"><span class="label"><?= t('title') ?></span><span class="value"><?= htmlspecialchars($viewBreach['title'] ?? '-') ?></span></div>
                    <div class="detail-item full-width"><span class="label"><?= t('description') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewBreach['description'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('breach_date') ?></span><span class="value"><?= formatDate($viewBreach['breach_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('discovery_date') ?></span><span class="value"><?= formatDate($viewBreach['discovery_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($viewBreach['department'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('breach_type') ?></span><span class="value"><?= getBreachTypeLabel($viewBreach['breach_type'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('risk_level') ?></span><span class="value"><span class="badge <?= getRiskClass($viewBreach['risk_level'] ?? 'low') ?>"><?= t($viewBreach['risk_level'] ?? 'low') ?></span></span></div>
                    <div class="detail-item"><span class="label"><?= t('status') ?></span><span class="value"><span class="badge <?= getStatusClass($viewBreach['status'] ?? 'open') ?>"><?= t($viewBreach['status'] ?? 'open') ?></span></span></div>
                    <div class="detail-item"><span class="label"><?= t('affected_subjects') ?></span><span class="value"><?= $viewBreach['affected_data_subjects'] ?? '-' ?></span></div>
                    <?php if (!empty($viewBreach['causes'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('causes') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewBreach['causes'])) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($viewBreach['measures_taken'])): ?>
                        <div class="detail-item full-width"><span class="label"><?= t('measures_taken') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewBreach['measures_taken'])) ?></span></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="modal-footer">
                <a href="?tab=breach&edit_breach=<?= $viewBreach['id'] ?>&lang=<?= $lang ?>" class="btn btn-warning"><i class="fas fa-edit"></i> <?= t('edit') ?></a>
                <a href="?tab=breach&lang=<?= $lang ?>" class="btn btn-secondary"><?= t('close') ?></a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         THIRD PARTY VIEW MODAL
         ============================================================ -->
    <?php if ($viewThirdparty): ?>
    <div class="modal-overlay" id="viewThirdpartyModal" style="display:flex;">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-handshake" style="margin-right:10px;"></i> <?= t('third_party') ?> #<?= $viewThirdparty['id'] ?></h3>
                <a href="?tab=thirdparty&lang=<?= $lang ?>" class="close-btn">&times;</a>
            </div>
            <div class="modal-body">
                <div class="detail-grid">
                    <div class="detail-item full-width"><span class="label"><?= t('company_name') ?></span><span class="value"><?= htmlspecialchars(!empty($viewThirdparty['company_name']) ? rot47decode($viewThirdparty['company_name']) : '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('contact_person') ?></span><span class="value"><?= htmlspecialchars(!empty($viewThirdparty['contact_person']) ? rot47decode($viewThirdparty['contact_person']) : '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('email') ?></span><span class="value"><?= htmlspecialchars(!empty($viewThirdparty['email']) ? rot47decode($viewThirdparty['email']) : '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('phone') ?></span><span class="value"><?= htmlspecialchars(!empty($viewThirdparty['phone']) ? rot47decode($viewThirdparty['phone']) : '-') ?></span></div>
                    <div class="detail-item full-width"><span class="label"><?= t('address') ?></span><span class="value"><?= htmlspecialchars(!empty($viewThirdparty['address']) ? rot47decode($viewThirdparty['address']) : '-') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('department') ?></span><span class="value"><?= htmlspecialchars(getDepartmentLabel($viewThirdparty['department'] ?? '-')) ?></span></div>
                    <div class="detail-item full-width"><span class="label"><?= t('service_provided') ?></span><span class="value"><?= nl2br(htmlspecialchars($viewThirdparty['service_provided'] ?? '-')) ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('agreement_signed') ?></span><span class="value"><?= getYesNoLabel($viewThirdparty['processing_agreement_signed'] ?? 'no') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('compliance_status') ?></span><span class="value"><span class="badge <?= getStatusClass($viewThirdparty['compliance_status'] ?? 'review_needed') ?>"><?= getComplianceStatusLabel($viewThirdparty['compliance_status'] ?? 'review_needed') ?></span></span></div>
                    <div class="detail-item"><span class="label"><?= t('agreement_date') ?></span><span class="value"><?= formatDate($viewThirdparty['agreement_date'] ?? '') ?></span></div>
                    <div class="detail-item"><span class="label"><?= t('expiry_date') ?></span><span class="value"><?= formatDate($viewThirdparty['agreement_expiry_date'] ?? '') ?></span></div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="?tab=thirdparty&edit_thirdparty=<?= $viewThirdparty['id'] ?>&lang=<?= $lang ?>" class="btn btn-warning"><i class="fas fa-edit"></i> <?= t('edit') ?></a>
                <a href="?tab=thirdparty&lang=<?= $lang ?>" class="btn btn-secondary"><?= t('close') ?></a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         FOOTER
         ============================================================ -->
    <div class="footer">
         <?= htmlspecialchars($companyName) ?> ·  <?= date('d-m-Y H:i') ?>
    </div>

</div>

<!-- ============================================================
     DELETE CONFIRMATION FORM
     ============================================================ -->
<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="tab" id="deleteTab" value="">
    <input type="hidden" name="action" id="deleteAction" value="">
    <input type="hidden" name="id" id="deleteId" value="">
    <input type="hidden" name="lang" value="<?= $lang ?>">
</form>

<!-- ============================================================
     ZIP BACKUP - PASSWORD ENTRY MODAL
     ============================================================ -->
<div class="pwmodal-overlay" id="zipPasswordModal">
    <div class="pwmodal-content">
        <div class="pwmodal-header">
            <h3><i class="fas fa-lock" style="margin-right:8px;"></i> ZIP-backup wachtwoord</h3>
            <a href="javascript:void(0)" class="close-btn" onclick="closeZipPasswordModal()">&times;</a>
        </div>
        <div class="pwmodal-body">
            <p style="font-size:13px; color:#444; margin-top:0;">
                Stel een wachtwoord in om de ZIP-backup (gdpr_register.json, dpia_registrations.json,
                data_breaches.json, third_parties.json) te versleutelen. Bewaar dit wachtwoord goed:
                zonder wachtwoord kan de backup niet worden geopend.
            </p>
            <div id="zipPasswordError" class="pwmodal-error" style="display:none;"></div>
            <div class="form-group">
                <label>Wachtwoord</label>
                <input type="password" id="zipPasswordInput" autocomplete="new-password">
            </div>
            <div class="pwmodal-hint">Minimaal 6 tekens.</div>
            <div class="form-group">
                <label>Bevestig wachtwoord</label>
                <input type="password" id="zipPasswordConfirmInput" autocomplete="new-password">
            </div>
        </div>
        <div class="pwmodal-footer">
            <button type="button" class="btn-backup" style="background:#888; border-color:#888;" onclick="closeZipPasswordModal()">Annuleren</button>
            <button type="button" class="btn-backup" onclick="submitZipPassword()"><i class="fas fa-file-archive"></i> Download ZIP</button>
        </div>
    </div>
</div>
<form method="POST" id="zipBackupForm" style="display:none;" action="?action=zipbackup&lang=<?= $lang ?>">
    <input type="hidden" name="zip_password" id="zipBackupPasswordField" value="">
    <input type="hidden" name="zip_password_confirm" id="zipBackupPasswordConfirmField" value="">
</form>

<!-- ============================================================
     MEASURE EDIT MODAL (rename a measure everywhere it's used)
     ============================================================ -->
<div class="pwmodal-overlay" id="measureEditModal">
    <div class="pwmodal-content" id="measureEditModalContent">
        <div class="pwmodal-header">
            <h3><i class="fas fa-edit" style="margin-right:8px;"></i> <?= t('edit_measure') ?></h3>
            <a href="javascript:void(0)" class="close-btn" onclick="closeMeasureEditModal()">&times;</a>
        </div>
        <form method="POST" id="measureEditForm" action="?lang=<?= $lang ?>">
            <div class="pwmodal-body">
                <p style="font-size:13px; color:#444; margin-top:0;"><?= t('measure_rename_warning') ?></p>
                <input type="hidden" name="action" value="rename_measure">
                <input type="hidden" name="measure_type" id="measureEditType" value="">
                <input type="hidden" name="old_measure" id="measureEditOldValue" value="">
                <div class="form-group">
                    <label><?= t('current_measure') ?></label>
                    <textarea id="measureEditCurrentDisplay" disabled style="background:#f0f0f0; width:100%; box-sizing:border-box; font-family:inherit; font-size:13px; padding:8px 10px; border:1px solid #999; resize:vertical;" rows="1"></textarea>
                </div>
                <div class="form-group">
                    <label><?= t('new_measure_name') ?></label>
                    <textarea name="new_measure" id="measureEditNewValue" autocomplete="off" required style="width:100%; box-sizing:border-box; font-family:inherit; font-size:13px; padding:8px 10px; border:1px solid #999; resize:vertical;" rows="1"></textarea>
                </div>
            </div>
            <div class="pwmodal-footer">
                <button type="button" class="btn-backup" style="background:#888; border-color:#888;" onclick="closeMeasureEditModal()"><?= t('cancel') ?></button>
                <button type="submit" class="btn-backup"><i class="fas fa-save"></i> <?= t('save') ?></button>
            </div>
        </form>
    </div>
</div>
<form method="POST" id="measureDeleteForm" style="display:none;" action="?lang=<?= $lang ?>">
    <input type="hidden" name="action" value="delete_measure">
    <input type="hidden" name="measure_type" id="measureDeleteType" value="">
    <input type="hidden" name="old_measure" id="measureDeleteOldValue" value="">
</form>

<!-- ============================================================
     DYNAMIC VALUE EDIT MODAL (rename department/risk origin/DPIA
     status/approval/consultation/approved-by/contact name everywhere
     it's used)
     ============================================================ -->
<div class="pwmodal-overlay" id="dynValueEditModal">
    <div class="pwmodal-content">
        <div class="pwmodal-header">
            <h3><i class="fas fa-edit" style="margin-right:8px;"></i> <?= t('edit_value') ?></h3>
            <a href="javascript:void(0)" class="close-btn" onclick="closeDynValueEditModal()">&times;</a>
        </div>
        <form method="POST" id="dynValueEditForm" action="?lang=<?= $lang ?>">
            <div class="pwmodal-body">
                <p style="font-size:13px; color:#444; margin-top:0;"><?= t('value_rename_warning') ?></p>
                <input type="hidden" name="action" value="rename_dynamic_value">
                <input type="hidden" name="field_type" id="dynValueEditType" value="">
                <input type="hidden" name="old_value" id="dynValueEditOldValue" value="">
                <div class="form-group">
                    <label><?= t('current_value') ?></label>
                    <input type="text" id="dynValueEditCurrentDisplay" value="" disabled style="background:#f0f0f0;">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label><?= t('new_value') ?></label>
                    <input type="text" name="new_value" id="dynValueEditNewValue" autocomplete="off" required>
                </div>
            </div>
            <div class="pwmodal-footer">
                <button type="button" class="btn-backup" style="background:#888; border-color:#888;" onclick="closeDynValueEditModal()"><?= t('cancel') ?></button>
                <button type="submit" class="btn-backup"><i class="fas fa-save"></i> <?= t('save') ?></button>
            </div>
        </form>
    </div>
</div>
<form method="POST" id="dynValueDeleteForm" style="display:none;" action="?lang=<?= $lang ?>">
    <input type="hidden" name="action" value="delete_dynamic_value">
    <input type="hidden" name="field_type" id="dynValueDeleteType" value="">
    <input type="hidden" name="old_value" id="dynValueDeleteOldValue" value="">
</form>

<!-- ============================================================
     JAVASCRIPT - MODAL CLICK OUTSIDE, ESC, DELETE, AUTO EXPAND
     ============================================================ -->
<script>
    // --- SCROLL POSITION MEMORY -------------------------------------------
    // Editen/bekijken van een AVG-, DPIA-, datalek-, derde partij- of
    // configuratie-item gebeurt via een normale paginanavigatie (link/POST).
    // De browser zet de scrollbar daarbij standaard bovenaan, nog voordat de
    // modal zichtbaar wordt. Hierdoor moest je na het sluiten van de modal
    // steeds opnieuw naar beneden scrollen om het volgende item te bewerken.
    // Onderstaande code onthoudt de scrollpositie per tab (via
    // sessionStorage) vlak voordat je een link binnen dezelfde tab opent of
    // een formulier verstuurt, en zet die positie direct na het laden van de
    // volgende pagina weer terug - nog voordat de gebruiker iets ziet.
    (function() {
        var currentTab = <?= json_encode($activeTab) ?>;
        var STORAGE_KEY = 'gdprapp_scroll_' + currentTab;

        // Voorkom dat de browser zelf ook nog aan scrollherstel gaat doen.
        if ('scrollRestoration' in history) {
            try { history.scrollRestoration = 'manual'; } catch (e) {}
        }

        function restoreScroll() {
            var saved = sessionStorage.getItem(STORAGE_KEY);
            if (saved !== null) {
                window.scrollTo(0, parseInt(saved, 10) || 0);
            }
        }
        // Meerdere keren proberen: meteen, na DOMContentLoaded, en nogmaals
        // na volledig laden (o.a. lettertypen/iconen en het automatisch
        // meegroeien van tekstvelden - zie autoExpand - kunnen de pagina na
        // het eerste herstel nog een fractie in hoogte laten verschuiven,
        // wat bij tabbladen met veel tekst zoals datalekken zichtbaar werd
        // als een klein verschil in scrollpositie).
        restoreScroll();
        document.addEventListener('DOMContentLoaded', restoreScroll);
        window.addEventListener('load', function() {
            restoreScroll();
            // Nog een laatste correctie nadat de browser alle late reflows
            // (lettertypen, iconen) heeft verwerkt.
            requestAnimationFrame(function() {
                requestAnimationFrame(restoreScroll);
            });
        });
        if (window.document && document.fonts && document.fonts.ready) {
            document.fonts.ready.then(restoreScroll).catch(function() {});
        }

        function rememberScroll() {
            try { sessionStorage.setItem(STORAGE_KEY, String(window.scrollY)); } catch (e) {}
        }

        // Bij elke klik op een link die binnen dezelfde tab blijft (bewerken,
        // bekijken, modal sluiten/annuleren, filteren, ...) de huidige
        // scrollpositie opslaan vlak voor de paginanavigatie.
        document.addEventListener('click', function(e) {
            var link = e.target.closest('a[href]');
            if (!link) return;
            var href = link.getAttribute('href') || '';
            if (href.indexOf('?') !== 0) return;
            var match = href.match(/[?&]tab=([^&]+)/);
            var targetTab = match ? decodeURIComponent(match[1]) : currentTab;
            if (targetTab === currentTab) rememberScroll();
        }, true);

        // Bij versturen van een formulier (bv. AVG/DPIA/datalek/derde
        // opslaan, of een maatregel/configuratiewaarde hernoemen/verwijderen)
        // ook de scrollpositie bewaren; deze acties laden altijd dezelfde
        // tab opnieuw.
        document.addEventListener('submit', function() {
            rememberScroll();
        }, true);
    })();

    // --- ZIP BACKUP PASSWORD MODAL ---
    function openZipPasswordModal() {
        var modal = document.getElementById('zipPasswordModal');
        var errorBox = document.getElementById('zipPasswordError');
        document.getElementById('zipPasswordInput').value = '';
        document.getElementById('zipPasswordConfirmInput').value = '';
        errorBox.style.display = 'none';
        errorBox.textContent = '';
        modal.classList.add('open');
        setTimeout(function() {
            document.getElementById('zipPasswordInput').focus();
        }, 50);
    }

    function closeZipPasswordModal() {
        document.getElementById('zipPasswordModal').classList.remove('open');
    }

    function submitZipPassword() {
        var pw = document.getElementById('zipPasswordInput').value;
        var pwConfirm = document.getElementById('zipPasswordConfirmInput').value;
        var errorBox = document.getElementById('zipPasswordError');

        if (!pw || pw.length < 6) {
            errorBox.textContent = 'Wachtwoord moet minimaal 6 tekens bevatten.';
            errorBox.style.display = 'block';
            return;
        }
        if (pw !== pwConfirm) {
            errorBox.textContent = 'De wachtwoorden komen niet overeen.';
            errorBox.style.display = 'block';
            return;
        }

        document.getElementById('zipBackupPasswordField').value = pw;
        document.getElementById('zipBackupPasswordConfirmField').value = pwConfirm;
        closeZipPasswordModal();
        document.getElementById('zipBackupForm').submit();
    }

    // Allow closing the password modal by clicking the dark overlay
    document.addEventListener('click', function(e) {
        var modal = document.getElementById('zipPasswordModal');
        if (e.target === modal) {
            closeZipPasswordModal();
        }
    });

    // Submit on Enter key inside the password fields
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            var modal = document.getElementById('zipPasswordModal');
            if (modal && modal.classList.contains('open')) {
                var active = document.activeElement;
                if (active && (active.id === 'zipPasswordInput' || active.id === 'zipPasswordConfirmInput')) {
                    e.preventDefault();
                    submitZipPassword();
                }
            }
        }
    });

    // --- MEASURE EDIT MODAL ---
    function openMeasureEditModal(type, currentValue) {
        var modal = document.getElementById('measureEditModal');
        var modalContent = document.getElementById('measureEditModalContent');
        document.getElementById('measureEditType').value = type;
        document.getElementById('measureEditOldValue').value = currentValue;
        var currentDisplay = document.getElementById('measureEditCurrentDisplay');
        var newValueInput = document.getElementById('measureEditNewValue');
        currentDisplay.value = currentValue;
        newValueInput.value = currentValue;

        // Size the modal to the length of the value: short measures keep the
        // compact default width, long ones get a wider modal (capped so it
        // never overflows the viewport) so the full text stays readable.
        var len = (currentValue || '').length;
        var width = Math.max(420, Math.min(900, len * 7 + 160));
        modalContent.style.maxWidth = width + 'px';

        modal.classList.add('open');
        setTimeout(function() {
            autoExpand(currentDisplay);
            autoExpand(newValueInput);
            newValueInput.focus();
            newValueInput.select();
        }, 50);
    }

    function closeMeasureEditModal() {
        document.getElementById('measureEditModal').classList.remove('open');
        document.getElementById('measureEditModalContent').style.maxWidth = '';
    }

    function confirmDeleteMeasure(type, value) {
        if (confirm('<?= t('confirm_delete_measure') ?>')) {
            document.getElementById('measureDeleteType').value = type;
            document.getElementById('measureDeleteOldValue').value = value;
            document.getElementById('measureDeleteForm').submit();
        }
    }

    // Allow closing the measure edit modal by clicking the dark overlay
    document.addEventListener('click', function(e) {
        var modal = document.getElementById('measureEditModal');
        if (e.target === modal) {
            closeMeasureEditModal();
        }
    });

    // Close the measure edit modal with the Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            var modal = document.getElementById('measureEditModal');
            if (modal && modal.classList.contains('open')) {
                closeMeasureEditModal();
            }
        }
    });

    // --- DYNAMIC VALUE EDIT MODAL (department, risk origin, DPIA status/
    //     approval/consultation, approved-by, contact names) ---
    function openDynValueEditModal(fieldType, currentValue) {
        var modal = document.getElementById('dynValueEditModal');
        document.getElementById('dynValueEditType').value = fieldType;
        document.getElementById('dynValueEditOldValue').value = currentValue;
        document.getElementById('dynValueEditCurrentDisplay').value = currentValue;
        document.getElementById('dynValueEditNewValue').value = currentValue;
        modal.classList.add('open');
        setTimeout(function() {
            var input = document.getElementById('dynValueEditNewValue');
            input.focus();
            input.select();
        }, 50);
    }

    function closeDynValueEditModal() {
        document.getElementById('dynValueEditModal').classList.remove('open');
    }

    function confirmDeleteDynValue(fieldType, value) {
        if (confirm('<?= t('confirm_delete_value') ?>')) {
            document.getElementById('dynValueDeleteType').value = fieldType;
            document.getElementById('dynValueDeleteOldValue').value = value;
            document.getElementById('dynValueDeleteForm').submit();
        }
    }

    // Allow closing the dynamic value edit modal by clicking the dark overlay
    document.addEventListener('click', function(e) {
        var modal = document.getElementById('dynValueEditModal');
        if (e.target === modal) {
            closeDynValueEditModal();
        }
    });

    // Close the dynamic value edit modal with the Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            var modal = document.getElementById('dynValueEditModal');
            if (modal && modal.classList.contains('open')) {
                closeDynValueEditModal();
            }
        }
    });

    document.addEventListener('DOMContentLoaded', function() {
        // --- AUTO EXPAND TEXTAREAS ---
        var textareas = document.querySelectorAll('textarea');
        textareas.forEach(function(textarea) {
            textarea.style.minHeight = '50px';
            autoExpand(textarea);
            textarea.addEventListener('input', function() {
                autoExpand(this);
            });
        });
        
        // --- MODAL CLICK OUTSIDE TO CLOSE ---
        const overlays = document.querySelectorAll('.modal-overlay');
        
        overlays.forEach(function(overlay) {
            // Find the form in this modal to detect changes
            const form = overlay.querySelector('form');
            let hasChanges = false;
            
            if (form) {
                // Track changes in form inputs
                const inputs = form.querySelectorAll('input, select, textarea');
                inputs.forEach(function(input) {
                    // Store initial value
                    const initialValue = input.value;
                    
                    // Listen for changes
                    input.addEventListener('change', function() {
                        if (this.value !== initialValue) {
                            hasChanges = true;
                        }
                    });
                    input.addEventListener('input', function() {
                        if (this.value !== initialValue) {
                            hasChanges = true;
                        }
                    });
                });
            }
            
            // Click on overlay (outside modal content)
            overlay.addEventListener('click', function(e) {
                if (e.target === overlay) {
                    // Check if there are unsaved changes
                    if (hasChanges) {
                        if (!confirm('<?= t('unsaved_changes_confirm') ?>')) {
                            return;
                        }
                    }
                    
                    // Find close button or cancel link
                    const closeBtn = overlay.querySelector('.close-btn');
                    if (closeBtn) {
                        closeBtn.click();
                    } else {
                        // Fallback: find any link that goes back to a tab
                        const cancelLink = overlay.querySelector('a[href*="tab="]');
                        if (cancelLink) {
                            window.location.href = cancelLink.getAttribute('href');
                        }
                    }
                }
            });
        });
        
        // --- ESC KEY TO CLOSE MODAL ---
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const openOverlay = document.querySelector('.modal-overlay[style*="display:flex"]');
                if (openOverlay) {
                    const closeBtn = openOverlay.querySelector('.close-btn');
                    if (closeBtn) {
                        closeBtn.click();
                    }
                }
            }
        });
    });
    
    function autoExpand(element) {
        element.style.height = 'auto';
        element.style.height = element.scrollHeight + 'px';
    }
    
    function confirmDelete(id, type) {
        if (confirm('<?= t('confirm_delete') ?>')) {
            document.getElementById('deleteTab').value = type;
            document.getElementById('deleteAction').value = 'delete_' + type;
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteForm').submit();
        }
    }
</script>

</body>
</html>