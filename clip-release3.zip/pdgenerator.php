<?php
// ============================================
// GDPR & DPIA PDF Generator - Toon ALLE details
// ============================================

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Configuration
$data_directory = 'C:\xampp821201\htdocs\productie\gdpr\dutch/';

// Hoofdverwerking
if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['generate'])) {
    try {
        generateGDPRDPIAPDF($data_directory);
    } catch (Exception $e) {
        die('Fout bij genereren rapport: ' . $e->getMessage());
    }
    exit;
}

// Functie om PDF rapport te genereren
function generateGDPRDPIAPDF($data_directory) {
    // Haal alle data op
    $all_entries = [];
    $files = getAllDataFiles($data_directory);
    
    foreach ($files as $file) {
        $entries = parseFileContent($file);
        $all_entries = array_merge($all_entries, $entries);
    }
    
    // Genereer HTML rapport
    $html = generateHTMLReport($all_entries);
    
    // Stuur HTML naar browser met print styling
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

// Helper functies
function getAllDataFiles($directory) {
    $files = [];
    if (is_dir($directory)) {
        $all_files = scandir($directory);
        foreach ($all_files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt' && $file !== '.' && $file !== '..') {
                $files[] = $directory . $file;
            }
        }
    }
    return $files;
}

function parseFileContent($filepath) {
    $entries = [];
    $content = file_get_contents($filepath);
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (strpos($trimmed, '--') === 0 || $trimmed === '' || strpos($trimmed, 'INSERT INTO') !== false) {
            continue;
        }
        
        if (strpos($trimmed, '(') === 0) {
            $data = parseDataRow($trimmed);
            if ($data && isset($data[0])) {
                $detected_type = detectFileTypeFromRow($data);
                
                $entry = [
                    'id' => $data[0] ?? '',
                    'type' => $detected_type,
                    'file' => basename($filepath),
                    'raw_data' => $data,
                    'field_count' => count($data),
                    'all_fields' => $data
                ];
                
                // COLUMN NAMES voor GDPR (33 velden)
                $gdpr_columns = [
                    'id', 'has_processing_agreement_with_third_party', 'we_are_processor', 'processing_activity', 'name_data_controller',
                    'contact_data_controller', 'name_joint_data_controller', 'contact_joint_data_controller', 'name_representative',
                    'contact_representative', 'name_dpo', 'contact_dpo', 'purpose_of_processing', 'legal_basis',
                    'categories_personal_data', 'categories_data_subjects', 'categories_recipients', 'retention_periods',
                    'risk_level', 'technical_measures', 'organizational_measures', 'dpia_required', 'is_international_data_transfers',
                    'to_country', 'safeguards', 'created_at', 'updated_at', 'review_due_date', 'created_by', 'updated_by',
                    'department', 'status', 'legitimate_interest_description', 'dpia_status'
                ];
                
                // COLUMN NAMES voor DPIA (28 velden)
                $dpia_columns = [
                    'id', 'record_id', 'description', 'necessity_proportionality', 'mitigation_measures', 'residual_risk',
                    'overall_risk_level', 'status', 'registered_by', 'registered_at', 'updated_at', 'notes', 'title',
                    'review_date', 'processing_activity_description', 'risk_origin', 'necessity_test', 'proportionality_test',
                    'data_subjects_affected', 'data_categories', 'compliance_checklist', 'risk_assessment_matrix',
                    'consultation_conducted', 'consultation_details', 'recommendations', 'management_approval',
                    'approved_by', 'approval_date'
                ];
                
                // Voeg alle velden toe met kolomnamen
                if ($detected_type === 'gdpr') {
                    $entry['columns'] = $gdpr_columns;
                    // Voeg alle velden toe
                    for ($i = 0; $i < min(count($data), count($gdpr_columns)); $i++) {
                        $column_name = $gdpr_columns[$i];
                        $entry[$column_name] = $data[$i] ?? '';
                    }
                } elseif ($detected_type === 'dpia') {
                    $entry['columns'] = $dpia_columns;
                    // Voeg alle velden toe
                    for ($i = 0; $i < min(count($data), count($dpia_columns)); $i++) {
                        $column_name = $dpia_columns[$i];
                        $entry[$column_name] = $data[$i] ?? '';
                    }
                } else {
                    $entry['columns'] = [];
                }
                
                $entries[] = $entry;
            }
        }
    }
    
    return $entries;
}

function parseDataRow($line) {
    $line = trim($line, ");\n\r\t");
    $line = trim($line, "),");
    
    $values = [];
    $current = '';
    $in_quotes = false;
    
    for ($i = 0; $i < strlen($line); $i++) {
        $char = $line[$i];
        
        if ($char === "'" && ($i === 0 || $line[$i-1] !== '\\')) {
            $in_quotes = !$in_quotes;
        } elseif ($char === ',' && !$in_quotes) {
            $values[] = trim($current, "'");
            $current = '';
        } else {
            $current .= $char;
        }
    }
    
    if ($current !== '') {
        $values[] = trim($current, "'");
    }
    
    return $values;
}

function detectFileTypeFromRow($data) {
    if (count($data) >= 33) {
        return 'gdpr';
    } elseif (count($data) >= 28) {
        return 'dpia';
    }
    return 'unknown';
}

// Genereer HTML rapport met ALLE details
function generateHTMLReport($entries) {
    // Tel statistieken
    $gdpr_count = count(array_filter($entries, function($e) { return $e['type'] === 'gdpr'; }));
    $dpia_count = count(array_filter($entries, function($e) { return $e['type'] === 'dpia'; }));
    
    $html = '<!DOCTYPE html>
    <html lang="nl">
    <head>
        <meta charset="UTF-8">
        <title>GDPR & DPIA Register - Compleet Overzicht</title>
        <style>
            @media print {
                @page {
                    size: A4;
                    margin: 1.5cm;
                }
                body {
                    font-family: Arial, sans-serif;
                    font-size: 10pt;
                    line-height: 1.3;
                    color: #000;
                }
                .page-break {
                    page-break-after: always;
                }
                .no-print {
                    display: none;
                }
                h1, h2, h3, h4 {
                    page-break-after: avoid;
                }
                .entry {
                    page-break-inside: avoid;
                }
                .details-table {
                    font-size: 9pt;
                }
            }
            @media screen {
                body {
                    font-family: Arial, sans-serif;
                    font-size: 13px;
                    line-height: 1.5;
                    max-width: 210mm;
                    margin: 0 auto;
                    padding: 15px;
                    background: #f5f5f5;
                }
                .print-btn {
                    position: fixed;
                    top: 15px;
                    right: 15px;
                    background: #007bff;
                    color: white;
                    padding: 8px 16px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    z-index: 1000;
                    font-size: 13px;
                }
                .print-btn:hover {
                    background: #0056b3;
                }
            }
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
            }
            .container {
                padding: 15px;
                background: white;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
            .header {
                text-align: center;
                margin-bottom: 25px;
                border-bottom: 2px solid #2c3e50;
                padding-bottom: 15px;
            }
            h1 {
                font-size: 22pt;
                margin: 0 0 8px 0;
                color: #2c3e50;
            }
            .subtitle {
                font-size: 13pt;
                color: #666;
                margin-bottom: 15px;
            }
            .info-box {
                background: #e8f4fc;
                border: 1px solid #b6d4fe;
                border-radius: 5px;
                padding: 12px;
                margin-bottom: 20px;
            }
            .section {
                margin-bottom: 25px;
            }
            h2 {
                font-size: 16pt;
                color: #34495e;
                border-bottom: 2px solid #3498db;
                padding-bottom: 5px;
                margin-top: 25px;
                margin-bottom: 15px;
            }
            h3 {
                font-size: 13pt;
                color: #2c3e50;
                margin-top: 20px;
                margin-bottom: 10px;
                background: #f8f9fa;
                padding: 8px;
                border-left: 4px solid #3498db;
            }
            .entry {
                border: 1px solid #ddd;
                border-radius: 5px;
                padding: 15px;
                margin-bottom: 20px;
                background: #fff;
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            }
            .entry-header {
                background: linear-gradient(to right, #f8f9fa, #e9ecef);
                padding: 10px 15px;
                margin: -15px -15px 15px -15px;
                border-bottom: 1px solid #dee2e6;
                border-radius: 5px 5px 0 0;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .entry-title {
                font-size: 14pt;
                font-weight: bold;
                color: #2c3e50;
            }
            .entry-meta {
                font-size: 10pt;
                color: #666;
            }
            .badge {
                display: inline-block;
                padding: 4px 8px;
                border-radius: 4px;
                font-size: 10pt;
                font-weight: bold;
                margin-right: 8px;
            }
            .badge-gdpr {
                background: #3498db;
                color: white;
            }
            .badge-dpia {
                background: #e74c3c;
                color: white;
            }
            .badge-high {
                background: #dc3545;
                color: white;
            }
            .badge-medium {
                background: #ffc107;
                color: #212529;
            }
            .badge-low {
                background: #28a745;
                color: white;
            }
            .badge-unknown {
                background: #6c757d;
                color: white;
            }
            .details-table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 15px;
                font-size: 10pt;
            }
            .details-table th {
                background: #f8f9fa;
                font-weight: bold;
                text-align: left;
                padding: 8px;
                border: 1px solid #dee2e6;
                width: 30%;
                vertical-align: top;
            }
            .details-table td {
                padding: 8px;
                border: 1px solid #dee2e6;
                vertical-align: top;
                background: white;
            }
            .details-table tr:nth-child(even) td {
                background: #f8f9fa;
            }
            .field-value {
                word-break: break-word;
                max-width: 0;
                overflow-wrap: break-word;
            }
            .empty-field {
                color: #999;
                font-style: italic;
            }
            .statistics {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
                gap: 12px;
                margin-bottom: 25px;
            }
            .stat-card {
                background: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 5px;
                padding: 15px;
                text-align: center;
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            }
            .stat-number {
                font-size: 20pt;
                font-weight: bold;
                color: #2c3e50;
                display: block;
                margin-bottom: 5px;
            }
            .stat-label {
                font-size: 10pt;
                color: #666;
            }
            .footer {
                text-align: center;
                margin-top: 40px;
                padding-top: 15px;
                border-top: 1px solid #ddd;
                font-size: 9pt;
                color: #666;
            }
            .toggle-details {
                background: #6c757d;
                color: white;
                border: none;
                padding: 5px 10px;
                border-radius: 3px;
                cursor: pointer;
                font-size: 10pt;
                margin-left: 10px;
            }
            .toggle-details:hover {
                background: #545b62;
            }
            .raw-data {
                background: #f8f9fa;
                border: 1px dashed #ccc;
                padding: 10px;
                margin-top: 15px;
                font-family: monospace;
                font-size: 9pt;
                display: none;
            }
            .raw-data.show {
                display: block;
            }
            .index-badge {
                background: #6c757d;
                color: white;
                padding: 3px 8px;
                border-radius: 3px;
                font-size: 9pt;
                margin-right: 5px;
            }
            .all-fields-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
                font-size: 9pt;
            }
            .all-fields-table th {
                background: #e9ecef;
                font-weight: bold;
                padding: 6px;
                border: 1px solid #dee2e6;
                text-align: left;
            }
            .all-fields-table td {
                padding: 6px;
                border: 1px solid #dee2e6;
                vertical-align: top;
            }
            .all-fields-table tr:nth-child(even) {
                background: #f8f9fa;
            }
            .column-index {
                width: 40px;
                text-align: center;
                background: #e9ecef;
                font-weight: bold;
            }
            .column-name {
                width: 180px;
                font-weight: bold;
                background: #f1f3f4;
            }
            .column-value {
                background: white;
            }
        </style>
    </head>
    <body>
        <button class="print-btn no-print" onclick="window.print()">🖨️ Afdrukken/PDF</button>
        
        <div class="container">
            <div class="header">
                <h1>GDPR & DPIA Register</h1>
                <div class="subtitle">Compleet Overzicht met Alle Details</div>
                <div style="font-size: 11pt; color: #666;">
                    Generatiedatum: ' . date('d-m-Y H:i:s') . ' | ' . count($entries) . ' entries gevonden
                </div>
            </div>
            
            <div class="statistics">
                <div class="stat-card">
                    <span class="stat-number">' . count($entries) . '</span>
                    <span class="stat-label">Totaal Entries</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">' . $gdpr_count . '</span>
                    <span class="stat-label">GDPR Verwerkingen</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">' . $dpia_count . '</span>
                    <span class="stat-label">DPIA Assessments</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">' . count(array_filter($entries, function($e) { 
                        return $e['type'] === 'unknown'; 
                    })) . '</span>
                    <span class="stat-label">Onbekend Type</span>
                </div>
            </div>';
    
    // GDPR Sectie met ALLE details
    if ($gdpr_count > 0) {
        $html .= '<div class="section">
            <h2>1. GDPR Verwerkingen (' . $gdpr_count . ')</h2>
            <div class="info-box">
                <strong>ℹ️ Informatie:</strong> Deze sectie toont alle ' . $gdpr_count . ' GDPR verwerkingen met alle ' . (isset($entries[0]['columns']) ? count($entries[0]['columns']) : '33') . ' velden per verwerking.
            </div>';
        
        $gdpr_entries = array_filter($entries, function($e) { return $e['type'] === 'gdpr'; });
        $gdpr_entries = array_values($gdpr_entries);
        
        foreach ($gdpr_entries as $index => $entry) {
            $risk_class = !empty($entry['risk_level']) ? strtolower($entry['risk_level']) : 'unknown';
            $risk_display = !empty($entry['risk_level']) ? $entry['risk_level'] : 'Onbekend';
            
            $html .= '<div class="entry">
                <div class="entry-header">
                    <div>
                        <span class="badge badge-gdpr">GDPR</span>
                        <span class="badge badge-' . $risk_class . '">' . $risk_display . ' risico</span>
                        <span class="index-badge">#' . ($index + 1) . '</span>
                    </div>
                    <div class="entry-meta">
                        ID: ' . htmlspecialchars($entry['id']) . ' | Bestand: ' . htmlspecialchars($entry['file']) . '
                    </div>
                </div>
                
                <h3>' . htmlspecialchars($entry['processing_activity'] ?? 'Verwerking ' . $entry['id']) . '</h3>';
            
            // Belangrijke velden eerst in een compacte tabel
            $important_fields_gdpr = [
                'name_data_controller' => 'Verwerkingsverantwoordelijke',
                'purpose_of_processing' => 'Doel van de verwerking',
                'legal_basis' => 'Wettelijke grondslag',
                'categories_personal_data' => 'Categorieën persoonsgegevens',
                'categories_data_subjects' => 'Betrokken personen',
                'retention_periods' => 'Bewaartermijn',
                'risk_level' => 'Risiconiveau',
                'dpia_required' => 'DPIA vereist',
                'status' => 'Status',
                'department' => 'Afdeling',
                'review_due_date' => 'Herbeoordelingsdatum',
                'created_at' => 'Aangemaakt op',
                'updated_at' => 'Bijgewerkt op'
            ];
            
            $html .= '<table class="details-table">
                <tbody>';
            
            foreach ($important_fields_gdpr as $field => $label) {
                if (isset($entry[$field]) && $entry[$field] !== '') {
                    $html .= '<tr>
                        <th>' . $label . ':</th>
                        <td class="field-value">' . nl2br(htmlspecialchars($entry[$field])) . '</td>
                    </tr>';
                }
            }
            
            $html .= '</tbody>
                </table>';
            
            // Toon ALLE velden in een gedetailleerde tabel
            $html .= '<h4 style="margin-top: 20px; font-size: 12pt; color: #495057;">Alle Velden (' . count($entry['all_fields']) . '):</h4>
                <table class="all-fields-table">
                    <thead>
                        <tr>
                            <th class="column-index">#</th>
                            <th class="column-name">Veldnaam</th>
                            <th class="column-value">Waarde</th>
                        </tr>
                    </thead>
                    <tbody>';
            
            for ($i = 0; $i < count($entry['all_fields']); $i++) {
                $value = $entry['all_fields'][$i] ?? '';
                $column_name = isset($entry['columns'][$i]) ? $entry['columns'][$i] : "veld_$i";
                
                $html .= '<tr>
                    <td class="column-index">' . $i . '</td>
                    <td class="column-name">' . htmlspecialchars($column_name) . '</td>
                    <td class="column-value">' . ($value !== '' ? nl2br(htmlspecialchars($value)) : '<span class="empty-field">(leeg)</span>') . '</td>
                </tr>';
            }
            
            $html .= '</tbody>
                </table>';
            
            $html .= '</div>';
            
            // Pagina break na elke 2 entries (voor print)
            if (($index + 1) % 2 === 0 && ($index + 1) < count($gdpr_entries)) {
                $html .= '<div class="page-break"></div>';
            }
        }
        
        $html .= '</div>';
    }
    
    // DPIA Sectie met ALLE details
    if ($dpia_count > 0) {
        $html .= '<div class="page-break"></div>
            <div class="section">
                <h2>2. DPIA Assessments (' . $dpia_count . ')</h2>
                <div class="info-box">
                    <strong>ℹ️ Informatie:</strong> Deze sectie toont alle ' . $dpia_count . ' DPIA assessments met alle ' . (isset($entries[0]['columns']) ? count($entries[0]['columns']) : '28') . ' velden per assessment.
                </div>';
        
        $dpia_entries = array_filter($entries, function($e) { return $e['type'] === 'dpia'; });
        $dpia_entries = array_values($dpia_entries);
        
        foreach ($dpia_entries as $index => $entry) {
            $risk_class = !empty($entry['overall_risk_level']) ? strtolower($entry['overall_risk_level']) : 'unknown';
            $risk_display = !empty($entry['overall_risk_level']) ? $entry['overall_risk_level'] : 'Onbekend';
            
            $html .= '<div class="entry">
                <div class="entry-header">
                    <div>
                        <span class="badge badge-dpia">DPIA</span>
                        <span class="badge badge-' . $risk_class . '">' . $risk_display . ' risico</span>
                        <span class="index-badge">#' . ($index + 1) . '</span>
                    </div>
                    <div class="entry-meta">
                        ID: ' . htmlspecialchars($entry['id']) . ' | Bestand: ' . htmlspecialchars($entry['file']) . '
                    </div>
                </div>
                
                <h3>' . htmlspecialchars($entry['title'] ?? 'DPIA ' . $entry['id']) . '</h3>';
            
            // Belangrijke velden eerst
            $important_fields_dpia = [
                'description' => 'Beschrijving',
                'processing_activity_description' => 'Verwerkingsactiviteit',
                'necessity_proportionality' => 'Noodzaak & evenredigheid',
                'mitigation_measures' => 'Mitigerende maatregelen',
                'residual_risk' => 'Resterend risico',
                'overall_risk_level' => 'Totaal risiconiveau',
                'status' => 'Status',
                'registered_at' => 'Geregistreerd op',
                'review_date' => 'Herbeoordelingsdatum',
                'data_subjects_affected' => 'Betrokken personen',
                'risk_origin' => 'Oorsprong risico',
                'consultation_conducted' => 'Consultatie uitgevoerd',
                'management_approval' => 'Goedkeuring management'
            ];
            
            $html .= '<table class="details-table">
                <tbody>';
            
            foreach ($important_fields_dpia as $field => $label) {
                if (isset($entry[$field]) && $entry[$field] !== '') {
                    $html .= '<tr>
                        <th>' . $label . ':</th>
                        <td class="field-value">' . nl2br(htmlspecialchars($entry[$field])) . '</td>
                    </tr>';
                }
            }
            
            $html .= '</tbody>
                </table>';
            
            // Toon ALLE velden in een gedetailleerde tabel
            $html .= '<h4 style="margin-top: 20px; font-size: 12pt; color: #495057;">Alle Velden (' . count($entry['all_fields']) . '):</h4>
                <table class="all-fields-table">
                    <thead>
                        <tr>
                            <th class="column-index">#</th>
                            <th class="column-name">Veldnaam</th>
                            <th class="column-value">Waarde</th>
                        </tr>
                    </thead>
                    <tbody>';
            
            for ($i = 0; $i < count($entry['all_fields']); $i++) {
                $value = $entry['all_fields'][$i] ?? '';
                $column_name = isset($entry['columns'][$i]) ? $entry['columns'][$i] : "veld_$i";
                
                $html .= '<tr>
                    <td class="column-index">' . $i . '</td>
                    <td class="column-name">' . htmlspecialchars($column_name) . '</td>
                    <td class="column-value">' . ($value !== '' ? nl2br(htmlspecialchars($value)) : '<span class="empty-field">(leeg)</span>') . '</td>
                </tr>';
            }
            
            $html .= '</tbody>
                </table>';
            
            $html .= '</div>';
            
            // Pagina break na elke 2 entries
            if (($index + 1) % 2 === 0 && ($index + 1) < count($dpia_entries)) {
                $html .= '<div class="page-break"></div>';
            }
        }
        
        $html .= '</div>';
    }
    
    // Samenvatting
    $html .= '<div class="page-break"></div>
        <div class="section">
            <h2>3. Samenvatting en Statistieken</h2>
            
            <h3>Risico Verdeling</h3>
            <table class="details-table">
                <thead>
                    <tr>
                        <th>Risiconiveau</th>
                        <th>GDPR</th>
                        <th>DPIA</th>
                        <th>Totaal</th>
                    </tr>
                </thead>
                <tbody>';
    
    // Definieer risiconiveaus
    $risk_levels = ['High', 'Medium', 'Low', 'Unknown'];
    $risk_counts = [
        'High' => ['gdpr' => 0, 'dpia' => 0],
        'Medium' => ['gdpr' => 0, 'dpia' => 0],
        'Low' => ['gdpr' => 0, 'dpia' => 0],
        'Unknown' => ['gdpr' => 0, 'dpia' => 0]
    ];
    
    // Tel risico\'s
    foreach ($entries as $entry) {
        if ($entry['type'] === 'gdpr') {
            $risk = !empty($entry['risk_level']) ? $entry['risk_level'] : 'Unknown';
            if (isset($risk_counts[$risk])) {
                $risk_counts[$risk]['gdpr']++;
            } else {
                $risk_counts['Unknown']['gdpr']++;
            }
        } elseif ($entry['type'] === 'dpia') {
            $risk = !empty($entry['overall_risk_level']) ? $entry['overall_risk_level'] : 'Unknown';
            if (isset($risk_counts[$risk])) {
                $risk_counts[$risk]['dpia']++;
            } else {
                $risk_counts['Unknown']['dpia']++;
            }
        }
    }
    
    // Toon risico tellingen
    foreach ($risk_counts as $risk => $counts) {
        $total = $counts['gdpr'] + $counts['dpia'];
        if ($total > 0) {
            $risk_class = strtolower($risk);
            $html .= '<tr>
                <td><span class="badge badge-' . $risk_class . '">' . htmlspecialchars($risk) . '</span></td>
                <td>' . $counts['gdpr'] . '</td>
                <td>' . $counts['dpia'] . '</td>
                <td><strong>' . $total . '</strong></td>
            </tr>';
        }
    }
    
    $html .= '</tbody>
            </table>
            
            <h3>Status Overzicht</h3>
            <table class="details-table">
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Aantal</th>
                    </tr>
                </thead>
                <tbody>';
    
    $status_counts = [];
    foreach ($entries as $entry) {
        $status = '';
        if ($entry['type'] === 'gdpr' && !empty($entry['status'])) {
            $status = $entry['status'];
        } elseif ($entry['type'] === 'dpia' && !empty($entry['status'])) {
            $status = $entry['status'];
        }
        
        if ($status !== '') {
            $status_counts[$status] = ($status_counts[$status] ?? 0) + 1;
        }
    }
    
    arsort($status_counts);
    foreach ($status_counts as $status => $count) {
        $html .= '<tr>
            <td>' . htmlspecialchars($status) . '</td>
            <td>' . $count . '</td>
        </tr>';
    }
    
    $html .= '</tbody>
            </table>
            
            <h3>Bestanden Overzicht</h3>
            <table class="details-table">
                <thead>
                    <tr>
                        <th>Bestand</th>
                        <th>GDPR</th>
                        <th>DPIA</th>
                        <th>Totaal</th>
                    </tr>
                </thead>
                <tbody>';
    
    $file_counts = [];
    foreach ($entries as $entry) {
        $file = $entry['file'];
        if (!isset($file_counts[$file])) {
            $file_counts[$file] = ['gdpr' => 0, 'dpia' => 0, 'unknown' => 0];
        }
        $file_counts[$file][$entry['type']]++;
    }
    
    foreach ($file_counts as $file => $counts) {
        $total = array_sum($counts);
        $html .= '<tr>
            <td>' . htmlspecialchars($file) . '</td>
            <td>' . $counts['gdpr'] . '</td>
            <td>' . $counts['dpia'] . '</td>
            <td><strong>' . $total . '</strong></td>
        </tr>';
    }
    
    $html .= '</tbody>
            </table>
        </div>
        
        <div class="footer">
            <strong>GDPR & DPIA Register - Compleet Overzicht</strong><br>
            Document gegenereerd op ' . date('d-m-Y H:i:s') . ' | ' . count($entries) . ' entries uit ' . count($file_counts) . ' bestanden<br>
            Gebruik de print-functie van uw browser om een PDF te maken (Ctrl+P of klik op de print knop)
        </div>
    </div>
    
    <script>
        // Auto-print optie (optioneel)
        setTimeout(function() {
            // window.print(); // Uncomment voor automatisch printen
        }, 1000);
        
        // Toggle raw data
        function toggleRawData(button) {
            var rawData = button.parentElement.querySelector(".raw-data");
            if (rawData.classList.contains("show")) {
                rawData.classList.remove("show");
                button.textContent = "Toon Raw Data";
            } else {
                rawData.classList.add("show");
                button.textContent = "Verberg Raw Data";
            }
        }
        
        // Pagina nummering toevoegen bij printen
        window.onbeforeprint = function() {
            var pageNumber = 1;
            var elements = document.querySelectorAll(".entry, h2, .section");
            
            elements.forEach(function(element) {
                if (element.classList.contains("entry")) {
                    element.setAttribute("data-page", pageNumber);
                }
            });
            
            var footer = document.querySelector(".footer");
            if (footer) {
                footer.innerHTML += " | Pagina " + pageNumber;
            }
        };
    </script>
</body>
</html>';
    
    return $html;
}

// HTML interface
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GDPR & DPIA PDF Generator</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            max-width: 800px;
            width: 100%;
        }
        
        .header {
            background: #2c3e50;
            color: white;
            padding: 40px;
            text-align: center;
        }
        
        h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .subtitle {
            font-size: 1.2em;
            opacity: 0.8;
            margin-bottom: 20px;
        }
        
        .content {
            padding: 40px;
        }
        
        .info-box {
            background: #f8f9fa;
            border-left: 4px solid #3498db;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 8px;
        }
        
        .features {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin: 30px 0;
        }
        
        .feature {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .feature:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .feature-icon {
            font-size: 2.5em;
            margin-bottom: 15px;
            display: block;
        }
        
        .feature h3 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .feature p {
            color: #666;
            font-size: 0.9em;
        }
        
        .generate-btn {
            display: block;
            width: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 20px;
            font-size: 1.2em;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            margin-top: 30px;
        }
        
        .generate-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(102, 126, 234, 0.4);
        }
        
        .note {
            background: #fff8e1;
            border: 1px solid #ffc107;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
            font-size: 0.9em;
            color: #666;
        }
        
        .instructions {
            margin-top: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .instructions ol {
            margin-left: 20px;
            margin-top: 10px;
        }
        
        .instructions li {
            margin-bottom: 10px;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .features {
                grid-template-columns: 1fr;
            }
            
            .header {
                padding: 30px 20px;
            }
            
            .content {
                padding: 30px 20px;
            }
            
            h1 {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📋 GDPR & DPIA Rapport Generator</h1>
            <div class="subtitle">Genereer een compleet rapport met ALLE details</div>
        </div>
        
        <div class="content">
            <div class="info-box">
                <h3>Wat krijg je?</h3>
                <p>Dit rapport toont <strong>alle velden en details</strong> van elke GDPR en DPIA entry in een print-vriendelijk formaat.</p>
            </div>
            
            <div class="features">
                <div class="feature">
                    <span class="feature-icon">📊</span>
                    <h3>Alle GDPR Velden</h3>
                    <p>Alle 33 velden per verwerking</p>
                </div>
                
                <div class="feature">
                    <span class="feature-icon">📈</span>
                    <h3>Alle DPIA Velden</h3>
                    <p>Alle 28 velden per assessment</p>
                </div>
                
                <div class="feature">
                    <span class="feature-icon">🔍</span>
                    <h3>Complete Details</h3>
                    <p>Geen informatie weggelaten</p>
                </div>
                
                <div class="feature">
                    <span class="feature-icon">📋</span>
                    <h3>Gestructureerd</h3>
                    <p>Overzichtelijke tabellen</p>
                </div>
            </div>
            
            <form method="post" action="">
                <button type="submit" class="generate-btn">
                    🚀 Compleet Rapport Genereren
                </button>
            </form>
            
            <div class="instructions">
                <h3>Hoe omzetten naar PDF:</h3>
                <ol>
                    <li>Klik op "Compleet Rapport Genereren"</li>
                    <li>Klik op de print knop bovenaan de pagina</li>
                    <li>Kies als printer "Microsoft Print to PDF" of "Save as PDF"</li>
                    <li>Sla het bestand op</li>
                </ol>
            </div>
            
            <div class="note">
                <strong>💡 Tip:</strong> Dit rapport bevat ALLE details. Het kan meerdere pagina\'s beslaan afhankelijk van het aantal entries.
            </div>
            
            <a href="javascript:history.back()" class="back-link">← Terug naar Data Viewer</a>
        </div>
    </div>
</body>
</html>