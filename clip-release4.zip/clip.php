<?php
// ============================================
// GDPR & DPIA Data Viewer
// Shows FULL INSERT INTO data from text files
// Human-readable search results
// Clear GDPR/DPIA type indicators
// Save multiple entries to template
// ============================================

// Configuration
$data_directory = 'C:\xampp821201\htdocs\productie\newmodel avg register english foodbank\30avg 30 dpia\release2\dutch/';

// Define column names for different file types
$column_names = [
    'gdpr' => [
        'id', 'has_processing_agreement_with_third_party', 'we_are_processor', 'processing_activity', 'name_data_controller',
        'contact_data_controller', 'name_joint_data_controller', 'contact_joint_data_controller', 'name_representative',
        'contact_representative', 'name_dpo', 'contact_dpo', 'purpose_of_processing', 'legal_basis',
        'categories_personal_data', 'categories_data_subjects', 'categories_recipients', 'retention_periods',
        'risk_level', 'technical_measures', 'organizational_measures', 'dpia_required', 'is_international_data_transfers',
        'to_country', 'safeguards', 'created_at', 'updated_at', 'review_due_date', 'created_by', 'updated_by',
        'department', 'status', 'legitimate_interest_description', 'dpia_status'
    ],
    'dpia' => [
        'id', 'record_id', 'description', 'necessity_proportionality', 'mitigation_measures', 'residual_risk',
        'overall_risk_level', 'status', 'registered_by', 'registered_at', 'updated_at', 'notes', 'title',
        'review_date', 'processing_activity_description', 'risk_origin', 'necessity_test', 'proportionality_test',
        'data_subjects_affected', 'data_categories', 'compliance_checklist', 'risk_assessment_matrix',
        'consultation_conducted', 'consultation_details', 'recommendations', 'management_approval',
        'approved_by', 'approval_date'
    ],
    'unknown' => []
];

// Initialize session
session_start();
if (!isset($_SESSION['selected_files'])) {
    $_SESSION['selected_files'] = [];
}
if (!isset($_SESSION['template_saved'])) {
    $_SESSION['template_saved'] = [];
}
if (!isset($_SESSION['selected_entries'])) {
    $_SESSION['selected_entries'] = [];
}

// Get all data files
$data_files = [];
if (is_dir($data_directory)) {
    $files = scandir($data_directory);
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
            $filepath = $data_directory . $file;
            $data_files[] = [
                'filename' => $file,
                'path' => $filepath,
                'entry_count' => count(parseFileContent($filepath, 'all')),
                'type' => 'all'
            ];
        }
    }
}

// Handle actions
$action = $_GET['action'] ?? '';
$search_query = trim($_POST['search_query'] ?? $_GET['q'] ?? '');
$selected_files = $_SESSION['selected_files'] ?? [];
$selected_entries = $_SESSION['selected_entries'] ?? [];

// Initialize results variable
$results = [];

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle file selection
    if (isset($_POST['selected_files'])) {
        $_SESSION['selected_files'] = $_POST['selected_files'];
        $selected_files = $_SESSION['selected_files'];
        
        // Automatically show all results when files are selected
        if (!empty($selected_files)) {
            $results = performMultiFileSearch('', $selected_files);
        }
    }
    
    // Handle clear all files action
    if (isset($_POST['action']) && $_POST['action'] === 'clear_all_files') {
        $_SESSION['selected_files'] = [];
        $selected_files = [];
        $_SESSION['selected_entries'] = [];
        $selected_entries = [];
        // Don't show results when clearing
    }
    
    // Handle entry selection
    if (isset($_POST['selected_entries'])) {
        $_SESSION['selected_entries'] = $_POST['selected_entries'];
        $selected_entries = $_SESSION['selected_entries'];
    }
    
    // Handle save to template action
    if (isset($_POST['action']) && $_POST['action'] === 'save_to_template') {
        $template_content = $_POST['template_content'] ?? '';
        $template_name = $_POST['template_name'] ?? 'template_' . date('Ymd_His') . '.txt';
        
        if (!empty($template_content)) {
            $template_path = $data_directory . 'templates/';
            
            // Create templates directory if it doesn't exist
            if (!is_dir($template_path)) {
                mkdir($template_path, 0755, true);
            }
            
            $template_file = $template_path . $template_name;
            
            if (file_put_contents($template_file, $template_content)) {
                $_SESSION['template_saved'] = [
                    'success' => true,
                    'filename' => $template_name,
                    'path' => $template_file,
                    'timestamp' => date('Y-m-d H:i:s')
                ];
            } else {
                $_SESSION['template_saved'] = [
                    'success' => false,
                    'error' => 'Failed to save template file',
                    'timestamp' => date('Y-m-d H:i:s')
                ];
            }
        }
    }
    
    // Handle select all entries
    if (isset($_POST['action']) && $_POST['action'] === 'select_all_entries') {
        if (isset($results)) {
            $all_entry_ids = [];
            foreach ($results as $entry) {
                $all_entry_ids[] = $entry['id'] . '|' . $entry['file'];
            }
            $_SESSION['selected_entries'] = $all_entry_ids;
            $selected_entries = $all_entry_ids;
        }
    }
    
    // Handle deselect all entries
    if (isset($_POST['action']) && $_POST['action'] === 'deselect_all_entries') {
        $_SESSION['selected_entries'] = [];
        $selected_entries = [];
    }
    
    // Handle search/filter
    if (isset($_POST['search_query'])) {
        if (!empty($selected_files)) {
            $results = performMultiFileSearch($search_query, $selected_files);
        }
    }
}

// Handle GET actions
if ($action) {
    switch ($action) {
        case 'search':
            if (!empty($selected_files)) {
                $results = performMultiFileSearch($search_query, $selected_files);
            }
            break;
            
        case 'remove_file':
            $file_to_remove = $_GET['file'] ?? '';
            if (($key = array_search($file_to_remove, $selected_files)) !== false) {
                unset($selected_files[$key]);
                $_SESSION['selected_files'] = array_values($selected_files);
                // After removing a file, show remaining results
                if (!empty($_SESSION['selected_files'])) {
                    $results = performMultiFileSearch('', $_SESSION['selected_files']);
                }
            }
            break;
            
        case 'show_full_data':
            $entry_id = $_GET['entry_id'] ?? '';
            $filename = $_GET['filename'] ?? '';
            if ($entry_id && $filename) {
                showFullData($entry_id, $filename);
                exit;
            }
            break;
            
        case 'show_file_content':
            $filename = $_GET['filename'] ?? '';
            if ($filename) {
                showFileContent($filename);
                exit;
            }
            break;
            
        case 'show_all':
            // Action to show all entries without search
            if (!empty($selected_files)) {
                $results = performMultiFileSearch('', $selected_files);
            }
            break;
            
        case 'clear_all_files':
            $_SESSION['selected_files'] = [];
            $selected_files = [];
            $_SESSION['selected_entries'] = [];
            $selected_entries = [];
            break;
            
        case 'download_template':
            $template_file = $_GET['file'] ?? '';
            if ($template_file && file_exists($data_directory . 'templates/' . $template_file)) {
                header('Content-Type: text/plain');
                header('Content-Disposition: attachment; filename="' . basename($template_file) . '"');
                readfile($data_directory . 'templates/' . $template_file);
                exit;
            }
            break;
            
        case 'delete_template':
            $template_file = $_GET['file'] ?? '';
            if ($template_file) {
                $template_path = $data_directory . 'templates/' . $template_file;
                if (file_exists($template_path)) {
                    unlink($template_path);
                }
            }
            break;
            
        case 'show_template':
            $template_file = $_GET['file'] ?? '';
            if ($template_file) {
                showTemplateContent($template_file);
                exit;
            }
            break;
            
        case 'toggle_entry':
            $entry_id = $_GET['entry_id'] ?? '';
            $filename = $_GET['filename'] ?? '';
            if ($entry_id && $filename) {
                $entry_key = $entry_id . '|' . $filename;
                if (($key = array_search($entry_key, $selected_entries)) !== false) {
                    unset($selected_entries[$key]);
                } else {
                    $selected_entries[] = $entry_key;
                }
                $_SESSION['selected_entries'] = array_values($selected_entries);
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit;
            }
            break;
            
        case 'clear_selected_entries':
            $_SESSION['selected_entries'] = [];
            $selected_entries = [];
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;
    }
}

// If no results yet but files are selected, show all results
if (empty($results) && !empty($selected_files)) {
    $results = performMultiFileSearch('', $selected_files);
}

// Get existing templates
$existing_templates = getExistingTemplates();

// ============================================
// ALL FUNCTIONS
// ============================================

// Function: Detect file type
function detectFileType($filepath) {
    $content = file_get_contents($filepath);
    if (strpos($content, 'gdpr_register') !== false) {
        return 'gdpr';
    } elseif (strpos($content, 'dpia_registrations') !== false) {
        return 'dpia';
    }
    return 'unknown';
}

// Function: Parse file content
function parseFileContent($filepath, $type) {
    global $column_names;
    
    $entries = [];
    $content = file_get_contents($filepath);
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        // Skip comments and empty lines
        if (strpos(trim($line), '--') === 0 || trim($line) === '') {
            continue;
        }
        
        // Parse data rows
        if (strpos($line, '(') === 0) {
            $data = parseDataRow($line);
            if ($data && isset($data[0])) {
                $detected_type = detectFileTypeFromRow($data);
                $column_list = $column_names[$detected_type] ?? [];
                
                $entry = [
                    'id' => $data[0] ?? '',
                    'type' => $detected_type,
                    'file' => basename($filepath),
                    'raw_line' => trim($line, " \t\n\r\0\x0B;"),
                    'raw_data' => $data,
                    'all_fields' => $data,
                    'field_count' => count($data),
                    'column_names' => $column_list,
                    'entry_key' => $data[0] . '|' . basename($filepath)
                ];
                
                // Add additional parsed fields if available
                if ($detected_type === 'gdpr' && count($data) >= 33) {
                    $entry['processing_activity'] = $data[3] ?? '';
                    $entry['name_data_controller'] = $data[4] ?? '';
                    $entry['purpose_of_processing'] = $data[12] ?? '';
                    $entry['risk_level'] = $data[18] ?? '';
                    $entry['status'] = $data[31] ?? '';
                    $entry['department'] = $data[30] ?? '';
                    $entry['review_due_date'] = $data[27] ?? '';
                    $entry['dpia_required'] = $data[21] ?? '';
                    $entry['legal_basis'] = $data[13] ?? '';
                    $entry['categories_personal_data'] = $data[14] ?? '';
                    $entry['categories_data_subjects'] = $data[15] ?? '';
                } elseif ($detected_type === 'dpia' && count($data) >= 28) {
                    $entry['title'] = $data[12] ?? '';
                    $entry['description'] = $data[2] ?? '';
                    $entry['overall_risk_level'] = $data[6] ?? '';
                    $entry['status'] = $data[7] ?? '';
                    $entry['processing_activity_description'] = $data[14] ?? '';
                    $entry['registered_at'] = $data[9] ?? '';
                    $entry['review_date'] = $data[13] ?? '';
                    $entry['data_subjects_affected'] = $data[18] ?? '';
                    $entry['residual_risk'] = $data[5] ?? '';
                    $entry['mitigation_measures'] = $data[4] ?? '';
                    $entry['necessity_proportionality'] = $data[3] ?? '';
                }
                
                $entries[] = $entry;
            }
        }
    }
    
    return $entries;
}

// Function: Detect file type from row
function detectFileTypeFromRow($data) {
    if (count($data) >= 33) {
        return 'gdpr';
    } elseif (count($data) >= 28) {
        return 'dpia';
    }
    return 'unknown';
}

// Function: Parse data row
function parseDataRow($line) {
    $line = trim($line, ");\n\r\t");
    $line = trim($line, "),");
    
    $values = [];
    $current = '';
    $in_quotes = false;
    
    for ($i = 0; $i < strlen($line); $i++) {
        $char = $line[$i];
        
        if ($char === "'" && ($i === 0 || $line[$i-1] !== '\\')) {
            $in_quotes = !$in_quotes;
        } elseif ($char === ',' && !$in_quotes) {
            $values[] = trim($current, "'");
            $current = '';
        } else {
            $current .= $char;
        }
    }
    
    if ($current !== '') {
        $values[] = trim($current, "'");
    }
    
    return $values;
}

// Function: Perform multi-file search
function performMultiFileSearch($query, $filenames) {
    global $data_directory;
    
    $results = [];
    foreach ($filenames as $filename) {
        $filepath = $data_directory . $filename;
        $entries = parseFileContent($filepath, 'all');
        
        foreach ($entries as $entry) {
            $match = false;
            
            // If query is empty, include all entries
            if (empty($query)) {
                $match = true;
            } else {
                // Search in all fields
                foreach ($entry as $value) {
                    if (is_string($value) && stripos($value, $query) !== false) {
                        $match = true;
                        break;
                    } elseif (is_array($value)) {
                        foreach ($value as $array_value) {
                            if (stripos($array_value, $query) !== false) {
                                $match = true;
                                break 2;
                            }
                        }
                    }
                }
            }
            
            if ($match) {
                $results[] = $entry;
            }
        }
    }
    
    return $results;
}

// Function: Get complete file content
function getCompleteFileContent($filename) {
    global $data_directory;
    
    $filepath = $data_directory . $filename;
    if (!file_exists($filepath)) {
        return "File not found: $filename";
    }
    
    $content = file_get_contents($filepath);
    return $content;
}

// Function: Get complete INSERT statements for an entry
function getCompleteInsertStatements($entry_id, $filename) {
    global $data_directory;
    
    $filepath = $data_directory . $filename;
    if (!file_exists($filepath)) {
        return "File not found: $filename";
    }
    
    $content = file_get_contents($filepath);
    $lines = explode("\n", $content);
    
    $all_statements = [];
    $current_statement = '';
    $in_statement = false;
    $found_our_id = false;
    
    foreach ($lines as $line) {
        $trimmed_line = trim($line);
        
        // Skip empty lines
        if (empty($trimmed_line)) {
            if ($in_statement) {
                $current_statement .= $line . "\n";
            }
            continue;
        }
        
        // Start of INSERT statement
        if (strpos($trimmed_line, 'INSERT INTO') !== false) {
            // If we were already in a statement, save it
            if ($in_statement) {
                $all_statements[] = [
                    'statement' => $current_statement,
                    'contains_our_id' => $found_our_id
                ];
            }
            
            // Start new statement
            $in_statement = true;
            $current_statement = $line . "\n";
            $found_our_id = false;
            continue;
        }
        
        // If we're in an INSERT statement
        if ($in_statement) {
            // Check if this line contains our entry ID
            if (strpos($line, "'" . $entry_id . "'") !== false) {
                $found_our_id = true;
            }
            
            // Add the line to the statement
            $current_statement .= $line . "\n";
            
            // Check if this is the end of the statement (ends with ;)
            if (substr(rtrim($line), -1) === ';') {
                $all_statements[] = [
                    'statement' => $current_statement,
                    'contains_our_id' => $found_our_id
                ];
                $in_statement = false;
                $current_statement = '';
                $found_our_id = false;
            }
        }
    }
    
    // If we're still in a statement at the end of file, add it
    if ($in_statement) {
        $all_statements[] = [
            'statement' => $current_statement,
            'contains_our_id' => $found_our_id
        ];
    }
    
    return $all_statements;
}

// Function: Show full data for an entry
function showFullData($entry_id, $filename) {
    $all_statements = getCompleteInsertStatements($entry_id, $filename);
    
    $data = [
        'entry_id' => $entry_id,
        'filename' => $filename,
        'total_statements' => count($all_statements),
        'statements' => $all_statements,
        'statements_with_id' => array_filter($all_statements, function($stmt) {
            return $stmt['contains_our_id'];
        }),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    header('Content-Type: application/json');
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

// Function: Show complete file content
function showFileContent($filename) {
    $content = getCompleteFileContent($filename);
    
    $data = [
        'filename' => $filename,
        'content' => $content,
        'size' => strlen($content),
        'lines' => count(explode("\n", $content)),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    header('Content-Type: application/json');
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

// Function: Show template content
function showTemplateContent($template_filename) {
    global $data_directory;
    
    $template_path = $data_directory . 'templates/' . $template_filename;
    if (!file_exists($template_path)) {
        $data = [
            'error' => 'Template not found: ' . $template_filename,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    } else {
        $content = file_get_contents($template_path);
        $data = [
            'filename' => $template_filename,
            'content' => $content,
            'size' => strlen($content),
            'lines' => count(explode("\n", $content)),
            'modified' => date('Y-m-d H:i:s', filemtime($template_path)),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
    
    header('Content-Type: application/json');
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

// Function: Get existing templates
function getExistingTemplates() {
    global $data_directory;
    $template_dir = $data_directory . 'templates/';
    $templates = [];
    
    if (is_dir($template_dir)) {
        $files = scandir($template_dir);
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..' && pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
                $template_path = $template_dir . $file;
                $templates[] = [
                    'filename' => $file,
                    'size' => filesize($template_path),
                    'modified' => date('Y-m-d H:i:s', filemtime($template_path)),
                    'path' => $template_path
                ];
            }
        }
    }
    
    // Sort by modification time, newest first
    usort($templates, function($a, $b) {
        return strtotime($b['modified']) - strtotime($a['modified']);
    });
    
    return $templates;
}

// Function: Generate template from entry
function generateEntryTemplate($entry) {
    $template = "// Template generated from " . $entry['type'] . " entry\n";
    $template .= "// Entry ID: " . $entry['id'] . "\n";
    $template .= "// Source File: " . $entry['file'] . "\n";
    $template .= "// Generated: " . date('Y-m-d H:i:s') . "\n";
    $template .= str_repeat("=", 80) . "\n\n";
    
    $columnNames = $entry['column_names'] ?? [];
    
    foreach ($entry['all_fields'] as $index => $value) {
        $colName = isset($columnNames[$index]) ? $columnNames[$index] : "field_$index";
        $template .= sprintf("%-40s: %s\n", $colName, $value);
    }
    
    $template .= "\n" . str_repeat("=", 80) . "\n";
    $template .= "// SQL INSERT Statement:\n";
    $template .= $entry['raw_line'] . ";\n\n";
    
    return $template;
}

// Function: Generate template from multiple entries
function generateMultipleEntriesTemplate($entries) {
    $template = "// Template generated from " . count($entries) . " entries\n";
    $template .= "// Generated: " . date('Y-m-d H:i:s') . "\n";
    $template .= "// Files: " . implode(', ', array_unique(array_column($entries, 'file'))) . "\n";
    $template .= str_repeat("=", 80) . "\n\n";
    
    foreach ($entries as $index => $entry) {
        $template .= "ENTRY " . ($index + 1) . " of " . count($entries) . "\n";
        $template .= str_repeat("-", 40) . "\n";
        $template .= "ID      : " . $entry['id'] . "\n";
        $template .= "Type    : " . strtoupper($entry['type']) . "\n";
        $template .= "File    : " . $entry['file'] . "\n\n";
        
        $columnNames = $entry['column_names'] ?? [];
        
        // Show key fields only for brevity
        if ($entry['type'] === 'gdpr') {
            $template .= "Processing Activity: " . ($entry['processing_activity'] ?? '') . "\n";
            $template .= "Purpose            : " . ($entry['purpose_of_processing'] ?? '') . "\n";
            $template .= "Risk Level         : " . ($entry['risk_level'] ?? '') . "\n";
            $template .= "Status             : " . ($entry['status'] ?? '') . "\n";
        } elseif ($entry['type'] === 'dpia') {
            $template .= "Title              : " . ($entry['title'] ?? '') . "\n";
            $template .= "Description        : " . ($entry['description'] ?? '') . "\n";
            $template .= "Risk Level         : " . ($entry['overall_risk_level'] ?? '') . "\n";
            $template .= "Status             : " . ($entry['status'] ?? '') . "\n";
        }
        
        $template .= "\n";
    }
    
    return $template;
}

// Function: Generate search results template
function generateResultsTemplate($results, $search_query = '', $selected_files = []) {
    $template = "// Search Results Template\n";
    $template .= "// Generated: " . date('Y-m-d H:i:s') . "\n";
    $template .= "// Files: " . implode(', ', $selected_files) . "\n";
    if (!empty($search_query)) {
        $template .= "// Search Query: " . $search_query . "\n";
    }
    $template .= "// Total Entries: " . count($results) . "\n";
    $template .= str_repeat("=", 80) . "\n\n";
    
    foreach ($results as $index => $entry) {
        $template .= "ENTRY " . ($index + 1) . " of " . count($results) . "\n";
        $template .= str_repeat("-", 40) . "\n";
        $template .= "ID      : " . $entry['id'] . "\n";
        $template .= "Type    : " . strtoupper($entry['type']) . "\n";
        $template .= "File    : " . $entry['file'] . "\n\n";
        
        if ($entry['type'] === 'gdpr') {
            $template .= "Processing Activity: " . ($entry['processing_activity'] ?? '') . "\n";
            $template .= "Purpose            : " . ($entry['purpose_of_processing'] ?? '') . "\n";
            $template .= "Risk Level         : " . ($entry['risk_level'] ?? '') . "\n";
            $template .= "Status             : " . ($entry['status'] ?? '') . "\n";
        } elseif ($entry['type'] === 'dpia') {
            $template .= "Title              : " . ($entry['title'] ?? '') . "\n";
            $template .= "Description        : " . ($entry['description'] ?? '') . "\n";
            $template .= "Risk Level         : " . ($entry['overall_risk_level'] ?? '') . "\n";
            $template .= "Status             : " . ($entry['status'] ?? '') . "\n";
        }
        
        $template .= "\n";
    }
    
    return $template;
}

// Function: Generate SQL template from multiple entries
function generateSQLTemplate($entries) {
    $template = "// SQL Template generated from " . count($entries) . " entries\n";
    $template .= "// Generated: " . date('Y-m-d H:i:s') . "\n";
    $template .= str_repeat("=", 80) . "\n\n";
    
    foreach ($entries as $entry) {
        $template .= "-- Entry ID: " . $entry['id'] . " (" . strtoupper($entry['type']) . ")\n";
        $template .= "-- Source: " . $entry['file'] . "\n";
        $template .= $entry['raw_line'] . ";\n\n";
    }
    
    return $template;
}

// Function: Generate CSV template from multiple entries
function generateCSVTemplate($entries) {
    $template = "ID,Type,File,Processing_Activity/Title,Purpose/Description,Risk_Level,Status\n";
    
    foreach ($entries as $entry) {
        $id = $entry['id'];
        $type = strtoupper($entry['type']);
        $file = $entry['file'];
        
        if ($entry['type'] === 'gdpr') {
            $title = str_replace('"', '""', $entry['processing_activity'] ?? '');
            $desc = str_replace('"', '""', $entry['purpose_of_processing'] ?? '');
            $risk = $entry['risk_level'] ?? '';
        } elseif ($entry['type'] === 'dpia') {
            $title = str_replace('"', '""', $entry['title'] ?? '');
            $desc = str_replace('"', '""', $entry['description'] ?? '');
            $risk = $entry['overall_risk_level'] ?? '';
        } else {
            $title = 'Unknown';
            $desc = 'Unknown';
            $risk = 'Unknown';
        }
        
        $status = $entry['status'] ?? '';
        
        $template .= "\"$id\",\"$type\",\"$file\",\"$title\",\"$desc\",\"$risk\",\"$status\"\n";
    }
    
    return $template;
}

// Function: Generate detailed template from multiple entries
function generateDetailedTemplate($entries) {
    $template = "// Detailed Template for " . count($entries) . " entries\n";
    $template .= "// Generated: " . date('Y-m-d H:i:s') . "\n";
    $template .= str_repeat("=", 80) . "\n\n";
    
    foreach ($entries as $entry_index => $entry) {
        $template .= "ENTRY " . ($entry_index + 1) . " of " . count($entries) . "\n";
        $template .= '=' . str_repeat("=", 60) . "\n";
        $template .= "ID          : " . $entry['id'] . "\n";
        $template .= "Type        : " . strtoupper($entry['type']) . "\n";
        $template .= "File        : " . $entry['file'] . "\n";
        $template .= "Field Count : " . $entry['field_count'] . "\n";
        $template .= '-' . str_repeat("-", 60) . "\n\n";
        
        $columnNames = $entry['column_names'] ?? [];
        
        $template .= "INDEX | COLUMN NAME                         | VALUE\n";
        $template .= "------|-------------------------------------|" . str_repeat("-", 40) . "\n";
        
        foreach ($entry['all_fields'] as $index => $value) {
            $colName = isset($columnNames[$index]) ? $columnNames[$index] : "field_$index";
            $indexStr = str_pad($index, 4, ' ', STR_PAD_LEFT);
            $colNameStr = str_pad($colName, 35, ' ');
            $template .= "$indexStr  | $colNameStr | " . ($value || 'NULL') . "\n";
        }
        
        $template .= "\n" . str_repeat("-", 60) . "\n\n";
    }
    
    return $template;
}

// Function: Get selected entries from results
function getSelectedEntries($results, $selected_entries_keys) {
    $selected = [];
    foreach ($results as $entry) {
        $entry_key = $entry['id'] . '|' . $entry['file'];
        if (in_array($entry_key, $selected_entries_keys)) {
            $selected[] = $entry;
        }
    }
    return $selected;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GDPR & DPIA Data Viewer</title>

   <style>
        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: #ffffff;
            color: #000000;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            font-size: 14px;
            line-height: 1.5;
            min-height: 100vh;
        }
        
        .container-fluid {
            padding: 20px;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        /* Typography */
        h1, h2, h3, h4, h5, h6 {
            font-weight: 600;
            margin-bottom: 15px;
            color: #000000;
        }
        
        h1 {
            font-size: 24px;
            font-weight: 700;
        }
        
        h5 {
            font-size: 16px;
        }
        
        h6 {
            font-size: 14px;
            font-weight: 600;
        }
        
        .text-muted {
            color: #666666;
        }
        
        .fw-bold {
            font-weight: 700;
        }
        
        .small {
            font-size: 12px;
        }
        
        /* Cards */
        .card {
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            background-color: #ffffff;
            margin-bottom: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        
        .card-header {
            background-color: #f5f5f5;
            color: #000000;
            border-bottom: 1px solid #e0e0e0;
            border-radius: 6px 6px 0 0;
            font-weight: 600;
            padding: 15px 20px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        /* Search Box */
        .search-box {
            background-color: #ffffff;
            padding: 25px;
            border: 1px solid #e0e0e0;
            margin-bottom: 30px;
            border-radius: 6px;
        }
        
        /* Buttons */
        .btn {
            display: inline-block;
            font-weight: 500;
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
            border: 1px solid #cccccc;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 4px;
            transition: all 0.2s;
            text-decoration: none;
            background-color: #ffffff;
            color: #000000;
        }
        
        .btn:hover {
            background-color: #f5f5f5;
            border-color: #999999;
            transform: none;
            box-shadow: none;
        }
        
        .btn-primary {
            background-color: #ffffff;
            color: #000000;
            border-color: #cccccc;
        }
        
        .btn-primary:hover {
            background-color: #f5f5f5;
            border-color: #999999;
        }
        
        .btn-outline-primary {
            background-color: #ffffff;
            color: #000000;
            border-color: #cccccc;
        }
        
        .btn-outline-primary:hover {
            background-color: #f5f5f5;
            border-color: #999999;
        }
        
        .btn-outline-danger {
            background-color: #ffffff;
            color: #000000;
            border-color: #cccccc;
        }
        
        .btn-outline-danger:hover {
            background-color: #f5f5f5;
            border-color: #999999;
        }
        
        .btn-outline-secondary {
            background-color: #ffffff;
            color: #000000;
            border-color: #cccccc;
        }
        
        .btn-outline-secondary:hover {
            background-color: #f5f5f5;
            border-color: #999999;
        }
        
        .btn-outline-info {
            background-color: #ffffff;
            color: #000000;
            border-color: #cccccc;
        }
        
        .btn-outline-info:hover {
            background-color: #f5f5f5;
            border-color: #999999;
        }
        
        .btn-info {
            background-color: #ffffff;
            color: #000000;
            border-color: #cccccc;
        }
        
        .btn-info:hover {
            background-color: #f5f5f5;
            border-color: #999999;
        }
        
        .btn-success {
            background-color: #ffffff;
            color: #000000;
            border-color: #cccccc;
        }
        
        .btn-success:hover {
            background-color: #f5f5f5;
            border-color: #999999;
        }
        
        .btn-danger {
            background-color: #ffffff;
            color: #000000;
            border-color: #cccccc;
        }
        
        .btn-danger:hover {
            background-color: #f5f5f5;
            border-color: #999999;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .btn-group {
            display: inline-flex;
            vertical-align: middle;
        }
        
        .btn-group-sm > .btn {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .btn-group-vertical {
            display: inline-flex;
            flex-direction: column;
        }
        
        /* Badges */
        .badge {
            display: inline-block;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 500;
            line-height: 1;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 4px;
            border: 1px solid #cccccc;
            background-color: #ffffff;
            color: #000000;
        }
        
        .badge-type {
            background-color: #ffffff;
        }
        
        .badge-gdpr {
            color: #000000;
            background-color: #ffffff;
            border-color: #666666;
        }
        
        .badge-dpia {
            color: #000000;
            background-color: #ffffff;
            border-color: #666666;
        }
        
        .badge-unknown {
            color: #000000;
            background-color: #ffffff;
            border-color: #666666;
        }
        
        .risk-badge {
            padding: 5px 10px;
            border: 1px solid #cccccc;
            font-weight: 500;
            background-color: #ffffff;
            color: #000000;
        }
        
        .risk-high { 
            background-color: #ffffff;
            color: #000000;
            border-color: #999999;
        }
        
        .risk-medium { 
            background-color: #ffffff;
            color: #000000;
            border-color: #999999;
        }
        
        .risk-low { 
            background-color: #ffffff;
            color: #000000;
            border-color: #999999;
        }
        
        .risk-unknown { 
            background-color: #ffffff;
            color: #000000;
            border-color: #999999;
        }
        
        /* Forms */
        .form-control, .form-select {
            display: block;
            width: 100%;
            padding: 8px 12px;
            font-size: 14px;
            line-height: 1.5;
            color: #000000;
            background-color: #ffffff;
            border: 1px solid #cccccc;
            border-radius: 4px;
            transition: border-color 0.15s ease-in-out;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #666666;
            outline: 0;
            box-shadow: 0 0 0 2px rgba(102, 102, 102, 0.1);
        }
        
        .form-text {
            display: block;
            margin-top: 5px;
            font-size: 12px;
            color: #666666;
        }
        
        .input-group {
            position: relative;
            display: flex;
            flex-wrap: wrap;
            align-items: stretch;
            width: 100%;
        }
        
        .input-group-lg > .form-control,
        .input-group-lg > .btn {
            padding: 12px 16px;
            font-size: 16px;
        }
        
        /* Tables */
        .table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .table th {
            background-color: #f5f5f5;
            color: #000000;
            border: 1px solid #e0e0e0;
            font-weight: 600;
            padding: 12px;
            text-align: left;
        }
        
        .table td {
            border: 1px solid #e0e0e0;
            background-color: #ffffff;
            padding: 12px;
            vertical-align: top;
        }
        
        .table-hover tbody tr:hover {
            background-color: #f9f9f9;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        /* Modals */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.3);
            display: none;
            z-index: 1050;
        }
        
        .modal.show {
            display: block;
        }
        
        .modal-dialog {
            position: relative;
            width: auto;
            margin: 30px auto;
            max-width: 95%;
        }
        
        .modal-content {
            position: relative;
            display: flex;
            flex-direction: column;
            width: 100%;
            background-color: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            outline: 0;
            max-height: 90vh;
            overflow: hidden;
        }
        
        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            background-color: #f5f5f5;
            color: #000000;
        }
        
        .modal-body {
            position: relative;
            flex: 1 1 auto;
            padding: 20px;
            overflow-y: auto;
        }
        
        .modal-footer {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding: 20px;
            border-top: 1px solid #e0e0e0;
            background-color: #f5f5f5;
        }
        
        .modal-fullscreen {
            width: 100vw;
            max-width: none;
            height: 100vh;
            margin: 0;
        }
        
        .btn-close {
            background: transparent;
            border: 0;
            font-size: 24px;
            cursor: pointer;
            color: #000000;
            line-height: 1;
        }
        
        /* File Selection */
        .file-selection-box {
            background-color: #f9f9f9;
            padding: 20px;
            border: 1px solid #e0e0e0;
            margin-bottom: 20px;
            border-radius: 6px;
        }
        
        .file-pill {
            background-color: #ffffff;
            color: #000000;
            padding: 6px 14px;
            margin: 5px;
            display: inline-flex;
            align-items: center;
            border: 1px solid #cccccc;
            border-radius: 20px;
            font-size: 13px;
        }
        
        .file-pill .remove-btn {
            margin-left: 8px;
            cursor: pointer;
            color: #666666;
            background: transparent;
            border: none;
            padding: 0;
            font-size: 14px;
        }
        
        .file-pill .remove-btn:hover {
            color: #000000;
        }
        
        /* Utility Classes */
        .row {
            display: flex;
            flex-wrap: wrap;
            margin-right: -10px;
            margin-left: -10px;
        }
        
        .col-lg-12, .col-md-8, .col-md-4, .col-12, .col-6 {
            position: relative;
            width: 100%;
            padding-right: 10px;
            padding-left: 10px;
        }
        
        @media (min-width: 768px) {
            .col-md-8 {
                flex: 0 0 66.666667%;
                max-width: 66.666667%;
            }
            .col-md-4 {
                flex: 0 0 33.333333%;
                max-width: 33.333333%;
            }
        }
        
        @media (min-width: 992px) {
            .col-lg-12 {
                flex: 0 0 100%;
                max-width: 100%;
            }
        }
        
        .py-4 {
            padding-top: 20px !important;
            padding-bottom: 20px !important;
        }
        
        .mt-1 { margin-top: 5px !important; }
        .mt-2 { margin-top: 10px !important; }
        .mt-3 { margin-top: 15px !important; }
        .mt-4 { margin-top: 20px !important; }
        .mb-0 { margin-bottom: 0 !important; }
        .mb-1 { margin-bottom: 5px !important; }
        .mb-2 { margin-bottom: 10px !important; }
        .mb-3 { margin-bottom: 15px !important; }
        .me-1 { margin-right: 5px !important; }
        .me-2 { margin-right: 10px !important; }
        .ms-1 { margin-left: 5px !important; }
        .ms-2 { margin-left: 10px !important; }
        
        .text-center { text-align: center !important; }
        .text-end { text-align: right !important; }
        
        .float-end { float: right !important; }
        
        .d-flex { display: flex !important; }
        .d-grid { display: grid !important; }
        .d-block { display: block !important; }
        .d-inline-flex { display: inline-flex !important; }
        
        .flex-wrap { flex-wrap: wrap !important; }
        .flex-column { flex-direction: column !important; }
        
        .justify-content-between { justify-content: space-between !important; }
        .justify-content-center { justify-content: center !important; }
        .justify-content-end { justify-content: flex-end !important; }
        
        .align-items-center { align-items: center !important; }
        .align-items-start { align-items: flex-start !important; }
        .align-items-end { align-items: flex-end !important; }
        
        .w-100 { width: 100% !important; }
        
        .gap-2 { gap: 10px !important; }
        
        .position-relative { position: relative !important; }
        .position-absolute { position: absolute !important; }
        
        .top-0 { top: 0 !important; }
        .right-0 { right: 0 !important; }
        
        .z-index-1000 { z-index: 1000 !important; }
        
        .border { border: 1px solid #e0e0e0 !important; }
        .border-top { border-top: 1px solid #e0e0e0 !important; }
        .border-bottom { border-bottom: 1px solid #e0e0e0 !important; }
        .border-left { border-left: 1px solid #e0e0e0 !important; }
        .border-right { border-right: 1px solid #e0e0e0 !important; }
        
        .bg-white { background-color: #ffffff !important; }
        .bg-light { background-color: #f5f5f5 !important; }
        .bg-secondary { background-color: #f5f5f5 !important; color: #000000 !important; }
        .bg-success { background-color: #ffffff !important; color: #000000 !important; border-color: #cccccc !important; }
        .bg-danger { background-color: #ffffff !important; color: #000000 !important; border-color: #cccccc !important; }
        .bg-info { background-color: #ffffff !important; color: #000000 !important; border-color: #cccccc !important; }
        .bg-warning { background-color: #ffffff !important; color: #000000 !important; border-color: #cccccc !important; }
        
        /* Custom Components */
        .result-item {
            cursor: pointer;
            border-left: 2px solid transparent;
            transition: all 0.2s;
        }
        
        .result-item:hover {
            border-left: 2px solid #666666;
            background-color: #f9f9f9;
        }
        
        .result-item.selected {
            background-color: #f0f8ff;
            border-left: 2px solid #007bff;
        }
        
        .entry-type-indicator {
            min-width: 100px;
        }
        
        .type-badge {
            padding: 6px 12px;
            border-radius: 4px;
            font-size: 12px;
            display: inline-flex;
            align-items: center;
            border: 1px solid #666666;
            background-color: #ffffff;
            color: #000000;
        }
        
        .gdpr-type {
            background-color: #ffffff;
            color: #000000;
            border-color: #666666;
        }
        
        .dpia-type {
            background-color: #ffffff;
            color: #000000;
            border-color: #666666;
        }
        
        .unknown-type {
            background-color: #ffffff;
            color: #000000;
            border-color: #666666;
        }
        
        .gdpr-title {
            color: #000000;
        }
        
        .dpia-title {
            color: #000000;
        }
        
        .unknown-title {
            color: #000000;
        }
        
        .entry-id {
            font-size: 14px;
            color: #000000;
            font-weight: 600;
        }
        
        .file-info {
            min-width: 120px;
        }
        
        .field-detail {
            margin-bottom: 12px;
            padding: 12px;
            background-color: #f9f9f9;
            border-radius: 4px;
            border-left: 3px solid #999999;
        }
        
        .field-label {
            font-weight: 600;
            color: #000000;
            margin-bottom: 6px;
            font-size: 13px;
        }
        
        .field-content {
            color: #000000;
            white-space: pre-wrap;
            word-break: break-word;
            font-size: 13px;
            line-height: 1.4;
        }
        
        .sql-code {
            font-family: 'Courier New', monospace;
            background-color: #f9f9f9;
            padding: 15px;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            white-space: pre-wrap;
            word-break: break-all;
            max-height: 500px;
            overflow-y: auto;
            font-size: 13px;
            color: #000000;
        }
        
        .statement-card {
            margin-bottom: 15px;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
        }
        
        .statement-header {
            background-color: #f5f5f5;
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .statement-body {
            padding: 15px;
        }
        
        .highlight-id {
            background-color: #f0f0f0;
            padding: 2px 4px;
            border-radius: 3px;
            font-weight: 600;
        }
        
        .field-table th {
            background-color: #f5f5f5;
            color: #000000;
        }
        
        .field-table td:nth-child(1) {
            background-color: #f5f5f5;
            font-weight: 600;
        }
        
        .field-name {
            font-weight: 600;
            color: #000000;
        }
        
        .field-value {
            word-break: break-all;
            color: #000000;
        }
        
        .multi-select {
            height: 200px;
        }
        
        .copy-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            z-index: 1000;
        }
        
        /* Checkbox styles */
        .form-check {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }
        
        .form-check-input {
            margin-right: 8px;
            cursor: pointer;
        }
        
        .form-check-label {
            cursor: pointer;
        }
        
        .entry-checkbox {
            transform: scale(1.2);
            margin-right: 10px;
        }
        
        /* Selection Controls */
        .selection-controls {
            background-color: #f8f9fa;
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
            border-radius: 6px 6px 0 0;
        }
        
        .selection-info {
            font-size: 13px;
            color: #666;
        }
        
        .selection-badge {
            font-size: 12px;
            padding: 3px 8px;
            margin-left: 5px;
        }
        
        /* Spinner */
        .spinner-border {
            display: inline-block;
            width: 2rem;
            height: 2rem;
            vertical-align: text-bottom;
            border: 0.25em solid #666666;
            border-right-color: transparent;
            border-radius: 50%;
            animation: spinner-border 0.75s linear infinite;
        }
        
        @keyframes spinner-border {
            to { transform: rotate(360deg); }
        }
        
        .visually-hidden {
            position: absolute !important;
            width: 1px !important;
            height: 1px !important;
            padding: 0 !important;
            margin: -1px !important;
            overflow: hidden !important;
            clip: rect(0,0,0,0) !important;
            white-space: nowrap !important;
            border: 0 !important;
        }
        
        /* Alert */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            background-color: #f9f9f9;
            color: #000000;
        }
        
        .alert-info {
            background-color: #f9f9f9;
            color: #000000;
            border-color: #e0e0e0;
        }
        
        .alert-danger {
            background-color: #f9f9f9;
            color: #000000;
            border-color: #e0e0e0;
        }
        
        /* Accordion */
        .accordion .card {
            margin-bottom: 10px;
            border: 1px solid #e0e0e0;
        }
        
        .accordion .btn-link {
            text-decoration: none;
            color: #000000;
            background: none;
            border: none;
            padding: 0;
            cursor: pointer;
        }
        
        .accordion .btn-link:hover {
            text-decoration: underline;
        }
        
        .collapse {
            display: none;
        }
        
        .collapse.show {
            display: block;
        }
        
        /* Text utilities */
        .text-decoration-none {
            text-decoration: none !important;
        }
        
        .bg-dark {
            background-color: #ffffff !important;
            color: #000000 !important;
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cccccc;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #999999;
        }
        
        /* Layout improvements */
        .d-grid.gap-2 {
            gap: 10px;
        }
        
        code {
            background-color: #f9f9f9;
            padding: 2px 4px;
            border-radius: 3px;
            border: 1px solid #e0e0e0;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            color: #000000;
        }
        
        /* Focus states */
        button:focus,
        input:focus,
        select:focus,
        textarea:focus {
            outline: 2px solid #666666;
            outline-offset: 2px;
        }
        
        /* Selection */
        ::selection {
            background-color: rgba(0, 0, 0, 0.1);
            color: #000000;
        }
        
        /* Template Styles */
        .template-pill {
            background-color: #ffffff;
            color: #000000;
            padding: 6px 12px;
            margin: 3px;
            display: inline-flex;
            align-items: center;
            border: 1px solid #cccccc;
            border-radius: 4px;
            font-size: 13px;
            max-width: 250px;
        }
        
        .template-actions {
            margin-left: 8px;
            display: flex;
            gap: 4px;
        }
        
        .template-btn {
            padding: 2px 6px;
            font-size: 11px;
            border-radius: 3px;
        }
        
        /* Bulk Actions */
        .bulk-actions {
            position: sticky;
            top: 0;
            background-color: #ffffff;
            z-index: 100;
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body>
    <div class="container-fluid py-4">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-12">
                <!-- Header -->
                <div class="search-box">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h1 class="mb-3">
                                GDPR & DPIA Data Viewer
                            </h1>
                            <p class="text-muted">
                                View complete INSERT INTO data from text files with column names | Save multiple entries to templates
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <?php if (!empty($existing_templates)): ?>
                                <button type="button" class="btn btn-outline-info" onclick="showTemplatesModal()">
                                    View Templates (<?php echo count($existing_templates); ?>)
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Success/Error Messages -->
                    <?php if (!empty($_SESSION['template_saved']) && isset($_SESSION['template_saved']['success'])): ?>
                        <?php if ($_SESSION['template_saved']['success']): ?>
                            <div class="alert alert-success mb-3">
                                Template saved successfully: <?php echo htmlspecialchars($_SESSION['template_saved']['filename']); ?>
                                <button type="button" class="btn btn-sm btn-outline-success float-end" 
                                        onclick="downloadTemplate('<?php echo htmlspecialchars($_SESSION['template_saved']['filename']); ?>')">
                                    Download
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-danger mb-3">
                                Failed to save template: <?php echo htmlspecialchars($_SESSION['template_saved']['error'] ?? 'Unknown error'); ?>
                            </div>
                        <?php endif; ?>
                        <?php $_SESSION['template_saved'] = []; ?>
                    <?php endif; ?>

                    <!-- File Selection -->
                    <div class="file-selection-box">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5>Select Files to View</h5>
                            <?php if (!empty($selected_files)): ?>
                                <div class="d-flex">
                                    <button type="button" class="btn btn-outline-danger btn-sm" onclick="clearAllFiles()">
                                        Clear All
                                    </button>
                                    <button type="button" class="btn btn-outline-info btn-sm ms-2" onclick="showSelectedFilesContent()">
                                        View All Files
                                    </button>
                                    <?php if (isset($results) && count($results) > 0): ?>
                                        <button type="button" class="btn btn-outline-success btn-sm ms-2" onclick="showSaveTemplateModal('results')">
                                            Save All Results as Template
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <form method="post" action="" class="mt-3" id="fileSelectionForm">
                            <div class="row">
                                <div class="col-md-8">
                                    <select name="selected_files[]" class="form-select multi-select" multiple required>
                                        <?php foreach ($data_files as $file_info): ?>
                                            <option value="<?php echo htmlspecialchars($file_info['filename']); ?>" 
                                                    <?php echo in_array($file_info['filename'], $selected_files) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($file_info['filename']); ?>
                                                (<?php echo $file_info['entry_count']; ?> entries)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text mt-2">
                                        Hold Ctrl (or Cmd on Mac) to select multiple files
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary mb-2 w-100">
                                        Apply Selection & Show Results
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary mb-2 w-100" onclick="selectAllFiles()">
                                        Select All
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary w-100" onclick="deselectAllFiles()">
                                        Deselect All
                                    </button>
                                </div>
                            </div>
                        </form>
                        
                        <!-- Selected Files Pills -->
                        <?php if (!empty($selected_files)): ?>
                            <div class="mt-3">
                                <h6>Selected Files (<?php echo count($selected_files); ?>):</h6>
                                <div class="d-flex flex-wrap mt-2">
                                    <?php foreach ($selected_files as $selected_file): ?>
                                        <div class="file-pill">
                                            <?php echo htmlspecialchars($selected_file); ?>
                                            <a href="?action=remove_file&file=<?php echo urlencode($selected_file); ?>" 
                                               class="remove-btn" title="Remove this file">
                                                ×
                                            </a>
                                            <button class="btn btn-sm btn-outline-info btn-view-file" 
                                                    onclick="showFileContent('<?php echo htmlspecialchars($selected_file); ?>')"
                                                    title="View complete file content">
                                                View
                                            </button>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Filter Form (Only show when files are selected) -->
                    <?php if (!empty($selected_files)): ?>
                    <form method="post" action="" id="filterForm">
                        <?php foreach ($selected_files as $sf): ?>
                            <input type="hidden" name="selected_files[]" value="<?php echo htmlspecialchars($sf); ?>">
                        <?php endforeach; ?>
                        <div class="input-group">
                            <input type="text" 
                                   name="search_query" 
                                   class="form-control" 
                                   placeholder="Filter results (optional)..."
                                   value="<?php echo htmlspecialchars($search_query); ?>"
                                   id="searchInput">
                            <button type="submit" class="btn btn-outline-primary">
                                Filter Results
                            </button>
                            <?php if (!empty($search_query)): ?>
                                <button type="button" class="btn btn-outline-secondary" onclick="clearFilter()">
                                    Clear Filter
                                </button>
                            <?php endif; ?>
                            <?php if (isset($results) && count($results) > 0): ?>
                                <button type="button" class="btn btn-outline-success" onclick="showSaveTemplateModal('results')">
                                    Save All Results
                                </button>
                                <?php if (!empty($selected_entries)): ?>
                                    <button type="button" class="btn btn-success" onclick="showSaveTemplateModal('selected')">
                                        Save Selected (<?php echo count($selected_entries); ?>)
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="form-text mt-2">
                            <?php if (isset($results)): ?>
                                Showing <?php echo count($results); ?> entries from <?php echo count($selected_files); ?> file(s)
                                <?php if (count($results) > 0): ?>
                                    | 
                                    <?php if (!empty($selected_entries)): ?>
                                        <strong><?php echo count($selected_entries); ?> selected</strong> | 
                                    <?php endif; ?>
                                    <a href="#" onclick="showSaveTemplateModal('results'); return false;">Save all as template</a>
                                    <?php if (!empty($selected_entries)): ?>
                                        | <a href="#" onclick="showSaveTemplateModal('selected'); return false;">Save selected as template</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php else: ?>
                                No entries found
                            <?php endif; ?>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>

                <!-- Results Section -->
                <div id="results-section">
                    <?php if (isset($results)): ?>
                        <div class="card">
                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">
                                        <?php if (!empty($search_query)): ?>
                                            Filtered Results
                                        <?php else: ?>
                                            All Results
                                        <?php endif; ?>
                                        <span class="badge bg-secondary ms-2">
                                            <?php echo count($results); ?> entries
                                        </span>
                                        <?php if (!empty($selected_entries)): ?>
                                            <span class="badge bg-success ms-2">
                                                <?php echo count($selected_entries); ?> selected
                                            </span>
                                        <?php endif; ?>
                                    </h5>
                                    <div>
                                        <?php if (!empty($search_query)): ?>
                                            <span class="text-muted">
                                                Filtered by: "<strong><?php echo htmlspecialchars($search_query); ?></strong>"
                                            </span>
                                        <?php endif; ?>
                                        <?php if (count($results) > 0): ?>
                                            <div class="btn-group ms-3">
                                                <button type="button" class="btn btn-outline-success btn-sm" onclick="showSaveTemplateModal('results')">
                                                    Save All
                                                </button>
                                                <?php if (!empty($selected_entries)): ?>
                                                    <button type="button" class="btn btn-success btn-sm" onclick="showSaveTemplateModal('selected')">
                                                        Save Selected (<?php echo count($selected_entries); ?>)
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Selection Controls -->
                            <?php if (isset($results) && count($results) > 0): ?>
                            <div class="selection-controls">
                                <form method="post" action="" id="selectionForm">
                                    <?php foreach ($selected_files as $sf): ?>
                                        <input type="hidden" name="selected_files[]" value="<?php echo htmlspecialchars($sf); ?>">
                                    <?php endforeach; ?>
                                    <input type="hidden" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>">
                                    
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center">
                                            <div class="form-check me-3">
                                                <input class="form-check-input" type="checkbox" 
                                                       id="selectAllCheckbox" 
                                                       onchange="toggleAllEntries(this.checked)">
                                                <label class="form-check-label" for="selectAllCheckbox">
                                                    Select All
                                                </label>
                                            </div>
                                            <span class="selection-info">
                                                <?php if (!empty($selected_entries)): ?>
                                                    <strong><?php echo count($selected_entries); ?></strong> entries selected
                                                <?php else: ?>
                                                    No entries selected
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                        <div class="d-flex">
                                            <?php if (!empty($selected_entries)): ?>
                                                <button type="button" class="btn btn-sm btn-outline-success me-2" 
                                                        onclick="showSaveTemplateModal('selected')">
                                                    Save Selected (<?php echo count($selected_entries); ?>)
                                                </button>
                                                <a href="?action=clear_selected_entries" class="btn btn-sm btn-outline-danger">
                                                    Clear Selection
                                                </a>
                                            <?php else: ?>
                                                <button type="submit" name="action" value="select_all_entries" 
                                                        class="btn btn-sm btn-outline-primary me-2">
                                                    Select All <?php echo count($results); ?> Entries
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <!-- Hidden checkboxes for selected entries -->
                                    <?php foreach ($selected_entries as $entry_key): ?>
                                        <input type="hidden" name="selected_entries[]" value="<?php echo htmlspecialchars($entry_key); ?>">
                                    <?php endforeach; ?>
                                </form>
                            </div>
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <!-- Results count and filter info -->
                                <?php if (!empty($search_query)): ?>
                                    <div class="alert alert-info mb-3">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span>
                                                Showing <?php echo count($results); ?> entries matching "<strong><?php echo htmlspecialchars($search_query); ?></strong>"
                                                <?php if (!empty($selected_entries)): ?>
                                                    (<strong><?php echo count($selected_entries); ?></strong> selected)
                                                <?php endif; ?>
                                            </span>
                                            <div>
                                                <button class="btn btn-sm btn-outline-secondary" onclick="clearFilter()">
                                                    Show All Entries
                                                </button>
                                                <?php if (count($results) > 0): ?>
                                                    <button class="btn btn-sm btn-outline-success ms-2" onclick="showSaveTemplateModal('results')">
                                                        Save All Results
                                                    </button>
                                                    <?php if (!empty($selected_entries)): ?>
                                                        <button class="btn btn-sm btn-success ms-2" onclick="showSaveTemplateModal('selected')">
                                                            Save Selected (<?php echo count($selected_entries); ?>)
                                                        </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info mb-3">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span>
                                                Showing all <?php echo count($results); ?> entries from <?php echo count($selected_files); ?> selected file(s)
                                                <?php if (!empty($selected_entries)): ?>
                                                    (<strong><?php echo count($selected_entries); ?></strong> selected)
                                                <?php endif; ?>
                                            </span>
                                            <?php if (count($results) > 0): ?>
                                                <div class="d-flex">
                                                    <button class="btn btn-sm btn-outline-success" onclick="showSaveTemplateModal('results')">
                                                        Save All Results
                                                    </button>
                                                    <?php if (!empty($selected_entries)): ?>
                                                        <button class="btn btn-sm btn-success ms-2" onclick="showSaveTemplateModal('selected')">
                                                            Save Selected (<?php echo count($selected_entries); ?>)
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (count($results) > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th width="50">
                                                        <!-- Checkbox column header -->
                                                    </th>
                                                    <th>Type</th>
                                                    <th>ID</th>
                                                    <th>Title / Description</th>
                                                    <th>Source File</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($results as $index => $entry): 
                                                    $is_gdpr = ($entry['type'] === 'gdpr');
                                                    $is_dpia = ($entry['type'] === 'dpia');
                                                    $is_unknown = ($entry['type'] === 'unknown');
                                                    $entry_key = $entry['id'] . '|' . $entry['file'];
                                                    $is_selected = in_array($entry_key, $selected_entries);
                                                ?>
                                                <tr class="result-item <?php echo $is_selected ? 'selected' : ''; ?>" 
                                                    id="entry-row-<?php echo $index; ?>">
                                                    <td>
                                                        <input type="checkbox" 
                                                               class="form-check-input entry-checkbox" 
                                                               name="selected_entry" 
                                                               value="<?php echo htmlspecialchars($entry_key); ?>"
                                                               <?php echo $is_selected ? 'checked' : ''; ?>
                                                               onchange="toggleEntrySelection('<?php echo htmlspecialchars($entry_key); ?>', this.checked)">
                                                    </td>
                                                    <td>
                                                        <div class="entry-type-indicator">
                                                            <?php if ($is_gdpr): ?>
                                                                <div class="type-badge gdpr-type">
                                                                    GDPR
                                                                </div>
                                                                <div class="small text-muted mt-1">
                                                                    Processing Register
                                                                </div>
                                                            <?php elseif ($is_dpia): ?>
                                                                <div class="type-badge dpia-type">
                                                                    DPIA
                                                                </div>
                                                                <div class="small text-muted mt-1">
                                                                    Impact Assessment
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="type-badge unknown-type">
                                                                    UNKNOWN
                                                                </div>
                                                                <div class="small text-muted mt-1">
                                                                    <?php echo $entry['field_count'] ?? '0'; ?> fields
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <strong class="entry-id"><?php echo htmlspecialchars($entry['id']); ?></strong>
                                                        <div class="small text-muted">
                                                            #<?php echo $index + 1; ?>
                                                            <?php if ($is_selected): ?>
                                                                <span class="badge bg-success selection-badge">Selected</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="entry-title">
                                                            <?php if ($is_gdpr): ?>
                                                                <div class="fw-bold gdpr-title">
                                                                    <?php echo htmlspecialchars($entry['processing_activity'] ?? 'GDPR Processing Activity'); ?>
                                                                </div>
                                                                <div class="mt-2">
                                                                    <!-- GDPR Specific Fields -->
                                                                    <?php if (isset($entry['purpose_of_processing']) && !empty($entry['purpose_of_processing'])): ?>
                                                                        <div class="field-detail">
                                                                            <div class="field-label">
                                                                                Purpose of Processing:
                                                                            </div>
                                                                            <div class="field-content">
                                                                                <?php echo htmlspecialchars($entry['purpose_of_processing']); ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    
                                                                    <?php if (isset($entry['categories_personal_data']) && !empty($entry['categories_personal_data'])): ?>
                                                                        <div class="field-detail">
                                                                            <div class="field-label">
                                                                                Categories of Personal Data:
                                                                            </div>
                                                                            <div class="field-content">
                                                                                <?php echo htmlspecialchars($entry['categories_personal_data']); ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    
                                                                    <?php if (isset($entry['categories_data_subjects']) && !empty($entry['categories_data_subjects'])): ?>
                                                                        <div class="field-detail">
                                                                            <div class="field-label">
                                                                                Categories of Data Subjects:
                                                                            </div>
                                                                            <div class="field-content">
                                                                                <?php echo htmlspecialchars($entry['categories_data_subjects']); ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="d-flex flex-wrap gap-2 mt-2">
                                                                    <?php if (isset($entry['risk_level']) && !empty($entry['risk_level'])): ?>
                                                                        <span class="badge risk-<?php echo strtolower($entry['risk_level']); ?>">
                                                                            <?php echo strtoupper($entry['risk_level']); ?>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                    <?php if (isset($entry['department']) && !empty($entry['department'])): ?>
                                                                        <span class="badge bg-secondary">
                                                                            <?php echo htmlspecialchars($entry['department']); ?>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                    <?php if (isset($entry['status']) && !empty($entry['status'])): ?>
                                                                        <span class="badge bg-light text-dark">
                                                                            <?php echo ucfirst($entry['status']); ?>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            <?php elseif ($is_dpia): ?>
                                                                <div class="fw-bold dpia-title">
                                                                    <?php echo htmlspecialchars($entry['title'] ?? 'DPIA Assessment'); ?>
                                                                </div>
                                                                <div class="mt-2">
                                                                    <!-- DPIA Specific Fields -->
                                                                    <?php if (isset($entry['description']) && !empty($entry['description'])): ?>
                                                                        <div class="field-detail">
                                                                            <div class="field-label">
                                                                                Description:
                                                                            </div>
                                                                            <div class="field-content">
                                                                                <?php echo htmlspecialchars($entry['description']); ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    
                                                                    <?php if (isset($entry['necessity_proportionality']) && !empty($entry['necessity_proportionality'])): ?>
                                                                        <div class="field-detail">
                                                                            <div class="field-label">
                                                                                Necessity & Proportionality:
                                                                            </div>
                                                                            <div class="field-content">
                                                                                <?php echo htmlspecialchars($entry['necessity_proportionality']); ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    
                                                                    <?php if (isset($entry['mitigation_measures']) && !empty($entry['mitigation_measures'])): ?>
                                                                        <div class="field-detail">
                                                                            <div class="field-label">
                                                                                Mitigation Measures:
                                                                            </div>
                                                                            <div class="field-content">
                                                                                <?php echo htmlspecialchars($entry['mitigation_measures']); ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="d-flex flex-wrap gap-2 mt-2">
                                                                    <?php if (isset($entry['overall_risk_level']) && !empty($entry['overall_risk_level'])): ?>
                                                                        <span class="badge risk-<?php echo strtolower($entry['overall_risk_level']); ?>">
                                                                            <?php echo strtoupper($entry['overall_risk_level']); ?>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                    <?php if (isset($entry['status']) && !empty($entry['status'])): ?>
                                                                        <span class="badge bg-light text-dark">
                                                                            <?php echo ucfirst($entry['status']); ?>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="fw-bold unknown-title">
                                                                    Data Entry #<?php echo htmlspecialchars($entry['id']); ?>
                                                                </div>
                                                                <div class="text-muted small mt-1">
                                                                    <?php echo htmlspecialchars(substr($entry['raw_line'] ?? '', 0, 100)); ?>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="file-info">
                                                            <span class="badge bg-secondary">
                                                                <?php echo htmlspecialchars($entry['file']); ?>
                                                            </span>
                                                            <div class="small text-muted mt-1">
                                                                <?php echo $entry['field_count'] ?? '0'; ?> fields
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <button type="button" 
                                                                    class="btn btn-info"
                                                                    onclick="showFullData('<?php echo $entry['id']; ?>', '<?php echo $entry['file']; ?>')"
                                                                    title="View full SQL data">
                                                                SQL
                                                            </button>
                                                            <button type="button" 
                                                                    class="btn btn-outline-info"
                                                                    onclick="showEntryDetails(<?php echo htmlspecialchars(json_encode($entry)); ?>)"
                                                                    title="View detailed fields">
                                                                Details
                                                            </button>
                                                            <button type="button" 
                                                                    class="btn btn-outline-success"
                                                                    onclick="showSaveTemplateModal('entry', <?php echo htmlspecialchars(json_encode($entry)); ?>)"
                                                                    title="Save entry as template">
                                                                Save
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center py-5">
                                        <h5>No entries found</h5>
                                        <p class="text-muted">
                                            <?php if (!empty($search_query)): ?>
                                                No entries match your filter "<strong><?php echo htmlspecialchars($search_query); ?></strong>"
                                                <br>
                                                <button class="btn btn-outline-primary mt-2" onclick="clearFilter()">
                                                    Clear Filter to show all entries
                                                </button>
                                            <?php else: ?>
                                                The selected files contain no data entries
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php elseif (empty($selected_files)): ?>
                        <div class="card">
                            <div class="card-body text-center py-5">
                                <h4>Select files to begin</h4>
                                <p class="text-muted">Choose one or more text files from the dropdown above</p>
                                <p class="small text-muted mt-2">
                                    <i>All entries will be automatically displayed after file selection</i>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Full Data Modal -->
    <div id="fullDataModal" class="modal" style="display: none;">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        Complete INSERT Data
                    </h5>
                    <button type="button" class="btn-close" onclick="closeModal()">×</button>
                </div>
                <div class="modal-body">
                    <div class="position-relative">
                        <button class="btn btn-sm btn-outline-secondary copy-btn" onclick="copyFullData()">
                            Copy All
                        </button>
                        <div id="fullDataContent">
                            <div class="text-center">
                                <div class="spinner-border" role="status"></div>
                                <p class="mt-2">Loading complete data...</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Save Template Modal -->
    <div id="saveTemplateModal" class="modal" style="display: none;">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Save to Template</h5>
                    <button type="button" class="btn-close" onclick="closeTemplateModal()">×</button>
                </div>
                <form method="post" action="" id="templateForm">
                    <input type="hidden" name="action" value="save_to_template">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label for="templateName" class="form-label">Template Name</label>
                                    <input type="text" class="form-control" id="templateName" 
                                           name="template_name" 
                                           value="template_<?php echo date('Ymd_His'); ?>.txt"
                                           required>
                                    <div class="form-text">Use .txt extension for the filename</div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="templateFormat" class="form-label">Format</label>
                                    <select class="form-select" id="templateFormat" onchange="updateTemplateContent()">
                                        <option value="human">Human Readable</option>
                                        <option value="sql">SQL Statements</option>
                                        <option value="csv">CSV Format</option>
                                        <option value="detailed">Detailed Fields</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="templateContent" class="form-label">Template Content</label>
                            <textarea class="form-control" id="templateContent" 
                                      name="template_content" rows="15" required></textarea>
                            <div class="form-text mt-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="templateType" 
                                           id="templateCurrentEntry" value="entry" 
                                           onclick="updateTemplateContent()">
                                    <label class="form-check-label" for="templateCurrentEntry">
                                        Current Entry Only
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="templateType" 
                                           id="templateSelectedEntries" value="selected"
                                           onclick="updateTemplateContent()">
                                    <label class="form-check-label" for="templateSelectedEntries">
                                        Selected Entries (<?php echo count($selected_entries); ?> entries)
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="templateType" 
                                           id="templateAllResults" value="all"
                                           onclick="updateTemplateContent()">
                                    <label class="form-check-label" for="templateAllResults">
                                        All Results (<?php echo isset($results) ? count($results) : 0; ?> entries)
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="templateType" 
                                           id="templateCustom" value="custom"
                                           onclick="updateTemplateContent()">
                                    <label class="form-check-label" for="templateCustom">
                                        Custom Content
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="closeTemplateModal()">Cancel</button>
                        <button type="submit" class="btn btn-success">Save Template</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Templates List Modal -->
    <div id="templatesModal" class="modal" style="display: none;">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Saved Templates (<?php echo count($existing_templates); ?>)</h5>
                    <button type="button" class="btn-close" onclick="closeTemplatesModal()">×</button>
                </div>
                <div class="modal-body">
                    <?php if (!empty($existing_templates)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Template Name</th>
                                        <th>Size</th>
                                        <th>Modified</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($existing_templates as $template): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($template['filename']); ?></strong>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary">
                                                    <?php echo formatBytes($template['size']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="small text-muted">
                                                    <?php echo $template['modified']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <button type="button" class="btn btn-outline-info" 
                                                            onclick="viewTemplate('<?php echo htmlspecialchars($template['filename']); ?>')">
                                                        View
                                                    </button>
                                                    <button type="button" class="btn btn-outline-success" 
                                                            onclick="downloadTemplate('<?php echo htmlspecialchars($template['filename']); ?>')">
                                                        Download
                                                    </button>
                                                    <button type="button" class="btn btn-outline-danger" 
                                                            onclick="deleteTemplate('<?php echo htmlspecialchars($template['filename']); ?>')">
                                                        Delete
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <h5>No templates saved yet</h5>
                            <p class="text-muted">Save your first template using the "Save as Template" button</p>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeTemplatesModal()">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // File Selection Functions
        function selectAllFiles() {
            const select = document.querySelector('select[name="selected_files[]"]');
            Array.from(select.options).forEach(option => {
                option.selected = true;
            });
        }

        function deselectAllFiles() {
            const select = document.querySelector('select[name="selected_files[]"]');
            Array.from(select.options).forEach(option => {
                option.selected = false;
            });
        }

        function clearAllFiles() {
            if (confirm('Remove all selected files?')) {
                window.location.href = '?action=clear_all_files';
            }
        }

        function clearFilter() {
            document.getElementById('searchInput').value = '';
            document.getElementById('filterForm').submit();
        }

        function showSelectedFilesContent() {
            const selectedFiles = <?php echo json_encode($selected_files); ?>;
            if (selectedFiles.length > 0) {
                showFileContent(selectedFiles[0]);
            }
        }

        function showAllEntries() {
            // Refresh page to show all entries again
            window.location.href = '?action=show_all';
        }

        // Auto-submit filter when typing (debounced)
        let searchTimeout;
        document.getElementById('searchInput')?.addEventListener('input', function(e) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                document.getElementById('filterForm').submit();
            }, 500);
        });

        // Modal Functions
        function showModal() {
            document.getElementById('fullDataModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('fullDataModal').style.display = 'none';
        }

        // Entry Selection Functions
        function toggleEntrySelection(entryKey, isChecked) {
            // Use AJAX to toggle selection without page reload
            fetch(`?action=toggle_entry&entry_id=${encodeURIComponent(entryKey.split('|')[0])}&filename=${encodeURIComponent(entryKey.split('|')[1])}`)
                .then(response => {
                    // Update UI immediately
                    const entryRow = document.querySelector(`input[value="${entryKey}"]`).closest('tr');
                    if (isChecked) {
                        entryRow.classList.add('selected');
                    } else {
                        entryRow.classList.remove('selected');
                    }
                    
                    // Update selected count badge if exists
                    updateSelectedCount();
                })
                .catch(error => {
                    console.error('Error toggling selection:', error);
                    // Fallback to page reload
                    window.location.reload();
                });
        }

        function toggleAllEntries(isChecked) {
            const checkboxes = document.querySelectorAll('.entry-checkbox');
            checkboxes.forEach(checkbox => {
                if (checkbox.checked !== isChecked) {
                    checkbox.checked = isChecked;
                    toggleEntrySelection(checkbox.value, isChecked);
                }
            });
        }

        function updateSelectedCount() {
            const selectedCount = document.querySelectorAll('.entry-checkbox:checked').length;
            const selectedBadges = document.querySelectorAll('.selection-badge, .badge.bg-success:contains("selected")');
            
            selectedBadges.forEach(badge => {
                if (badge.textContent.includes('selected')) {
                    badge.textContent = selectedCount + ' selected';
                }
            });
            
            // Update any buttons that show selected count
            const selectedButtons = document.querySelectorAll('button:contains("Save Selected")');
            selectedButtons.forEach(button => {
                if (button.textContent.includes('Selected')) {
                    button.textContent = button.textContent.replace(/\(\d+\)/, `(${selectedCount})`);
                }
            });
        }

        // Template Modals
        let currentEntryForTemplate = null;
        let currentTemplateType = 'entry';

        function showSaveTemplateModal(type, entry = null) {
            if (type === 'entry' && entry) {
                currentEntryForTemplate = entry;
                currentTemplateType = 'entry';
                document.getElementById('templateCurrentEntry').checked = true;
            } else if (type === 'selected') {
                currentTemplateType = 'selected';
                document.getElementById('templateSelectedEntries').checked = true;
            } else if (type === 'results') {
                currentTemplateType = 'all';
                document.getElementById('templateAllResults').checked = true;
            }
            
            // Update template content based on selection
            updateTemplateContent();
            
            // Show modal
            document.getElementById('saveTemplateModal').style.display = 'block';
        }

        function closeTemplateModal() {
            document.getElementById('saveTemplateModal').style.display = 'none';
            currentEntryForTemplate = null;
            currentTemplateType = 'entry';
        }

        function showTemplatesModal() {
            document.getElementById('templatesModal').style.display = 'block';
        }

        function closeTemplatesModal() {
            document.getElementById('templatesModal').style.display = 'none';
        }

        function updateTemplateContent() {
            const format = document.getElementById('templateFormat').value;
            const templateType = document.querySelector('input[name="templateType"]:checked').value;
            
            let content = '';
            
            if (templateType === 'entry' && currentEntryForTemplate) {
                // Generate template for current entry
                if (format === 'sql') {
                    content = generateSQLTemplate([currentEntryForTemplate]);
                } else if (format === 'csv') {
                    content = generateCSVTemplate([currentEntryForTemplate]);
                } else if (format === 'detailed') {
                    content = generateDetailedTemplate([currentEntryForTemplate]);
                } else {
                    content = generateEntryTemplate(currentEntryForTemplate);
                }
            } else if (templateType === 'selected') {
                // Generate template for selected entries
                const selectedEntries = getSelectedEntries();
                if (selectedEntries.length > 0) {
                    if (format === 'sql') {
                        content = generateSQLTemplate(selectedEntries);
                    } else if (format === 'csv') {
                        content = generateCSVTemplate(selectedEntries);
                    } else if (format === 'detailed') {
                        content = generateDetailedTemplate(selectedEntries);
                    } else {
                        content = generateMultipleEntriesTemplate(selectedEntries);
                    }
                } else {
                    content = "// No entries selected\n// Please select entries first";
                }
            } else if (templateType === 'all') {
                // Generate template for all results
                const results = <?php echo json_encode($results ?? []); ?>;
                const searchQuery = <?php echo json_encode($search_query); ?>;
                const selectedFiles = <?php echo json_encode($selected_files); ?>;
                
                if (results.length > 0) {
                    if (format === 'sql') {
                        content = generateSQLTemplate(results);
                    } else if (format === 'csv') {
                        content = generateCSVTemplate(results);
                    } else if (format === 'detailed') {
                        content = generateDetailedTemplate(results);
                    } else {
                        content = generateResultsTemplate(results, searchQuery, selectedFiles);
                    }
                } else {
                    content = "// No results available\n// Please select files first";
                }
            }
            
            document.getElementById('templateContent').value = content;
        }

        function getSelectedEntries() {
            const selectedEntries = [];
            const checkboxes = document.querySelectorAll('.entry-checkbox:checked');
            
            checkboxes.forEach(checkbox => {
                const entryKey = checkbox.value;
                // Find the entry data from the results
                const results = <?php echo json_encode($results ?? []); ?>;
                const [entryId, filename] = entryKey.split('|');
                
                const entry = results.find(e => e.id === entryId && e.file === filename);
                if (entry) {
                    selectedEntries.push(entry);
                }
            });
            
            return selectedEntries;
        }

        function generateEntryTemplate(entry) {
            let template = `// Template generated from ${entry.type} entry\n`;
            template += `// Entry ID: ${entry.id}\n`;
            template += `// Source File: ${entry.file}\n`;
            template += `// Generated: ${new Date().toISOString().replace('T', ' ').substr(0, 19)}\n`;
            template += '='.repeat(80) + '\n\n';
            
            const columnNames = entry.column_names || [];
            
            entry.all_fields.forEach((value, index) => {
                const colName = columnNames[index] || `field_${index}`;
                template += `${colName.padEnd(40)}: ${value || 'NULL'}\n`;
            });
            
            template += '\n' + '='.repeat(80) + '\n';
            template += '// SQL INSERT Statement:\n';
            template += entry.raw_line + ';\n';
            
            return template;
        }

        function generateMultipleEntriesTemplate(entries) {
            let template = `// Template generated from ${entries.length} selected entries\n`;
            template += `// Generated: ${new Date().toISOString().replace('T', ' ').substr(0, 19)}\n`;
            template += `// Files: ${[...new Set(entries.map(e => e.file))].join(', ')}\n`;
            template += '='.repeat(80) + '\n\n';
            
            entries.forEach((entry, index) => {
                template += `ENTRY ${index + 1} of ${entries.length}\n`;
                template += '-'.repeat(40) + '\n';
                template += `ID      : ${entry.id}\n`;
                template += `Type    : ${entry.type.toUpperCase()}\n`;
                template += `File    : ${entry.file}\n\n`;
                
                if (entry.type === 'gdpr') {
                    template += `Processing Activity: ${entry.processing_activity || ''}\n`;
                    template += `Purpose            : ${entry.purpose_of_processing || ''}\n`;
                    template += `Risk Level         : ${entry.risk_level || ''}\n`;
                    template += `Status             : ${entry.status || ''}\n`;
                } else if (entry.type === 'dpia') {
                    template += `Title              : ${entry.title || ''}\n`;
                    template += `Description        : ${entry.description || ''}\n`;
                    template += `Risk Level         : ${entry.overall_risk_level || ''}\n`;
                    template += `Status             : ${entry.status || ''}\n`;
                }
                
                template += '\n';
            });
            
            return template;
        }

        function generateResultsTemplate(results, searchQuery, selectedFiles) {
            let template = `// Search Results Template\n`;
            template += `// Generated: ${new Date().toISOString().replace('T', ' ').substr(0, 19)}\n`;
            template += `// Files: ${selectedFiles.join(', ')}\n`;
            if (searchQuery) {
                template += `// Search Query: ${searchQuery}\n`;
            }
            template += `// Total Entries: ${results.length}\n`;
            template += '='.repeat(80) + '\n\n';
            
            results.forEach((entry, index) => {
                template += `ENTRY ${index + 1} of ${results.length}\n`;
                template += '-'.repeat(40) + '\n';
                template += `ID      : ${entry.id}\n`;
                template += `Type    : ${entry.type.toUpperCase()}\n`;
                template += `File    : ${entry.file}\n\n`;
                
                if (entry.type === 'gdpr') {
                    template += `Processing Activity: ${entry.processing_activity || ''}\n`;
                    template += `Purpose            : ${entry.purpose_of_processing || ''}\n`;
                    template += `Risk Level         : ${entry.risk_level || ''}\n`;
                    template += `Status             : ${entry.status || ''}\n`;
                } else if (entry.type === 'dpia') {
                    template += `Title              : ${entry.title || ''}\n`;
                    template += `Description        : ${entry.description || ''}\n`;
                    template += `Risk Level         : ${entry.overall_risk_level || ''}\n`;
                    template += `Status             : ${entry.status || ''}\n`;
                }
                
                template += '\n';
            });
            
            return template;
        }

        function generateSQLTemplate(entries) {
            let template = `// SQL Template generated from ${entries.length} entries\n`;
            template += `// Generated: ${new Date().toISOString().replace('T', ' ').substr(0, 19)}\n`;
            template += '='.repeat(80) + '\n\n';
            
            entries.forEach(entry => {
                template += `-- Entry ID: ${entry.id} (${entry.type.toUpperCase()})\n`;
                template += `-- Source: ${entry.file}\n`;
                template += entry.raw_line + ';\n\n';
            });
            
            return template;
        }

        function generateCSVTemplate(entries) {
            let template = 'ID,Type,File,Processing_Activity/Title,Purpose/Description,Risk_Level,Status\n';
            
            entries.forEach(entry => {
                const id = entry.id;
                const type = entry.type.toUpperCase();
                const file = entry.file;
                
                let title, desc, risk;
                if (entry.type === 'gdpr') {
                    title = (entry.processing_activity || '').replace(/"/g, '""');
                    desc = (entry.purpose_of_processing || '').replace(/"/g, '""');
                    risk = entry.risk_level || '';
                } else if (entry.type === 'dpia') {
                    title = (entry.title || '').replace(/"/g, '""');
                    desc = (entry.description || '').replace(/"/g, '""');
                    risk = entry.overall_risk_level || '';
                } else {
                    title = 'Unknown';
                    desc = 'Unknown';
                    risk = 'Unknown';
                }
                
                const status = entry.status || '';
                
                template += `"${id}","${type}","${file}","${title}","${desc}","${risk}","${status}"\n`;
            });
            
            return template;
        }

        function generateDetailedTemplate(entries) {
            let template = `// Detailed Template for ${entries.length} entries\n`;
            template += `// Generated: ${new Date().toISOString().replace('T', ' ').substr(0, 19)}\n`;
            template += '='.repeat(80) + '\n\n';
            
            entries.forEach((entry, entryIndex) => {
                template += `ENTRY ${entryIndex + 1} of ${entries.length}\n`;
                template += '='.repeat(60) + '\n';
                template += `ID          : ${entry.id}\n`;
                template += `Type        : ${entry.type.toUpperCase()}\n`;
                template += `File        : ${entry.file}\n`;
                template += `Field Count : ${entry.field_count}\n`;
                template += '-'.repeat(60) + '\n\n';
                
                const columnNames = entry.column_names || [];
                
                template += "INDEX | COLUMN NAME                         | VALUE\n";
                template += "------|-------------------------------------|" + '-'.repeat(40) + '\n';
                
                entry.all_fields.forEach((value, index) => {
                    const colName = columnNames[index] || `field_${index}`;
                    const indexStr = index.toString().padStart(4, ' ');
                    const colNameStr = colName.padEnd(35, ' ');
                    template += `${indexStr}  | ${colNameStr} | ${value || 'NULL'}\n`;
                });
                
                template += "\n" + '-'.repeat(60) + '\n\n';
            });
            
            return template;
        }

        // Template Management Functions
        function viewTemplate(filename) {
            showModal();
            
            fetch(`?action=show_template&file=${encodeURIComponent(filename)}`)
                .then(response => response.json())
                .then(data => {
                    let html = `
                        <div class="mb-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h6 class="mb-0">Template Information</h6>
                                        </div>
                                        <div class="card-body">
                                            <table class="table table-sm">
                                                <tr>
                                                    <th width="150">File Name:</th>
                                                    <td><code>${data.filename}</code></td>
                                                </tr>
                                                <tr>
                                                    <th>File Size:</th>
                                                    <td>${formatBytes(data.size)}</td>
                                                </tr>
                                                <tr>
                                                    <th>Lines:</th>
                                                    <td><span class="badge bg-secondary">${data.lines}</span></td>
                                                </tr>
                                                <tr>
                                                    <th>Modified:</th>
                                                    <td>${data.modified || data.timestamp}</td>
                                                </tr>
                                                <tr>
                                                    <th>Retrieved:</th>
                                                    <td>${data.timestamp}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <h5>Template Content</h5>
                                <div class="sql-code">${escapeHtml(data.content)}</div>
                            </div>
                        </div>
                    `;
                    
                    document.getElementById('fullDataContent').innerHTML = html;
                })
                .catch(error => {
                    document.getElementById('fullDataContent').innerHTML = `
                        <div class="alert alert-danger">
                            Error loading template: ${error.message}
                        </div>
                    `;
                });
        }

        function downloadTemplate(filename) {
            window.location.href = `?action=download_template&file=${encodeURIComponent(filename)}`;
        }

        function deleteTemplate(filename) {
            if (confirm(`Are you sure you want to delete template "${filename}"?`)) {
                window.location.href = `?action=delete_template&file=${encodeURIComponent(filename)}`;
            }
        }

        // Show full data for an entry
        function showFullData(entryId, filename) {
            showModal();
            
            fetch(`?action=show_full_data&entry_id=${entryId}&filename=${encodeURIComponent(filename)}`)
                .then(response => response.json())
                .then(data => {
                    let html = `
                        <div class="mb-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h6 class="mb-0">Entry Information</h6>
                                        </div>
                                        <div class="card-body">
                                            <table class="table table-sm">
                                                <tr>
                                                    <th width="150">Entry ID:</th>
                                                    <td><strong>${data.entry_id}</strong></td>
                                                </tr>
                                                <tr>
                                                    <th>Source File:</th>
                                                    <td><code>${data.filename}</code></td>
                                                </tr>
                                                <tr>
                                                    <th>Total Statements:</th>
                                                    <td><span class="badge bg-secondary">${data.total_statements}</span></td>
                                                </tr>
                                                <tr>
                                                    <th>Statements with this ID:</th>
                                                    <td><span class="badge bg-secondary">${data.statements_with_id.length}</span></td>
                                                </tr>
                                                <tr>
                                                    <th>Retrieved:</th>
                                                    <td>${data.timestamp}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <h5>All INSERT Statements in File</h5>
                                <p class="text-muted">Showing ${data.total_statements} statements from the file. Statements containing ID <strong>${data.entry_id}</strong> are highlighted.</p>
                                
                                <div class="accordion" id="statementsAccordion">
                    `;
                    
                    // Display all statements
                    data.statements.forEach((stmt, index) => {
                        const hasId = stmt.contains_our_id;
                        const statementId = `stmt-${index}`;
                        const escapedStatement = escapeHtml(stmt.statement);
                        const highlightedStatement = hasId ? 
                            escapedStatement.replace(new RegExp(`'${data.entry_id}'`, 'g'), `<span class="highlight-id">'${data.entry_id}'</span>`) :
                            escapedStatement;
                        
                        html += `
                            <div class="card statement-card ${hasId ? 'border-success' : ''}">
                                <div class="statement-header" id="heading-${statementId}">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0">
                                            <button class="btn btn-link btn-sm text-decoration-none" type="button" onclick="toggleCollapse('${statementId}')">
                                                Statement ${index + 1}
                                            </button>
                                            ${hasId ? '<span class="badge bg-secondary ms-2">Contains ID</span>' : ''}
                                        </h6>
                                        <small class="text-muted">${stmt.statement.length} characters</small>
                                    </div>
                                </div>
                                <div id="collapse-${statementId}" class="collapse">
                                    <div class="statement-body">
                                        <div class="sql-code">${highlightedStatement}</div>
                                        <div class="mt-2 text-end">
                                            <button class="btn btn-sm btn-outline-secondary" onclick="copyStatement(${index})">
                                                Copy
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                    
                    html += `
                                </div>
                            </div>
                        </div>
                    `;
                    
                    document.getElementById('fullDataContent').innerHTML = html;
                    
                    // Auto-expand statements that contain our ID
                    data.statements.forEach((stmt, index) => {
                        if (stmt.contains_our_id) {
                            toggleCollapse(`stmt-${index}`);
                        }
                    });
                })
                .catch(error => {
                    document.getElementById('fullDataContent').innerHTML = `
                        <div class="alert alert-danger">
                            Error loading data: ${error.message}
                        </div>
                    `;
                });
        }

        function showFileContent(filename) {
            showModal();
            
            fetch(`?action=show_file_content&filename=${encodeURIComponent(filename)}`)
                .then(response => response.json())
                .then(data => {
                    let html = `
                        <div class="mb-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h6 class="mb-0">File Information</h6>
                                        </div>
                                        <div class="card-body">
                                            <table class="table table-sm">
                                                <tr>
                                                    <th width="150">File Name:</th>
                                                    <td><code>${data.filename}</code></td>
                                                </tr>
                                                <tr>
                                                    <th>File Size:</th>
                                                    <td>${formatBytes(data.size)}</td>
                                                </tr>
                                                <tr>
                                                    <th>Lines:</th>
                                                    <td><span class="badge bg-secondary">${data.lines}</span></td>
                                                </tr>
                                                <tr>
                                                    <th>Retrieved:</th>
                                                    <td>${data.timestamp}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <h5>Complete File Content</h5>
                                <div class="sql-code">${escapeHtml(data.content)}</div>
                            </div>
                        </div>
                    `;
                    
                    document.getElementById('fullDataContent').innerHTML = html;
                })
                .catch(error => {
                    document.getElementById('fullDataContent').innerHTML = `
                        <div class="alert alert-danger">
                            Error loading file: ${error.message}
                        </div>
                    `;
                });
        }

        function toggleCollapse(id) {
            const element = document.getElementById(`collapse-${id}`);
            if (element.style.display === 'none' || element.style.display === '') {
                element.style.display = 'block';
            } else {
                element.style.display = 'none';
            }
        }

        function copyFullData() {
            const sqlCodeElements = document.querySelectorAll('.sql-code');
            let allText = '';
            
            sqlCodeElements.forEach((element, index) => {
                allText += `-- Statement ${index + 1}\n`;
                allText += element.textContent + '\n\n';
            });
            
            navigator.clipboard.writeText(allText)
                .then(() => {
                    showCopyFeedback('.copy-btn');
                })
                .catch(err => {
                    alert('Failed to copy: ' + err);
                });
        }

        function copyStatement(index) {
            const statementElement = document.querySelector(`#collapse-stmt-${index} .sql-code`);
            if (statementElement) {
                const text = statementElement.textContent;
                navigator.clipboard.writeText(text)
                    .then(() => {
                        const btn = document.querySelector(`#collapse-stmt-${index} .btn-outline-secondary`);
                        showCopyFeedbackOnElement(btn);
                    })
                    .catch(err => {
                        alert('Failed to copy: ' + err);
                    });
            }
        }

        function showCopyFeedback(selector) {
            const btn = document.querySelector(selector);
            const originalHtml = btn.innerHTML;
            btn.innerHTML = 'Copied!';
            btn.classList.add('btn-success');
            
            setTimeout(() => {
                btn.innerHTML = originalHtml;
                btn.classList.remove('btn-success');
            }, 2000);
        }

        function showCopyFeedbackOnElement(element) {
            const originalHtml = element.innerHTML;
            element.innerHTML = 'Copied!';
            element.classList.add('btn-success');
            
            setTimeout(() => {
                element.innerHTML = originalHtml;
                element.classList.remove('btn-success');
            }, 2000);
        }

        function showEntryDetails(entry) {
            let html = `
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">Entry Information</h6>
                            </div>
                            <div class="card-body">
                                <table class="table table-sm">
                                    <tr>
                                        <th width="150">ID:</th>
                                        <td><strong>${entry.id}</strong></td>
                                    </tr>
                                    <tr>
                                        <th>Type:</th>
                                        <td><span class="badge badge-${entry.type} badge-type">${entry.type.toUpperCase()}</span></td>
                                    </tr>
                                    <tr>
                                        <th>Source File:</th>
                                        <td><span class="badge bg-secondary">${entry.file}</span></td>
                                    </tr>
                                    <tr>
                                        <th>Field Count:</th>
                                        <td><span class="badge bg-secondary">${entry.field_count || '0'}</span></td>
                                    </tr>
                                    <tr>
                                        <th>Raw Line:</th>
                                        <td><div class="sql-code small">${escapeHtml(entry.raw_line || 'N/A')}</div></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <h5>All Fields with Column Names (${entry.field_count || '0'})</h5>
                    <div class="table-responsive">
                        <table class="table table-sm field-table">
                            <thead>
                                <tr>
                                    <th width="60">#</th>
                                    <th>Column Name</th>
                                    <th>Value</th>
                                </tr>
                            </thead>
                            <tbody>
            `;
            
            // Display all fields with column names
            const columnNames = entry.column_names || [];
            entry.all_fields.forEach((value, index) => {
                const columnName = columnNames[index] || `Field ${index}`;
                html += `
                    <tr>
                        <td class="text-center"><strong>${index}</strong></td>
                        <td class="field-name">${escapeHtml(columnName)}</td>
                        <td class="field-value">${escapeHtml(value || 'NULL')}</td>
                    </tr>
                `;
            });
            
            html += `
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="mt-3 text-end">
                    <button class="btn btn-outline-success me-2" onclick="showSaveTemplateModal('entry', ${JSON.stringify(entry)})">
                        Save as Template
                    </button>
                    <button class="btn btn-info" onclick="showFullData('${entry.id}', '${entry.file}')">
                        View Full INSERT Data
                    </button>
                </div>
            `;
            
            // Create a temporary modal for entry details
            const modalDiv = document.createElement('div');
            modalDiv.className = 'modal';
            modalDiv.id = 'entryDetailsModal';
            modalDiv.style.display = 'block';
            modalDiv.innerHTML = `
                <div class="modal-dialog" style="max-width: 95%;">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                Entry Field Details with Column Names
                            </h5>
                            <button type="button" class="btn-close" onclick="this.closest('.modal').style.display='none'">×</button>
                        </div>
                        <div class="modal-body">
                            ${html}
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modalDiv);
            
            // Close modal when clicking outside
            modalDiv.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.style.display = 'none';
                }
            });
        }

        function formatBytes(bytes, decimals = 2) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const dm = decimals < 0 ? 0 : decimals;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        }

        function escapeHtml(text) {
            if (text === null || text === undefined) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // Close modal when clicking outside
        document.getElementById('fullDataModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
        
        document.getElementById('saveTemplateModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeTemplateModal();
            }
        });
        
        document.getElementById('templatesModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeTemplatesModal();
            }
        });
        
        // Initialize selected count on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateSelectedCount();
        });
    </script>
</body>
</html>

<?php
// Helper function to format bytes
function formatBytes($bytes, $decimals = 2) {
    $size = ['B', 'KB', 'MB', 'GB', 'TB'];
    $factor = floor((strlen($bytes) - 1) / 3);
    return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . @$size[$factor];
}
?>